from fastapi.testclient import TestClient

from backend.main import app


client = TestClient(app)


def test_node_library_and_navigation_layout() -> None:
    response = client.get("/")
    assert response.status_code == 200

    html = response.text
    assert 'id="nodeLibraryToggle"' in html
    assert 'aria-controls="nodeLibrary"' in html
    assert 'id="nodeLibrary"' in html
    assert 'id="exportScriptButton"' in html
    assert "导出脚本" in html

    node_library = html.split('<aside id="nodeLibrary"', 1)[1].split("</aside>", 1)[0]
    assert 'id="operatorPanel"' in node_library
    assert 'id="imageInput"' not in node_library
    assert "upload-box" not in node_library
    assert "category-tabs" not in node_library

    assert 'id="imageInput"' not in html
    assert 'id="imageLightbox"' in html
    assert 'id="lightboxDownload"' in html
    assert 'id="lightboxRestore"' in html


def test_frontend_assets_include_interactive_node_preview() -> None:
    js = client.get("/assets/js/app.js")
    css = client.get("/assets/css/styles.css")

    assert js.status_code == 200
    assert css.status_code == 200
    assert "function toggleNodeLibrary()" in js.text
    assert "function downloadNodePreview(" in js.text
    assert "function openImageLightbox(" in js.text
    assert "function closeImageLightbox(" in js.text
    assert "data-preview-action=\"download\"" in js.text
    assert "data-preview-action=\"zoom\"" in js.text
    assert ".node-effect-frame img" in css.text
    assert "object-fit:contain" in css.text.replace(" ", "")
    assert ".image-lightbox.open" in css.text


def test_multiple_workflow_tabs_and_save_shortcut_are_wired() -> None:
    html = client.get("/").text
    js = client.get("/assets/js/app.js").text
    css = client.get("/assets/css/styles.css").text

    assert 'id="workflowTabs"' in html
    assert 'id="newWorkflowButton"' in html
    assert "Ctrl+S" in js
    assert "function newWorkflow()" in js
    assert "function switchWorkflow(" in js
    assert "function closeWorkflow(" in js
    assert "function renderWorkflowTabs()" in js
    assert 'event.key.toLowerCase() === "s"' in js
    assert "WORKSPACE_STORAGE_KEY" in js
    assert ".workflow-tab.active" in css
    assert ".save-state-dot.saved" in css
    assert ".save-state-dot.dirty" in css


def test_thumbnail_uses_intrinsic_size_and_batch_summary_ui_exists() -> None:
    js = client.get("/assets/js/app.js").text
    css = client.get("/assets/css/styles.css").text.replace(" ", "")
    assert ".node-effect-frameimg{display:block;width:auto;height:auto;max-width:100%;max-height:100%;object-fit:contain" in css
    assert "function renderBatchSummary(" in js
    assert "批量处理汇总" in js


def test_topbar_keeps_json_actions_but_removes_redundant_save_and_load_buttons() -> None:
    html = client.get("/").text
    top_actions = html.split('<div class="top-actions">', 1)[1].split('</div>', 1)[0]

    assert 'onclick="saveWorkflowLocal()"' not in top_actions
    assert 'onclick="loadWorkflowLocal()"' not in top_actions
    assert "💾 保存" not in top_actions
    assert "📂 加载" not in top_actions
    assert "导出 JSON" in top_actions
    assert "导入 JSON" in top_actions


def test_node_toolbar_is_available_on_selection_and_uses_trash_icon() -> None:
    js = client.get("/assets/js/app.js").text
    css = client.get("/assets/css/styles.css").text.replace(" ", "")

    assert "${renderNodeToolbarHtml(node)}" in js
    assert 'data-node-action="delete"' in js
    assert "🗑" in js
    assert ".node.selected>.node-toolbar{display:flex}" in css
    assert "function selectNodeWithoutRerender(" in js


def test_metric_results_have_dedicated_frontend_rendering() -> None:
    js = client.get("/assets/js/app.js").text
    css = client.get("/assets/css/styles.css").text

    assert "function renderMetricResultHtml(" in js
    assert 'result_type === "metrics"' in js
    assert "数值结果" in js
    assert ".node-metric-frame" in css
    assert ".metric-row" in css
    assert ".node-combined-result" in css
    assert "图像与数值结果" in js
    assert ".metric-preview-card" in css


def test_operator_library_buttons_control_categories_not_canvas_nodes() -> None:
    html = client.get("/").text
    js = client.get("/assets/js/app.js").text

    assert 'onclick="collapseAllOperatorGroups()"' in html
    assert 'onclick="expandAllOperatorGroups()"' in html
    assert "function collapseAllOperatorGroups()" in js
    assert "function expandAllOperatorGroups()" in js
    assert "collapsedOperatorGroups" in js


def test_minimap_uses_dynamic_mapping_and_click_navigation() -> None:
    html = client.get("/").text
    js = client.get("/assets/js/app.js").text
    css = client.get("/assets/css/styles.css").text

    assert "导航视图 · 点击定位" in html
    assert "function computeMinimapTransform()" in js
    assert "function navigateFromMinimap(" in js
    assert 'addEventListener("click", navigateFromMinimap)' in js
    assert "minimapWorldToScreen" in js
    assert "cursor:crosshair" in css


def test_logic_library_and_multi_port_nodes_are_wired() -> None:
    html = client.get("/").text
    js = client.get("/assets/js/app.js").text
    css = client.get("/assets/css/styles.css").text

    assert 'id="logicLibraryTitle"' in html
    assert "逻辑节点库" in html
    assert 'id="logicOperatorPanel"' in html
    assert 'id="logicSearch"' in html
    assert "function collapseAllLogicOperatorGroups()" in js
    assert "function expandAllLogicOperatorGroups()" in js
    assert "function nodeInputPorts(" in js
    assert "function nodeOutputPorts(" in js
    assert "data-handle=" in js
    assert "connectingSourceHandle" in js
    assert ".library-section.logic-library" in css
    assert ".node-port-row" in css
    assert ".port.boolean" in css


def test_partial_results_and_failed_node_are_rendered_after_execution_error() -> None:
    js = client.get("/assets/js/app.js").text
    api_js = client.get("/assets/js/api.js").text
    css = client.get("/assets/css/styles.css").text

    assert "error.payload = data" in api_js
    assert "function renderExecutionFailureSummary(" in js
    assert 'preview?.result_type === "error"' in js
    assert "工作流执行中断" in js
    assert ".node.execution-error" in css
    assert ".execution-error-summary" in css
    assert ".node-error-frame" in css


def test_double_click_adds_operator_at_current_view_center() -> None:
    operators_js = client.get("/assets/js/app/operators.js").text
    canvas_js = client.get("/assets/js/app/canvas.js").text
    minimap_js = client.get("/assets/js/app/minimap.js").text

    assert "op.ondblclick = () => addNodeAtViewportCenter(type);" in operators_js
    assert "function addNodeAtViewportCenter(type)" in operators_js
    assert "centerOnPoint" in operators_js
    assert "centerRenderedNodeOnWorldPoint(id, options.centerOnPoint)" in operators_js
    assert "stabilizeNodeAtViewportCenter(id)" in operators_js
    assert "function getViewportCenterWorldPoint()" in canvas_js
    assert "rect.left + rect.width / 2" in canvas_js
    assert "rect.top + rect.height / 2" in canvas_js
    assert "function centerRenderedNodeOnWorldPoint(" in canvas_js
    assert "element.getBoundingClientRect()" in canvas_js
    assert "function stabilizeNodeAtViewportCenter(" in canvas_js
    assert "window.requestAnimationFrame" in canvas_js
    assert 'if(typeof getViewportWorldRect === "function") return getViewportWorldRect();' in minimap_js
    assert "function renderedNodeWorldSize(" in minimap_js
    assert "const nodeSize = renderedNodeWorldSize(node);" in minimap_js


def test_yolo_select_masks_use_dynamic_output_ports() -> None:
    canvas_js = client.get("/assets/js/app/canvas.js").text
    app_js = client.get("/assets/js/app.js").text

    assert "function resolveDynamicOutputCount(" in canvas_js
    assert "meta?.dynamic_outputs" in canvas_js
    assert "nodeOutputPorts(meta, node" in canvas_js
    assert "function pruneInvalidEdgesForNode(" in canvas_js
    assert "dynamic_outputs" in app_js


def test_beautify_layout_button_and_routing_are_wired() -> None:
    html = client.get("/").text
    canvas_js = client.get("/assets/js/app/canvas.js").text
    app_js = client.get("/assets/js/app.js").text
    css = client.get("/assets/css/styles.css").text

    assert 'id="beautifyLayoutButton"' in html
    assert 'onclick="beautifyWorkflowLayout()"' in html
    assert "美化排线" in html
    assert "function beautifyWorkflowLayout()" in canvas_js
    assert "function topologicalNodeOrderForLayout()" in canvas_js
    assert "function orderLayersByBarycenter(" in canvas_js
    assert "centerLayoutOnCurrentViewport" in canvas_js
    assert "function calculateEdgeWaypoints(" in canvas_js
    assert "function calculateFastEdgeWaypoints(" in canvas_js
    assert "renderEdges({ fast:true })" in canvas_js
    assert "window.requestAnimationFrame" in canvas_js
    assert "const nodeById = new Map(" in canvas_js
    assert "const routingRects = options.fast ? null" in canvas_js
    assert "polylineCollidesWithRects" in canvas_js
    assert "roundedOrthogonalPath" in canvas_js
    assert "renderEdgeDefinitions" in canvas_js
    assert "overflow:visible" in css
    assert "edge-arrow-shape" in css
    assert "Layout beautify markers" in app_js
    assert ".tool-button" in css


def test_batch_csv_multi_input_selector_is_rendered() -> None:
    canvas_js = client.get("/assets/js/app/canvas.js").text
    css = client.get("/assets/css/styles.css").text

    assert "meta?.dynamic_inputs" in canvas_js
    assert "function renderCsvFieldSelector(" in canvas_js
    assert 'schema.type === "csv_field_selector"' in canvas_js
    assert "csvFieldConnection(" in canvas_js
    assert "CSV 字段设置" in canvas_js
    assert ".csv-field-selector" in css
    assert ".csv-field-column" in css


def test_shared_project_library_button_dialog_and_client_actions_are_wired() -> None:
    html = client.get("/").text
    library_js = client.get("/assets/js/app/project_library.js").text
    api_js = client.get("/assets/js/api.js").text
    css = client.get("/assets/css/styles.css").text

    rail = html.split('<nav class="rail"', 1)[1].split('</nav>', 1)[0]
    assert rail.index('onclick="showModelManager()"') < rail.index('id="projectLibraryButton"')
    assert 'onclick="saveWorkflowLocal()"' not in rail
    assert 'onclick="openProjectFromServer()"' not in rail
    assert '<span>保存项目</span>' not in rail
    assert '<span>打开项目</span>' not in rail
    assert 'onclick="showProjectLibrary()"' in rail
    assert '<span>项目库</span>' in rail
    assert 'id="projectLibraryDialog"' in html
    assert 'id="sharedProjectsTab"' in html
    assert 'id="myProjectsTab" class="project-library-tab active"' in html
    assert 'id="saveCurrentProjectButton"' in html
    assert 'onclick="saveCurrentProjectFromLibrary()"' in html
    assert 'id="projectLibrarySearch"' in html
    assert '/assets/js/app/project_library.js' in html

    assert "VisionApi.listSharedProjects" in library_js
    assert "VisionApi.getSharedProject" in library_js
    assert "VisionApi.shareProject" in library_js
    assert "VisionApi.unshareProject" in library_js
    assert "VisionApi.deleteProject" in library_js
    assert "saveCurrentProjectFromLibrary" in library_js
    assert "deleteOwnProjectFromLibrary" in library_js
    assert "removeDeletedProjectDocuments" in library_js
    assert "删除项目" in library_js
    assert "openSharedProjectCopy" in library_js
    assert "projectId:null" not in library_js  # 共享副本不携带原项目 ID
    assert "saved:false" in library_js
    assert "共享工作流始终以新副本打开" in library_js

    assert "function listSharedProjects(" in api_js
    assert "function getSharedProject(" in api_js
    assert "function shareProject(" in api_js
    assert "function unshareProject(" in api_js
    assert "function deleteProject(" in api_js
    assert ".project-library-dialog.open" in css
    assert ".project-library-save" in css
    assert ".project-library-item" in css
