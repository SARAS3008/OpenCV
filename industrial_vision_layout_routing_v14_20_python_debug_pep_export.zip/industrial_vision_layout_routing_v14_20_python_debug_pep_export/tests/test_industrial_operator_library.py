from __future__ import annotations

import sys
from pathlib import Path
from types import SimpleNamespace

import cv2
import numpy as np

from backend.algorithms.industrial import INDUSTRIAL_OPERATOR_META, INDUSTRIAL_OPERATOR_TYPES, _industrial_execute
from backend.algorithms.registry import OPERATOR_CATALOG, OPERATOR_DEFINITIONS
from backend.models.workflow import WorkflowRequest
from backend.services.script_exporter import generate_algorithm_script


def _images() -> dict[str, np.ndarray]:
    image = np.zeros((160, 220, 3), dtype=np.uint8)
    cv2.rectangle(image, (30, 30), (90, 120), (220, 220, 220), -1)
    cv2.circle(image, (155, 80), 30, (80, 180, 250), -1)
    cv2.line(image, (10, 145), (210, 130), (255, 255, 255), 3)
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    _, mask = cv2.threshold(gray, 50, 255, cv2.THRESH_BINARY)
    return {
        "image": image,
        "gray": gray,
        "mask": mask,
        "template": image[20:130, 20:105].copy(),
        "reference": np.roll(image, 5, axis=1),
        "flat": np.full_like(image, 220),
        "dark": np.full_like(image, 10),
    }


def _inputs_for(node_type: str) -> dict[str, object]:
    images = _images()
    metadata = INDUSTRIAL_OPERATOR_META[node_type]
    inputs: dict[str, object] = {}
    for port in metadata.get("inputs", []):
        handle = str(port["handle"])
        required = port.get("required", True)
        port_type = str(port.get("type") or "any")
        if port_type == "image":
            if handle == "mask":
                value = images["mask"]
            elif handle == "template":
                value = images["template"]
            elif handle == "reference":
                value = images["reference"]
            elif handle == "flat":
                value = images["flat"]
            elif handle == "dark":
                value = images["dark"]
            else:
                value = images["image"]
            inputs[handle] = value
            inputs[f"{handle}_color_space"] = "GRAY" if value.ndim == 2 else "BGR"
        elif required:
            if handle == "points":
                inputs[handle] = [[10, 20], [30, 40]]
            elif handle.startswith("line"):
                inputs[handle] = {"p1": [10, 10], "p2": [100, 50]}
            elif handle.startswith("p"):
                inputs[handle] = [10, 20]
            else:
                inputs[handle] = 1

    if node_type == "ChannelMerge":
        inputs = {
            "c1": images["gray"],
            "c1_color_space": "GRAY",
            "c2": images["gray"],
            "c2_color_space": "GRAY",
            "c3": images["gray"],
            "c3_color_space": "GRAY",
        }
    if node_type == "ShapeMatch":
        inputs = {
            "in": images["mask"],
            "in_color_space": "GRAY",
            "template": images["mask"][20:130, 20:105],
            "template_color_space": "GRAY",
        }
    return inputs


def test_industrial_library_registers_large_category_set() -> None:
    assert len(INDUSTRIAL_OPERATOR_TYPES) >= 60
    assert INDUSTRIAL_OPERATOR_TYPES <= set(OPERATOR_DEFINITIONS)
    assert {"图像", "测量", "识别"} <= set(OPERATOR_CATALOG)
    assert "OCRRecognize" in INDUSTRIAL_OPERATOR_TYPES
    assert "DynamicThreshold" in INDUSTRIAL_OPERATOR_TYPES
    assert "CaliperEdgePair" in INDUSTRIAL_OPERATOR_TYPES
    assert "TemplateMatchNCC" in INDUSTRIAL_OPERATOR_TYPES


def test_every_dependency_free_industrial_operator_runs_and_declares_outputs() -> None:
    excluded = {"OCRRecognize", "BarcodeDecode", "DataMatrixDecode", "ArucoMarkerDetect"}
    for node_type in sorted(INDUSTRIAL_OPERATOR_TYPES - excluded):
        result = _industrial_execute(
            node_type,
            _inputs_for(node_type),
            INDUSTRIAL_OPERATOR_META[node_type].get("params", {}),
        )
        assert isinstance(result, dict), node_type
        declared = {item["handle"] for item in INDUSTRIAL_OPERATOR_META[node_type].get("outputs", [])}
        assert declared <= set(result), f"{node_type} 缺少输出：{sorted(declared - set(result))}"


def test_ocr_tesseract_result_is_normalized(monkeypatch) -> None:
    fake = SimpleNamespace()
    fake.Output = SimpleNamespace(DICT=object())
    fake.image_to_data = lambda *args, **kwargs: {
        "text": ["", "ABC123"],
        "conf": ["-1", "96.5"],
        "left": [0, 12],
        "top": [0, 18],
        "width": [0, 64],
        "height": [0, 22],
    }
    monkeypatch.setitem(sys.modules, "pytesseract", fake)
    result = _industrial_execute(
        "OCRRecognize",
        {"in": _images()["image"], "in_color_space": "BGR"},
        {"engine": "TESSERACT", "language": "eng", "psm": 7, "oem": 3, "min_confidence": 50},
    )
    assert result["text"] == "ABC123"
    assert result["items"][0]["bbox"] == [12, 18, 64, 22]
    assert result["count"] == 1


def test_barcode_result_is_normalized(monkeypatch) -> None:
    class FakeDetector:
        def detectAndDecodeWithType(self, image):
            del image
            points = np.asarray([[[10, 10], [90, 10], [90, 40], [10, 40]]], dtype=np.float32)
            return True, ["6901234567890"], ["EAN_13"], points

    monkeypatch.setattr(cv2, "barcode_BarcodeDetector", FakeDetector, raising=False)
    result = _industrial_execute(
        "BarcodeDecode",
        {"in": _images()["image"], "in_color_space": "BGR"},
        {},
    )
    assert result["found"] is True
    assert result["text"] == "6901234567890"
    assert result["items"][0]["type"] == "EAN_13"


def test_datamatrix_result_is_normalized(monkeypatch) -> None:
    class FakeRect:
        left = 8
        top = 72
        width = 50
        height = 24

    class FakeResult:
        rect = FakeRect()
        data = b"DM-001"

    fake_module = SimpleNamespace(decode=lambda image, timeout, max_count: [FakeResult()])
    fake_package = SimpleNamespace(pylibdmtx=fake_module)
    monkeypatch.setitem(sys.modules, "pylibdmtx", fake_package)
    monkeypatch.setitem(sys.modules, "pylibdmtx.pylibdmtx", fake_module)
    result = _industrial_execute(
        "DataMatrixDecode",
        {"in": _images()["image"], "in_color_space": "BGR"},
        {"timeout_ms": 100, "max_count": 5, "encoding": "utf-8"},
    )
    assert result["found"] is True
    assert result["text"] == "DM-001"
    assert result["items"][0]["bbox"] == [8, 64, 50, 24]


def test_polar_transform_uses_image_center_for_negative_coordinates() -> None:
    images = _images()
    result = _industrial_execute(
        "PolarTransform",
        {"in": images["image"], "in_color_space": "BGR"},
        {"center_x": -1, "center_y": -1, "max_radius": 60, "output_width": 60, "output_height": 180},
    )
    assert result["center"] == [110.0, 80.0]
    assert result["out"].shape[:2] == (180, 60)


def test_all_industrial_types_can_be_exported_in_one_workflow() -> None:
    nodes = [{"id": "read", "type": "ReadImage", "params": {}}]
    edges: list[dict[str, str]] = []
    for index, node_type in enumerate(sorted(INDUSTRIAL_OPERATOR_TYPES), start=1):
        node_id = f"industrial_{index}"
        nodes.append({"id": node_id, "type": node_type, "params": INDUSTRIAL_OPERATOR_META[node_type].get("params", {})})
        for port in INDUSTRIAL_OPERATOR_META[node_type].get("inputs", []):
            if port.get("required", True) and port.get("type") == "image":
                edges.append({
                    "source": "read",
                    "sourceHandle": "out",
                    "target": node_id,
                    "targetHandle": str(port["handle"]),
                })
    source = generate_algorithm_script(WorkflowRequest.model_validate({"nodes": nodes, "edges": edges}))
    compile(source, "industrial_all_nodes.py", "exec")
    assert "def _industrial_execute" in source
    assert "OCRRecognize" in source


def test_exported_multibranch_defect_workflow_runs() -> None:
    workflow = WorkflowRequest.model_validate({
        "nodes": [
            {"id": "inspection", "type": "ReadImage", "params": {}},
            {"id": "reference", "type": "ReadImage", "params": {}},
            {"id": "difference", "type": "ImageDifference", "params": {"threshold": 5, "min_area": 1}},
            {"id": "blob", "type": "BlobAnalysis", "params": {"threshold": 0, "min_area": 1, "max_area": 0}},
        ],
        "edges": [
            {"source": "inspection", "target": "difference", "targetHandle": "in"},
            {"source": "reference", "target": "difference", "targetHandle": "reference"},
            {"source": "difference", "sourceHandle": "mask", "target": "blob", "targetHandle": "in"},
        ],
    })
    source = generate_algorithm_script(workflow)
    namespace: dict[str, object] = {"__name__": "industrial_export_test", "__file__": "/tmp/industrial_export.py"}
    exec(compile(source, "industrial_export.py", "exec"), namespace)
    images = _images()
    output = namespace["run_algorithm"](
        images["image"],
        image_inputs={"inspection": images["image"], "reference": images["reference"]},
    )
    assert isinstance(output, np.ndarray)
    assert output.shape == images["image"].shape


def test_frontend_renders_image_measurement_and_recognition_categories() -> None:
    root = Path(__file__).resolve().parents[1]
    source = (root / "frontend/assets/js/app/operators.js").read_text(encoding="utf-8")
    page = (root / "frontend/index.html").read_text(encoding="utf-8")
    assert 'categories:["图像", "测量", "识别"]' in source
    assert "工业视觉算子库" in page
    assert "搜索图像、测量、OCR、条码算子" in page
