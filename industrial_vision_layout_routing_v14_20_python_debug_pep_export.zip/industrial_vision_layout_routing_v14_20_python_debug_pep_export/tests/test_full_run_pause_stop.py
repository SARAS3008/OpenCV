from __future__ import annotations

import threading
import time

import pytest
from fastapi.testclient import TestClient

from backend.main import app
from backend.services.workflow_run_manager import WorkflowRunControlError, WorkflowRunManager, workflow_run_manager
from tests.auth_utils import auth_headers


def _wait_for(predicate, timeout: float = 2.0) -> None:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if predicate():
            return
        time.sleep(0.01)
    raise AssertionError("condition was not reached before timeout")


def test_run_control_pause_resume_blocks_at_checkpoint() -> None:
    events: list[dict] = []
    manager = WorkflowRunManager(max_runs=5, ttl_seconds=60)
    control = manager.create(user_id="u", workspace_id="w", event_callback=events.append)
    control.pause()

    finished = threading.Event()

    def worker() -> None:
        control.checkpoint()
        finished.set()

    thread = threading.Thread(target=worker, daemon=True)
    thread.start()
    _wait_for(lambda: control.snapshot()["state"] == "paused")
    assert not finished.is_set()
    assert events[-1]["event"] == "workflow_paused"

    control.resume()
    thread.join(timeout=2)
    assert finished.is_set()
    assert control.snapshot()["state"] == "running"
    assert events[-1]["event"] == "workflow_resumed"


def test_run_control_cancel_releases_paused_checkpoint() -> None:
    manager = WorkflowRunManager(max_runs=5, ttl_seconds=60)
    control = manager.create(user_id="u", workspace_id="w")
    control.pause()

    thread = threading.Thread(target=control.checkpoint, daemon=True)
    thread.start()
    _wait_for(lambda: control.snapshot()["state"] == "paused")
    control.cancel()
    thread.join(timeout=2)

    assert not thread.is_alive()
    assert control.is_cancelled() is True
    assert control.snapshot()["state"] == "cancel_requested"


def test_run_control_isolated_by_user_and_workspace() -> None:
    manager = WorkflowRunManager(max_runs=5, ttl_seconds=60)
    control = manager.create(user_id="u1", workspace_id="w1")

    with pytest.raises(WorkflowRunControlError) as user_error:
        manager.pause(control.run_id, user_id="u2", workspace_id="w1")
    assert user_error.value.status_code == 403

    with pytest.raises(WorkflowRunControlError) as workspace_error:
        manager.cancel(control.run_id, user_id="u1", workspace_id="w2")
    assert workspace_error.value.status_code == 403


def test_full_run_control_endpoints_and_frontend_controls() -> None:
    client = TestClient(app)
    user, headers = auth_headers(client, "full-run-control")
    workspace_id = user["default_workspace_id"]
    control = workflow_run_manager.create(user_id=user["user_id"], workspace_id=workspace_id)

    paused = client.post("/api/run/pause", headers=headers, json={"run_id": control.run_id})
    assert paused.status_code == 200
    assert paused.json()["pause_requested"] is True

    resumed = client.post("/api/run/resume", headers=headers, json={"run_id": control.run_id})
    assert resumed.status_code == 200
    assert resumed.json()["state"] == "running"

    stopped = client.post("/api/run/cancel", headers=headers, json={"run_id": control.run_id})
    assert stopped.status_code == 200
    assert stopped.json()["cancel_requested"] is True

    html = client.get("/").text
    api_js = client.get("/assets/js/api.js").text
    controller_js = client.get("/assets/js/app/run_controller.js").text
    assert 'id="fullPauseButton"' in html
    assert 'id="fullStopButton"' in html
    assert 'onclick="toggleFullRunPause()"' in html
    assert 'onclick="stopFullRun()"' in html
    assert 'controlWorkflowRun("pause"' in api_js
    assert 'controlWorkflowRun("resume"' in api_js
    assert 'controlWorkflowRun("cancel"' in api_js
    assert "async function toggleFullRunPause()" in controller_js
    assert "async function stopFullRun()" in controller_js
