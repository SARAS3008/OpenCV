import cv2
import numpy as np

from backend.algorithms.registry import OPERATORS, OPERATOR_META, OPERATOR_CATALOG
from backend.models.workflow import WorkflowRequest
from backend.services.image_store import ImageStore
from backend.services.workflow_engine import run_workflow


def _rotated_rect_mask() -> np.ndarray:
    mask = np.zeros((180, 220), dtype=np.uint8)
    box = cv2.boxPoints(((110, 90), (90, 40), 25)).astype(np.int32)
    cv2.fillPoly(mask, [box], 255)
    return mask


def test_mask_min_area_rect_outputs_ordered_points_and_rect() -> None:
    mask = _rotated_rect_mask()
    result = OPERATORS["MaskMinAreaRect"]({"in": mask, "in_color_space": "GRAY"}, {"select_mode": "UNION"}, {})

    assert result["out"].shape == (180, 220, 3)
    assert len(result["points"]) == 4
    assert len(result["top_left"]) == 2
    assert "left" in result["lines"]
    assert result["metrics"]["found"] is True
    assert result["metrics"]["width"] > 30
    assert result["metrics"]["height"] > 30


def test_rotated_rect_feature_selects_line_and_point() -> None:
    mask = _rotated_rect_mask()
    rect = OPERATORS["MaskMinAreaRect"]({"in": mask, "in_color_space": "GRAY"}, {}, {})["rect"]

    line_result = OPERATORS["RotatedRectFeature"]({"rect": rect}, {"feature_type": "LINE", "line": "LEFT"}, {})
    assert "abc" in line_result["line"]
    assert line_result["line"]["length"] > 10

    point_result = OPERATORS["RotatedRectFeature"]({"rect": rect}, {"feature_type": "POINT", "point": "BOTTOM_RIGHT"}, {})
    assert len(point_result["point"]) == 2
    assert point_result["selected"] == point_result["point"]


def test_apply_mask_outputs_masked_roi_and_bbox() -> None:
    image = np.zeros((100, 120, 3), dtype=np.uint8)
    image[:, :] = (10, 80, 160)
    mask = np.zeros((100, 120), dtype=np.uint8)
    cv2.rectangle(mask, (20, 30), (70, 60), 255, -1)

    result = OPERATORS["ApplyMask"](
        {"in": image, "mask": mask, "in_color_space": "BGR", "mask_color_space": "GRAY"},
        {"output_mode": "ROI", "bbox_mode": "UNION"},
        {},
    )
    assert result["bbox"] == [20, 30, 51, 31]
    assert result["out"].shape == (31, 51, 3)
    assert result["mask"].shape == (100, 120)
    assert result["metrics"]["mask_pixels"] == int(np.count_nonzero(mask))


def test_fit_line_from_edges_and_point_line_distance() -> None:
    edge = np.zeros((120, 140), dtype=np.uint8)
    cv2.line(edge, (20, 30), (120, 80), 255, 1)

    line_result = OPERATORS["FitLineFromEdges"]({"in": edge, "in_color_space": "GRAY"}, {"min_points": 2}, {})
    assert line_result["metrics"]["found"] is True
    assert "abc" in line_result["line"]

    distance_result = OPERATORS["PointLineDistance"]({"point": [20, 60], "line": line_result["line"]}, {}, {})
    assert distance_result["distance"] > 0
    assert len(distance_result["foot_point"]) == 2
    assert distance_result["value"] == distance_result["distance"]


def test_point_line_distance_respects_xy_and_yx_coordinate_order() -> None:
    line = {"abc": [0.0, 1.0, -10.0], "p1": [0.0, 10.0], "p2": [100.0, 10.0]}

    xy = OPERATORS["PointLineDistance"](
        {"point": [20.0, 30.0], "line": line},
        {"point_order": "XY"},
        {},
    )
    yx = OPERATORS["PointLineDistance"](
        {"point": [30.0, 20.0], "line": line},
        {"point_order": "YX"},
        {},
    )

    assert xy["distance"] == 20.0
    assert yx["distance"] == 20.0
    assert xy["data"]["raw_point"] == [20.0, 30.0]
    assert yx["data"]["raw_point"] == [30.0, 20.0]
    assert yx["data"]["point"] == [20.0, 30.0]
    assert yx["data"]["point_order"] == "YX"

def test_point_line_distance_draws_extended_line_and_visible_foot_marker() -> None:
    image = np.zeros((80, 120, 3), dtype=np.uint8)
    line = {"abc": [0.0, 1.0, -10.0], "p1": [30.0, 10.0], "p2": [70.0, 10.0]}

    result = OPERATORS["PointLineDistance"](
        {"image": image, "point": [100.0, 30.0], "line": line, "image_color_space": "BGR"},
        {},
        {},
    )

    out = result["out"]
    assert result["line"]["extended_p1"][1] == 10
    assert result["line"]["extended_p2"][1] == 10
    assert result["foot_point"] == [100.0, 10.0]
    # 线段原始范围是 x=[30,70]；若延长线被绘制，x=5 处也应出现绿色像素。
    left_extension = out[max(0, 10 - 1): min(out.shape[0], 10 + 2), max(0, 5 - 1): min(out.shape[1], 5 + 2)]
    assert int(left_extension[:, :, 1].max()) > 0
    foot_patch = out[max(0, 10 - 3): min(out.shape[0], 10 + 4), max(0, 100 - 3): min(out.shape[1], 100 + 4)]
    assert int(foot_patch.max()) > 0


def test_point_line_distance_manual_fallback_runs_without_edges(tmp_path) -> None:
    workflow = WorkflowRequest.model_validate(
        {
            "nodes": [
                {
                    "id": "distance",
                    "type": "PointLineDistance",
                    "params": {
                        "point_x": 20,
                        "point_y": 30,
                        "x1": 0,
                        "y1": 10,
                        "x2": 100,
                        "y2": 10,
                    },
                }
            ],
            "edges": [],
        }
    )

    result = run_workflow(workflow, ImageStore(tmp_path, {".png"}))
    preview = next(item for item in result["previews"] if item["node_id"] == "distance")

    assert result["success"] is True
    assert preview["metrics"]["distance"] == 20.0
    assert OPERATOR_META["PointLineDistance"]["inputs"][0]["required"] is False
    assert OPERATOR_META["PointLineDistance"]["inputs"][1]["required"] is False



def test_mask_min_area_rect_port_values_match_annotated_points() -> None:
    mask = np.zeros((260, 180), dtype=np.uint8)
    cv2.ellipse(mask, (76, 132), (38, 92), 4, 0, 360, 255, -1)
    result = OPERATORS["MaskMinAreaRect"]({"in": mask, "in_color_space": "GRAY"}, {"select_mode": "UNION"}, {})

    assert result["data"]["top_left"] == result["top_left"]
    assert result["data"]["top_right"] == result["top_right"]
    assert result["data"]["bottom_left"] == result["bottom_left"]
    assert result["data"]["bottom_right"] == result["bottom_right"]
    assert result["rect"]["points"] == result["points"]
    assert result["rect"]["top_left"] == result["top_left"]
    assert result["rect"]["top_right"] == result["top_right"]
    assert result["rect"]["bottom_left"] == result["bottom_left"]
    assert result["rect"]["bottom_right"] == result["bottom_right"]

    tl, tr, br, bl = result["points"]
    assert tl[1] <= bl[1]
    assert tr[1] <= br[1]
    assert tl[0] <= tr[0]
    assert bl[0] <= br[0]
    assert result["lines"]["top"] == [tl, tr]
    assert result["lines"]["left"] == [tl, bl]
    assert result["lines"]["right"] == [tr, br]
    assert result["lines"]["bottom"] == [bl, br]


def test_rotated_rect_feature_uses_canonical_mask_rect_points() -> None:
    mask = np.zeros((220, 180), dtype=np.uint8)
    box = cv2.boxPoints(((90, 110), (56, 140), 12)).astype(np.int32)
    cv2.fillPoly(mask, [box], 255)
    rect_result = OPERATORS["MaskMinAreaRect"]({"in": mask, "in_color_space": "GRAY"}, {}, {})
    feature = OPERATORS["RotatedRectFeature"]({"rect": rect_result["rect"]}, {"feature_type": "POINT", "point": "TOP_LEFT"}, {})

    assert feature["point"] == rect_result["top_left"]
    assert feature["selected"] == rect_result["top_left"]

def test_new_measurement_nodes_are_registered_in_catalog() -> None:
    for name in ["MaskMinAreaRect", "RotatedRectFeature", "ApplyMask", "FitLineFromEdges", "PointLineDistance"]:
        assert name in OPERATORS
        assert name in OPERATOR_META
    image_groups = {group["group"]: group["items"] for group in OPERATOR_CATALOG["图像"]}
    assert "ApplyMask" in image_groups["ROI与Mask"]
    assert "MaskMinAreaRect" in image_groups["几何测量"]
    assert "RotatedRectFeature" in image_groups["几何测量"]
    assert "FitLineFromEdges" in image_groups["几何测量"]
    assert "PointLineDistance" in image_groups["几何测量"]
