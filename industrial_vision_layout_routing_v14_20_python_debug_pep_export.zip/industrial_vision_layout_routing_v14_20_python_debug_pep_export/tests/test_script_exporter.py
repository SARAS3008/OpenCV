from pathlib import Path
import subprocess
import sys

import cv2
import numpy as np
from fastapi.testclient import TestClient

from backend.main import app
from tests.auth_utils import auth_headers
from backend.models.workflow import WorkflowRequest
from backend.services.script_exporter import generate_algorithm_script


client = TestClient(app)
_, AUTH_HEADERS = auth_headers(client, "export")


def make_workflow() -> WorkflowRequest:
    return WorkflowRequest.model_validate(
        {
            "nodes": [
                {"id": "n1", "type": "ReadImage", "params": {"image_path": "ignored.png"}},
                {"id": "n2", "type": "ColorConvert", "params": {"mode": "GRAY"}},
                {"id": "n3", "type": "GaussianBlur", "params": {"ksize": 5, "sigma": 0}},
                {"id": "n4", "type": "Canny", "params": {"threshold1": 20, "threshold2": 80}},
            ],
            "edges": [
                {"source": "n1", "target": "n2"},
                {"source": "n2", "target": "n3"},
                {"source": "n3", "target": "n4"},
            ],
        }
    )


def test_exported_script_is_plain_algorithm_and_runs(tmp_path: Path) -> None:
    source = generate_algorithm_script(make_workflow())
    assert "def run_algorithm(input_image):" in source
    assert "WORKFLOW" not in source
    assert "topological_sort" not in source
    assert "OPERATORS" not in source
    assert '"nodes"' not in source
    assert '"edges"' not in source

    script = tmp_path / "vision_algorithm.py"
    script.write_text(source, encoding="utf-8")
    input_path = tmp_path / "input.png"
    output_path = tmp_path / "result.png"
    image = np.zeros((80, 120, 3), dtype=np.uint8)
    cv2.rectangle(image, (20, 20), (90, 60), (255, 255, 255), -1)
    assert cv2.imwrite(str(input_path), image)

    subprocess.run(
        [sys.executable, str(script), "--input", str(input_path), "--output", str(output_path)],
        check=True,
        cwd=tmp_path,
    )
    result = cv2.imread(str(output_path), cv2.IMREAD_UNCHANGED)
    assert result is not None
    assert result.shape == (80, 120)


def test_export_endpoint_uses_algorithm_filename() -> None:
    response = client.post("/api/export-script", json=make_workflow().model_dump(), headers=AUTH_HEADERS)
    assert response.status_code == 200
    assert "vision_algorithm.py" in response.headers["content-disposition"]
    assert "def run_algorithm(input_image):" in response.text


def test_exported_script_respects_custom_multi_output_ports(tmp_path: Path) -> None:
    workflow = WorkflowRequest.model_validate(
        {
            "nodes": [
                {"id": "read", "type": "ReadImage"},
                {"id": "brightness", "type": "MeanBrightness"},
                {"id": "limit", "type": "LogicConstant", "params": {"value_type": "NUMBER", "value": "4"}},
                {"id": "compare", "type": "LogicCompare", "params": {"operator": "GT"}},
            ],
            "edges": [
                {"source": "read", "target": "brightness"},
                {"source": "brightness", "sourceHandle": "mean_brightness", "target": "compare", "targetHandle": "a"},
                {"source": "limit", "target": "compare", "targetHandle": "b"},
            ],
        }
    )
    source = generate_algorithm_script(workflow)
    assert "meanbrightness_mean_brightness" in source
    namespace: dict[str, object] = {}
    exec(compile(source, "vision_algorithm.py", "exec"), namespace)
    image = np.full((16, 16, 3), 100, dtype=np.uint8)
    assert namespace["run_algorithm"](image) is True


def make_batch_workflow(input_dir: Path | str = "inputs", output_dir: Path | str = "outputs") -> WorkflowRequest:
    return WorkflowRequest.model_validate(
        {
            "nodes": [
                {
                    "id": "reader",
                    "type": "BatchReadImages",
                    "params": {
                        "folder_path": str(input_dir),
                        "recursive": "YES",
                        "extensions": ".png",
                        "continue_on_error": "YES",
                    },
                },
                {"id": "brightness", "type": "MeanBrightness", "params": {}},
                {
                    "id": "saver",
                    "type": "SaveBatchResults",
                    "params": {
                        "output_dir": str(output_dir),
                        "save_images": "YES",
                        "image_format": "PNG",
                        "filename_suffix": "_result",
                        "preserve_structure": "YES",
                        "write_csv": "YES",
                        "csv_filename": "measurements.csv",
                        "csv_export_mode": "SELECTED_INPUTS",
                        "result_input_count": 1,
                        "csv_fields": [
                            {"input": "result1", "enabled": True, "column": "brightness.mean"},
                        ],
                    },
                },
            ],
            "edges": [
                {"source": "reader", "target": "brightness", "targetHandle": "in"},
                {"source": "brightness", "target": "saver", "sourceHandle": "out", "targetHandle": "in"},
                {
                    "source": "brightness",
                    "target": "saver",
                    "sourceHandle": "mean_brightness",
                    "targetHandle": "result1",
                },
            ],
        }
    )


def test_batch_exported_script_runs_and_writes_selected_csv(tmp_path: Path) -> None:
    input_dir = tmp_path / "inputs"
    output_dir = tmp_path / "outputs"
    input_dir.mkdir()
    first = np.full((20, 30, 3), 40, dtype=np.uint8)
    second = np.full((20, 30, 3), 120, dtype=np.uint8)
    assert cv2.imwrite(str(input_dir / "first.png"), first)
    assert cv2.imwrite(str(input_dir / "second.png"), second)

    source = generate_algorithm_script(make_batch_workflow(input_dir, output_dir))
    assert "def run_batch(" in source
    assert "brightness.mean" in source
    script = tmp_path / "vision_batch_algorithm.py"
    script.write_text(source, encoding="utf-8")

    subprocess.run(
        [sys.executable, str(script), "--input", str(input_dir), "--output", str(output_dir)],
        check=True,
        cwd=tmp_path,
    )

    assert (output_dir / "first_result.png").is_file()
    assert (output_dir / "second_result.png").is_file()
    csv_text = (output_dir / "measurements.csv").read_text(encoding="utf-8-sig")
    assert "brightness.mean" in csv_text
    assert "40.0" in csv_text
    assert "120.0" in csv_text


def test_batch_export_endpoint_uses_batch_filename() -> None:
    response = client.post(
        "/api/export-script",
        json=make_batch_workflow().model_dump(),
        headers=AUTH_HEADERS,
    )
    assert response.status_code == 200
    assert "vision_batch_algorithm.py" in response.headers["content-disposition"]
    assert "def run_batch(" in response.text


def test_exported_script_has_structured_pep_oriented_public_api() -> None:
    source = generate_algorithm_script(make_workflow())
    assert "# Style: PEP 8 / PEP 257 oriented generated source." in source
    assert "class PipelineMetadata:" in source
    assert "PIPELINE_METADATA = PipelineMetadata(" in source
    assert "class VisionPipeline:" in source
    assert "def run(self, input_image: np.ndarray) -> Any:" in source
    assert "def main() -> int:" in source
    assert "raise SystemExit(main())" in source
    assert "# Generated algorithm" in source
    assert "# Reusable public API" in source
    namespace: dict[str, object] = {"__name__": "structured_export_test"}
    exec(compile(source, "vision_algorithm.py", "exec", dont_inherit=True), namespace)
    pipeline = namespace["VisionPipeline"]()
    image = np.zeros((20, 30, 3), dtype=np.uint8)
    result = pipeline.run(image)
    assert isinstance(result, np.ndarray)
    assert result.shape == (20, 30)
    assert namespace["PIPELINE_METADATA"].as_dict()["node_count"] == 4


def test_exported_python_snippet_supports_lambda_and_exception_flow() -> None:
    workflow = WorkflowRequest.model_validate(
        {
            "nodes": [
                {"id": "source", "type": "LogicConstant", "params": {"value_type": "NUMBER", "value": "5"}},
                {
                    "id": "snippet",
                    "type": "PythonSnippet",
                    "params": {
                        "code": "def process(value):\n    fn = lambda item: item + 1\n    try:\n        return sum(fn(item) for item in range(int(value)))\n    except (TypeError, ValueError):\n        return -1\n",
                        "input_bindings": [
                            {"handle": "in", "name": "value", "label": "数量", "type": "number", "required": True}
                        ],
                    },
                },
            ],
            "edges": [{"source": "source", "target": "snippet", "targetHandle": "in"}],
        }
    )
    source = generate_algorithm_script(workflow)
    namespace: dict[str, object] = {"__name__": "snippet_lambda_export"}
    exec(compile(source, "vision_algorithm.py", "exec", dont_inherit=True), namespace)
    assert namespace["run_algorithm"]() == 15
