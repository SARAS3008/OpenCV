from __future__ import annotations

import csv
import subprocess
import sys
import types
from pathlib import Path

import cv2
import numpy as np
import pytest

from backend.models.workflow import WorkflowRequest
from backend.services.script_exporter import generate_algorithm_script


class FakeResult:
    def __init__(self, task: str, source: np.ndarray) -> None:
        self.names = {0: "left", 1: "right", 2: "other"}
        self.orig_img = source.copy()
        self.orig_shape = source.shape[:2]
        self.speed = {"preprocess": 1.1, "inference": 2.2, "postprocess": 0.8}
        self.boxes = None
        self.masks = None
        self.keypoints = None
        self.obb = None
        self.probs = None
        boxes = types.SimpleNamespace(
            xyxy=np.asarray([[8, 10, 28, 38], [55, 12, 82, 40]], dtype=np.float32),
            cls=np.asarray([0, 1], dtype=np.float32),
            conf=np.asarray([0.91, 0.84], dtype=np.float32),
            id=None,
        )
        if task == "classify":
            self.probs = types.SimpleNamespace(data=np.asarray([0.08, 0.86, 0.06], dtype=np.float32))
        elif task == "obb":
            self.obb = types.SimpleNamespace(
                xyxyxyxy=np.asarray(
                    [
                        [[8, 10], [28, 10], [28, 38], [8, 38]],
                        [[55, 12], [82, 12], [82, 40], [55, 40]],
                    ],
                    dtype=np.float32,
                ),
                xywhr=np.asarray([[18, 24, 20, 28, 0], [68.5, 26, 27, 28, 0]], dtype=np.float32),
                cls=np.asarray([0, 1], dtype=np.float32),
                conf=np.asarray([0.91, 0.84], dtype=np.float32),
            )
        else:
            self.boxes = boxes
            if task == "segment":
                self.masks = types.SimpleNamespace(
                    xy=[
                        np.asarray([[8, 10], [28, 10], [28, 38], [8, 38]], dtype=np.float32),
                        np.asarray([[55, 12], [82, 12], [82, 40], [55, 40]], dtype=np.float32),
                    ]
                )
            if task == "pose":
                self.keypoints = types.SimpleNamespace(
                    xy=np.asarray([[[12, 14], [18, 20]], [[60, 16], [72, 24]]], dtype=np.float32),
                    conf=np.asarray([[0.8, 0.9], [0.7, 0.85]], dtype=np.float32),
                )

    def plot(self) -> np.ndarray:
        result = self.orig_img.copy()
        cv2.rectangle(result, (8, 10), (28, 38), (0, 255, 0), 2)
        cv2.rectangle(result, (55, 12), (82, 40), (0, 255, 0), 2)
        return result


class FakeYOLO:
    instances = 0
    predict_calls: list[dict[str, object]] = []

    def __init__(self, _model_path: str, task: str = "auto") -> None:
        type(self).instances += 1
        self.task = task

    def predict(self, **kwargs: object) -> list[FakeResult]:
        type(self).predict_calls.append(dict(kwargs))
        task = str(kwargs.get("task") or self.task or "detect")
        if task == "auto":
            task = "detect"
        return [FakeResult(task, np.asarray(kwargs["source"]))]


@pytest.fixture(autouse=True)
def fake_ultralytics(monkeypatch: pytest.MonkeyPatch) -> None:
    FakeYOLO.instances = 0
    FakeYOLO.predict_calls = []
    monkeypatch.setitem(sys.modules, "ultralytics", types.SimpleNamespace(YOLO=FakeYOLO))


def yolo_workflow(task: str = "detect", *, model_path: str = "yolov8n.pt") -> WorkflowRequest:
    return WorkflowRequest.model_validate(
        {
            "nodes": [
                {"id": "read", "type": "ReadImage"},
                {
                    "id": "yolo",
                    "type": "YoloInfer",
                    "params": {
                        "model_path": model_path,
                        "task": task,
                        "confidence": 0.25,
                        "iou": 0.45,
                        "imgsz": 640,
                        "max_det": 50,
                        "max_results": 20,
                        "include_geometry": "YES",
                        "max_geometry_points": 100,
                        "output_mode": "ANNOTATED",
                        "device": "cpu",
                    },
                },
                {"id": "display", "type": "Display"},
            ],
            "edges": [
                {"source": "read", "target": "yolo", "targetHandle": "in"},
                {"source": "yolo", "target": "display", "sourceHandle": "out", "targetHandle": "in"},
            ],
        }
    )


def exec_export(workflow: WorkflowRequest, script_path: Path) -> dict[str, object]:
    source = generate_algorithm_script(workflow)
    assert "from backend" not in source
    assert "import backend" not in source
    assert "run_yolo_infer_node" in source
    namespace: dict[str, object] = {"__file__": str(script_path), "__name__": "exported_test"}
    exec(compile(source, str(script_path), "exec"), namespace)
    return namespace


@pytest.mark.parametrize("task", ["detect", "segment", "classify", "pose", "obb"])
def test_exported_yolo_runtime_supports_all_tasks(tmp_path: Path, task: str) -> None:
    namespace = exec_export(yolo_workflow(task), tmp_path / "vision_algorithm.py")
    image = np.zeros((64, 96, 3), dtype=np.uint8)
    result = namespace["run_yolo_infer_node"](
        "yolo",
        image,
        "BGR",
        yolo_workflow(task).nodes[1].params,
    )
    assert result["task"] == task
    assert isinstance(result["out"], np.ndarray)
    if task == "classify":
        assert result["count"] == 1
        assert result["top_class"] == "right"
        assert result["data"]["yolo"]["classification"]["top5"]
    else:
        assert result["count"] == 2
        assert len(result["detections"]) == 2
    if task == "segment":
        assert result["detections"][0]["mask_polygon"]
    if task == "pose":
        assert result["detections"][0]["keypoints"]["xy"]
    if task == "obb":
        assert result["detections"][0]["obb_polygon"]


def test_yolo_model_cache_and_predict_arguments(tmp_path: Path) -> None:
    namespace = exec_export(yolo_workflow(), tmp_path / "vision_algorithm.py")
    image = np.zeros((64, 96, 3), dtype=np.uint8)
    params = yolo_workflow().nodes[1].params
    namespace["run_yolo_infer_node"]("yolo", image, "BGR", params)
    namespace["run_yolo_infer_node"]("yolo", image, "BGR", params)
    assert FakeYOLO.instances == 1
    assert FakeYOLO.predict_calls[-1]["device"] == "cpu"
    assert FakeYOLO.predict_calls[-1]["task"] == "detect"


def test_exported_yolo_selection_and_roi_chain_runs(tmp_path: Path) -> None:
    workflow = WorkflowRequest.model_validate(
        {
            "nodes": [
                {"id": "read", "type": "ReadImage"},
                {"id": "yolo", "type": "YoloInfer", "params": {"model_path": "yolov8n.pt", "task": "detect", "include_geometry": "YES"}},
                {"id": "select", "type": "YoloSelectTopDetections", "params": {"top_k": 2, "min_confidence": 0.2, "selection_mode": "MIXED_TOP_K", "require_exact_count": "YES"}},
                {"id": "distance", "type": "RoiPairEdgeDistance", "params": {"threshold1": 20, "threshold2": 80, "padding": 1}},
                {"id": "display", "type": "Display"},
            ],
            "edges": [
                {"source": "read", "target": "yolo", "targetHandle": "in"},
                {"source": "yolo", "sourceHandle": "detections", "target": "select", "targetHandle": "detections"},
                {"source": "read", "target": "select", "targetHandle": "image"},
                {"source": "read", "target": "distance", "targetHandle": "image"},
                {"source": "select", "sourceHandle": "selected", "target": "distance", "targetHandle": "detections"},
                {"source": "distance", "target": "display", "targetHandle": "in"},
            ],
        }
    )
    namespace = exec_export(workflow, tmp_path / "vision_algorithm.py")
    image = np.zeros((64, 96, 3), dtype=np.uint8)
    result = namespace["run_algorithm"](image)
    assert isinstance(result, np.ndarray)
    assert result.shape[0] >= image.shape[0]
    assert result.shape[1] > image.shape[1]


def test_exported_dynamic_yolo_masks_keep_port_mapping(tmp_path: Path) -> None:
    workflow = WorkflowRequest.model_validate(
        {
            "nodes": [
                {"id": "read", "type": "ReadImage"},
                {"id": "yolo", "type": "YoloInfer", "params": {"model_path": "yolov8n.pt", "task": "segment", "include_geometry": "YES"}},
                {"id": "select", "type": "YoloSelectTopDetections", "params": {"selection_mode": "PER_CLASS_BEST", "class_indices": "0,1", "top_k": 2, "min_confidence": 0.2, "require_exact_count": "YES"}},
                {"id": "display", "type": "Display"},
            ],
            "edges": [
                {"source": "read", "target": "yolo"},
                {"source": "yolo", "sourceHandle": "detections", "target": "select", "targetHandle": "detections"},
                {"source": "read", "target": "select", "targetHandle": "image"},
                {"source": "select", "sourceHandle": "mask2", "target": "display", "targetHandle": "in"},
            ],
        }
    )
    namespace = exec_export(workflow, tmp_path / "vision_algorithm.py")
    mask = namespace["run_algorithm"](np.zeros((64, 96, 3), dtype=np.uint8))
    assert isinstance(mask, np.ndarray)
    assert mask.dtype == np.uint8
    assert int(mask[20, 65]) == 255
    assert int(mask[20, 15]) == 0


def _write_fake_ultralytics_module(path: Path) -> None:
    path.write_text(
        '''import cv2\nimport numpy as np\n\nclass Result:\n    def __init__(self, source):\n        self.names = {0: "part"}\n        self.orig_img = source.copy()\n        self.orig_shape = source.shape[:2]\n        self.speed = {"inference": 1.0}\n        self.boxes = type("Boxes", (), {\n            "xyxy": np.asarray([[4, 4, 14, 14]], dtype=np.float32),\n            "cls": np.asarray([0], dtype=np.float32),\n            "conf": np.asarray([0.93], dtype=np.float32),\n            "id": None,\n        })()\n        self.masks = None\n        self.keypoints = None\n        self.obb = None\n        self.probs = None\n    def plot(self):\n        result = self.orig_img.copy()\n        cv2.rectangle(result, (4, 4), (14, 14), (0, 255, 0), 1)\n        return result\n\nclass YOLO:\n    def __init__(self, model_path, task="auto"):\n        self.model_path = model_path\n        self.task = task\n    def predict(self, **kwargs):\n        return [Result(kwargs["source"])]\n''',
        encoding="utf-8",
    )


def test_exported_batch_yolo_script_runs_with_model_override(tmp_path: Path) -> None:
    input_dir = tmp_path / "inputs"
    output_dir = tmp_path / "outputs"
    input_dir.mkdir()
    assert cv2.imwrite(str(input_dir / "one.png"), np.zeros((24, 32, 3), dtype=np.uint8))
    model_path = tmp_path / "portable.pt"
    model_path.write_bytes(b"fake")
    workflow = WorkflowRequest.model_validate(
        {
            "nodes": [
                {"id": "reader", "type": "BatchReadImages", "params": {"folder_path": "server/input", "extensions": ".png", "recursive": "NO"}},
                {"id": "detector", "type": "YoloInfer", "params": {"model_path": "/server/models/missing.pt", "task": "detect", "include_geometry": "YES"}},
                {"id": "saver", "type": "SaveBatchResults", "params": {"output_dir": "server/output", "save_images": "YES", "image_format": "PNG", "write_csv": "YES", "csv_filename": "yolo.csv", "csv_export_mode": "SELECTED_INPUTS", "csv_fields": [{"input": "result1", "enabled": True, "column": "yolo.count"}, {"input": "result2", "enabled": True, "column": "yolo.class"}]}},
            ],
            "edges": [
                {"source": "reader", "target": "detector", "targetHandle": "in"},
                {"source": "detector", "sourceHandle": "out", "target": "saver", "targetHandle": "in"},
                {"source": "detector", "sourceHandle": "count", "target": "saver", "targetHandle": "result1"},
                {"source": "detector", "sourceHandle": "top_class", "target": "saver", "targetHandle": "result2"},
            ],
        }
    )
    source = generate_algorithm_script(workflow)
    assert "--model" in source
    script_path = tmp_path / "vision_batch_algorithm.py"
    script_path.write_text(source, encoding="utf-8")
    _write_fake_ultralytics_module(tmp_path / "ultralytics.py")
    subprocess.run(
        [
            sys.executable,
            str(script_path),
            "--input",
            str(input_dir),
            "--output",
            str(output_dir),
            "--model",
            str(model_path),
        ],
        check=True,
        cwd=tmp_path,
    )
    assert (output_dir / "one.png").is_file()
    with (output_dir / "yolo.csv").open("r", encoding="utf-8-sig", newline="") as stream:
        rows = list(csv.DictReader(stream))
    assert rows[0]["yolo.count"] == "1"
    assert rows[0]["yolo.class"] == "part"
