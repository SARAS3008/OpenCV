from __future__ import annotations

from pathlib import Path

from fastapi.testclient import TestClient

from backend.main import app
from backend.services.project_store import ProjectStore
from tests.auth_utils import auth_headers


client = TestClient(app)


def _workflow(node_type: str = "ReadImage") -> dict:
    return {
        "version": "2.3",
        "nodes": [{"id": "n1", "type": node_type, "params": {}}],
        "edges": [],
        "modules": [],
    }


def test_project_store_shared_snapshot_is_stable_and_private_projects_are_hidden(tmp_path: Path) -> None:
    store = ProjectStore(tmp_path / "projects")
    shared = store.save_project(workflow=_workflow("ReadImage"), owner_id="alice", name="共享案例")
    private = store.save_project(workflow=_workflow("Display"), owner_id="bob", name="私有案例")

    store.share_project(shared["project_id"], "alice", shared_by="alice")
    listed = store.list_shared_projects(query="共享")
    assert [item["project_id"] for item in listed] == [shared["project_id"]]
    assert private["project_id"] not in {item["project_id"] for item in listed}

    # 原项目继续编辑时，共享库仍保持分享时锁定的版本快照。
    store.save_project(
        workflow=_workflow("Display"),
        owner_id="alice",
        project_id=shared["project_id"],
        name="共享案例",
    )
    public_project = store.get_shared_project(shared["project_id"], "alice")
    assert public_project["workflow"]["nodes"][0]["type"] == "ReadImage"
    assert store.get_project(shared["project_id"], "alice")["workflow"]["nodes"][0]["type"] == "Display"

    store.unshare_project(shared["project_id"], "alice")
    assert store.list_shared_projects(query="共享") == []


def test_shared_project_library_allows_other_user_to_open_read_only_copy() -> None:
    author, author_headers = auth_headers(client, "library-author")
    viewer, viewer_headers = auth_headers(client, "library-viewer")
    unique_name = f"共享视觉教学项目-{author['user_id'][-8:]}"

    saved = client.post(
        "/api/projects",
        json={"name": unique_name, "description": "供团队学习的完整工作流", "workflow": _workflow("ReadImage")},
        headers=author_headers,
    )
    assert saved.status_code == 200, saved.text
    project_id = saved.json()["project"]["project_id"]

    # 未分享时，其他用户项目库不可见。
    before = client.get(f"/api/projects/library?query={unique_name}", headers=viewer_headers)
    assert before.status_code == 200
    assert before.json()["projects"] == []

    shared = client.post(f"/api/projects/{project_id}/share", json={}, headers=author_headers)
    assert shared.status_code == 200, shared.text
    assert shared.json()["project"]["is_shared"] is True

    listed = client.get(f"/api/projects/library?query={unique_name}", headers=viewer_headers)
    assert listed.status_code == 200, listed.text
    items = listed.json()["projects"]
    assert len(items) == 1
    assert items[0]["author_name"] == "library-author"
    assert items[0]["is_own_workspace"] is False
    assert items[0]["node_count"] == 1

    opened = client.get(
        f"/api/projects/library/{project_id}",
        params={"owner_scope": author["default_workspace_id"]},
        headers=viewer_headers,
    )
    assert opened.status_code == 200, opened.text
    public_project = opened.json()["project"]
    assert public_project["read_only"] is True
    assert public_project["workflow"]["nodes"][0]["type"] == "ReadImage"
    assert public_project["author_name"] == "library-author"

    # 浏览者不能通过自己的工作区项目接口读取或修改原项目。
    private_open = client.get(f"/api/projects/{project_id}", headers=viewer_headers)
    assert private_open.status_code == 404

    unshared = client.post(f"/api/projects/{project_id}/unshare", headers=author_headers)
    assert unshared.status_code == 200
    unavailable = client.get(
        f"/api/projects/library/{project_id}",
        params={"owner_scope": author["default_workspace_id"]},
        headers=viewer_headers,
    )
    assert unavailable.status_code == 404
