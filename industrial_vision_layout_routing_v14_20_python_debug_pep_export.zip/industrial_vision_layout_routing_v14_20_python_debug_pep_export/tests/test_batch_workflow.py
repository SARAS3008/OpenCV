from __future__ import annotations

import csv
import json
from pathlib import Path

import cv2
import numpy as np

from backend.algorithms.registry import OPERATORS, OPERATOR_CATALOG, OPERATOR_META
from backend.models.workflow import WorkflowRequest
from backend.services.image_store import ImageStore
from backend.services.workflow_engine import run_workflow


def write_image(path: Path, value: int) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    image = np.full((36, 48, 3), value, dtype=np.uint8)
    cv2.rectangle(image, (8, 8), (30, 28), (255, 255, 255), -1)
    ok, buffer = cv2.imencode(path.suffix, image)
    assert ok
    buffer.tofile(str(path))


def test_custom_operator_is_auto_registered() -> None:
    assert "MeanBrightness" in OPERATORS
    assert OPERATOR_META["MeanBrightness"]["label"] == "平均亮度统计"
    custom_groups = [group for group in OPERATOR_CATALOG["图像"] if group["group"] == "自定义算子"]
    assert custom_groups
    assert "MeanBrightness" in custom_groups[0]["items"]


def test_batch_workflow_saves_images_and_csv_with_multiple_metrics(tmp_path: Path) -> None:
    source_dir = tmp_path / "source"
    write_image(source_dir / "a.png", 20)
    write_image(source_dir / "nested" / "b.png", 80)

    store = ImageStore(
        upload_dir=tmp_path / "uploads",
        allowed_extensions={".png", ".jpg", ".jpeg"},
        path_base=tmp_path,
    )
    workflow = WorkflowRequest.model_validate(
        {
            "nodes": [
                {
                    "id": "n1",
                    "type": "BatchReadImages",
                    "params": {
                        "folder_path": "source",
                        "recursive": "YES",
                        "extensions": ".png",
                        "max_images": 0,
                        "continue_on_error": "YES",
                    },
                },
                {"id": "n2", "type": "MeanBrightness"},
                {"id": "n3", "type": "FindContours", "params": {"threshold": 127, "min_area": 5}},
                {
                    "id": "n4",
                    "type": "SaveBatchResults",
                    "params": {
                        "output_dir": "results",
                        "save_images": "YES",
                        "image_format": "PNG",
                        "filename_suffix": "_done",
                        "preserve_structure": "YES",
                        "write_csv": "YES",
                        "csv_filename": "measurements.csv",
                    },
                },
            ],
            "edges": [
                {"source": "n1", "target": "n2"},
                {"source": "n2", "target": "n3"},
                {"source": "n3", "target": "n4"},
            ],
        }
    )

    events: list[dict] = []
    result = run_workflow(workflow, store, event_callback=events.append)
    assert result["success"] is True
    assert result["mode"] == "batch"
    assert result["batch"]["total"] == 2
    assert result["batch"]["succeeded"] == 2
    assert result["batch"]["failed"] == 0
    assert (tmp_path / "results" / "a_done.png").is_file()
    assert (tmp_path / "results" / "nested" / "b_done.png").is_file()

    csv_path = tmp_path / "results" / "measurements.csv"
    assert csv_path.is_file()
    with csv_path.open("r", encoding="utf-8-sig", newline="") as stream:
        rows = list(csv.DictReader(stream))
    assert len(rows) == 2
    assert rows[0]["source_name"] == "a.png"
    assert "n2_平均亮度统计.mean_brightness" in rows[0]
    assert "n3_轮廓查找.contour_count" in rows[0]
    assert rows[0]["status"] == "success"
    assert result["previews"]

    batch_events = [event for event in events if event["event"].startswith("batch_")]
    assert [event["event"] for event in batch_events] == [
        "batch_started",
        "batch_item_started",
        "batch_item_completed",
        "batch_item_started",
        "batch_item_completed",
        "batch_completed",
    ]
    assert batch_events[0]["processed"] == 0
    assert batch_events[0]["progress_percent"] == 0.0
    assert batch_events[2]["processed"] == 1
    assert batch_events[2]["progress_percent"] == 50.0
    assert batch_events[-1]["processed"] == 2
    assert batch_events[-1]["progress_percent"] == 100.0
    assert batch_events[-1]["succeeded"] == 2
    assert batch_events[-1]["failed"] == 0


def test_batch_csv_selected_inputs_support_multiple_nodes_and_field_selection(tmp_path: Path) -> None:
    source_dir = tmp_path / "source"
    write_image(source_dir / "sample.png", 40)

    store = ImageStore(
        upload_dir=tmp_path / "uploads",
        allowed_extensions={".png", ".jpg", ".jpeg"},
        path_base=tmp_path,
    )
    workflow = WorkflowRequest.model_validate(
        {
            "nodes": [
                {
                    "id": "reader",
                    "type": "BatchReadImages",
                    "params": {
                        "folder_path": "source",
                        "recursive": "YES",
                        "extensions": ".png",
                        "max_images": 0,
                        "continue_on_error": "YES",
                    },
                },
                {"id": "brightness", "type": "MeanBrightness"},
                {"id": "contours", "type": "FindContours", "params": {"threshold": 127, "min_area": 5}},
                {
                    "id": "distance",
                    "type": "PointLineDistance",
                    "params": {"point_x": 20, "point_y": 30, "x1": 0, "y1": 10, "x2": 100, "y2": 10},
                },
                {
                    "id": "save",
                    "type": "SaveBatchResults",
                    "params": {
                        "output_dir": "results",
                        "save_images": "NO",
                        "write_csv": "YES",
                        "csv_filename": "selected.csv",
                        "csv_export_mode": "SELECTED_INPUTS",
                        "result_input_count": 4,
                        "csv_fields": [
                            {"input": "result1", "enabled": True, "column": "brightness_mean"},
                            {"input": "result2", "enabled": False, "column": "brightness_std"},
                            {"input": "result3", "enabled": True, "column": "geometry.distance"},
                            {"input": "result4", "enabled": True, "column": "geometry.foot"},
                        ],
                    },
                },
            ],
            "edges": [
                {"source": "reader", "target": "brightness", "sourceHandle": "out", "targetHandle": "in"},
                {"source": "reader", "target": "contours", "sourceHandle": "out", "targetHandle": "in"},
                {"source": "contours", "target": "save", "sourceHandle": "out", "targetHandle": "in"},
                {"source": "brightness", "target": "save", "sourceHandle": "mean_brightness", "targetHandle": "result1"},
                {"source": "brightness", "target": "save", "sourceHandle": "brightness_std", "targetHandle": "result2"},
                {"source": "distance", "target": "save", "sourceHandle": "distance", "targetHandle": "result3"},
                {"source": "distance", "target": "save", "sourceHandle": "foot_point", "targetHandle": "result4"},
            ],
        }
    )

    result = run_workflow(workflow, store)
    csv_path = tmp_path / "results" / "selected.csv"
    with csv_path.open("r", encoding="utf-8-sig", newline="") as stream:
        rows = list(csv.DictReader(stream))

    assert result["success"] is True
    assert result["batch"]["csv_export_mode"] == "SELECTED_INPUTS"
    assert result["batch"]["csv_columns"] == ["brightness_mean", "geometry.distance", "geometry.foot"]
    assert len(rows) == 1
    assert float(rows[0]["brightness_mean"]) > 0
    assert float(rows[0]["geometry.distance"]) == 20.0
    assert json.loads(rows[0]["geometry.foot"]) == [20.0, 10.0]
    assert "brightness_std" not in rows[0]
    assert not any(key.startswith("brightness_平均亮度统计") for key in rows[0])


def test_batch_csv_selected_inputs_rejects_duplicate_column_names(tmp_path: Path) -> None:
    source_dir = tmp_path / "source"
    write_image(source_dir / "sample.png", 40)
    store = ImageStore(
        upload_dir=tmp_path / "uploads",
        allowed_extensions={".png"},
        path_base=tmp_path,
    )
    workflow = WorkflowRequest.model_validate(
        {
            "nodes": [
                {"id": "reader", "type": "BatchReadImages", "params": {"folder_path": "source", "extensions": ".png"}},
                {"id": "brightness", "type": "MeanBrightness"},
                {
                    "id": "save",
                    "type": "SaveBatchResults",
                    "params": {
                        "output_dir": "results",
                        "save_images": "NO",
                        "write_csv": "YES",
                        "csv_export_mode": "SELECTED_INPUTS",
                        "result_input_count": 2,
                        "csv_fields": [
                            {"input": "result1", "enabled": True, "column": "same"},
                            {"input": "result2", "enabled": True, "column": "same"},
                        ],
                    },
                },
            ],
            "edges": [
                {"source": "reader", "target": "brightness"},
                {"source": "brightness", "target": "save", "sourceHandle": "out", "targetHandle": "in"},
                {"source": "brightness", "target": "save", "sourceHandle": "mean_brightness", "targetHandle": "result1"},
                {"source": "brightness", "target": "save", "sourceHandle": "brightness_std", "targetHandle": "result2"},
            ],
        }
    )

    result = run_workflow(workflow, store)
    assert result["batch"]["failed"] == 1
    assert "CSV 列名冲突" in result["batch"]["rows"][0]["error"]


def test_batch_csv_selected_inputs_rejects_image_variable_port(tmp_path: Path) -> None:
    source_dir = tmp_path / "source"
    write_image(source_dir / "sample.png", 40)
    store = ImageStore(
        upload_dir=tmp_path / "uploads",
        allowed_extensions={".png"},
        path_base=tmp_path,
    )
    workflow = WorkflowRequest.model_validate(
        {
            "nodes": [
                {"id": "reader", "type": "BatchReadImages", "params": {"folder_path": "source", "extensions": ".png"}},
                {"id": "brightness", "type": "MeanBrightness"},
                {
                    "id": "save",
                    "type": "SaveBatchResults",
                    "params": {
                        "output_dir": "results",
                        "save_images": "NO",
                        "write_csv": "YES",
                        "csv_export_mode": "SELECTED_INPUTS",
                        "result_input_count": 1,
                    },
                },
            ],
            "edges": [
                {"source": "reader", "target": "brightness"},
                {"source": "brightness", "target": "save", "sourceHandle": "out", "targetHandle": "in"},
                {"source": "brightness", "target": "save", "sourceHandle": "out", "targetHandle": "result1"},
            ],
        }
    )

    try:
        run_workflow(workflow, store)
    except ValueError as exc:
        assert "连接了图像端口" in str(exc)
    else:
        raise AssertionError("应拒绝把图像输出连接为 CSV 变量")


def test_save_batch_results_metadata_declares_dynamic_csv_inputs() -> None:
    metadata = OPERATOR_META["SaveBatchResults"]
    assert metadata["inputs"][0]["handle"] == "in"
    assert metadata["dynamic_inputs"][0]["prefix"] == "result"
    assert metadata["dynamic_inputs"][0]["max_count"] == 20
    assert metadata["param_schema"]["csv_fields"]["type"] == "csv_field_selector"
