from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import cv2
import numpy as np

from backend.algorithms.registry import OPERATOR_DEFINITIONS, OPERATOR_META
from backend.models.workflow import WorkflowRequest
from backend.services.script_exporter import (
    STANDALONE_EXPORT_BUILTIN_TYPES,
    STANDALONE_EXPORT_OUTPUT_HANDLES,
    generate_algorithm_script,
)


def _capture_node(node_id: str, bindings: list[tuple[str, str, str]]) -> tuple[dict, list[dict]]:
    """Create a PythonSnippet sink that returns every connected output unchanged."""

    input_bindings = []
    edges = []
    names = []
    for index, (source_id, source_handle, name) in enumerate(bindings, start=1):
        handle = "in" if index == 1 else f"arg{index - 1}"
        input_bindings.append(
            {
                "handle": handle,
                "name": name,
                "label": name,
                "type": "any",
                "required": True,
            }
        )
        edges.append(
            {
                "source": source_id,
                "sourceHandle": source_handle,
                "target": node_id,
                "targetHandle": handle,
            }
        )
        names.append(name)
    arguments = ", ".join(names)
    pairs = ", ".join(f"{name!r}: {name}" for name in names)
    node = {
        "id": node_id,
        "type": "PythonSnippet",
        "params": {
            "input_bindings": input_bindings,
            "output_kind": "VALUE",
            "code": f"def process({arguments}):\n    return {{{pairs}}}\n",
        },
    }
    return node, edges


def _execute(workflow: dict, image: np.ndarray | None = None):
    source = generate_algorithm_script(WorkflowRequest.model_validate(workflow))
    namespace: dict[str, object] = {"__name__": "export_test", "__file__": "/tmp/export_test.py"}
    exec(compile(source, "vision_algorithm.py", "exec"), namespace)
    if image is None:
        return namespace["run_algorithm"]()
    return namespace["run_algorithm"](image)


def test_every_builtin_node_is_in_export_support_matrix() -> None:
    builtins = {name for name, definition in OPERATOR_DEFINITIONS.items() if definition.builtin}
    assert builtins == set(STANDALONE_EXPORT_BUILTIN_TYPES)


def test_declared_multi_outputs_are_all_covered() -> None:
    for node_type, handles in STANDALONE_EXPORT_OUTPUT_HANDLES.items():
        declared = {item["handle"] for item in OPERATOR_META[node_type].get("outputs", [])}
        assert declared <= set(handles), f"{node_type} 缺少导出端口：{sorted(declared - set(handles))}"


def test_all_example_workflows_can_generate_and_compile() -> None:
    examples = Path(__file__).resolve().parents[1] / "examples"
    for path in sorted(examples.glob("*.json")):
        workflow = WorkflowRequest.model_validate(json.loads(path.read_text(encoding="utf-8")))
        source = generate_algorithm_script(workflow)
        compile(source, f"{path.stem}.py", "exec")


def test_image_less_logic_workflow_runs_without_input() -> None:
    workflow = {
        "nodes": [
            {"id": "a", "type": "LogicConstant", "params": {"value_type": "NUMBER", "value": "12"}},
            {"id": "b", "type": "LogicConstant", "params": {"value_type": "NUMBER", "value": "10"}},
            {"id": "compare", "type": "LogicCompare", "params": {"operator": "GT"}},
        ],
        "edges": [
            {"source": "a", "target": "compare", "targetHandle": "a"},
            {"source": "b", "target": "compare", "targetHandle": "b"},
        ],
    }
    assert _execute(workflow) is True


def test_filter_contours_exports_every_declared_port() -> None:
    capture, capture_edges = _capture_node(
        "capture",
        [("filter", handle, f"filter_{handle}") for handle in ("out", "mask", "roi", "roi_mask", "bbox", "contour", "contours", "contour_infos")],
    )
    workflow = {
        "nodes": [
            {"id": "read", "type": "ReadImage"},
            {"id": "threshold", "type": "Threshold", "params": {"threshold": 100}},
            {"id": "filter", "type": "FilterContours", "params": {"select_mode": "MAX", "min_area": 10}},
            capture,
        ],
        "edges": [
            {"source": "read", "target": "threshold"},
            {"source": "threshold", "target": "filter"},
            *capture_edges,
        ],
    }
    image = np.zeros((80, 120, 3), dtype=np.uint8)
    cv2.rectangle(image, (20, 15), (95, 65), (255, 255, 255), -1)
    result = _execute(workflow, image)
    assert result["filter_out"].shape == (80, 120, 3)
    assert result["filter_mask"].shape == (80, 120)
    assert result["filter_roi"].size > 0
    assert result["filter_bbox"][2] > 0
    assert result["filter_contour_infos"]


def test_geometry_and_mask_nodes_keep_all_measurement_ports() -> None:
    bindings = [
        ("rect", "rect", "rect_value"),
        ("rect", "points", "rect_points"),
        ("rect", "top_left", "top_left"),
        ("rect", "lines", "rect_lines"),
        ("feature", "selected", "selected"),
        ("feature", "point", "feature_point"),
        ("feature", "line", "feature_line"),
        ("apply", "masked", "masked"),
        ("apply", "mask", "mask"),
        ("apply", "roi", "roi"),
        ("apply", "roi_mask", "roi_mask"),
        ("apply", "bbox", "mask_bbox"),
        ("fit", "line", "fit_line"),
        ("fit", "p1", "fit_p1"),
        ("fit", "p2", "fit_p2"),
        ("fit", "abc", "fit_abc"),
        ("fit", "angle", "fit_angle"),
    ]
    capture, capture_edges = _capture_node("capture", bindings)
    workflow = {
        "nodes": [
            {"id": "read", "type": "ReadImage"},
            {"id": "threshold", "type": "Threshold", "params": {"threshold": 100}},
            {"id": "rect", "type": "MaskMinAreaRect"},
            {"id": "feature", "type": "RotatedRectFeature", "params": {"feature_type": "POINT", "point": "TOP_LEFT"}},
            {"id": "apply", "type": "ApplyMask", "params": {"output_mode": "ROI"}},
            {"id": "canny", "type": "Canny", "params": {"threshold1": 20, "threshold2": 80}},
            {"id": "fit", "type": "FitLineFromEdges", "params": {"min_points": 2}},
            capture,
        ],
        "edges": [
            {"source": "read", "target": "threshold"},
            {"source": "threshold", "target": "rect"},
            {"source": "rect", "sourceHandle": "rect", "target": "feature", "targetHandle": "rect"},
            {"source": "read", "target": "feature", "targetHandle": "image"},
            {"source": "read", "target": "apply", "targetHandle": "in"},
            {"source": "threshold", "target": "apply", "targetHandle": "mask"},
            {"source": "read", "target": "canny"},
            {"source": "canny", "target": "fit"},
            *capture_edges,
        ],
    }
    image = np.zeros((100, 140, 3), dtype=np.uint8)
    cv2.rectangle(image, (25, 20), (110, 78), (255, 255, 255), -1)
    result = _execute(workflow, image)
    assert result["rect_value"]["points"]
    assert len(result["rect_points"]) == 4
    assert len(result["top_left"]) == 2
    assert result["feature_point"] == result["top_left"]
    assert result["masked"].shape == image.shape
    assert result["mask"].shape == image.shape[:2]
    assert result["roi"].size > 0
    assert result["mask_bbox"][2] > 0
    assert result["fit_line"]["abc"]
    assert len(result["fit_abc"]) == 3


def test_orb_connected_template_and_mask_export_all_ports() -> None:
    handles = (
        "out", "mask", "roi", "roi_mask", "masked", "annotated", "matches",
        "match_count", "good_match_count", "inlier_count", "confidence",
        "homography_found", "transform_found", "corners", "roi_bbox", "roi_polygon",
        "homography", "affine",
    )
    capture, capture_edges = _capture_node("capture", [("orb", handle, f"orb_{handle}") for handle in handles])
    workflow = {
        "nodes": [
            {"id": "read", "type": "ReadImage"},
            {"id": "mask", "type": "Threshold", "params": {"threshold": 0}},
            {
                "id": "orb",
                "type": "ORBFeatureMatch",
                "params": {
                    "roi_mode": "MASK",
                    "output_mode": "ANNOTATED",
                    "min_matches": 4,
                    "n_features": 800,
                },
            },
            capture,
        ],
        "edges": [
            {"source": "read", "target": "mask"},
            {"source": "read", "target": "orb", "targetHandle": "in"},
            {"source": "read", "target": "orb", "targetHandle": "template"},
            {"source": "mask", "target": "orb", "targetHandle": "mask"},
            *capture_edges,
        ],
    }
    rng = np.random.default_rng(7)
    image = rng.integers(0, 256, size=(96, 128, 3), dtype=np.uint8)
    result = _execute(workflow, image)
    assert result["orb_out"].shape == image.shape
    assert result["orb_mask"].shape == image.shape[:2]
    assert result["orb_matches"].ndim == 3
    assert result["orb_match_count"] > 0
    assert result["orb_good_match_count"] >= 4
    assert result["orb_transform_found"] is True
    assert len(result["orb_corners"]) == 4


def test_multiple_read_image_nodes_export_as_named_inputs(tmp_path: Path) -> None:
    workflow = WorkflowRequest.model_validate(
        {
            "nodes": [
                {"id": "source", "type": "ReadImage"},
                {"id": "mask_source", "type": "ReadImage"},
                {"id": "apply", "type": "ApplyMask", "params": {"output_mode": "MASKED"}},
            ],
            "edges": [
                {"source": "source", "target": "apply", "targetHandle": "in"},
                {"source": "mask_source", "target": "apply", "targetHandle": "mask"},
            ],
        }
    )
    source = generate_algorithm_script(workflow)
    assert "def run_algorithm(input_image=None, image_inputs=None):" in source
    assert "节点ID=PATH" in source
    namespace: dict[str, object] = {"__name__": "export_test", "__file__": str(tmp_path / "algorithm.py")}
    exec(compile(source, "vision_algorithm.py", "exec"), namespace)

    image = np.full((30, 40, 3), 120, dtype=np.uint8)
    mask = np.zeros((30, 40, 3), dtype=np.uint8)
    mask[:, 10:25] = 255
    result = namespace["run_algorithm"](None, {"source": image, "mask_source": mask})
    assert np.all(result[:, :10] == 0)
    assert np.all(result[:, 10:25] == 120)

    script_path = tmp_path / "vision_algorithm.py"
    image_path = tmp_path / "source.png"
    mask_path = tmp_path / "mask.png"
    output_path = tmp_path / "result.png"
    script_path.write_text(source, encoding="utf-8")
    assert cv2.imwrite(str(image_path), image)
    assert cv2.imwrite(str(mask_path), mask)
    subprocess.run(
        [
            sys.executable,
            str(script_path),
            "--input",
            f"source={image_path}",
            "--input",
            f"mask_source={mask_path}",
            "--output",
            str(output_path),
        ],
        check=True,
        cwd=tmp_path,
    )
    cli_result = cv2.imread(str(output_path), cv2.IMREAD_COLOR)
    assert cli_result is not None
    assert np.all(cli_result[:, :10] == 0)
    assert np.all(cli_result[:, 10:25] == 120)
