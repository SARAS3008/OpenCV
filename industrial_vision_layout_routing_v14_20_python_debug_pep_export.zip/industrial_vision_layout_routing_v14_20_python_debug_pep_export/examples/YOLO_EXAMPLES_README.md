# YOLO 示例工作流

## 1. 单图示例：yolo_single_image_workflow.json

流程结构：

```text
读取图像(ReadImage) -> YOLO推理(YoloInfer) -> 结果显示(Display)
                         └─ count -> 比较(LogicCompare)：判断检测数量是否 > 0
```

导入后需要修改：

- `ReadImage.image_path`：改成后端服务器可访问的图片路径。
- `YoloInfer.model_path`：在节点参数里点击“选择”上传模型，或填写服务器上的模型路径。
- `YoloInfer.task`：默认 `auto`，也可以改成 `detect`、`segment`、`classify`、`pose`、`obb`。

运行后主要查看：

- `YOLO推理.out`：标注图；
- `YOLO推理.count`：结果数量；
- `YOLO推理.top_class` / `top_confidence`：最高类别和置信度；
- `YOLO推理.detections`：结构化结果列表；
- `比较` 节点：判断是否检出目标。

## 2. 批量示例：yolo_batch_workflow.json

流程结构：

```text
批量读取图片(BatchReadImages) -> YOLO推理(YoloInfer) -> 保存批量结果(SaveBatchResults)
```

导入后需要修改：

- `BatchReadImages.folder_path`：改成待检测图片文件夹。
- `YoloInfer.model_path`：上传或填写 YOLO 模型路径。
- `SaveBatchResults.output_dir`：改成输出目录。

运行后会保存标注图，并生成 `yolo_results.csv`，其中包含 `data.yolo` 展平后的检测摘要。

## 导出为独立 Python 脚本

包含以下节点的工作流可以直接使用“导出脚本”：

- `YoloInfer`：检测、实例分割、分类、姿态估计、OBB；
- `YoloSelectTopDetections`：混合 Top-K、按类别分别筛选、动态 `mask1/mask2...`；
- `RoiPairEdgeDistance`：两个检测目标的 ROI 边缘检测与中心距离。

导出的脚本不依赖平台 `backend` 包，但运行环境需要安装：

```bash
pip install "ultralytics>=8.3,<9.0" "opencv-python>=4.10,<5.0" "numpy>=2.0,<3.0"
```

模型路径会优先使用工作流中 `YoloInfer.model_path` 的配置。平台上传模型通常保存为服务器路径；把脚本复制到其他电脑后，可以在命令行覆盖模型位置。

单个 YOLO 节点：

```bash
python vision_algorithm.py --input test.png --output result.png --model D:\models\best.pt
```

批量工作流：

```bash
python vision_batch_algorithm.py --input D:\images --output D:\results --model D:\models\best.pt
```

一个流程包含多个 YOLO 节点时，使用节点 ID 指定模型，参数可以重复：

```bash
python vision_algorithm.py \
  --input test.png \
  --model detector_a=D:\models\a.pt \
  --model detector_b=D:\models\b.pt
```

还可以统一覆盖推理设备：

```bash
python vision_algorithm.py --input test.png --model best.pt --device 0
```

作为 Python 模块调用时，先设置模型覆盖，再调用 `run_algorithm`：

```python
import cv2
import vision_algorithm as algorithm

algorithm.configure_yolo_models({"yolo_detect": "D:/models/best.pt"}, device="0")
result = algorithm.run_algorithm(cv2.imread("test.png"))
```
