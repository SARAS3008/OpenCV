from fastapi import APIRouter, Depends
from fastapi.responses import JSONResponse, Response

from backend.models.workflow import WorkflowRequest
from backend.api.dependencies import require_workspace_run
from backend.services.script_exporter import generate_algorithm_script

router = APIRouter()


@router.post("/export-script")
def export_script(workflow: WorkflowRequest, _workspace_id: str = Depends(require_workspace_run)):
    try:
        source = generate_algorithm_script(workflow)
    except (ValueError, KeyError, TypeError, RuntimeError) as exc:
        return JSONResponse(
            status_code=400,
            content={"success": False, "error": str(exc)},
        )

    is_batch = any(node.type == "BatchReadImages" for node in workflow.nodes)
    filename = "vision_batch_algorithm.py" if is_batch else "vision_algorithm.py"
    return Response(
        content=source.encode("utf-8"),
        media_type="text/x-python; charset=utf-8",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )
