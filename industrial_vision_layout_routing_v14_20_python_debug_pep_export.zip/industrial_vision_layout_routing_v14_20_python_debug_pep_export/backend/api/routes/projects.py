from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Request

from backend.api.dependencies import get_auth_store, get_project_store, get_user_id, require_workspace_edit, require_workspace_manage, require_workspace_view
from backend.models.workflow import WorkflowRequest
from backend.services.auth_store import AuthStore
from backend.services.project_store import ProjectStore

router = APIRouter(prefix="/projects")


@router.get("")
def list_projects(
    project_store: ProjectStore = Depends(get_project_store),
    workspace_id: str = Depends(require_workspace_view),
) -> dict[str, Any]:
    return {"success": True, "projects": project_store.list_projects(workspace_id)}


@router.get("/library")
def list_shared_project_library(
    query: str = "",
    limit: int = 100,
    project_store: ProjectStore = Depends(get_project_store),
    auth_store: AuthStore = Depends(get_auth_store),
    current_workspace_id: str = Depends(require_workspace_view),
) -> dict[str, Any]:
    projects = project_store.list_shared_projects(query="", limit=max(limit, 500))
    normalized_query = str(query or "").strip().lower()
    visible: list[dict[str, Any]] = []
    for item in projects:
        author = auth_store.get_public_user(str(item.get("author_id") or "")) or {}
        item["author_name"] = author.get("display_name") or item.get("author_id") or "匿名用户"
        item["is_own_workspace"] = item.get("owner_scope") == current_workspace_id
        searchable = " ".join([str(item.get("name") or ""), str(item.get("description") or ""), str(item.get("author_name") or "")]).lower()
        if normalized_query and normalized_query not in searchable:
            continue
        visible.append(item)
    return {"success": True, "projects": visible[: max(1, min(int(limit), 500))]}


@router.get("/library/{project_id}")
def get_shared_project_from_library(
    project_id: str,
    owner_scope: str,
    project_store: ProjectStore = Depends(get_project_store),
    auth_store: AuthStore = Depends(get_auth_store),
    current_workspace_id: str = Depends(require_workspace_view),
) -> dict[str, Any]:
    try:
        project = project_store.get_shared_project(project_id, owner_scope)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    author = auth_store.get_public_user(str(project.get("author_id") or "")) or {}
    project["author_name"] = author.get("display_name") or project.get("author_id") or "匿名用户"
    project["is_own_workspace"] = owner_scope == current_workspace_id
    return {"success": True, "project": project}


@router.post("")
async def save_project(
    request: Request,
    project_store: ProjectStore = Depends(get_project_store),
    user_id: str = Depends(get_user_id),
    workspace_id: str = Depends(require_workspace_edit),
) -> dict[str, Any]:
    payload = await request.json()
    try:
        workflow = WorkflowRequest.model_validate(payload.get("workflow") or {})
        project = project_store.save_project(
            workflow=workflow,
            owner_id=workspace_id,
            project_id=payload.get("project_id"),
            name=payload.get("name"),
            description=payload.get("description") if "description" in payload else None,
            change_note=payload.get("change_note") or "保存工作流",
            workspace_id=workspace_id,
            create_version=payload.get("create_version", True) is not False,
        )
        project["storage_scope"] = workspace_id
        project["owner_id"] = project.get("created_by") or user_id
        project["created_by"] = project.get("created_by") or user_id
        project["updated_by"] = user_id
        # 重新写入附加字段，便于审计。
        project_store.overwrite_project(project["project_id"], workspace_id, project)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return {"success": True, "project": project}


@router.post("/{project_id}/share")
async def share_project_to_library(
    project_id: str,
    request: Request,
    project_store: ProjectStore = Depends(get_project_store),
    user_id: str = Depends(get_user_id),
    workspace_id: str = Depends(require_workspace_manage),
) -> dict[str, Any]:
    payload = await request.json() if request.headers.get("content-type", "").lower().startswith("application/json") else {}
    try:
        project = project_store.share_project(
            project_id,
            workspace_id,
            version_id=(payload or {}).get("version_id"),
            shared_by=user_id,
            description=(payload or {}).get("description") if "description" in (payload or {}) else None,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return {
        "success": True,
        "project": {
            "project_id": project.get("project_id"),
            "is_shared": True,
            "shared_at": project.get("shared_at"),
            "shared_version_id": project.get("shared_version_id"),
        },
    }


@router.post("/{project_id}/unshare")
def remove_project_from_library(
    project_id: str,
    project_store: ProjectStore = Depends(get_project_store),
    workspace_id: str = Depends(require_workspace_manage),
) -> dict[str, Any]:
    try:
        project = project_store.unshare_project(project_id, workspace_id)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    return {"success": True, "project": {"project_id": project.get("project_id"), "is_shared": False}}


@router.get("/{project_id}")
def get_project(
    project_id: str,
    project_store: ProjectStore = Depends(get_project_store),
    workspace_id: str = Depends(require_workspace_view),
) -> dict[str, Any]:
    try:
        return {"success": True, "project": project_store.get_project(project_id, workspace_id)}
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.delete("/{project_id}")
def delete_project(
    project_id: str,
    project_store: ProjectStore = Depends(get_project_store),
    workspace_id: str = Depends(require_workspace_manage),
) -> dict[str, Any]:
    try:
        return {"success": True, "project": project_store.delete_project(project_id, workspace_id)}
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.get("/{project_id}/versions")
def list_project_versions(
    project_id: str,
    project_store: ProjectStore = Depends(get_project_store),
    workspace_id: str = Depends(require_workspace_view),
) -> dict[str, Any]:
    try:
        return {"success": True, "versions": project_store.list_versions(project_id, workspace_id)}
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.get("/{project_id}/versions/{version_id}")
def get_project_version(
    project_id: str,
    version_id: str,
    project_store: ProjectStore = Depends(get_project_store),
    workspace_id: str = Depends(require_workspace_view),
) -> dict[str, Any]:
    try:
        return {"success": True, "version": project_store.get_version(project_id, version_id, workspace_id)}
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.get("/{project_id}/diff")
def diff_project_versions(
    project_id: str,
    from_version: str | None = None,
    to_version: str | None = None,
    project_store: ProjectStore = Depends(get_project_store),
    workspace_id: str = Depends(require_workspace_view),
) -> dict[str, Any]:
    try:
        return {"success": True, **project_store.diff_versions(project_id, workspace_id, from_version=from_version, to_version=to_version)}
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.post("/{project_id}/rollback/{version_id}")
def rollback_project(
    project_id: str,
    version_id: str,
    project_store: ProjectStore = Depends(get_project_store),
    workspace_id: str = Depends(require_workspace_edit),
) -> dict[str, Any]:
    try:
        return {"success": True, "project": project_store.rollback_project(project_id, version_id, workspace_id)}
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.post("/{project_id}/release/{version_id}")
def release_project_version(
    project_id: str,
    version_id: str,
    project_store: ProjectStore = Depends(get_project_store),
    workspace_id: str = Depends(require_workspace_manage),
) -> dict[str, Any]:
    try:
        return {"success": True, "project": project_store.release_version(project_id, version_id, workspace_id)}
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
