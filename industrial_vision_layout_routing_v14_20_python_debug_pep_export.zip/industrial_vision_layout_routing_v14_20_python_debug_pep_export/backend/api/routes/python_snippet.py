from __future__ import annotations

import ast
import secrets
from typing import Any, Literal

from fastapi import APIRouter, Depends
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field

from backend.algorithms.ai.yolo.model_manager import YoloModelManager
from backend.algorithms.script.python_snippet import _validate_code, normalize_input_bindings
from backend.api.dependencies import (
    get_image_store,
    get_model_manager,
    get_user_id,
    require_workspace_run,
    require_workspace_view,
)
from backend.models.workflow import WorkflowRequest
from backend.services.image_store import ImageStore
from backend.services.python_snippet_debugger import (
    PythonSnippetDebugError,
    python_snippet_debug_manager,
)
from backend.services.workflow_debugger import workflow_debug_manager

router = APIRouter()


class PythonSnippetValidationRequest(BaseModel):
    code: str = Field(default="", max_length=200_000)
    input_bindings: list[dict[str, Any]] | None = Field(default=None, max_length=20)


class PythonSnippetDebugStartRequest(BaseModel):
    workflow: WorkflowRequest
    node_id: str = Field(min_length=1, max_length=100)
    breakpoints: list[int] = Field(default_factory=list, max_length=500)
    pause_on_start: bool = False


class PythonSnippetDebugCommandRequest(BaseModel):
    session_id: str = Field(min_length=1, max_length=200)
    action: Literal["continue", "step_into", "step_over", "step_out", "stop"]


class PythonSnippetDebugSessionRequest(BaseModel):
    session_id: str = Field(min_length=1, max_length=200)


def _target_names(target: ast.expr) -> list[str]:
    if isinstance(target, ast.Name):
        return [target.id]
    if isinstance(target, (ast.Tuple, ast.List)):
        names: list[str] = []
        for item in target.elts:
            names.extend(_target_names(item))
        return names
    return []


def _analyze_code(code: str, input_bindings: list[dict[str, Any]] | None = None) -> dict[str, Any]:
    tree = ast.parse(code or "", mode="exec")
    assigned: set[str] = set()
    has_process = False
    process_parameters: list[str] = []
    process_required_parameters: list[str] = []
    accepts_var_kwargs = False
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef) and node.name == "process":
            has_process = True
            positional = [*node.args.posonlyargs, *node.args.args]
            default_offset = len(positional) - len(node.args.defaults)
            for index, argument in enumerate(positional):
                process_parameters.append(argument.arg)
                if index < default_offset:
                    process_required_parameters.append(argument.arg)
            for argument, default in zip(node.args.kwonlyargs, node.args.kw_defaults, strict=False):
                process_parameters.append(argument.arg)
                if default is None:
                    process_required_parameters.append(argument.arg)
            accepts_var_kwargs = node.args.kwarg is not None
        elif isinstance(node, ast.Assign):
            for target in node.targets:
                assigned.update(_target_names(target))
        elif isinstance(node, ast.AnnAssign):
            assigned.update(_target_names(node.target))
        elif isinstance(node, ast.AugAssign):
            assigned.update(_target_names(node.target))

    output_names = [name for name in ["out", "image", "value", "metrics", "data", "result"] if name in assigned]
    warnings: list[str] = []
    bindings = normalize_input_bindings(input_bindings, strict=True)
    binding_names = {str(item["name"]) for item in bindings}
    special_names = {"inputs", "ports", "args", "params", "settings", "context", "input_meta"}
    if not has_process and not output_names:
        warnings.append("代码没有定义 process()，也没有给 out/image/value/metrics/data/result 赋值，运行后可能没有有效输出。")
    if "metrics" in assigned and "data" not in assigned:
        warnings.append("metrics 会显示在节点预览里；如需把结构化结果传给后续节点，建议同时写入 data。")
    if has_process and not accepts_var_kwargs:
        unresolved = [name for name in process_required_parameters if name not in binding_names and name not in special_names]
        if unresolved:
            warnings.append(f"process() 必填参数没有对应输入：{'、'.join(unresolved)}。运行时会报错。")
        unused = sorted(binding_names.difference(process_parameters))
        if unused:
            warnings.append(f"以下命名输入不会注入当前 process()：{'、'.join(unused)}；可添加同名参数或使用 **kwargs。")

    return {
        "line_count": len((code or "").splitlines()),
        "has_process": has_process,
        "process_parameters": process_parameters,
        "process_required_parameters": process_required_parameters,
        "accepts_var_kwargs": accepts_var_kwargs,
        "available_input_names": sorted(binding_names),
        "assigned_outputs": output_names,
        "warnings": warnings,
    }


@router.post("/python-snippet/validate")
def validate_python_snippet(payload: PythonSnippetValidationRequest, _workspace_id: str = Depends(require_workspace_view)):
    code = payload.code or ""
    try:
        _validate_code(code)
        bindings = normalize_input_bindings(payload.input_bindings, strict=True)
        analysis = _analyze_code(code, bindings)
        return {"success": True, "valid": True, "analysis": analysis}
    except Exception as exc:
        return JSONResponse(
            status_code=400,
            content={
                "success": False,
                "valid": False,
                "error": str(exc),
                "cause_type": type(exc).__name__,
            },
        )

def _debug_error_response(exc: Exception) -> JSONResponse:
    status_code = exc.status_code if isinstance(exc, PythonSnippetDebugError) else 400
    return JSONResponse(
        status_code=status_code,
        content={
            "success": False,
            "error": str(exc),
            "cause_type": type(exc).__name__,
        },
    )


@router.post("/python-snippet/debug/start")
def start_python_snippet_debug(
    payload: PythonSnippetDebugStartRequest,
    image_store: ImageStore = Depends(get_image_store),
    model_manager: YoloModelManager = Depends(get_model_manager),
    user_id: str = Depends(get_user_id),
    workspace_id: str = Depends(require_workspace_run),
):
    upstream_session = None
    try:
        upstream_session, node, inputs = workflow_debug_manager.prepare_node_inputs(
            payload.workflow,
            image_store,
            node_id=payload.node_id,
            user_id=user_id,
            workspace_id=workspace_id,
            model_manager=model_manager,
        )
        if node.type != "PythonSnippet":
            raise ValueError("断点调试仅支持 Python 自定义算子节点")
        code = str(node.params.get("code") or "")
        _validate_code(code)
        runtime_params = {key: value for key, value in node.params.items() if key != "code"}
        runtime_params["input_bindings"] = normalize_input_bindings(
            runtime_params.get("input_bindings"),
            strict=True,
        )
        try:
            timeout_ms = int(float(runtime_params.get("timeout_ms", 1000)))
        except (TypeError, ValueError):
            timeout_ms = 1000
        timeout_ms = max(1000, min(300_000, timeout_ms))
        context = upstream_session.context
        event = python_snippet_debug_manager.start(
            session_id=secrets.token_urlsafe(24),
            owner_id=user_id,
            workspace_id=workspace_id,
            code=code,
            inputs=dict(inputs),
            params=runtime_params,
            context_info={
                "image_id": context.image_id,
                "batch_index": context.batch_index,
                "batch_total": context.batch_total,
            },
            breakpoints=payload.breakpoints,
            pause_on_start=payload.pause_on_start,
            timeout_ms=timeout_ms,
        )
        return {"success": True, **event}
    except Exception as exc:
        return _debug_error_response(exc)
    finally:
        if upstream_session is not None:
            try:
                workflow_debug_manager.reset(
                    upstream_session.session_id,
                    user_id=user_id,
                    workspace_id=workspace_id,
                )
            except Exception:
                pass


@router.post("/python-snippet/debug/command")
def command_python_snippet_debug(
    payload: PythonSnippetDebugCommandRequest,
    user_id: str = Depends(get_user_id),
    workspace_id: str = Depends(require_workspace_run),
):
    try:
        event = python_snippet_debug_manager.command(
            payload.session_id,
            action=payload.action,
            owner_id=user_id,
            workspace_id=workspace_id,
        )
        return {"success": True, **event}
    except Exception as exc:
        return _debug_error_response(exc)


@router.post("/python-snippet/debug/status")
def python_snippet_debug_status(
    payload: PythonSnippetDebugSessionRequest,
    user_id: str = Depends(get_user_id),
    workspace_id: str = Depends(require_workspace_run),
):
    try:
        event = python_snippet_debug_manager.status(
            payload.session_id,
            owner_id=user_id,
            workspace_id=workspace_id,
        )
        return {"success": True, **event}
    except Exception as exc:
        return _debug_error_response(exc)


@router.post("/python-snippet/debug/stop")
def stop_python_snippet_debug(
    payload: PythonSnippetDebugSessionRequest,
    user_id: str = Depends(get_user_id),
    workspace_id: str = Depends(require_workspace_run),
):
    try:
        event = python_snippet_debug_manager.stop(
            payload.session_id,
            owner_id=user_id,
            workspace_id=workspace_id,
        )
        return {"success": True, **event}
    except Exception as exc:
        return _debug_error_response(exc)

