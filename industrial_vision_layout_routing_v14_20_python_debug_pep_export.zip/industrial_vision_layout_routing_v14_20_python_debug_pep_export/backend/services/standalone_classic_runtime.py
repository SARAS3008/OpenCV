"""Pure OpenCV runtime embedded into exported scripts for complex classic-vision nodes.

This module intentionally has no dependency on ``backend`` so its source can be copied
verbatim into a generated standalone script.
"""
from __future__ import annotations

import cv2
import numpy as np


def _as_int(value, default=0):
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return int(default)


def _as_float(value, default=0.0):
    try:
        return float(value)
    except (TypeError, ValueError):
        return float(default)


def _upper(value, default):
    text = str(default if value is None else value).strip().upper()
    return text or default


def _yes(value, default=False):
    if value is None:
        return bool(default)
    return str(value).strip().upper() in {"1", "TRUE", "YES", "Y", "是", "ON"}


def _ensure_bgr(image, color_space="BGR"):
    if image is None:
        raise ValueError("输入图像不能为空")
    if image.ndim == 2:
        return cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
    if image.ndim == 3 and image.shape[2] == 4:
        return cv2.cvtColor(image, cv2.COLOR_BGRA2BGR)
    if str(color_space or "BGR").upper() == "RGB":
        return cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
    return image.copy()


def _to_gray(image, color_space="BGR"):
    if image is None:
        raise ValueError("输入图像不能为空")
    if image.ndim == 2:
        return image
    if image.ndim == 3 and image.shape[2] == 4:
        return cv2.cvtColor(image, cv2.COLOR_BGRA2GRAY)
    if str(color_space or "BGR").upper() == "RGB":
        return cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
    return cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)


def _mask_to_binary(mask_image, threshold=1, invert=False, color_space="BGR"):
    gray = _to_gray(mask_image, color_space)
    threshold = int(np.clip(_as_int(threshold, 1), 0, 255))
    binary = cv2.threshold(gray.astype(np.uint8), threshold, 255, cv2.THRESH_BINARY)[1]
    return cv2.bitwise_not(binary) if invert else binary


def _selected_mask_bbox(binary_mask, mode="UNION"):
    contours, _ = cv2.findContours(binary_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return [0, 0, 0, 0]
    if _upper(mode, "UNION") == "LARGEST":
        x, y, w, h = cv2.boundingRect(max(contours, key=cv2.contourArea))
    else:
        x, y, w, h = cv2.boundingRect(np.vstack(contours))
    return [int(x), int(y), int(w), int(h)]


def _binary_from_input(image, color_space, params):
    gray = _to_gray(image, color_space)
    mode = _upper(params.get("binary_mode", "AUTO"), "AUTO")
    threshold = _as_int(params.get("threshold", 127), 127)
    if mode == "INPUT_BINARY":
        return ((gray > 0).astype(np.uint8)) * 255
    if mode == "THRESH_BINARY_INV":
        return cv2.threshold(gray, threshold, 255, cv2.THRESH_BINARY_INV)[1]
    if mode == "OTSU":
        return cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)[1]
    if mode == "OTSU_INV":
        return cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV | cv2.THRESH_OTSU)[1]
    if mode == "THRESH_BINARY":
        return cv2.threshold(gray, threshold, 255, cv2.THRESH_BINARY)[1]
    unique = np.unique(gray)
    if unique.size <= 4 and set(int(v) for v in unique.tolist()).issubset({0, 1, 255}):
        return ((gray > 0).astype(np.uint8)) * 255
    return cv2.threshold(gray, threshold, 255, cv2.THRESH_BINARY)[1]


def _contour_info(contour, index):
    area = float(cv2.contourArea(contour))
    perimeter = float(cv2.arcLength(contour, True))
    x, y, w, h = cv2.boundingRect(contour)
    bbox_area = float(w * h)
    hull_area = float(cv2.contourArea(cv2.convexHull(contour)))
    moments = cv2.moments(contour)
    if abs(moments.get("m00", 0.0)) > 1e-9:
        center_x = float(moments["m10"] / moments["m00"])
        center_y = float(moments["m01"] / moments["m00"])
    else:
        center_x = float(x + w / 2.0)
        center_y = float(y + h / 2.0)
    return {
        "index": int(index),
        "area": area,
        "perimeter": perimeter,
        "bbox": [int(x), int(y), int(w), int(h)],
        "bbox_width": int(w),
        "bbox_height": int(h),
        "bbox_area": bbox_area,
        "aspect_ratio": float(w / h) if h else 0.0,
        "extent": float(area / bbox_area) if bbox_area else 0.0,
        "solidity": float(area / hull_area) if hull_area else 0.0,
        "circularity": float((4.0 * np.pi * area) / (perimeter * perimeter)) if perimeter else 0.0,
        "center": [center_x, center_y],
        "center_x": center_x,
        "center_y": center_y,
    }


def _passes_range(value, minimum, maximum):
    return value >= minimum and (maximum <= 0 or value <= maximum)


def _json_contour(contour, max_points):
    points = contour.reshape(-1, 2)
    if max_points > 0 and len(points) > max_points:
        step = max(1, int(np.ceil(len(points) / float(max_points))))
        points = points[::step][:max_points]
    return [[int(x), int(y)] for x, y in points]


def run_filter_contours_node(image, color_space, params):
    binary = _binary_from_input(image, color_space, params)
    retrieval = {
        "EXTERNAL": cv2.RETR_EXTERNAL,
        "LIST": cv2.RETR_LIST,
        "CCOMP": cv2.RETR_CCOMP,
        "TREE": cv2.RETR_TREE,
    }.get(_upper(params.get("retrieval_mode", "EXTERNAL"), "EXTERNAL"), cv2.RETR_EXTERNAL)
    approximation = {
        "SIMPLE": cv2.CHAIN_APPROX_SIMPLE,
        "NONE": cv2.CHAIN_APPROX_NONE,
    }.get(_upper(params.get("approx_mode", "SIMPLE"), "SIMPLE"), cv2.CHAIN_APPROX_SIMPLE)
    contours, _ = cv2.findContours(binary, retrieval, approximation)
    all_items = [(contour, _contour_info(contour, index)) for index, contour in enumerate(contours)]

    ranges = {
        "area": (_as_float(params.get("min_area", 0), 0), _as_float(params.get("max_area", 0), 0)),
        "perimeter": (_as_float(params.get("min_perimeter", 0), 0), _as_float(params.get("max_perimeter", 0), 0)),
        "bbox_width": (_as_float(params.get("min_width", 0), 0), _as_float(params.get("max_width", 0), 0)),
        "bbox_height": (_as_float(params.get("min_height", 0), 0), _as_float(params.get("max_height", 0), 0)),
    }
    filtered = []
    for contour, info in all_items:
        if all(_passes_range(float(info[key]), limits[0], limits[1]) for key, limits in ranges.items()):
            filtered.append((contour, info))

    sort_by = str(params.get("sort_by", "area") or "area").strip()
    valid_sort_fields = {
        "area", "perimeter", "bbox_width", "bbox_height", "bbox_area", "aspect_ratio",
        "circularity", "solidity", "extent", "center_x", "center_y",
    }
    if sort_by not in valid_sort_fields:
        sort_by = "area"
    select_mode = _upper(params.get("select_mode", "MAX"), "MAX")
    if select_mode in {"MIN", "BOTTOM_K"}:
        descending = False
    elif select_mode in {"MAX", "TOP_K"}:
        descending = True
    else:
        descending = _upper(params.get("sort_order", "DESC"), "DESC") != "ASC"
    ordered = sorted(filtered, key=lambda item: float(item[1].get(sort_by, 0.0)), reverse=descending)
    if select_mode in {"MAX", "MIN"}:
        selected = ordered[:1]
    elif select_mode in {"TOP_K", "BOTTOM_K"}:
        selected = ordered[:max(1, _as_int(params.get("top_k", 1), 1))]
    elif select_mode == "NTH":
        index = max(0, _as_int(params.get("nth_index", 0), 0))
        selected = ordered[index:index + 1]
    elif select_mode == "ALL_SORTED":
        selected = ordered
    else:
        selected = ordered[:1]

    selected_contours = [item[0] for item in selected]
    selected_infos = [item[1] for item in selected]
    selected_mask = np.zeros(binary.shape[:2], dtype=np.uint8)
    if selected_contours:
        cv2.drawContours(selected_mask, selected_contours, -1, 255, thickness=cv2.FILLED)

    if selected_infos:
        height, width = selected_mask.shape[:2]
        x1 = int(np.clip(min(info["bbox"][0] for info in selected_infos), 0, width))
        y1 = int(np.clip(min(info["bbox"][1] for info in selected_infos), 0, height))
        x2 = int(np.clip(max(info["bbox"][0] + info["bbox"][2] for info in selected_infos), 0, width))
        y2 = int(np.clip(max(info["bbox"][1] + info["bbox"][3] for info in selected_infos), 0, height))
        bbox = [x1, y1, max(0, x2 - x1), max(0, y2 - y1)]
    else:
        bbox = [0, 0, 0, 0]
    x, y, w, h = bbox
    image_bgr = _ensure_bgr(image, color_space)
    roi = image_bgr[y:y + h, x:x + w].copy() if w > 0 and h > 0 else np.zeros((0, 0, 3), dtype=np.uint8)
    roi_mask = selected_mask[y:y + h, x:x + w].copy() if w > 0 and h > 0 else np.zeros((0, 0), dtype=np.uint8)

    canvas = image_bgr.copy()
    if _yes(params.get("draw_all", "YES"), True) and filtered:
        cv2.drawContours(canvas, [item[0] for item in filtered], -1, (120, 120, 120), 1)
    if selected_contours:
        cv2.drawContours(canvas, selected_contours, -1, (0, 255, 0), 2)
        if w > 0 and h > 0:
            cv2.rectangle(canvas, (x, y), (x + w, y + h), (0, 180, 255), 2)
        for rank, info in enumerate(selected_infos, start=1):
            cx, cy = info["center"]
            cv2.circle(canvas, (int(round(cx)), int(round(cy))), 3, (0, 0, 255), -1)
            cv2.putText(canvas, f"#{rank}", (int(info["bbox"][0]), max(16, int(info["bbox"][1]) - 4)), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 220, 255), 1, cv2.LINE_AA)
    cv2.putText(canvas, f"selected: {len(selected_infos)}/{len(filtered)} by {sort_by}", (12, 28), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 220, 255), 2, cv2.LINE_AA)

    max_points = max(0, _as_int(params.get("max_points", 200), 200))
    selected_points = [_json_contour(contour, max_points) for contour in selected_contours]
    rounded_infos = []
    for info in selected_infos:
        rounded = dict(info)
        for key in ("area", "perimeter", "bbox_area", "aspect_ratio", "extent", "solidity", "circularity", "center_x", "center_y"):
            rounded[key] = round(float(rounded.get(key, 0.0)), 6)
        rounded["center"] = [round(float(value), 6) for value in rounded.get("center", [])]
        rounded_infos.append(rounded)
    selected_areas = [float(info["area"]) for info in selected_infos]
    metrics = {
        "contour_total": len(all_items),
        "contour_filtered": len(filtered),
        "selected_count": len(selected),
        "selected_area_total": round(sum(selected_areas), 4),
        "selected_area_max": round(max(selected_areas, default=0.0), 4),
        "selected_area_min": round(min(selected_areas, default=0.0), 4),
        "selected_bbox_x": bbox[0], "selected_bbox_y": bbox[1], "selected_bbox_w": bbox[2], "selected_bbox_h": bbox[3],
        "sort_by": sort_by, "select_mode": select_mode,
    }
    if rounded_infos:
        primary = rounded_infos[0]
        metrics.update({
            "primary_area": round(float(primary.get("area", 0.0)), 4),
            "primary_perimeter": round(float(primary.get("perimeter", 0.0)), 4),
            "primary_circularity": round(float(primary.get("circularity", 0.0)), 6),
            "primary_solidity": round(float(primary.get("solidity", 0.0)), 6),
        })
    return {
        "out": canvas, "out_color_space": "BGR",
        "mask": selected_mask, "mask_color_space": "GRAY",
        "roi": roi, "roi_color_space": "BGR",
        "roi_mask": roi_mask, "roi_mask_color_space": "GRAY",
        "bbox": bbox,
        "contour": selected_points[0] if selected_points else [],
        "contours": selected_points,
        "contour_infos": rounded_infos,
        "metrics": metrics,
        "data": {"bbox": bbox, "contour": selected_points[0] if selected_points else [], "contours": selected_points, "contour_infos": rounded_infos},
    }


def _order_box_points(points):
    points = np.asarray(points, dtype=np.float32).reshape(4, 2)
    by_y = points[np.lexsort((points[:, 0], points[:, 1]))]
    top = by_y[:2][np.argsort(by_y[:2, 0])]
    bottom = by_y[2:][np.argsort(by_y[2:, 0])]
    tl, tr = top[0], top[1]
    bl, br = bottom[0], bottom[1]
    return np.array([tl, tr, br, bl], dtype=np.float32)


def _line_from_points(p1, p2):
    x1, y1 = float(p1[0]), float(p1[1])
    x2, y2 = float(p2[0]), float(p2[1])
    dx, dy = x2 - x1, y2 - y1
    return {
        "p1": [round(x1, 3), round(y1, 3)],
        "p2": [round(x2, 3), round(y2, 3)],
        "length": round(float(np.hypot(dx, dy)), 6),
        "abc": [round(y1 - y2, 9), round(x2 - x1, 9), round(x1 * y2 - x2 * y1, 9)],
    }


def _rect_dict(points, angle=None):
    ordered = _order_box_points(points)
    tl, tr, br, bl = ordered
    top_len = float(np.linalg.norm(tr - tl))
    bottom_len = float(np.linalg.norm(br - bl))
    left_len = float(np.linalg.norm(bl - tl))
    right_len = float(np.linalg.norm(br - tr))
    width = (top_len + bottom_len) / 2.0
    height = (left_len + right_len) / 2.0
    center = ordered.mean(axis=0)
    visual_angle = float(np.degrees(np.arctan2((tr - tl)[1], (tr - tl)[0])))
    raw_points = [[round(float(x), 3), round(float(y), 3)] for x, y in ordered]
    points_int = [[int(round(float(x))), int(round(float(y)))] for x, y in ordered]
    lines = {
        "top": [points_int[0], points_int[1]],
        "right": [points_int[1], points_int[2]],
        "bottom": [points_int[3], points_int[2]],
        "left": [points_int[0], points_int[3]],
    }
    return {
        "center": [round(float(center[0]), 3), round(float(center[1]), 3)],
        "center_pixel": [int(round(float(center[0]))), int(round(float(center[1])))],
        "size": [round(width, 3), round(height, 3)],
        "width": round(width, 3), "height": round(height, 3),
        "angle": round(visual_angle, 6),
        "opencv_angle": round(float(angle) if angle is not None else visual_angle, 6),
        "points": points_int, "raw_points": raw_points,
        "top_left": points_int[0], "top_right": points_int[1], "bottom_right": points_int[2], "bottom_left": points_int[3],
        "raw_top_left": raw_points[0], "raw_top_right": raw_points[1], "raw_bottom_right": raw_points[2], "raw_bottom_left": raw_points[3],
        "lines": lines,
        "raw_lines": {name: [raw_points[points_int.index(pair[0])], raw_points[points_int.index(pair[1])]] for name, pair in lines.items()},
    }


def _rect_from_value(value, params):
    if isinstance(value, dict):
        if isinstance(value.get("rect"), dict):
            return _rect_from_value(value["rect"], params)
        if value.get("points") is not None:
            points = np.asarray(value["points"], dtype=np.float32).reshape(-1, 2)
            if len(points) >= 4:
                return _rect_dict(points[:4], value.get("angle"))
        if {"center", "size", "angle"}.issubset(value):
            center, size = value["center"], value["size"]
            return _rect_dict(cv2.boxPoints(((float(center[0]), float(center[1])), (float(size[0]), float(size[1])), float(value["angle"]))), float(value["angle"]))
        if {"center_x", "center_y", "width", "height", "angle"}.issubset(value):
            angle = float(value["angle"])
            return _rect_dict(cv2.boxPoints(((float(value["center_x"]), float(value["center_y"])), (float(value["width"]), float(value["height"])), angle)), angle)
    if isinstance(value, (list, tuple, np.ndarray)):
        array = np.asarray(value, dtype=np.float32)
        if array.size >= 8:
            return _rect_dict(array.reshape(-1, 2)[:4])
    cx = _as_float(params.get("center_x", 0), 0)
    cy = _as_float(params.get("center_y", 0), 0)
    width = max(0.0, _as_float(params.get("width", 0), 0))
    height = max(0.0, _as_float(params.get("height", 0), 0))
    angle = _as_float(params.get("angle", 0), 0)
    if width <= 0 or height <= 0:
        raise ValueError("未连接 rect 输入时，需要填写 width 和 height 参数")
    return _rect_dict(cv2.boxPoints(((cx, cy), (width, height), angle)), angle)


def run_mask_min_area_rect_node(mask_image, color_space, params):
    binary = _mask_to_binary(mask_image, params.get("threshold", 1), _yes(params.get("invert_mask", "NO")), color_space)
    contours, _ = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    canvas = _ensure_bgr(mask_image, color_space)
    if not contours:
        return {"out": canvas, "out_color_space": "BGR", "rect": {}, "points": [], "top_left": [], "top_right": [], "bottom_left": [], "bottom_right": [], "lines": {}, "angle": 0.0, "center": [], "size": [], "data": {"found": False}, "metrics": {"found": False, "area": 0.0}}
    if _upper(params.get("select_mode", "UNION"), "UNION") == "LARGEST":
        points = max(contours, key=cv2.contourArea).reshape(-1, 2).astype(np.float32)
    else:
        points = np.vstack(contours).reshape(-1, 2).astype(np.float32)
    rect_tuple = cv2.minAreaRect(points)
    rect = _rect_dict(cv2.boxPoints(rect_tuple), rect_tuple[2])
    rect["image_shape"] = [int(binary.shape[0]), int(binary.shape[1])]
    rect["coordinate_order"] = "XY"
    cv2.polylines(canvas, [np.int32(np.asarray(rect["points"]).reshape(-1, 1, 2))], True, (0, 255, 0), 2, cv2.LINE_AA)
    for label, point in (("TL", rect["top_left"]), ("TR", rect["top_right"]), ("BR", rect["bottom_right"]), ("BL", rect["bottom_left"])):
        cv2.circle(canvas, tuple(point), 4, (0, 0, 255), -1, cv2.LINE_AA)
        cv2.putText(canvas, label, (point[0] + 4, point[1] - 4), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0, 220, 255), 1, cv2.LINE_AA)
    result = {key: rect[key] for key in ("points", "top_left", "top_right", "bottom_left", "bottom_right", "lines", "angle", "center", "size")}
    result.update({
        "out": canvas, "out_color_space": "BGR", "rect": rect,
        "data": {"found": True, "rect": rect, **result},
        "metrics": {"found": True, "area": round(float(rect_tuple[1][0] * rect_tuple[1][1]), 4), "width": rect["width"], "height": rect["height"], "angle": rect["angle"]},
    })
    return result


def run_rotated_rect_feature_node(rect_value, image, image_color_space, params):
    rect = _rect_from_value(rect_value, params)
    feature_type = _upper(params.get("feature_type", "POINT"), "POINT")
    point_name = _upper(params.get("point", "TOP_LEFT"), "TOP_LEFT")
    line_name = _upper(params.get("line", "TOP"), "TOP")
    point_map = {
        "TOP_LEFT": rect["top_left"], "LEFT_TOP": rect["top_left"],
        "TOP_RIGHT": rect["top_right"], "RIGHT_TOP": rect["top_right"],
        "BOTTOM_LEFT": rect["bottom_left"], "LEFT_BOTTOM": rect["bottom_left"],
        "BOTTOM_RIGHT": rect["bottom_right"], "RIGHT_BOTTOM": rect["bottom_right"],
    }
    line_map = {"TOP": rect["lines"]["top"], "RIGHT": rect["lines"]["right"], "BOTTOM": rect["lines"]["bottom"], "LEFT": rect["lines"]["left"]}
    selected_point = point_map.get(point_name, rect["top_left"])
    selected_line_points = line_map.get(line_name, rect["lines"]["top"])
    selected_line = _line_from_points(selected_line_points[0], selected_line_points[1])
    selected = selected_point if feature_type == "POINT" else selected_line
    if isinstance(image, np.ndarray):
        canvas = _ensure_bgr(image, image_color_space)
    else:
        points = np.asarray(rect["points"], dtype=np.float32)
        canvas = np.zeros((max(160, int(np.ceil(np.max(points[:, 1]) + 40))), max(200, int(np.ceil(np.max(points[:, 0]) + 40))), 3), dtype=np.uint8)
    cv2.polylines(canvas, [np.int32(np.asarray(rect["points"]).reshape(-1, 1, 2))], True, (80, 180, 255), 1, cv2.LINE_AA)
    if feature_type == "POINT":
        cv2.circle(canvas, tuple(int(round(v)) for v in selected_point), 5, (0, 0, 255), -1, cv2.LINE_AA)
    else:
        cv2.line(canvas, tuple(int(round(v)) for v in selected_line["p1"]), tuple(int(round(v)) for v in selected_line["p2"]), (0, 255, 0), 2, cv2.LINE_AA)
    lines = {name: _line_from_points(pair[0], pair[1]) for name, pair in rect["lines"].items()}
    return {"out": canvas, "out_color_space": "BGR", "selected": selected, "point": selected_point, "line": selected_line, "points": rect["points"], "lines": lines, "rect": rect, "data": {"selected": selected, "point": selected_point, "line": selected_line, "rect": rect}, "metrics": {"feature_type": feature_type, "point": point_name, "line": line_name}}


def run_apply_mask_node(image, image_color_space, mask_image, mask_color_space, params):
    image_bgr = _ensure_bgr(image, image_color_space)
    binary = _mask_to_binary(mask_image, params.get("threshold", 1), _yes(params.get("invert_mask", "NO")), mask_color_space)
    if binary.shape[:2] != image_bgr.shape[:2]:
        if _yes(params.get("resize_mask", "NO")):
            binary = cv2.resize(binary, (image_bgr.shape[1], image_bgr.shape[0]), interpolation=cv2.INTER_NEAREST)
        else:
            raise ValueError(f"mask 尺寸 {binary.shape[:2]} 与原图尺寸 {image_bgr.shape[:2]} 不一致；可开启 resize_mask")
    if _upper(params.get("background", "BLACK"), "BLACK") == "WHITE":
        masked = np.full_like(image_bgr, 255)
        masked[binary > 0] = image_bgr[binary > 0]
    else:
        masked = cv2.bitwise_and(image_bgr, image_bgr, mask=binary)
    bbox = _selected_mask_bbox(binary, _upper(params.get("bbox_mode", "UNION"), "UNION"))
    x, y, w, h = bbox
    roi = masked[y:y + h, x:x + w].copy() if w > 0 and h > 0 else np.zeros((0, 0, 3), dtype=np.uint8)
    roi_mask = binary[y:y + h, x:x + w].copy() if w > 0 and h > 0 else np.zeros((0, 0), dtype=np.uint8)
    mode = _upper(params.get("output_mode", "MASKED"), "MASKED")
    if mode == "ROI":
        out, out_color = roi, "BGR"
    elif mode == "ROI_MASK":
        out, out_color = roi_mask, "GRAY"
    elif mode == "MASK":
        out, out_color = binary, "GRAY"
    else:
        out, out_color = masked, "BGR"
    mask_pixels = int(np.count_nonzero(binary))
    ratio = mask_pixels / float(binary.size or 1)
    return {"out": out, "out_color_space": out_color, "masked": masked, "masked_color_space": "BGR", "mask": binary, "mask_color_space": "GRAY", "roi": roi, "roi_color_space": "BGR", "roi_mask": roi_mask, "roi_mask_color_space": "GRAY", "bbox": bbox, "data": {"bbox": bbox, "mask_pixels": mask_pixels, "mask_ratio": ratio}, "metrics": {"mask_pixels": mask_pixels, "mask_ratio": round(ratio, 6), "bbox_x": bbox[0], "bbox_y": bbox[1], "bbox_w": bbox[2], "bbox_h": bbox[3]}}


def _line_endpoints_from_abc(a, b, c, width, height):
    candidates = []
    if abs(b) > 1e-12:
        candidates.extend([(0.0, -c / b), (float(width - 1), -(a * (width - 1) + c) / b)])
    if abs(a) > 1e-12:
        candidates.extend([(-c / a, 0.0), (-(b * (height - 1) + c) / a, float(height - 1))])
    in_bounds = [(x, y) for x, y in candidates if -1 <= x <= width and -1 <= y <= height]
    points = in_bounds[:2] if len(in_bounds) >= 2 else candidates[:2]
    if len(points) < 2:
        points = [(0.0, 0.0), (float(width - 1), 0.0)]
    return [[int(round(np.clip(x, 0, width - 1))), int(round(np.clip(y, 0, height - 1)))] for x, y in points]


def run_fit_line_from_edges_node(edge_image, color_space, params):
    gray = _to_gray(edge_image, color_space)
    threshold = _as_int(params.get("threshold", 1), 1)
    max_points = max(0, _as_int(params.get("max_points", 5000), 5000))
    min_points = max(2, _as_int(params.get("min_points", 20), 20))
    binary = cv2.threshold(gray.astype(np.uint8), threshold, 255, cv2.THRESH_BINARY)[1]
    ys, xs = np.nonzero(binary)
    canvas = _ensure_bgr(edge_image, color_space)
    if len(xs) < min_points:
        return {"out": canvas, "out_color_space": "BGR", "line": {}, "p1": [], "p2": [], "abc": [], "angle": 0.0, "data": {"found": False}, "metrics": {"found": False, "point_count": int(len(xs))}}
    points = np.column_stack([xs, ys]).astype(np.float32)
    if max_points and len(points) > max_points:
        step = max(1, int(np.ceil(len(points) / float(max_points))))
        points = points[::step][:max_points]
    distance_type = {
        "L1": cv2.DIST_L1, "L2": cv2.DIST_L2, "L12": cv2.DIST_L12,
        "FAIR": cv2.DIST_FAIR, "WELSCH": cv2.DIST_WELSCH, "HUBER": cv2.DIST_HUBER,
    }.get(_upper(params.get("distance_type", "L2"), "L2"), cv2.DIST_L2)
    vx, vy, x0, y0 = [float(value) for value in cv2.fitLine(points, distance_type, 0, 0.01, 0.01).reshape(-1)]
    a, b, c = -vy, vx, vy * x0 - vx * y0
    h, w = gray.shape[:2]
    p1, p2 = _line_endpoints_from_abc(a, b, c, w, h)
    angle = round(float(np.degrees(np.arctan2(vy, vx))), 6)
    line = {"p1": p1, "p2": p2, "abc": [round(a, 9), round(b, 9), round(c, 9)], "image_shape": [int(h), int(w)], "coordinate_order": "XY", "vx": round(vx, 9), "vy": round(vy, 9), "x0": round(x0, 6), "y0": round(y0, 6), "angle": angle}
    if _yes(params.get("draw_points", "NO")):
        canvas[binary > 0] = (80, 80, 80)
    cv2.line(canvas, tuple(p1), tuple(p2), (0, 255, 0), 2, cv2.LINE_AA)
    cv2.circle(canvas, (int(round(x0)), int(round(y0))), 4, (0, 0, 255), -1, cv2.LINE_AA)
    return {"out": canvas, "out_color_space": "BGR", "line": line, "p1": p1, "p2": p2, "abc": line["abc"], "angle": angle, "data": {"found": True, "line": line, "point_count": int(len(points))}, "metrics": {"found": True, "point_count": int(len(points)), "angle": angle, "vx": line["vx"], "vy": line["vy"]}}
