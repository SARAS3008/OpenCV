from __future__ import annotations

import threading
import uuid
from collections import OrderedDict
from dataclasses import dataclass, field
from datetime import datetime, timezone
from time import monotonic
from typing import Any, Callable

RunEventCallback = Callable[[dict[str, Any]], None]


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


class WorkflowRunControlError(RuntimeError):
    def __init__(self, message: str, *, status_code: int = 404) -> None:
        super().__init__(message)
        self.status_code = status_code


@dataclass(slots=True)
class WorkflowRunControl:
    run_id: str
    user_id: str
    workspace_id: str
    event_callback: RunEventCallback | None = None
    created_at: str = field(default_factory=_utc_now)
    touched_at: float = field(default_factory=monotonic)
    state: str = "running"
    pause_requested: bool = False
    cancel_requested: bool = False
    _pause_announced: bool = False
    _condition: threading.Condition = field(default_factory=threading.Condition)

    def _touch(self) -> None:
        self.touched_at = monotonic()

    def _emit(self, event: str, *, level: str = "info", message: str, **payload: Any) -> None:
        callback = self.event_callback
        if callback is None:
            return
        callback(
            {
                "event": event,
                "level": level,
                "message": message,
                "timestamp": _utc_now(),
                "run_id": self.run_id,
                **payload,
            }
        )

    def pause(self) -> dict[str, Any]:
        with self._condition:
            if self.state in {"completed", "failed", "cancelled"}:
                raise WorkflowRunControlError("当前整体运行已经结束", status_code=409)
            if self.cancel_requested:
                raise WorkflowRunControlError("当前整体运行正在结束", status_code=409)
            self.pause_requested = True
            if self.state != "paused":
                self.state = "pause_requested"
            self._touch()
            self._condition.notify_all()
            return self.snapshot()

    def resume(self) -> dict[str, Any]:
        with self._condition:
            if self.state in {"completed", "failed", "cancelled"}:
                raise WorkflowRunControlError("当前整体运行已经结束", status_code=409)
            if self.cancel_requested:
                raise WorkflowRunControlError("当前整体运行正在结束", status_code=409)
            self.pause_requested = False
            self.state = "running"
            self._touch()
            self._condition.notify_all()
            return self.snapshot()

    def cancel(self) -> dict[str, Any]:
        with self._condition:
            if self.state in {"completed", "failed", "cancelled"}:
                return self.snapshot()
            self.cancel_requested = True
            self.pause_requested = False
            self.state = "cancel_requested"
            self._touch()
            self._condition.notify_all()
            return self.snapshot()

    def is_cancelled(self) -> bool:
        with self._condition:
            return self.cancel_requested

    def checkpoint(self) -> None:
        """Pause at a safe scheduling boundary and return after resume.

        Synchronous image/model operators are not preempted. The caller reaches
        this checkpoint before/after a node and between batch images.
        """

        announce_pause = False
        announce_resume = False
        with self._condition:
            self._touch()
            while self.pause_requested and not self.cancel_requested:
                if not self._pause_announced:
                    self._pause_announced = True
                    self.state = "paused"
                    announce_pause = True
                    break
                self._condition.wait(timeout=0.25)
                self._touch()

        if announce_pause:
            self._emit(
                "workflow_paused",
                level="warning",
                message="整体运行已暂停，可点击继续运行从当前进度恢复",
            )

        with self._condition:
            while self.pause_requested and not self.cancel_requested:
                self._condition.wait(timeout=0.25)
                self._touch()
            if self._pause_announced and not self.cancel_requested:
                self._pause_announced = False
                self.state = "running"
                announce_resume = True
            elif self.cancel_requested:
                self._pause_announced = False

        if announce_resume:
            self._emit(
                "workflow_resumed",
                level="success",
                message="整体运行已继续",
            )

    def finish(self, state: str) -> None:
        with self._condition:
            self.pause_requested = False
            if state == "cancelled":
                self.cancel_requested = True
            self.state = state
            self._pause_announced = False
            self._touch()
            self._condition.notify_all()

    def snapshot(self) -> dict[str, Any]:
        return {
            "run_id": self.run_id,
            "state": self.state,
            "pause_requested": self.pause_requested,
            "paused": self.state == "paused",
            "cancel_requested": self.cancel_requested,
            "created_at": self.created_at,
        }


class WorkflowRunManager:
    def __init__(self, *, max_runs: int = 200, ttl_seconds: float = 900.0) -> None:
        self.max_runs = max(1, int(max_runs))
        self.ttl_seconds = max(30.0, float(ttl_seconds))
        self._lock = threading.RLock()
        self._runs: OrderedDict[str, WorkflowRunControl] = OrderedDict()

    def _cleanup_locked(self) -> None:
        now = monotonic()
        expired = [
            run_id
            for run_id, control in self._runs.items()
            if control.state in {"completed", "failed", "cancelled"}
            and now - control.touched_at > self.ttl_seconds
        ]
        for run_id in expired:
            self._runs.pop(run_id, None)
        while len(self._runs) >= self.max_runs:
            removable = next(
                (run_id for run_id, control in self._runs.items() if control.state in {"completed", "failed", "cancelled"}),
                None,
            )
            if removable is None:
                raise WorkflowRunControlError("当前活动运行数量已达到上限，请稍后再试", status_code=429)
            self._runs.pop(removable, None)

    def create(self, *, user_id: str, workspace_id: str, event_callback: RunEventCallback | None = None) -> WorkflowRunControl:
        with self._lock:
            self._cleanup_locked()
            control = WorkflowRunControl(
                run_id=uuid.uuid4().hex,
                user_id=user_id,
                workspace_id=workspace_id,
                event_callback=event_callback,
            )
            self._runs[control.run_id] = control
            return control

    def _get(self, run_id: str, *, user_id: str, workspace_id: str) -> WorkflowRunControl:
        with self._lock:
            self._cleanup_locked()
            control = self._runs.get(run_id)
            if control is None:
                raise WorkflowRunControlError("整体运行会话不存在或已过期", status_code=404)
            if control.user_id != user_id or control.workspace_id != workspace_id:
                raise WorkflowRunControlError("无权控制该整体运行", status_code=403)
            self._runs.move_to_end(run_id)
            return control

    def pause(self, run_id: str, *, user_id: str, workspace_id: str) -> dict[str, Any]:
        return self._get(run_id, user_id=user_id, workspace_id=workspace_id).pause()

    def resume(self, run_id: str, *, user_id: str, workspace_id: str) -> dict[str, Any]:
        return self._get(run_id, user_id=user_id, workspace_id=workspace_id).resume()

    def cancel(self, run_id: str, *, user_id: str, workspace_id: str) -> dict[str, Any]:
        return self._get(run_id, user_id=user_id, workspace_id=workspace_id).cancel()

    def status(self, run_id: str, *, user_id: str, workspace_id: str) -> dict[str, Any]:
        return self._get(run_id, user_id=user_id, workspace_id=workspace_id).snapshot()

    def clear(self) -> None:
        with self._lock:
            controls = list(self._runs.values())
            self._runs.clear()
        for control in controls:
            control.cancel()


workflow_run_manager = WorkflowRunManager()
