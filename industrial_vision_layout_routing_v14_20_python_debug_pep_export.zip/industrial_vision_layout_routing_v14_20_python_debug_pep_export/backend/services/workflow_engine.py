from __future__ import annotations

import base64
import csv
import json
from collections import defaultdict, deque
from datetime import datetime
from pathlib import Path
from time import perf_counter
from typing import Any, Callable

import cv2
import numpy as np

from backend.algorithms.registry import OPERATORS, OPERATOR_META
from backend.algorithms.types import ExecutionContext
from backend.models.workflow import WorkflowEdge, WorkflowNode, WorkflowRequest
from backend.services.image_store import ImageStore
from backend.algorithms.ai.yolo.model_manager import YoloModelManager
from backend.services.node_executor import ExecutionCancelledError, NodeExecutor
from backend.config import NODE_MAX_IMAGE_PIXELS, NODE_MAX_INPUT_BYTES, NODE_MAX_OUTPUT_BYTES, PREVIEW_MAX_SIDE


WorkflowEventCallback = Callable[[dict[str, Any]], None]


def _emit_event(callback: WorkflowEventCallback | None, event: str, *, level: str = "info", message: str = "", **payload: Any) -> None:
    """向可选的实时日志消费者发送轻量事件。

    日志回调属于观察能力，任何回调异常都不能影响工作流本身。事件中不携带
    图像或大块 metrics/data，避免流式通道被结果数据阻塞。
    """

    if callback is None:
        return
    item = {
        "event": event,
        "level": level,
        "timestamp": datetime.now().astimezone().isoformat(timespec="seconds"),
        "message": message,
        **payload,
    }
    try:
        callback(item)
    except Exception:
        return


class WorkflowExecutionError(ValueError):
    """工作流节点执行失败，并携带已经完成的执行现场。"""

    def __init__(
        self,
        message: str,
        *,
        node_id: str,
        node_type: str,
        node_label: str,
        order: list[str],
        executed_order: list[str],
        previews: list[dict[str, Any]],
        cause_type: str = "",
    ) -> None:
        super().__init__(message)
        self.node_id = node_id
        self.node_type = node_type
        self.node_label = node_label
        self.order = list(order)
        self.executed_order = list(executed_order)
        self.previews = list(previews)
        self.cause_type = cause_type
        self.debug_session_id: str | None = None
        self.workflow_signature: str = ""
        self.debug_next_node_id: str | None = None

    @property
    def pending_nodes(self) -> list[str]:
        completed = set(self.executed_order)
        completed.add(self.node_id)
        return [node_id for node_id in self.order if node_id not in completed]

    def to_response(self) -> dict[str, Any]:
        failed_preview = {
            "node_id": self.node_id,
            "type": self.node_type,
            "label": self.node_label,
            "result_type": "error",
            "status": "error",
            "error": str(self),
            "metrics": {},
            "data": {},
        }
        return {
            "success": False,
            "error": str(self),
            "mode": "single",
            "stage": "node_execution",
            "order": self.order,
            "executed_order": self.executed_order,
            "pending_nodes": self.pending_nodes,
            "previews": [*self.previews, failed_preview],
            "failed_node": {
                "node_id": self.node_id,
                "type": self.node_type,
                "label": self.node_label,
                "error": str(self),
                "cause_type": self.cause_type,
            },
        }


def image_to_data_url(image: np.ndarray, color_space: str = "BGR") -> str:
    if image is None:
        return ""
    if image.dtype != np.uint8:
        image = np.clip(image, 0, 255).astype(np.uint8)
    encode_image = image
    if image.ndim == 3 and str(color_space).upper() == "RGB":
        encode_image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
    ok, buffer = cv2.imencode(".png", encode_image)
    if not ok:
        raise ValueError("图像编码失败")
    encoded = base64.b64encode(buffer.tobytes()).decode("utf-8")
    return f"data:image/png;base64,{encoded}"




def _json_safe_value(value: Any, path: str = "result") -> Any:
    """把节点结果限制为可安全返回给浏览器的 JSON 数据。

    图像数组只能通过算子的图像输出端口传递，不能混入 metrics/data。
    这样可在具体节点执行阶段抛出错误，并保留此前节点的预览，而不是
    等 FastAPI 序列化整个响应时才产生无法定位的 HTTP 500。
    """

    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, np.ndarray):
        raise ValueError(
            f"{path} 包含图像/数组数据，不能作为数值结果返回；"
            "请把图像放在 out 输出端口，把统计值放在 metrics 或独立数值输出端口"
        )
    if isinstance(value, Path):
        return str(value)
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, dict):
        return {
            str(key): _json_safe_value(child, f"{path}.{key}")
            for key, child in value.items()
        }
    if isinstance(value, (list, tuple, set)):
        return [
            _json_safe_value(child, f"{path}[{index}]")
            for index, child in enumerate(value)
        ]
    raise ValueError(f"{path} 包含无法序列化的结果类型：{type(value).__name__}")


def _parameter_fallback_handles(metadata: dict[str, Any]) -> set[str]:
    """返回可由节点参数兜底的输入端口。

    算子元数据可以在 param_schema 中用 ``fallback_for`` 声明某个参数在
    对应输入端口未连接时生效。执行器必须在必需端口校验阶段识别该声明，
    否则算子内部的手动参数兜底永远没有机会执行。
    """

    schema = metadata.get("param_schema")
    if not isinstance(schema, dict):
        return set()
    handles: set[str] = set()
    for definition in schema.values():
        if not isinstance(definition, dict):
            continue
        raw = definition.get("fallback_for")
        if isinstance(raw, str) and raw.strip():
            handles.add(raw.strip())
        elif isinstance(raw, (list, tuple, set)):
            handles.update(str(item).strip() for item in raw if str(item).strip())
    return handles


def topological_sort(nodes: list[WorkflowNode], edges: list[WorkflowEdge]) -> list[str]:
    node_ids = [node.id for node in nodes]
    if len(node_ids) != len(set(node_ids)):
        raise ValueError("节点 ID 不能重复")

    node_set = set(node_ids)
    indegree = {node_id: 0 for node_id in node_ids}
    graph: dict[str, list[str]] = {node_id: [] for node_id in node_ids}

    for edge in edges:
        if edge.source not in node_set or edge.target not in node_set:
            raise ValueError("存在无效连线：source 或 target 节点不存在")
        graph[edge.source].append(edge.target)
        indegree[edge.target] += 1

    queue = deque(node_id for node_id in node_ids if indegree[node_id] == 0)
    order: list[str] = []
    while queue:
        node_id = queue.popleft()
        order.append(node_id)
        for target_id in graph[node_id]:
            indegree[target_id] -= 1
            if indegree[target_id] == 0:
                queue.append(target_id)

    if len(order) != len(node_ids):
        raise ValueError("流程中存在环，请检查节点连线")
    return order


def _merge_data(target: dict[str, Any], source: Any) -> None:
    if not isinstance(source, dict):
        return
    for key, value in source.items():
        target[key] = value


def _prepare_graph(workflow: WorkflowRequest):
    order = topological_sort(workflow.nodes, workflow.edges)
    nodes = {node.id: node for node in workflow.nodes}
    incoming: dict[str, list[WorkflowEdge]] = defaultdict(list)
    outgoing: dict[str, list[WorkflowEdge]] = defaultdict(list)
    for edge in workflow.edges:
        incoming[edge.target].append(edge)
        outgoing[edge.source].append(edge)
    return order, nodes, incoming, outgoing


def _truthy(value: Any) -> bool:
    if isinstance(value, str):
        normalized = value.strip().lower()
        if normalized in {"", "0", "false", "no", "off", "否", "假"}:
            return False
        if normalized in {"1", "true", "yes", "on", "是", "真"}:
            return True
    return bool(value)


def _execute_once(
    workflow: WorkflowRequest,
    image_store: ImageStore,
    context: ExecutionContext,
    *,
    collect_previews: bool,
    event_callback: WorkflowEventCallback | None = None,
    emit_node_events: bool = True,
    cancel_check: Callable[[], bool] | None = None,
    pause_wait: Callable[[], None] | None = None,
) -> tuple[list[str], dict[str, dict[str, Any]], list[dict[str, Any]]]:
    order, nodes, incoming, outgoing = _prepare_graph(workflow)
    outputs: dict[str, dict[str, Any]] = {}
    previews: list[dict[str, Any]] = []
    executed_order: list[str] = []
    executing: set[str] = set()
    node_started_at: dict[str, float] = {}
    order_index = {node_id: index for index, node_id in enumerate(order)}

    def edge_handle(edge: WorkflowEdge) -> str:
        return edge.targetHandle or "in"

    def sorted_edges(edge_list: list[WorkflowEdge]) -> list[WorkflowEdge]:
        return sorted(edge_list, key=lambda item: order_index.get(item.source, 10**9))

    def collect_static_ancestors(node_id: str, target: set[str]) -> None:
        if node_id in target:
            return
        target.add(node_id)
        # LogicIfElse 的 true/false 分支是运行期根据 condition 决定的，不能静态展开两个分支。
        if nodes[node_id].type == "LogicIfElse":
            return
        for edge in sorted_edges(incoming[node_id]):
            collect_static_ancestors(edge.source, target)

    def execute_static_prerequisites(input_edges: list[WorkflowEdge]) -> None:
        required: set[str] = set()
        for edge in input_edges:
            collect_static_ancestors(edge.source, required)
        for candidate_id in order:
            if candidate_id in required:
                execute_node(candidate_id)

    def output_value(edge: WorkflowEdge) -> Any:
        source_output = outputs[edge.source]
        source_handle = edge.sourceHandle or "out"
        if source_handle not in source_output:
            raise ValueError(f"上游节点 {edge.source} 不存在输出端口：{source_handle}")
        return source_output[source_handle]

    kernel = NodeExecutor(
        context=context,
        outputs=outputs,
        collect_preview=collect_previews,
        cancel_check=cancel_check,
        pause_wait=pause_wait,
        max_input_bytes=NODE_MAX_INPUT_BYTES,
        max_output_bytes=NODE_MAX_OUTPUT_BYTES,
        max_image_pixels=NODE_MAX_IMAGE_PIXELS,
        preview_max_side=PREVIEW_MAX_SIDE,
    )

    def run_current_node(node_id: str, input_edges: list[WorkflowEdge], selected_if_handle: str | None = None) -> None:
        node = nodes[node_id]
        metadata = OPERATOR_META.get(node.type, {})
        node_label = str(metadata.get("label", node.type))

        if emit_node_events:
            node_started_at[node_id] = perf_counter()
            _emit_event(
                event_callback,
                "node_started",
                message=f"开始执行节点 {node_id} · {node_label}",
                node_id=node_id,
                node_type=node.type,
                node_label=node_label,
                node_index=order_index.get(node_id, 0) + 1,
                node_total=len(order),
            )

        outcome = kernel.execute(node, input_edges, selected_if_handle=selected_if_handle)
        if outcome.preview is not None:
            previews.append(outcome.preview)
        executed_order.append(node_id)
        if emit_node_events:
            elapsed_ms = round((perf_counter() - node_started_at.pop(node_id, perf_counter())) * 1000, 2)
            _emit_event(
                event_callback,
                "node_completed",
                level="success",
                message=f"节点 {node_id} · {node_label} 执行完成（{elapsed_ms:.2f} ms，{outcome.result_kind}）",
                node_id=node_id,
                node_type=node.type,
                node_label=node_label,
                node_index=order_index.get(node_id, 0) + 1,
                node_total=len(order),
                duration_ms=elapsed_ms,
                result_kind=outcome.result_kind,
                input_bytes=outcome.input_bytes,
                output_bytes=outcome.output_bytes,
            )

    def execute_node(node_id: str) -> None:
        if node_id in outputs:
            return
        if node_id in executing:
            raise ValueError("流程中存在递归执行，请检查节点连线")
        if node_id not in nodes:
            raise ValueError(f"节点不存在：{node_id}")

        node = nodes[node_id]
        metadata = OPERATOR_META.get(node.type, {})
        node_label = str(metadata.get("label", node.type))
        executing.add(node_id)
        try:
            if node.type == "LogicIfElse":
                by_handle: dict[str, list[WorkflowEdge]] = defaultdict(list)
                for edge in incoming[node_id]:
                    by_handle[edge_handle(edge)].append(edge)
                condition_edges = by_handle.get("condition", [])
                if len(condition_edges) != 1:
                    raise ValueError("If/Else 节点必须连接且只能连接一个 condition 输入")
                condition_edge = condition_edges[0]
                execute_node(condition_edge.source)
                condition = _truthy(output_value(condition_edge))
                selected_handle = "true_value" if condition else "false_value"
                selected_edges = by_handle.get(selected_handle, [])
                if len(selected_edges) != 1:
                    raise ValueError(f"If/Else 条件为 {condition}，但缺少 {selected_handle} 输入")
                selected_edge = selected_edges[0]
                execute_node(selected_edge.source)
                run_current_node(node_id, [condition_edge, selected_edge], selected_handle)
            else:
                input_edges = sorted_edges(incoming[node_id])
                execute_static_prerequisites(input_edges)
                run_current_node(node_id, input_edges)
        except WorkflowExecutionError:
            raise
        except ExecutionCancelledError as exc:
            exc.previews = list(previews)
            exc.executed_order = list(executed_order)
            raise
        except Exception as exc:
            if emit_node_events:
                started_at = node_started_at.pop(node_id, None)
                duration_ms = round((perf_counter() - started_at) * 1000, 2) if started_at is not None else 0.0
                _emit_event(
                    event_callback,
                    "node_failed",
                    level="error",
                    message=f"节点 {node_id} · {node_label} 执行失败：{exc}",
                    node_id=node_id,
                    node_type=node.type,
                    node_label=node_label,
                    node_index=order_index.get(node_id, 0) + 1,
                    node_total=len(order),
                    duration_ms=duration_ms,
                    error=str(exc),
                    cause_type=type(exc).__name__,
                )
            raise WorkflowExecutionError(
                f"节点 {node_id}（{node_label} / {node.type}）执行失败：{exc}",
                node_id=node_id,
                node_type=node.type,
                node_label=node_label,
                order=order,
                executed_order=executed_order,
                previews=previews,
                cause_type=type(exc).__name__,
            ) from exc
        finally:
            executing.discard(node_id)

    sink_ids = [node_id for node_id in order if not outgoing[node_id]] or order
    for node_id in sink_ids:
        execute_node(node_id)

    return order, outputs, previews


def _yes(value: Any, default: bool = False) -> bool:
    if value is None:
        return default
    return str(value).strip().upper() in {"1", "TRUE", "YES", "Y", "是", "ON"}


def _integer(value: Any, default: int = 0) -> int:
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return default


def _parse_extensions(value: Any, defaults: set[str]) -> set[str]:
    text = str(value or "").strip()
    if not text:
        return set(defaults)
    extensions: set[str] = set()
    for item in text.replace(";", ",").split(","):
        suffix = item.strip().lower()
        if not suffix:
            continue
        extensions.add(suffix if suffix.startswith(".") else f".{suffix}")
    return extensions or set(defaults)


def _flatten_metrics(data: dict[str, Any]) -> dict[str, Any]:
    flat: dict[str, Any] = {}

    def visit(prefix: str, value: Any) -> None:
        if isinstance(value, dict):
            for key, child in value.items():
                visit(f"{prefix}.{key}" if prefix else str(key), child)
        elif isinstance(value, (list, tuple, set)):
            flat[prefix] = json.dumps(list(value), ensure_ascii=False)
        elif value is None or isinstance(value, (str, int, float, bool)):
            flat[prefix] = value
        else:
            flat[prefix] = json.dumps(value, ensure_ascii=False, default=str)

    visit("", data)
    return {key: value for key, value in flat.items() if key}


def _safe_csv_name(value: Any) -> str:
    name = Path(str(value or "results.csv").strip()).name
    if not name.lower().endswith(".csv"):
        name += ".csv"
    return name


def _output_suffix(source_path: Path, format_name: str) -> str:
    normalized = str(format_name or "SOURCE").upper()
    if normalized == "PNG":
        return ".png"
    if normalized == "JPG":
        return ".jpg"
    if normalized == "WEBP":
        return ".webp"
    return source_path.suffix.lower() or ".png"


def _save_result_image(path: Path, image: np.ndarray, color_space: str) -> None:
    encode_image = image
    if image.ndim == 3 and str(color_space).upper() == "RGB":
        encode_image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
    path.parent.mkdir(parents=True, exist_ok=True)
    ok, buffer = cv2.imencode(path.suffix or ".png", encode_image)
    if not ok:
        raise ValueError(f"无法编码结果图：{path}")
    try:
        buffer.tofile(str(path))
    except OSError as exc:
        raise ValueError(f"无法保存结果图：{path}") from exc


CSV_BASE_FIELDS = [
    "source_path",
    "source_name",
    "relative_path",
    "output_path",
    "status",
    "error",
]


def _csv_metric_fields(rows: list[dict[str, Any]]) -> list[str]:
    """Preserve configured/encountered column order instead of alphabetic sorting."""

    seen = set(CSV_BASE_FIELDS)
    fields: list[str] = []
    for row in rows:
        for key in row:
            if key in seen:
                continue
            seen.add(key)
            fields.append(key)
    return fields


def _write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    metric_fields = _csv_metric_fields(rows)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8-sig") as stream:
        writer = csv.DictWriter(stream, fieldnames=CSV_BASE_FIELDS + metric_fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def _normalize_csv_field_config(value: Any) -> list[dict[str, Any]]:
    if isinstance(value, str):
        try:
            value = json.loads(value)
        except (TypeError, ValueError, json.JSONDecodeError):
            value = []
    if not isinstance(value, list):
        return []
    normalized: list[dict[str, Any]] = []
    seen_inputs: set[str] = set()
    for item in value:
        if not isinstance(item, dict):
            continue
        input_handle = str(item.get("input") or "").strip()
        if not input_handle or input_handle in seen_inputs:
            continue
        seen_inputs.add(input_handle)
        normalized.append(
            {
                "input": input_handle,
                "enabled": item.get("enabled") is not False,
                "column": str(item.get("column") or "").strip(),
            }
        )
    return normalized


def _batch_result_input_count(params: dict[str, Any]) -> int:
    return max(1, min(20, _integer(params.get("result_input_count"), 4)))


def _batch_csv_variable_edges(workflow: WorkflowRequest, saver: WorkflowNode) -> list[WorkflowEdge]:
    max_count = _batch_result_input_count(saver.params)
    valid_handles = {f"result{index}" for index in range(1, max_count + 1)}
    edges = [
        edge
        for edge in workflow.edges
        if edge.target == saver.id and (edge.targetHandle or "in") in valid_handles
    ]
    return sorted(edges, key=lambda edge: int((edge.targetHandle or "result0").removeprefix("result") or 0))


def _default_csv_column(edge: WorkflowEdge, nodes: dict[str, WorkflowNode]) -> str:
    source = nodes.get(edge.source)
    metadata = OPERATOR_META.get(source.type if source else "", {})
    label = str(metadata.get("label") or (source.type if source else edge.source))
    return f"{edge.source}_{label}.{edge.sourceHandle or 'out'}"


def _csv_json_value(value: Any, *, path: str) -> Any:
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, np.ndarray):
        raise ValueError(f"{path} 是图像/数组，不能写入 CSV；请连接数值、文本、列表或字典输出端口")
    if isinstance(value, Path):
        return str(value)
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, dict):
        return {str(key): _csv_json_value(child, path=f"{path}.{key}") for key, child in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [_csv_json_value(child, path=f"{path}[]") for child in value]
    return str(value)


def _flatten_selected_csv_value(prefix: str, value: Any) -> dict[str, Any]:
    prefix = str(prefix or "value").strip() or "value"
    if isinstance(value, dict):
        flattened: dict[str, Any] = {}
        for key, child in value.items():
            nested_prefix = f"{prefix}.{key}"
            nested = _flatten_selected_csv_value(nested_prefix, child)
            for nested_key, nested_value in nested.items():
                if nested_key in flattened:
                    raise ValueError(f"CSV 列名冲突：{nested_key}")
                flattened[nested_key] = nested_value
        if not value:
            flattened[prefix] = "{}"
        return flattened
    if isinstance(value, np.ndarray):
        raise ValueError(f"CSV变量 {prefix} 是图像/数组，不能直接写入 CSV；请选择数值或数据输出端口")
    if isinstance(value, (list, tuple, set)):
        safe_value = _csv_json_value(value, path=prefix)
        return {prefix: json.dumps(safe_value, ensure_ascii=False)}
    return {prefix: _csv_json_value(value, path=prefix)}


def _collect_selected_csv_values(
    workflow: WorkflowRequest,
    nodes: dict[str, WorkflowNode],
    saver: WorkflowNode,
    outputs: dict[str, dict[str, Any]],
) -> dict[str, Any]:
    config = {item["input"]: item for item in _normalize_csv_field_config(saver.params.get("csv_fields"))}
    values: dict[str, Any] = {}
    for edge in _batch_csv_variable_edges(workflow, saver):
        input_handle = edge.targetHandle or "in"
        field = config.get(input_handle)
        if field is not None and field.get("enabled") is False:
            continue
        source_output = outputs.get(edge.source)
        if source_output is None:
            raise ValueError(f"CSV变量 {input_handle} 的源节点尚未执行：{edge.source}")
        source_handle = edge.sourceHandle or "out"
        if source_handle not in source_output:
            raise ValueError(f"CSV变量 {input_handle} 的源节点不存在输出端口：{edge.source}.{source_handle}")
        column = str((field or {}).get("column") or _default_csv_column(edge, nodes)).strip()
        flattened = _flatten_selected_csv_value(column, source_output[source_handle])
        for key, value in flattened.items():
            if key in values:
                raise ValueError(f"CSV 列名冲突：{key}；请在保存批量结果节点中设置不同列名")
            values[key] = value
    return values


def _validate_batch_workflow(workflow: WorkflowRequest):
    batch_inputs = [node for node in workflow.nodes if node.type == "BatchReadImages"]
    savers = [node for node in workflow.nodes if node.type == "SaveBatchResults"]
    single_inputs = [node for node in workflow.nodes if node.type == "ReadImage"]
    if len(batch_inputs) != 1:
        raise ValueError("批量流程必须且只能包含一个“批量读取图片”节点")
    if single_inputs:
        raise ValueError("批量流程不能同时包含“读取图像”节点")
    if len(savers) != 1:
        raise ValueError("批量流程必须且只能包含一个“保存批量结果”节点")

    order, nodes, incoming, outgoing = _prepare_graph(workflow)
    batch_node = batch_inputs[0]
    saver = savers[0]
    if incoming[batch_node.id]:
        raise ValueError("批量读取图片节点不能有上游连线")
    saver_edges = incoming[saver.id]
    image_edges = [edge for edge in saver_edges if (edge.targetHandle or "in") == "in"]
    if len(image_edges) != 1:
        raise ValueError("保存批量结果节点的“结果图”端口必须连接且只能连接一个上游图像节点")
    max_count = _batch_result_input_count(saver.params)
    valid_variable_handles = {f"result{index}" for index in range(1, max_count + 1)}
    unknown_handles = sorted(
        {
            edge.targetHandle or "in"
            for edge in saver_edges
            if (edge.targetHandle or "in") != "in" and (edge.targetHandle or "in") not in valid_variable_handles
        }
    )
    if unknown_handles:
        raise ValueError(f"保存批量结果节点存在无效输入端口：{'、'.join(unknown_handles)}")
    target_handles = [edge.targetHandle or "in" for edge in saver_edges]
    duplicates = sorted({handle for handle in target_handles if target_handles.count(handle) > 1})
    if duplicates:
        raise ValueError(f"保存批量结果节点的输入端口不能重复连接：{'、'.join(duplicates)}")
    for edge in saver_edges:
        target_handle = edge.targetHandle or "in"
        if target_handle == "in":
            continue
        source_node = nodes.get(edge.source)
        source_meta = OPERATOR_META.get(source_node.type if source_node else "", {})
        output_defs = source_meta.get("outputs") if isinstance(source_meta, dict) else None
        if isinstance(output_defs, list):
            source_handle = edge.sourceHandle or "out"
            output_def = next(
                (
                    item
                    for item in output_defs
                    if isinstance(item, dict) and str(item.get("handle") or "") == source_handle
                ),
                None,
            )
            if isinstance(output_def, dict) and str(output_def.get("type") or "").lower() == "image":
                raise ValueError(
                    f"CSV变量 {target_handle} 连接了图像端口 {edge.source}.{source_handle}；"
                    "请改为连接 number/text/boolean/list/object 等数据输出端口"
                )
    if outgoing[saver.id]:
        raise ValueError("保存批量结果节点必须是工作流末端节点")
    return order, nodes, batch_node, saver


def run_batch_workflow(workflow: WorkflowRequest, image_store: ImageStore, *, user_id: str = "default", workspace_id: str | None = None, model_manager: YoloModelManager | None = None, event_callback: WorkflowEventCallback | None = None, cancel_check: Callable[[], bool] | None = None, pause_wait: Callable[[], None] | None = None) -> dict[str, Any]:
    order, nodes, batch_node, saver = _validate_batch_workflow(workflow)
    input_params = batch_node.params
    save_params = saver.params

    source_root = image_store.resolve_directory(str(input_params.get("folder_path") or ""))
    if source_root is None:
        raise ValueError(f"批量图片文件夹不存在或不可访问：{input_params.get('folder_path', '')}")

    extensions = _parse_extensions(input_params.get("extensions"), image_store.allowed_extensions)
    images = image_store.list_images(
        source_root,
        extensions=extensions,
        recursive=_yes(input_params.get("recursive"), True),
        limit=max(0, _integer(input_params.get("max_images"), 0)),
    )
    if not images:
        raise ValueError(f"文件夹中没有找到符合扩展名的图片：{source_root}")

    _emit_event(
        event_callback,
        "batch_started",
        message=f"批量任务开始，共发现 {len(images)} 张图片",
        total=len(images),
        processed=0,
        succeeded=0,
        failed=0,
        progress_percent=0.0,
        source_dir=str(source_root),
    )

    output_dir = image_store.prepare_output_directory(str(save_params.get("output_dir") or "batch_outputs"))
    save_images = _yes(save_params.get("save_images"), True)
    preserve_structure = _yes(save_params.get("preserve_structure"), True)
    continue_on_error = _yes(input_params.get("continue_on_error"), True)
    write_csv = _yes(save_params.get("write_csv"), True)
    filename_suffix = str(save_params.get("filename_suffix") or "")
    image_format = str(save_params.get("image_format") or "SOURCE")
    csv_export_mode = str(save_params.get("csv_export_mode") or "AUTO_ALL").strip().upper()
    if csv_export_mode not in {"AUTO_ALL", "SELECTED_INPUTS"}:
        csv_export_mode = "AUTO_ALL"

    rows: list[dict[str, Any]] = []
    generated_artifact_paths: list[str] = []
    succeeded = 0
    failed = 0
    last_success_path: Path | None = None

    for index, source_path in enumerate(images, start=1):
        if pause_wait:
            pause_wait()
        if cancel_check and cancel_check():
            raise ExecutionCancelledError(
                "批量运行已取消/结束",
                batch={
                    "total": len(images),
                    "processed": succeeded + failed,
                    "succeeded": succeeded,
                    "failed": failed,
                    "rows": rows[:100],
                    "rows_truncated": len(rows) > 100,
                    "output_dir": str(output_dir),
                },
            )
        item_started_at = perf_counter()
        _emit_event(
            event_callback,
            "batch_item_started",
            message=f"开始处理第 {index}/{len(images)} 张：{source_path.name}",
            index=index,
            total=len(images),
            processed=index - 1,
            succeeded=succeeded,
            failed=failed,
            progress_percent=round(((index - 1) / len(images)) * 100, 2),
            source_name=source_path.name,
        )
        relative = source_path.relative_to(source_root)
        row: dict[str, Any] = {
            "source_path": str(source_path),
            "source_name": source_path.name,
            "relative_path": str(relative),
            "output_path": "",
            "status": "success",
            "error": "",
        }
        try:
            context = ExecutionContext(
                image_id=None,
                image_store=image_store,
                current_image_path=source_path,
                source_root=source_root,
                batch_index=index,
                batch_total=len(images),
                user_id=user_id,
                workspace_id=workspace_id or user_id,
                model_manager=model_manager,
            )
            _, outputs, _ = _execute_once(
                workflow, image_store, context, collect_previews=False, event_callback=event_callback, emit_node_events=False, cancel_check=cancel_check, pause_wait=pause_wait
            )
            result = outputs[saver.id]
            result_image = result.get("out")
            if not isinstance(result_image, np.ndarray):
                raise ValueError("保存批量结果节点没有收到有效图像")

            if save_images:
                result_suffix = _output_suffix(source_path, image_format)
                relative_parent = relative.parent if preserve_structure else Path()
                destination = output_dir / relative_parent / f"{source_path.stem}{filename_suffix}{result_suffix}"
                if not preserve_structure and destination.exists():
                    destination = output_dir / f"{source_path.stem}{filename_suffix}_{index:05d}{result_suffix}"
                _save_result_image(destination, result_image, str(result.get("out_color_space", "BGR")))
                row["output_path"] = str(destination)
                generated_artifact_paths.append(str(destination))

            if csv_export_mode == "SELECTED_INPUTS":
                row.update(_collect_selected_csv_values(workflow, nodes, saver, outputs))
            else:
                row.update(_flatten_metrics(result.get("data", {})))
            succeeded += 1
            last_success_path = source_path
            item_duration_ms = round((perf_counter() - item_started_at) * 1000, 2)
            _emit_event(
                event_callback,
                "batch_item_completed",
                level="success",
                message=f"第 {index}/{len(images)} 张处理完成：{source_path.name}（{item_duration_ms:.2f} ms）",
                index=index,
                total=len(images),
                processed=index,
                progress_percent=round((index / len(images)) * 100, 2),
                source_name=source_path.name,
                duration_ms=item_duration_ms,
                succeeded=succeeded,
                failed=failed,
            )
        except ExecutionCancelledError as exc:
            exc.batch = {
                "total": len(images),
                "processed": succeeded + failed,
                "succeeded": succeeded,
                "failed": failed,
                "rows": rows[:100],
                "rows_truncated": len(rows) > 100,
                "output_dir": str(output_dir),
            }
            raise
        except Exception as exc:  # 每张图片独立记录错误，便于批量排查。
            failed += 1
            row["status"] = "error"
            row["error"] = str(exc)
            item_duration_ms = round((perf_counter() - item_started_at) * 1000, 2)
            _emit_event(
                event_callback,
                "batch_item_failed",
                level="error",
                message=f"第 {index}/{len(images)} 张处理失败：{source_path.name} · {exc}",
                index=index,
                total=len(images),
                processed=index,
                progress_percent=round((index / len(images)) * 100, 2),
                source_name=source_path.name,
                duration_ms=item_duration_ms,
                succeeded=succeeded,
                failed=failed,
                error=str(exc),
            )
            if not continue_on_error:
                rows.append(row)
                if write_csv:
                    _write_csv(output_dir / _safe_csv_name(save_params.get("csv_filename")), rows)
                raise ValueError(f"处理图片失败：{source_path}：{exc}") from exc
        rows.append(row)

    csv_path: Path | None = None
    if write_csv:
        csv_path = output_dir / _safe_csv_name(save_params.get("csv_filename"))
        _write_csv(csv_path, rows)
        generated_artifact_paths.append(str(csv_path))

    previews: list[dict[str, Any]] = []
    if last_success_path is not None:
        preview_context = ExecutionContext(
            image_id=None,
            image_store=image_store,
            current_image_path=last_success_path,
            source_root=source_root,
            batch_index=succeeded + failed,
            batch_total=len(images),
            user_id=user_id,
            workspace_id=workspace_id or user_id,
            model_manager=model_manager,
        )
        _, _, previews = _execute_once(
            workflow, image_store, preview_context, collect_previews=True, event_callback=event_callback, emit_node_events=False, cancel_check=cancel_check, pause_wait=pause_wait
        )

    _emit_event(
        event_callback,
        "batch_completed",
        level="success" if failed == 0 else "warning",
        message=f"批量任务完成：成功 {succeeded} 张，失败 {failed} 张，共 {len(images)} 张",
        total=len(images),
        processed=len(images),
        progress_percent=100.0,
        succeeded=succeeded,
        failed=failed,
        output_dir=str(output_dir),
        csv_path=str(csv_path) if csv_path else "",
        csv_export_mode=csv_export_mode,
        csv_columns=_csv_metric_fields(rows),
    )

    return {
        "success": True,
        "mode": "batch",
        "order": order,
        "previews": previews,
        "batch": {
            "source_dir": str(source_root),
            "output_dir": str(output_dir),
            "csv_path": str(csv_path) if csv_path else "",
            "csv_export_mode": csv_export_mode,
            "csv_columns": _csv_metric_fields(rows),
            "total": len(images),
            "succeeded": succeeded,
            "failed": failed,
            "rows": rows[:100],
            "rows_truncated": len(rows) > 100,
            "_artifact_paths": generated_artifact_paths,
        },
    }


def run_workflow(
    workflow: WorkflowRequest,
    image_store: ImageStore,
    *,
    user_id: str = "default",
    workspace_id: str | None = None,
    model_manager: YoloModelManager | None = None,
    event_callback: WorkflowEventCallback | None = None,
    cancel_check: Callable[[], bool] | None = None,
    pause_wait: Callable[[], None] | None = None,
) -> dict[str, Any]:
    started_at = perf_counter()
    _emit_event(
        event_callback,
        "workflow_started",
        message=f"工作流开始运行：{len(workflow.nodes)} 个节点，{len(workflow.edges)} 条连线",
        node_total=len(workflow.nodes),
        edge_total=len(workflow.edges),
    )
    try:
        if pause_wait:
            pause_wait()
        if cancel_check and cancel_check():
            raise ExecutionCancelledError("工作流运行已取消/结束")
        if not workflow.nodes:
            raise ValueError("流程为空，请先添加节点")

        has_batch_input = any(node.type == "BatchReadImages" for node in workflow.nodes)
        has_batch_saver = any(node.type == "SaveBatchResults" for node in workflow.nodes)
        if has_batch_input or has_batch_saver:
            result = run_batch_workflow(
                workflow,
                image_store,
                user_id=user_id,
                workspace_id=workspace_id,
                model_manager=model_manager,
                event_callback=event_callback,
                cancel_check=cancel_check,
                pause_wait=pause_wait,
            )
        else:
            context = ExecutionContext(
                image_id=workflow.image_id,
                image_store=image_store,
                user_id=user_id,
                workspace_id=workspace_id or user_id,
                model_manager=model_manager,
            )
            order, outputs, previews = _execute_once(
                workflow, image_store, context, collect_previews=True, event_callback=event_callback, cancel_check=cancel_check, pause_wait=pause_wait
            )
            sink_data: dict[str, Any] = {}
            outgoing_ids = {edge.source for edge in workflow.edges}
            for node_id, node_result in outputs.items():
                if node_id not in outgoing_ids and node_result.get("data"):
                    sink_data[node_id] = node_result["data"]
            result = {
                "success": True,
                "mode": "single",
                "previews": previews,
                "order": order,
                "data": sink_data,
            }

        if pause_wait:
            pause_wait()
        if cancel_check and cancel_check():
            raise ExecutionCancelledError("工作流运行已取消/结束")
        duration_ms = round((perf_counter() - started_at) * 1000, 2)
        _emit_event(
            event_callback,
            "workflow_completed",
            level="success",
            message=f"工作流运行完成（{duration_ms:.2f} ms）",
            mode=result.get("mode", "single"),
            duration_ms=duration_ms,
            executed_order=result.get("order", []),
        )
        return result
    except Exception as exc:
        duration_ms = round((perf_counter() - started_at) * 1000, 2)
        cancelled = isinstance(exc, ExecutionCancelledError)
        _emit_event(
            event_callback,
            "workflow_cancelled" if cancelled else "workflow_failed",
            level="warning" if cancelled else "error",
            message=f"整体运行已结束（{duration_ms:.2f} ms）" if cancelled else f"工作流运行失败：{exc}",
            duration_ms=duration_ms,
            error=str(exc),
            cause_type=type(exc).__name__,
        )
        raise
