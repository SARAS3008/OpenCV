from __future__ import annotations

from collections import Counter
from pathlib import Path
from typing import Any

import cv2
import numpy as np


_YOLO_MODEL_CACHE: dict[tuple[str, str], Any] = {}
_YOLO_MODEL_OVERRIDES: dict[str, str] = {}
_YOLO_DEVICE_OVERRIDE = ""
_YOLO_NODE_IDS: list[str] = []
_VALID_YOLO_TASKS = {"auto", "detect", "segment", "classify", "pose", "obb"}
_ALLOWED_YOLO_MODEL_SUFFIXES = {
    ".pt", ".onnx", ".engine", ".torchscript", ".mlmodel", ".tflite",
    ".pb", ".xml", ".bin", ".yaml", ".yml",
}


def configure_yolo_models(overrides: dict[str, str] | None = None, device: str | None = None) -> None:
    """Configure model paths/device before calling run_algorithm from another Python module."""

    global _YOLO_DEVICE_OVERRIDE
    if overrides:
        for node_id, model_path in overrides.items():
            key = str(node_id or "").strip()
            value = str(model_path or "").strip()
            if not key or not value:
                raise ValueError("YOLO模型覆盖必须使用非空的节点ID和模型路径")
            _YOLO_MODEL_OVERRIDES[key] = value
    if device is not None:
        _YOLO_DEVICE_OVERRIDE = str(device or "").strip()


def configure_yolo_cli(model_args: list[str] | None = None, device: str = "") -> None:
    """Parse repeatable CLI values: PATH for one node, or NODE_ID=PATH for many nodes."""

    overrides: dict[str, str] = {}
    for raw_item in model_args or []:
        item = str(raw_item or "").strip()
        if not item:
            continue
        if "=" in item:
            node_id, model_path = item.split("=", 1)
            node_id = node_id.strip()
            model_path = model_path.strip()
            if not node_id or not model_path:
                raise ValueError("--model 多节点格式必须是 节点ID=模型路径")
            overrides[node_id] = model_path
            continue
        if len(_YOLO_NODE_IDS) != 1:
            raise ValueError("流程包含多个YOLO节点时，--model 必须使用 节点ID=模型路径；参数可重复")
        overrides[_YOLO_NODE_IDS[0]] = item
    configure_yolo_models(overrides, device)


def _yolo_bool(value: Any, default: bool = False) -> bool:
    if value is None:
        return default
    return str(value).strip().upper() in {"1", "TRUE", "YES", "Y", "是", "ON"}


def _yolo_int(value: Any, default: int) -> int:
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return default


def _yolo_float(value: Any, default: float) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _normalize_yolo_task(value: Any) -> str:
    task = str(value or "auto").strip().lower()
    aliases = {
        "": "auto", "detection": "detect", "det": "detect", "seg": "segment",
        "classification": "classify", "cls": "classify", "keypoint": "pose", "keypoints": "pose",
    }
    task = aliases.get(task, task)
    if task not in _VALID_YOLO_TASKS:
        raise ValueError(f"不支持的YOLO推理任务：{value}，可选值：{', '.join(sorted(_VALID_YOLO_TASKS))}")
    return task


def _parse_yolo_class_indices(value: Any) -> list[int]:
    if value is None:
        return []
    if isinstance(value, (list, tuple, set)):
        parts = list(value)
    else:
        text = str(value or "").strip()
        if not text:
            return []
        for left, right in [("[", ""), ("]", ""), ("（", ""), ("）", ""), ("(", ""), (")", "")]:
            text = text.replace(left, right)
        text = text.replace("，", ",").replace("；", ",").replace(";", ",").replace(" ", ",")
        parts = [part for part in text.split(",") if str(part).strip()]
    result: list[int] = []
    seen: set[int] = set()
    for part in parts:
        try:
            class_id = int(str(part).strip())
        except (TypeError, ValueError) as exc:
            raise ValueError(f"类别index只能填写非负整数，例如0,1,8；无法解析：{part}") from exc
        if class_id < 0:
            raise ValueError(f"类别index不能为负数：{class_id}")
        if class_id not in seen:
            result.append(class_id)
            seen.add(class_id)
    return result


def _parse_yolo_class_filter(value: Any) -> set[str]:
    text = str(value or "").strip()
    if not text:
        return set()
    return {part.strip().lower() for part in text.replace("；", ",").replace(";", ",").split(",") if part.strip()}


def _is_yolo_alias(raw_path: str) -> bool:
    if not raw_path or "/" in raw_path or "\\" in raw_path:
        return False
    path = Path(raw_path)
    return path.name == raw_path and path.stem.lower().startswith("yolo") and path.suffix.lower() in _ALLOWED_YOLO_MODEL_SUFFIXES


def _exported_script_dir() -> Path:
    script_file = globals().get("__file__")
    if script_file:
        try:
            return Path(str(script_file)).expanduser().resolve().parent
        except (OSError, RuntimeError):
            pass
    return Path.cwd().resolve()


def _resolve_exported_yolo_model(node_id: str, configured_path: Any) -> str:
    raw = str(_YOLO_MODEL_OVERRIDES.get(node_id) or configured_path or "").strip()
    if not raw:
        raise ValueError(f"YOLO节点 {node_id} 未配置模型；请在节点中设置model_path，或运行时使用 --model 覆盖")

    candidate = Path(raw).expanduser()
    script_dir = _exported_script_dir()
    candidates: list[Path] = []
    if candidate.is_absolute():
        candidates.append(candidate)
        candidates.extend([Path.cwd() / candidate.name, script_dir / candidate.name])
    else:
        candidates.extend([Path.cwd() / candidate, script_dir / candidate, script_dir / candidate.name])

    checked: set[str] = set()
    for item in candidates:
        try:
            key = str(item.resolve(strict=False))
        except (OSError, RuntimeError):
            key = str(item)
        if key in checked:
            continue
        checked.add(key)
        if item.is_file():
            return str(item.resolve())

    if _is_yolo_alias(raw):
        return raw
    raise FileNotFoundError(
        f"YOLO节点 {node_id} 的模型文件不存在：{raw}。"
        f"请把模型复制到脚本目录，或使用 --model {node_id}=模型路径 覆盖。"
    )


def _load_exported_yolo_model(node_id: str, configured_path: Any, task: str) -> tuple[Any, str]:
    model_ref = _resolve_exported_yolo_model(node_id, configured_path)
    key = (model_ref, task)
    if key in _YOLO_MODEL_CACHE:
        return _YOLO_MODEL_CACHE[key], model_ref
    try:
        from ultralytics import YOLO
    except ImportError as exc:
        raise RuntimeError("独立YOLO脚本需要Ultralytics，请执行：pip install 'ultralytics>=8.3,<9.0'") from exc
    model = YOLO(model_ref) if task == "auto" else YOLO(model_ref, task=task)
    _YOLO_MODEL_CACHE[key] = model
    return model, model_ref


def _yolo_image(image: np.ndarray, color_space: Any) -> np.ndarray:
    if not isinstance(image, np.ndarray):
        raise ValueError("YOLO推理节点的输入必须是图像")
    if image.ndim == 2:
        return cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
    if image.ndim != 3:
        raise ValueError(f"YOLO输入图像维度无效：{image.shape}")
    if str(color_space or "BGR").upper() == "RGB":
        return cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
    if image.shape[2] == 4:
        return cv2.cvtColor(image, cv2.COLOR_BGRA2BGR)
    if image.shape[2] == 1:
        return cv2.cvtColor(image[:, :, 0], cv2.COLOR_GRAY2BGR)
    return image[:, :, :3]


def _yolo_to_numpy(value: Any) -> np.ndarray | None:
    if value is None:
        return None
    try:
        if hasattr(value, "detach"):
            value = value.detach()
        if hasattr(value, "cpu"):
            value = value.cpu()
        if hasattr(value, "numpy"):
            value = value.numpy()
        if isinstance(value, np.ndarray):
            return value
        if hasattr(value, "tolist"):
            return np.asarray(value.tolist())
    except Exception:
        return None
    try:
        return np.asarray(value)
    except Exception:
        return None


def _yolo_to_list(value: Any, digits: int = 6) -> Any:
    array = _yolo_to_numpy(value)
    if array is None:
        return None
    if np.issubdtype(array.dtype, np.floating):
        array = np.round(array.astype(float), digits)
    if array.ndim == 0:
        scalar = array.item()
        return scalar.item() if isinstance(scalar, np.generic) else scalar
    return array.tolist()


def _yolo_int_or_none(value: Any) -> int | None:
    try:
        return int(value)
    except (TypeError, ValueError):
        try:
            return int(_yolo_to_list(value))
        except (TypeError, ValueError):
            return None


def _yolo_float_or_none(value: Any) -> float | None:
    try:
        return round(float(value), 6)
    except (TypeError, ValueError):
        try:
            return round(float(_yolo_to_list(value)), 6)
        except (TypeError, ValueError):
            return None


def _yolo_name(names: Any, class_id: int | None) -> str:
    if class_id is None:
        return ""
    if isinstance(names, dict):
        return str(names.get(class_id, names.get(str(class_id), class_id)))
    if isinstance(names, (list, tuple)) and 0 <= class_id < len(names):
        return str(names[class_id])
    return str(class_id)


def _yolo_limit_points(points: Any, max_points: int) -> Any:
    if not isinstance(points, list) or max_points <= 0 or len(points) <= max_points:
        return points
    indices = np.linspace(0, len(points) - 1, max_points, dtype=int)
    return [points[int(index)] for index in indices]


def _yolo_as_xy_points(points: Any) -> list[list[float]]:
    if not isinstance(points, list):
        return []
    if points and all(isinstance(value, (int, float)) for value in points):
        return [[float(points[index]), float(points[index + 1])] for index in range(0, len(points) - 1, 2)]
    normalized: list[list[float]] = []
    for point in points:
        if isinstance(point, (list, tuple)) and len(point) >= 2:
            try:
                normalized.append([float(point[0]), float(point[1])])
            except (TypeError, ValueError):
                continue
    return normalized


def _yolo_limit_polygon(points: Any, max_points: int) -> list[list[float]]:
    normalized = _yolo_as_xy_points(points)
    if not normalized or max_points <= 0 or len(normalized) <= max_points:
        return normalized
    max_points = max(3, max_points)
    contour = np.asarray(normalized, dtype=np.float32).reshape(-1, 1, 2)
    perimeter = float(cv2.arcLength(contour, True))
    if perimeter > 0:
        best: np.ndarray | None = None
        low, high = 0.0, max(1.0, perimeter * 0.05)
        for _ in range(18):
            epsilon = (low + high) / 2.0
            approx = cv2.approxPolyDP(contour, epsilon, True)
            if 3 <= len(approx) <= max_points:
                best = approx
                high = epsilon
            elif len(approx) > max_points:
                low = epsilon
            else:
                high = epsilon
        if best is not None and len(best) >= 3:
            return [[float(point[0][0]), float(point[0][1])] for point in best]
    indices = np.linspace(0, len(normalized), max_points, endpoint=False, dtype=int)
    return [normalized[min(len(normalized) - 1, int(index))] for index in indices]


def _extract_yolo_boxes(result: Any, names: Any, max_points: int) -> list[dict[str, Any]]:
    boxes = getattr(result, "boxes", None)
    if boxes is None:
        return []
    xyxy = _yolo_to_list(getattr(boxes, "xyxy", None)) or []
    classes = _yolo_to_list(getattr(boxes, "cls", None)) or []
    confidences = _yolo_to_list(getattr(boxes, "conf", None)) or []
    track_ids = _yolo_to_list(getattr(boxes, "id", None)) or []
    detections: list[dict[str, Any]] = []
    for index, coords in enumerate(xyxy):
        class_id = _yolo_int_or_none(classes[index] if index < len(classes) else None)
        item: dict[str, Any] = {
            "index": index,
            "class_id": class_id,
            "class_name": _yolo_name(names, class_id),
            "confidence": _yolo_float_or_none(confidences[index] if index < len(confidences) else None),
            "box_xyxy": _yolo_limit_points(coords, max_points),
        }
        if index < len(track_ids):
            item["track_id"] = _yolo_int_or_none(track_ids[index])
        detections.append(item)
    return detections


def _attach_yolo_masks(result: Any, detections: list[dict[str, Any]], max_points: int) -> int:
    masks = getattr(result, "masks", None)
    polygons = getattr(masks, "xy", None) if masks is not None else None
    if polygons is None and masks is not None:
        polygons = getattr(masks, "xyn", None)
    if polygons is None:
        return 0
    count = 0
    for index, polygon in enumerate(polygons):
        points = _yolo_to_list(polygon) or []
        if index < len(detections):
            detections[index]["mask_polygon"] = _yolo_limit_polygon(points, max_points)
            detections[index]["mask_point_count"] = len(detections[index]["mask_polygon"])
            detections[index]["mask_source"] = "polygon"
        count += 1
    return count


def _attach_yolo_keypoints(result: Any, detections: list[dict[str, Any]], max_points: int) -> int:
    keypoints = getattr(result, "keypoints", None)
    if keypoints is None:
        return 0
    xy = _yolo_to_list(getattr(keypoints, "xy", None)) or []
    confidence = _yolo_to_list(getattr(keypoints, "conf", None)) or []
    count = 0
    for index, points in enumerate(xy):
        item: dict[str, Any] = {"xy": _yolo_limit_points(points, max_points)}
        if index < len(confidence):
            item["confidence"] = _yolo_limit_points(confidence[index], max_points)
        if index < len(detections):
            detections[index]["keypoints"] = item
        else:
            detections.append({"index": index, "keypoints": item})
        count += len(points) if isinstance(points, list) else 0
    return count


def _extract_yolo_obb(result: Any, names: Any, max_points: int) -> list[dict[str, Any]]:
    obb = getattr(result, "obb", None)
    if obb is None:
        return []
    polygons = _yolo_to_list(getattr(obb, "xyxyxyxy", None)) or []
    xywhr = _yolo_to_list(getattr(obb, "xywhr", None)) or []
    classes = _yolo_to_list(getattr(obb, "cls", None)) or []
    confidences = _yolo_to_list(getattr(obb, "conf", None)) or []
    detections: list[dict[str, Any]] = []
    for index in range(max(len(polygons), len(xywhr), len(classes), len(confidences))):
        class_id = _yolo_int_or_none(classes[index] if index < len(classes) else None)
        item: dict[str, Any] = {
            "index": index,
            "class_id": class_id,
            "class_name": _yolo_name(names, class_id),
            "confidence": _yolo_float_or_none(confidences[index] if index < len(confidences) else None),
        }
        if index < len(polygons):
            item["obb_polygon"] = _yolo_limit_points(polygons[index], max_points)
        if index < len(xywhr):
            item["obb_xywhr"] = _yolo_limit_points(xywhr[index], max_points)
        detections.append(item)
    return detections


def _extract_yolo_classification(result: Any, names: Any) -> dict[str, Any]:
    probs = getattr(result, "probs", None)
    if probs is None:
        return {"top5": [], "top_class": "", "top_confidence": 0.0, "probabilities": []}
    data = _yolo_to_list(getattr(probs, "data", None)) or []
    if data:
        pairs = sorted(enumerate(data), key=lambda item: float(item[1]), reverse=True)[:5]
        top5 = [
            {"class_id": int(class_id), "class_name": _yolo_name(names, int(class_id)), "confidence": round(float(conf), 6)}
            for class_id, conf in pairs
        ]
    else:
        top_ids = _yolo_to_list(getattr(probs, "top5", None)) or []
        top_conf = _yolo_to_list(getattr(probs, "top5conf", None)) or []
        top5 = [
            {
                "class_id": int(class_id),
                "class_name": _yolo_name(names, int(class_id)),
                "confidence": round(float(top_conf[index]), 6) if index < len(top_conf) else None,
            }
            for index, class_id in enumerate(top_ids)
        ]
    if not top5:
        top1 = _yolo_int_or_none(getattr(probs, "top1", None))
        top1_conf = _yolo_float_or_none(getattr(probs, "top1conf", None)) or 0.0
        if top1 is not None:
            top5 = [{"class_id": top1, "class_name": _yolo_name(names, top1), "confidence": top1_conf}]
    top = top5[0] if top5 else {}
    return {
        "top5": top5,
        "top_class": str(top.get("class_name") or ""),
        "top_confidence": float(top.get("confidence") or 0.0),
        "probabilities": data,
    }


def _extract_yolo_payload(result: Any, task: str, include_geometry: bool, max_results: int, max_points: int) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    names = getattr(result, "names", None)
    if names is None:
        names = getattr(getattr(result, "model", None), "names", {})
    resolved_task = task
    detections: list[dict[str, Any]] = []
    extra: dict[str, Any] = {}
    classification = _extract_yolo_classification(result, names)
    if classification["top5"] and task in {"auto", "classify"}:
        resolved_task = "classify"
        extra["classification"] = classification
    elif task == "obb" or getattr(result, "obb", None) is not None:
        resolved_task = "obb"
        detections = _extract_yolo_obb(result, names, max_points)
    else:
        detections = _extract_yolo_boxes(result, names, max_points)
        if task == "segment" or getattr(result, "masks", None) is not None:
            resolved_task = "segment"
            extra["mask_count"] = _attach_yolo_masks(result, detections, max_points) if include_geometry else 0
        if task == "pose" or getattr(result, "keypoints", None) is not None:
            resolved_task = "pose"
            extra["keypoint_count"] = _attach_yolo_keypoints(result, detections, max_points) if include_geometry else 0
        if resolved_task == "auto":
            resolved_task = "detect"
    if not include_geometry:
        for item in detections:
            for key in ["box_xyxy", "mask_polygon", "keypoints", "obb_polygon", "obb_xywhr"]:
                item.pop(key, None)
    shape = getattr(result, "orig_shape", None)
    if shape is None and isinstance(getattr(result, "orig_img", None), np.ndarray):
        shape = result.orig_img.shape[:2]
    if shape is not None:
        try:
            height, width = list(shape)[:2]
            for item in detections:
                item.setdefault("image_shape", [int(height), int(width)])
        except Exception:
            pass
    if max_results > 0:
        detections = detections[:max_results]
    return detections, {**extra, "resolved_task": resolved_task}


def _annotated_yolo_image(result: Any, fallback: np.ndarray) -> np.ndarray:
    try:
        annotated = result.plot()
        if isinstance(annotated, np.ndarray):
            if annotated.ndim == 2:
                return cv2.cvtColor(annotated, cv2.COLOR_GRAY2BGR)
            if annotated.ndim == 3 and annotated.shape[2] == 4:
                return cv2.cvtColor(annotated, cv2.COLOR_BGRA2BGR)
            return annotated[:, :, :3]
    except Exception:
        pass
    return fallback.copy()


def run_yolo_infer_node(node_id: str, image: np.ndarray, color_space: str, params: dict[str, Any]) -> dict[str, Any]:
    task = _normalize_yolo_task(params.get("task", "auto"))
    model, model_ref = _load_exported_yolo_model(node_id, params.get("model_path"), task)
    model_input = _yolo_image(image, color_space)
    confidence = max(0.0, min(1.0, _yolo_float(params.get("confidence", 0.25), 0.25)))
    iou = max(0.0, min(1.0, _yolo_float(params.get("iou", 0.45), 0.45)))
    imgsz = max(1, _yolo_int(params.get("imgsz", 640), 640))
    max_det = max(1, _yolo_int(params.get("max_det", 300), 300))
    max_results = max(0, _yolo_int(params.get("max_results", max_det), max_det))
    max_points = max(0, _yolo_int(params.get("max_geometry_points", 500), 500))
    include_geometry = _yolo_bool(params.get("include_geometry"), True)
    output_mode = str(params.get("output_mode", "ANNOTATED") or "ANNOTATED").strip().upper()
    device = _YOLO_DEVICE_OVERRIDE or str(params.get("device", "") or "").strip()
    class_indices = _parse_yolo_class_indices(params.get("class_indices"))
    predict_args: dict[str, Any] = {
        "source": model_input, "conf": confidence, "iou": iou, "imgsz": imgsz,
        "max_det": max_det, "verbose": False, "save": False,
    }
    if device:
        predict_args["device"] = device
    if class_indices and task in {"detect", "segment", "pose", "obb"}:
        predict_args["classes"] = class_indices
    if task != "auto":
        predict_args["task"] = task
    results = model.predict(**predict_args)
    if not results:
        raise ValueError("YOLO未返回推理结果")
    result = results[0]
    detections, extra = _extract_yolo_payload(result, task, include_geometry, max_results, max_points)
    if class_indices:
        allowed = set(class_indices)
        detections = [item for item in detections if _yolo_int_or_none(item.get("class_id")) in allowed]
    class_filter = _parse_yolo_class_filter(params.get("class_filter"))
    if class_filter:
        detections = [
            item for item in detections
            if str(item.get("class_id")).lower() in class_filter or str(item.get("class_name") or "").lower() in class_filter
        ]
    classification = extra.get("classification") or {}
    if classification:
        top_class = classification.get("top_class", "")
        top_confidence = float(classification.get("top_confidence") or 0.0)
        count = 1 if top_class else 0
        per_class_counts = {str(top_class): 1} if top_class else {}
    else:
        top = max(detections, key=lambda item: float(item.get("confidence") or 0.0), default={})
        top_class = str(top.get("class_name") or "")
        top_confidence = float(top.get("confidence") or 0.0)
        count = len(detections)
        per_class_counts = dict(Counter(str(item.get("class_name") or item.get("class_id") or "unknown") for item in detections))
    metrics: dict[str, Any] = {
        "task": extra.get("resolved_task", task), "model": Path(model_ref).name,
        "result_count": count, "top_class": top_class, "top_confidence": round(top_confidence, 6),
        "per_class_counts": per_class_counts, "class_indices": class_indices,
    }
    speed = getattr(result, "speed", {}) or {}
    if isinstance(speed, dict):
        metrics["speed_ms"] = {str(key): round(float(value), 4) for key, value in speed.items() if isinstance(value, (int, float))}
    for key in ("mask_count", "keypoint_count"):
        if key in extra:
            metrics[key] = extra[key]
    output_image = model_input.copy() if output_mode == "ORIGINAL" else _annotated_yolo_image(result, model_input)
    data: dict[str, Any] = {
        "yolo": {
            "task": metrics["task"], "model_path": model_ref, "result_count": count,
            "top_class": top_class, "top_confidence": round(top_confidence, 6),
            "per_class_counts": per_class_counts, "class_indices": class_indices,
            "class_filter": sorted(class_filter), "detections": detections,
        }
    }
    if classification:
        data["yolo"]["classification"] = classification
    return {
        "out": output_image, "detections": detections, "count": count, "top_class": top_class,
        "top_confidence": round(top_confidence, 6), "task": metrics["task"], "metrics": metrics, "data": data,
    }


def _detection_confidence(item: Any) -> float:
    try:
        return float(item.get("confidence") or 0.0) if isinstance(item, dict) else 0.0
    except (TypeError, ValueError):
        return 0.0


def _detection_class_id(item: Any) -> int:
    try:
        return int(item.get("class_id")) if isinstance(item, dict) else -1
    except (TypeError, ValueError):
        return -1


def _detection_box(item: dict[str, Any]) -> tuple[float, float, float, float] | None:
    coords = item.get("box_xyxy") or item.get("bbox") or item.get("xyxy")
    if not isinstance(coords, (list, tuple)) or len(coords) < 4:
        return None
    try:
        x1, y1, x2, y2 = [float(coords[index]) for index in range(4)]
    except (TypeError, ValueError):
        return None
    return (x1, y1, x2, y2) if x2 > x1 and y2 > y1 else None


def _detection_area(item: dict[str, Any]) -> float:
    box = _detection_box(item)
    return max(0.0, box[2] - box[0]) * max(0.0, box[3] - box[1]) if box else 0.0


def _detection_center(item: dict[str, Any]) -> tuple[float, float] | None:
    box = _detection_box(item)
    return ((box[0] + box[2]) / 2.0, (box[1] + box[3]) / 2.0) if box else None


def _detection_shape(image: Any, detections: list[dict[str, Any]]) -> tuple[int, int] | None:
    if isinstance(image, np.ndarray):
        return int(image.shape[0]), int(image.shape[1])
    for item in detections:
        shape = item.get("image_shape") or item.get("image_shape_hw") or item.get("orig_shape")
        if isinstance(shape, (list, tuple)) and len(shape) >= 2:
            try:
                height, width = int(shape[0]), int(shape[1])
                if height > 0 and width > 0:
                    return height, width
            except (TypeError, ValueError):
                pass
    boxes = [box for item in detections if (box := _detection_box(item)) is not None]
    if boxes:
        return max(1, int(np.ceil(max(box[3] for box in boxes)))), max(1, int(np.ceil(max(box[2] for box in boxes))))
    return None


def _detection_polygon(item: dict[str, Any]) -> list[list[float]]:
    return _yolo_as_xy_points(item.get("mask_polygon") or item.get("polygon") or item.get("segmentation"))


def _clamp_detection_box(box: tuple[float, float, float, float], width: int, height: int, padding: int = 0) -> tuple[int, int, int, int]:
    x1, y1, x2, y2 = box
    x1_i = max(0, min(width - 1, int(round(x1)) - padding))
    y1_i = max(0, min(height - 1, int(round(y1)) - padding))
    x2_i = max(1, min(width, int(round(x2)) + padding))
    y2_i = max(1, min(height, int(round(y2)) + padding))
    return x1_i, y1_i, max(x1_i + 1, x2_i), max(y1_i + 1, y2_i)


def _detection_mask(item: dict[str, Any], height: int, width: int) -> np.ndarray:
    mask = np.zeros((height, width), dtype=np.uint8)
    polygon = _detection_polygon(item)
    if len(polygon) >= 3:
        points = np.asarray(polygon, dtype=np.float32)
        points[:, 0] = np.clip(points[:, 0], 0, max(0, width - 1))
        points[:, 1] = np.clip(points[:, 1], 0, max(0, height - 1))
        cv2.fillPoly(mask, [np.round(points).astype(np.int32)], 255)
    elif (box := _detection_box(item)) is not None:
        x1, y1, x2, y2 = _clamp_detection_box(box, width, height)
        mask[y1:y2, x1:x2] = 255
    return mask


def run_yolo_select_node(detections_input: Any, image: Any, params: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(detections_input, list):
        raise ValueError("YOLO目标筛选节点需要连接detections输出")
    min_confidence = max(0.0, min(1.0, _yolo_float(params.get("min_confidence", 0.35), 0.35)))
    top_k = max(1, _yolo_int(params.get("top_k", 2), 2))
    sort_by = str(params.get("sort_by", "CONFIDENCE_DESC") or "CONFIDENCE_DESC").strip().upper()
    aliases = {"CONF": "CONFIDENCE_DESC", "CONFIDENCE": "CONFIDENCE_DESC", "SCORE": "CONFIDENCE_DESC", "CLASS_ID": "CLASS_ID_DESC", "ID": "CLASS_ID_DESC", "AREA": "AREA_DESC", "LEFT": "LEFT_TO_RIGHT", "X": "LEFT_TO_RIGHT", "TOP": "TOP_TO_BOTTOM", "Y": "TOP_TO_BOTTOM"}
    sort_by = aliases.get(sort_by, sort_by)
    allowed_sort = {"CONFIDENCE_DESC", "CLASS_ID_DESC", "AREA_DESC", "LEFT_TO_RIGHT", "TOP_TO_BOTTOM"}
    if sort_by not in allowed_sort:
        raise ValueError(f"不支持的检测结果排序方式：{sort_by}")
    require_exact = _yolo_bool(params.get("require_exact_count"), True)
    class_indices = _parse_yolo_class_indices(params.get("class_indices"))
    mode = str(params.get("selection_mode", "AUTO") or "AUTO").strip().upper()
    if mode == "AUTO":
        mode = "PER_CLASS_BEST" if class_indices else "MIXED_TOP_K"
    if mode not in {"PER_CLASS_BEST", "MIXED_TOP_K"}:
        raise ValueError("selection_mode只能是AUTO、MIXED_TOP_K或PER_CLASS_BEST")
    detections = [dict(item) for item in detections_input if isinstance(item, dict)]
    valid = [item for item in detections if _detection_box(item) is not None]
    selected: list[dict[str, Any]] = []
    missing: list[dict[str, Any]] = []
    if mode == "PER_CLASS_BEST":
        if not class_indices:
            class_indices = sorted({_detection_class_id(item) for item in valid if _detection_class_id(item) >= 0})[:top_k]
        for rank, class_id in enumerate(class_indices, start=1):
            same_class = [item for item in valid if _detection_class_id(item) == class_id]
            best_any = max(same_class, key=lambda item: (_detection_confidence(item), _detection_area(item)), default=None)
            qualified = [item for item in same_class if _detection_confidence(item) >= min_confidence]
            best = max(qualified, key=lambda item: (_detection_confidence(item), _detection_area(item)), default=None)
            if best is None:
                missing.append({"class_id": class_id, "found": False, "best_confidence": round(_detection_confidence(best_any), 6) if best_any else None, "reason": "below_threshold" if best_any else "not_detected"})
                continue
            item = dict(best)
            center = _detection_center(item)
            if center:
                item["center"] = [round(center[0], 3), round(center[1], 3)]
            item.update({"selected_rank": rank, "target_id": item.get("track_id") if item.get("track_id") is not None else item.get("class_id"), "found": True})
            selected.append(item)
        expected_count = len(class_indices)
        top_k = expected_count or top_k
        if require_exact and missing:
            details = ", ".join(f"index={item['class_id']}({item['reason']}, best={item['best_confidence']})" for item in missing)
            raise ValueError(f"按类别分别筛选未找到全部目标：{details}；阈值为{min_confidence}")
    else:
        filtered = [item for item in valid if _detection_confidence(item) >= min_confidence]
        if sort_by == "CLASS_ID_DESC":
            filtered.sort(key=lambda item: (_detection_class_id(item), _detection_confidence(item)), reverse=True)
        elif sort_by == "AREA_DESC":
            filtered.sort(key=lambda item: (_detection_area(item), _detection_confidence(item)), reverse=True)
        elif sort_by == "LEFT_TO_RIGHT":
            filtered.sort(key=lambda item: (_detection_center(item) or (10**12, 10**12))[0])
        elif sort_by == "TOP_TO_BOTTOM":
            filtered.sort(key=lambda item: (_detection_center(item) or (10**12, 10**12))[1])
        else:
            filtered.sort(key=lambda item: (_detection_confidence(item), _detection_area(item)), reverse=True)
        selected = [dict(item) for item in filtered[:top_k]]
        expected_count = top_k
        if require_exact and len(selected) < top_k:
            raise ValueError(f"筛选后只有{len(selected)}个目标，少于要求的{top_k}个")
        for index, item in enumerate(selected, start=1):
            center = _detection_center(item)
            if center:
                item["center"] = [round(center[0], 3), round(center[1], 3)]
            item.update({"selected_rank": index, "target_id": item.get("track_id") if item.get("track_id") is not None else item.get("class_id"), "found": True})
    centers = [item.get("center") for item in selected if isinstance(item.get("center"), list)]
    if mode == "PER_CLASS_BEST":
        by_rank = {int(item["selected_rank"]): item for item in selected if isinstance(item.get("selected_rank"), int)}
        mask_items = [by_rank.get(rank) for rank in range(1, expected_count + 1)]
    else:
        mask_items = list(selected[:expected_count])
    shape = _detection_shape(image, detections)
    masks: list[np.ndarray] = []
    combined: np.ndarray | None = None
    if shape:
        height, width = shape
        combined = np.zeros((height, width), dtype=np.uint8)
        for item in mask_items:
            mask = _detection_mask(item, height, width) if isinstance(item, dict) else np.zeros((height, width), dtype=np.uint8)
            masks.append(mask)
            combined = cv2.bitwise_or(combined, mask)
    metrics = {
        "input_count": len(detections_input), "valid_count": len(valid), "selected_count": len(selected),
        "expected_count": expected_count, "min_confidence": min_confidence, "top_k": top_k,
        "selection_mode": mode, "class_indices": class_indices, "missing_indices": missing,
        "sort_by": sort_by, "mask_output_count": len(mask_items),
        "mask_ports": [f"mask{index}" for index in range(1, len(mask_items) + 1)],
        "selected": [{"rank": item.get("selected_rank"), "target_id": item.get("target_id"), "class_id": item.get("class_id"), "class_name": item.get("class_name"), "confidence": item.get("confidence"), "center": item.get("center"), "box_xyxy": item.get("box_xyxy"), "found": item.get("found", True)} for item in selected],
    }
    result: dict[str, Any] = {
        "selected": selected, "count": len(selected), "expected_count": expected_count,
        "missing_indices": missing, "first": selected[0] if selected else None,
        "second": selected[1] if len(selected) > 1 else None, "centers": centers,
        "metrics": metrics, "data": {"yolo_selected": metrics},
    }
    if combined is not None:
        result.update({"mask": combined, "out": combined})
    for index, mask in enumerate(masks, start=1):
        result[f"mask{index}"] = mask
    return result


def _roi_edge(image: np.ndarray, box: tuple[int, int, int, int], low: int, high: int, aperture: int) -> np.ndarray:
    x1, y1, x2, y2 = box
    roi = image[y1:y2, x1:x2]
    if roi.size == 0:
        return np.zeros((1, 1), dtype=np.uint8)
    gray = cv2.cvtColor(_yolo_image(roi, "BGR"), cv2.COLOR_BGR2GRAY) if roi.ndim == 3 else roi
    return cv2.Canny(gray, low, high, apertureSize=aperture)


def _roi_pair_canvas(image: np.ndarray, detections: list[dict[str, Any]], boxes: list[tuple[int, int, int, int]], centers: list[tuple[float, float]], distance: float, edges: list[np.ndarray]) -> np.ndarray:
    base = _yolo_image(image, "BGR").copy()
    for index, (item, box, center) in enumerate(zip(detections, boxes, centers), start=1):
        x1, y1, x2, y2 = box
        center_px = (int(round(center[0])), int(round(center[1])))
        cv2.rectangle(base, (x1, y1), (x2, y2), (0, 220, 255), 2)
        cv2.circle(base, center_px, 5, (0, 80, 255), -1)
        label = f"#{index} id={item.get('target_id', item.get('class_id'))} conf={float(item.get('confidence') or 0):.2f}"
        cv2.putText(base, label, (x1, max(18, y1 - 8)), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 220, 255), 2, cv2.LINE_AA)
    if len(centers) >= 2:
        p1 = tuple(int(round(value)) for value in centers[0])
        p2 = tuple(int(round(value)) for value in centers[1])
        cv2.line(base, p1, p2, (0, 80, 255), 2)
        midpoint = (int(round((p1[0] + p2[0]) / 2)), int(round((p1[1] + p2[1]) / 2)))
        cv2.putText(base, f"distance={distance:.2f}px", (max(8, midpoint[0] - 70), max(24, midpoint[1] - 8)), cv2.FONT_HERSHEY_SIMPLEX, 0.65, (0, 80, 255), 2, cv2.LINE_AA)
    panels: list[np.ndarray] = []
    target_width = max(180, min(320, base.shape[1] // 3))
    for index, edge in enumerate(edges, start=1):
        edge_bgr = cv2.cvtColor(edge, cv2.COLOR_GRAY2BGR)
        scale = target_width / max(1, edge_bgr.shape[1])
        resized = cv2.resize(edge_bgr, (target_width, max(1, int(round(edge_bgr.shape[0] * scale)))), interpolation=cv2.INTER_NEAREST)
        title = np.zeros((28, target_width, 3), dtype=np.uint8)
        cv2.putText(title, f"ROI {index} Canny", (8, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.58, (255, 255, 255), 1, cv2.LINE_AA)
        panels.append(np.vstack([title, resized]))
    if not panels:
        return base
    panel = np.vstack(panels)
    if panel.shape[0] < base.shape[0]:
        panel = np.vstack([panel, np.zeros((base.shape[0] - panel.shape[0], panel.shape[1], 3), dtype=np.uint8)])
    elif panel.shape[0] > base.shape[0]:
        base = np.vstack([base, np.zeros((panel.shape[0] - base.shape[0], base.shape[1], 3), dtype=np.uint8)])
    return np.hstack([base, panel])


def run_roi_pair_edge_distance_node(image: Any, color_space: str, detections_input: Any, params: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(image, np.ndarray):
        raise ValueError("ROI边缘距离节点需要连接原图image输入")
    if not isinstance(detections_input, list) or len(detections_input) < 2:
        raise ValueError("ROI边缘距离节点至少需要2个检测目标")
    pair = [dict(item) for item in detections_input[:2] if isinstance(item, dict)]
    if len(pair) < 2:
        raise ValueError("前两个检测目标格式无效")
    padding = max(0, _yolo_int(params.get("padding", 0), 0))
    low = max(0, _yolo_int(params.get("threshold1", 50), 50))
    high = max(0, _yolo_int(params.get("threshold2", 150), 150))
    aperture = _yolo_int(params.get("aperture_size", 3), 3)
    aperture = aperture if aperture in {3, 5, 7} else 3
    bgr = _yolo_image(image, color_space)
    height, width = bgr.shape[:2]
    boxes: list[tuple[int, int, int, int]] = []
    centers: list[tuple[float, float]] = []
    edges: list[np.ndarray] = []
    for item in pair:
        box_float = _detection_box(item)
        if box_float is None:
            raise ValueError("检测目标缺少有效box_xyxy；YOLO节点需要打开include_geometry")
        box = _clamp_detection_box(box_float, width, height, padding)
        boxes.append(box)
        center = ((box[0] + box[2]) / 2.0, (box[1] + box[3]) / 2.0)
        centers.append(center)
        item["center"] = [round(center[0], 3), round(center[1], 3)]
        item["target_id"] = item.get("track_id") if item.get("track_id") is not None else item.get("class_id")
        edges.append(_roi_edge(bgr, box, low, high, aperture))
    distance = float(np.hypot(centers[0][0] - centers[1][0], centers[0][1] - centers[1][1]))
    canvas = _roi_pair_canvas(bgr, pair, boxes, centers, distance, edges)
    metrics = {
        "distance_px": round(distance, 6),
        "center1": [round(centers[0][0], 3), round(centers[0][1], 3)],
        "center2": [round(centers[1][0], 3), round(centers[1][1], 3)],
        "target1": {"target_id": pair[0].get("target_id"), "class_id": pair[0].get("class_id"), "class_name": pair[0].get("class_name"), "confidence": pair[0].get("confidence"), "box_xyxy": list(boxes[0]), "edge_pixel_count": int(np.count_nonzero(edges[0]))},
        "target2": {"target_id": pair[1].get("target_id"), "class_id": pair[1].get("class_id"), "class_name": pair[1].get("class_name"), "confidence": pair[1].get("confidence"), "box_xyxy": list(boxes[1]), "edge_pixel_count": int(np.count_nonzero(edges[1]))},
    }
    return {
        "out": canvas, "edge1": edges[0], "edge2": edges[1], "distance": round(distance, 6),
        "center1": metrics["center1"], "center2": metrics["center2"], "metrics": metrics,
        "data": {"roi_pair_edge_distance": metrics},
    }
