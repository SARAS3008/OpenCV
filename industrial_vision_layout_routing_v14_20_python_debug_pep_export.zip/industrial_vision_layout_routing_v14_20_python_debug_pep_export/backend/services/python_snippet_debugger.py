from __future__ import annotations

import json
import math
import multiprocessing as mp
import os
import statistics
import tempfile
import time
import traceback
from collections import OrderedDict
from contextlib import redirect_stdout
from dataclasses import dataclass, field
from io import StringIO
from queue import Empty
from threading import RLock
from typing import Any, Literal, Mapping, Optional, Sequence

import cv2
import numpy as np

from backend.algorithms.script.python_snippet import (
    _ALLOWED_BUILTINS,
    _apply_worker_limits,
    _invoke_process,
    _normalize_result,
    _runtime_input_maps,
    _sanitize_worker_environment,
    _validate_code,
    normalize_input_bindings,
)
from backend.config import (
    PYTHON_SNIPPET_START_METHOD,
    PYTHON_SNIPPET_STARTUP_GRACE_SECONDS,
)

DebugCommand = Literal["continue", "step_into", "step_over", "step_out", "stop"]
_DEBUG_FILENAME = "<PythonSnippet>"
_MAX_DEBUG_VARIABLES = 80
_MAX_COLLECTION_PREVIEW = 20
_MAX_TEXT_PREVIEW = 2_000
_MAX_CONSOLE_PREVIEW = 20_000


class PythonSnippetDebugError(ValueError):
    """Raised when a line-level Python snippet debug session is unavailable."""

    def __init__(self, message: str, *, status_code: int = 400) -> None:
        super().__init__(message)
        self.status_code = status_code


class _DebugStopped(RuntimeError):
    pass


def _finite_float(value: float) -> float | str:
    return value if math.isfinite(value) else str(value)


def _debug_value(value: Any, *, depth: int = 0) -> Any:
    """Return a bounded, JSON-safe debugger representation without copying images."""

    if value is None or isinstance(value, (str, bool, int)):
        if isinstance(value, str) and len(value) > _MAX_TEXT_PREVIEW:
            return value[:_MAX_TEXT_PREVIEW] + "…"
        return value
    if isinstance(value, float):
        return _finite_float(value)
    if isinstance(value, np.generic):
        return _debug_value(value.item(), depth=depth)
    if isinstance(value, np.ndarray):
        summary: dict[str, Any] = {
            "type": "ndarray",
            "shape": [int(item) for item in value.shape],
            "dtype": str(value.dtype),
            "size": int(value.size),
        }
        if value.size and np.issubdtype(value.dtype, np.number):
            try:
                summary.update(
                    {
                        "min": _finite_float(float(np.nanmin(value))),
                        "max": _finite_float(float(np.nanmax(value))),
                        "mean": _finite_float(float(np.nanmean(value))),
                    }
                )
            except (TypeError, ValueError, FloatingPointError):
                pass
        return summary
    if depth >= 2:
        return {"type": type(value).__name__}
    if isinstance(value, Mapping):
        result: dict[str, Any] = {}
        for index, (key, child) in enumerate(value.items()):
            if index >= _MAX_COLLECTION_PREVIEW:
                result["…"] = f"其余 {max(0, len(value) - index)} 项"
                break
            result[str(key)] = _debug_value(child, depth=depth + 1)
        return {"type": type(value).__name__, "length": len(value), "value": result}
    if isinstance(value, (list, tuple, set, frozenset)):
        items = list(value)
        return {
            "type": type(value).__name__,
            "length": len(items),
            "value": [
                _debug_value(item, depth=depth + 1)
                for item in items[:_MAX_COLLECTION_PREVIEW]
            ],
            "truncated": len(items) > _MAX_COLLECTION_PREVIEW,
        }
    if callable(value):
        return {"type": type(value).__name__, "callable": True, "name": getattr(value, "__name__", "")}
    return {"type": type(value).__name__}


def _snippet_stack(frame: Any) -> list[dict[str, Any]]:
    frames: list[dict[str, Any]] = []
    current = frame
    while current is not None:
        if current.f_code.co_filename == _DEBUG_FILENAME:
            frames.append(
                {
                    "function": current.f_code.co_name,
                    "line": int(current.f_lineno),
                }
            )
        current = current.f_back
    frames.reverse()
    return frames


def _snippet_depth(frame: Any) -> int:
    return len(_snippet_stack(frame))


def _debug_snapshot(
    frame: Any,
    *,
    source_lines: list[str],
    stdout_buffer: StringIO,
    reason: str,
) -> dict[str, Any]:
    local_items = list(frame.f_locals.items())
    locals_payload: dict[str, Any] = {}
    for name, value in local_items[:_MAX_DEBUG_VARIABLES]:
        if name.startswith("__"):
            continue
        locals_payload[str(name)] = _debug_value(value)
    line_number = int(frame.f_lineno)
    source_line = source_lines[line_number - 1] if 0 < line_number <= len(source_lines) else ""
    return {
        "state": "paused",
        "reason": reason,
        "line": line_number,
        "function": frame.f_code.co_name,
        "source_line": source_line,
        "locals": locals_payload,
        "locals_truncated": len(local_items) > _MAX_DEBUG_VARIABLES,
        "stack": _snippet_stack(frame),
        "console": stdout_buffer.getvalue()[-_MAX_CONSOLE_PREVIEW:],
    }


def _build_runtime(
    inputs: dict[str, Any],
    params: dict[str, Any],
    context_info: dict[str, Any],
) -> tuple[dict[str, Any], dict[str, Any], dict[str, Any], list[dict[str, Any]]]:
    bindings = normalize_input_bindings(params.get("input_bindings"), strict=True)
    combined_inputs, named_inputs, input_meta = _runtime_input_maps(inputs, bindings)
    settings = params.get("custom_params")
    if not isinstance(settings, dict):
        settings = {}

    def get_input(name: str, default: Any = None) -> Any:
        if name in named_inputs:
            value = named_inputs[name]
            return default if value is None else value
        if name in combined_inputs:
            value = combined_inputs[name]
            return default if value is None else value
        return default

    def emit(value: Any = None, **outputs: Any) -> dict[str, Any]:
        if outputs:
            if value is not None and "out" not in outputs and "value" not in outputs:
                outputs["out"] = value
            return outputs
        return {"out": value}

    namespace: dict[str, Any] = {
        "inputs": combined_inputs,
        "ports": dict(inputs),
        "args": named_inputs,
        "params": params,
        "settings": settings,
        "context": context_info,
        "input_meta": input_meta,
        "np": np,
        "cv2": cv2,
        "math": math,
        "statistics": statistics,
        "json": json,
        "Any": Any,
        "Mapping": Mapping,
        "Optional": Optional,
        "Sequence": Sequence,
        "get_input": get_input,
        "emit": emit,
        "out": None,
        "metrics": {},
        "data": {},
    }
    namespace.update(named_inputs)
    globals_dict = {"__builtins__": _ALLOWED_BUILTINS, **namespace}
    return namespace, globals_dict, settings, input_meta


def _python_snippet_debug_worker(
    event_queue: mp.Queue,
    command_queue: mp.Queue,
    code: str,
    inputs: dict[str, Any],
    params: dict[str, Any],
    context_info: dict[str, Any],
    breakpoints: list[int],
    pause_on_start: bool,
) -> None:
    stdout_buffer = StringIO()
    try:
        _apply_worker_limits()
        _sanitize_worker_environment()
        _validate_code(code)
        source_lines = code.splitlines()
        executable_breakpoints = {line for line in breakpoints if 1 <= line <= len(source_lines)}
        namespace, globals_dict, settings, input_meta = _build_runtime(inputs, params, context_info)
        combined_inputs = namespace["inputs"]
        named_inputs = namespace["args"]

        mode: DebugCommand = "continue"
        target_depth = 0
        first_line_pending = bool(pause_on_start)
        skip_location: tuple[int, int] | None = None
        resumed_breakpoint_scope: tuple[int, int] | None = None

        def wait_for_command(frame: Any, reason: str) -> None:
            nonlocal mode, target_depth, skip_location, resumed_breakpoint_scope
            event_queue.put(
                {
                    "ok": True,
                    "event": _debug_snapshot(
                        frame,
                        source_lines=source_lines,
                        stdout_buffer=stdout_buffer,
                        reason=reason,
                    ),
                }
            )
            command = command_queue.get(timeout=300)
            action = str(command.get("action") if isinstance(command, dict) else command)
            if action == "stop":
                raise _DebugStopped("断点调试已停止")
            if action not in {"continue", "step_into", "step_over", "step_out"}:
                action = "continue"
            mode = action  # type: ignore[assignment]
            target_depth = _snippet_depth(frame)
            skip_location = (id(frame), int(frame.f_lineno))
            resumed_breakpoint_scope = (id(frame), int(frame.f_lineno))

        def frame_is_within(frame: Any, parent_id: int) -> bool:
            current = frame
            while current is not None:
                if id(current) == parent_id:
                    return True
                current = current.f_back
            return False

        def tracer(frame: Any, event: str, _arg: Any) -> Any:
            nonlocal first_line_pending, skip_location, resumed_breakpoint_scope
            if frame.f_code.co_filename != _DEBUG_FILENAME:
                return tracer
            if event != "line":
                return tracer
            location = (id(frame), int(frame.f_lineno))
            if skip_location == location:
                skip_location = None
                return tracer
            depth = _snippet_depth(frame)
            suppress_breakpoint = False
            if resumed_breakpoint_scope is not None:
                parent_id, resumed_line = resumed_breakpoint_scope
                if frame_is_within(frame, parent_id) and int(frame.f_lineno) == resumed_line:
                    suppress_breakpoint = True
                elif id(frame) == parent_id and int(frame.f_lineno) != resumed_line:
                    resumed_breakpoint_scope = None
            reason = ""
            if first_line_pending:
                first_line_pending = False
                reason = "entry"
            elif frame.f_lineno in executable_breakpoints and not suppress_breakpoint:
                reason = "breakpoint"
            elif mode == "step_into" and not suppress_breakpoint:
                reason = "step_into"
            elif mode == "step_over" and depth <= target_depth and not suppress_breakpoint:
                reason = "step_over"
            elif mode == "step_out" and depth < target_depth and not suppress_breakpoint:
                reason = "step_out"
            if reason:
                wait_for_command(frame, reason)
            return tracer

        with tempfile.TemporaryDirectory(prefix="vision-snippet-debug-") as working_dir:
            os.chdir(working_dir)
            import sys

            sys.settrace(tracer)
            try:
                with redirect_stdout(stdout_buffer):
                    exec(compile(code, _DEBUG_FILENAME, "exec"), globals_dict, namespace)
                    process = namespace.get("process") or globals_dict.get("process")
                    if callable(process):
                        raw_result = _invoke_process(
                            process,
                            named_inputs=named_inputs,
                            combined_inputs=combined_inputs,
                            raw_inputs=inputs,
                            params=params,
                            settings=settings,
                            context_info=context_info,
                            input_meta=input_meta,
                        )
                    else:
                        raw_result = namespace.get("result") if "result" in namespace else None
            finally:
                sys.settrace(None)

        normalized = _normalize_result(raw_result, namespace, params)
        event_queue.put(
            {
                "ok": True,
                "event": {
                    "state": "completed",
                    "result": _debug_value(normalized),
                    "console": stdout_buffer.getvalue()[-_MAX_CONSOLE_PREVIEW:],
                },
            }
        )
    except _DebugStopped as exc:
        event_queue.put({"ok": True, "event": {"state": "stopped", "message": str(exc)}})
    except Exception as exc:  # pragma: no cover - executed in child process
        trace = traceback.format_exc(limit=12)
        line = None
        for item in reversed(traceback.extract_tb(exc.__traceback__)):
            if item.filename == _DEBUG_FILENAME:
                line = item.lineno
                break
        event_queue.put(
            {
                "ok": False,
                "event": {
                    "state": "error",
                    "error": str(exc),
                    "cause_type": type(exc).__name__,
                    "line": line,
                    "traceback": trace,
                    "console": stdout_buffer.getvalue()[-_MAX_CONSOLE_PREVIEW:],
                },
            }
        )


@dataclass
class PythonSnippetDebugSession:
    session_id: str
    owner_id: str
    workspace_id: str
    process: mp.Process
    event_queue: mp.Queue
    command_queue: mp.Queue
    timeout_seconds: float
    created_at: float = field(default_factory=time.monotonic)
    touched_at: float = field(default_factory=time.monotonic)
    lock: RLock = field(default_factory=RLock)
    last_event: dict[str, Any] | None = None
    finished: bool = False

    def _decorate(self, event: dict[str, Any]) -> dict[str, Any]:
        payload = dict(event)
        payload["debug_session_id"] = self.session_id
        self.last_event = payload
        self.touched_at = time.monotonic()
        if payload.get("state") in {"completed", "stopped", "error"}:
            self.finished = True
        return payload

    def wait_event(self) -> dict[str, Any]:
        timeout = self.timeout_seconds + PYTHON_SNIPPET_STARTUP_GRACE_SECONDS
        try:
            payload = self.event_queue.get(timeout=timeout)
        except Empty as exc:
            self.stop_process()
            raise PythonSnippetDebugError("Python 断点调试等待超时") from exc
        event = payload.get("event") if isinstance(payload, dict) else None
        if not isinstance(event, dict):
            raise PythonSnippetDebugError("Python 断点调试进程返回了无效事件")
        return self._decorate(event)

    def command(self, action: DebugCommand) -> dict[str, Any]:
        with self.lock:
            if self.finished:
                return self.last_event or self._decorate({"state": "stopped", "message": "调试会话已结束"})
            if not self.process.is_alive():
                self.finished = True
                return self._decorate({"state": "error", "error": "调试子进程已退出"})
            self.command_queue.put({"action": action})
            return self.wait_event()

    def stop_process(self) -> None:
        if self.process.is_alive():
            try:
                self.command_queue.put_nowait({"action": "stop"})
            except Exception:
                pass
            self.process.join(0.5)
        if self.process.is_alive():
            self.process.terminate()
            self.process.join(1.0)
        self.finished = True
        for queue in (self.event_queue, self.command_queue):
            try:
                queue.close()
            except Exception:
                pass


class PythonSnippetDebugManager:
    def __init__(self, *, ttl_seconds: int = 900, max_sessions: int = 24) -> None:
        self.ttl_seconds = max(60, int(ttl_seconds))
        self.max_sessions = max(1, int(max_sessions))
        self._sessions: OrderedDict[str, PythonSnippetDebugSession] = OrderedDict()
        self._lock = RLock()

    def _cleanup_locked(self) -> None:
        now = time.monotonic()
        expired = [
            session_id
            for session_id, session in self._sessions.items()
            if now - session.touched_at > self.ttl_seconds
        ]
        for session_id in expired:
            session = self._sessions.pop(session_id, None)
            if session:
                session.stop_process()
        while len(self._sessions) >= self.max_sessions:
            _session_id, session = self._sessions.popitem(last=False)
            session.stop_process()

    def start(
        self,
        *,
        session_id: str,
        owner_id: str,
        workspace_id: str,
        code: str,
        inputs: dict[str, Any],
        params: dict[str, Any],
        context_info: dict[str, Any],
        breakpoints: list[int],
        pause_on_start: bool,
        timeout_ms: int,
    ) -> dict[str, Any]:
        _validate_code(code)
        methods = set(mp.get_all_start_methods())
        start_method = PYTHON_SNIPPET_START_METHOD if PYTHON_SNIPPET_START_METHOD in methods else "spawn"
        context = mp.get_context(start_method)
        event_queue: mp.Queue = context.Queue(maxsize=8)
        command_queue: mp.Queue = context.Queue(maxsize=8)
        process = context.Process(
            target=_python_snippet_debug_worker,
            args=(
                event_queue,
                command_queue,
                code,
                inputs,
                params,
                context_info,
                sorted(set(int(line) for line in breakpoints if int(line) > 0)),
                bool(pause_on_start),
            ),
            daemon=True,
        )
        process.start()
        session = PythonSnippetDebugSession(
            session_id=session_id,
            owner_id=owner_id,
            workspace_id=workspace_id,
            process=process,
            event_queue=event_queue,
            command_queue=command_queue,
            timeout_seconds=max(1.0, min(300.0, timeout_ms / 1000.0)),
        )
        with self._lock:
            self._cleanup_locked()
            self._sessions[session_id] = session
        try:
            event = session.wait_event()
        except Exception:
            with self._lock:
                self._sessions.pop(session_id, None)
            session.stop_process()
            raise
        if session.finished:
            with self._lock:
                self._sessions.pop(session_id, None)
            session.stop_process()
        return event

    def _get(self, session_id: str, *, owner_id: str, workspace_id: str) -> PythonSnippetDebugSession:
        with self._lock:
            self._cleanup_locked()
            session = self._sessions.get(session_id)
            if session is None:
                raise PythonSnippetDebugError("Python 断点调试会话不存在或已过期", status_code=404)
            if session.owner_id != owner_id or session.workspace_id != workspace_id:
                raise PythonSnippetDebugError("无权访问该 Python 断点调试会话", status_code=403)
            session.touched_at = time.monotonic()
            self._sessions.move_to_end(session_id)
            return session

    def command(
        self,
        session_id: str,
        *,
        action: DebugCommand,
        owner_id: str,
        workspace_id: str,
    ) -> dict[str, Any]:
        session = self._get(session_id, owner_id=owner_id, workspace_id=workspace_id)
        event = session.command(action)
        if session.finished:
            with self._lock:
                self._sessions.pop(session_id, None)
            session.stop_process()
        return event

    def status(self, session_id: str, *, owner_id: str, workspace_id: str) -> dict[str, Any]:
        session = self._get(session_id, owner_id=owner_id, workspace_id=workspace_id)
        return session.last_event or {"state": "starting", "debug_session_id": session_id}

    def stop(self, session_id: str, *, owner_id: str, workspace_id: str) -> dict[str, Any]:
        session = self._get(session_id, owner_id=owner_id, workspace_id=workspace_id)
        if not session.finished and session.process.is_alive():
            try:
                event = session.command("stop")
            except PythonSnippetDebugError:
                event = {"state": "stopped", "message": "断点调试已停止", "debug_session_id": session_id}
        else:
            event = session.last_event or {"state": "stopped", "debug_session_id": session_id}
        with self._lock:
            self._sessions.pop(session_id, None)
        session.stop_process()
        return event

    def clear(self) -> None:
        with self._lock:
            sessions = list(self._sessions.values())
            self._sessions.clear()
        for session in sessions:
            session.stop_process()


python_snippet_debug_manager = PythonSnippetDebugManager()
