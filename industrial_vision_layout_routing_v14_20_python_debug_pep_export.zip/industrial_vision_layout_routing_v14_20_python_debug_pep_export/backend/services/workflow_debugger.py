from __future__ import annotations

import hashlib
import json
import secrets
import threading
from collections import OrderedDict, defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from time import monotonic, perf_counter
from typing import Any, Literal

import numpy as np

from backend.algorithms.registry import OPERATOR_META
from backend.algorithms.types import ExecutionContext
from backend.config import (
    DEBUG_PREVIEW_MAX_SIDE,
    DEBUG_RELEASE_UNUSED_OUTPUTS,
    DEBUG_SESSION_MAX_ITEMS,
    DEBUG_SESSION_MAX_MEMORY_BYTES,
    DEBUG_SESSION_MAX_PER_WORKSPACE,
    DEBUG_SESSION_TTL_SECONDS,
    NODE_MAX_IMAGE_PIXELS,
    NODE_MAX_INPUT_BYTES,
    NODE_MAX_OUTPUT_BYTES,
)
from backend.models.workflow import WorkflowEdge, WorkflowRequest
from backend.services.image_store import ImageStore
from backend.services.node_executor import ExecutionCancelledError, NodeExecutor, estimate_value_bytes
from backend.algorithms.ai.yolo.model_manager import YoloModelManager
from backend.services.workflow_engine import (
    WorkflowEventCallback,
    WorkflowExecutionError,
    _emit_event,
    _integer,
    _parse_extensions,
    _prepare_graph,
    _truthy,
    _validate_batch_workflow,
    _yes,
)

DebugAction = Literal["step", "run_to_node"]


def _estimate_value_bytes(value: Any, seen: set[int] | None = None) -> int:
    return estimate_value_bytes(value, seen)


def _format_megabytes(size_bytes: int) -> str:
    return f"{size_bytes / (1024 * 1024):.1f} MB"


class DebugSessionError(ValueError):
    """调试会话不可用、已过期或与当前工作流不一致。"""

    def __init__(self, message: str, *, status_code: int = 400, restart_required: bool = False) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.restart_required = restart_required

    def to_response(self) -> dict[str, Any]:
        return {
            "success": False,
            "error": str(self),
            "mode": "debug",
            "restart_required": self.restart_required,
        }


def workflow_execution_signature(workflow: WorkflowRequest) -> str:
    """只对影响执行的字段计算摘要，移动节点或折叠面板不会中断调试。"""

    payload = {
        "image_id": workflow.image_id,
        "nodes": [
            {
                "id": node.id,
                "type": node.type,
                "params": node.params,
            }
            for node in workflow.nodes
        ],
        "edges": [
            {
                "source": edge.source,
                "target": edge.target,
                "sourceHandle": edge.sourceHandle or "out",
                "targetHandle": edge.targetHandle or "in",
            }
            for edge in workflow.edges
        ],
    }
    raw = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


@dataclass
class WorkflowDebugSession:
    session_id: str
    owner_id: str
    workspace_id: str
    workflow: WorkflowRequest
    signature: str
    context: ExecutionContext
    created_at: float = field(default_factory=monotonic)
    touched_at: float = field(default_factory=monotonic)
    lock: threading.RLock = field(default_factory=threading.RLock)
    completion_emitted: bool = False
    debug_sample: dict[str, Any] | None = None
    max_memory_bytes: int = DEBUG_SESSION_MAX_MEMORY_BYTES

    def __post_init__(self) -> None:
        self.order, self.nodes, self.incoming, self.outgoing = _prepare_graph(self.workflow)
        self.order_index = {node_id: index for index, node_id in enumerate(self.order)}
        self.sink_ids = [node_id for node_id in self.order if not self.outgoing[node_id]] or list(self.order)
        self.outputs: dict[str, dict[str, Any]] = {}
        self.completed_nodes: set[str] = set()
        self.released_nodes: set[str] = set()
        self.previews_by_node: OrderedDict[str, dict[str, Any]] = OrderedDict()
        self.executed_order: list[str] = []
        self.last_node_id: str | None = None
        self.memory_bytes: int = 0
        self.cancel_event = threading.Event()
        self.kernel = NodeExecutor(
            context=self.context,
            outputs=self.outputs,
            collect_preview=True,
            cancel_check=self.cancel_event.is_set,
            max_input_bytes=NODE_MAX_INPUT_BYTES,
            max_output_bytes=NODE_MAX_OUTPUT_BYTES,
            max_image_pixels=NODE_MAX_IMAGE_PIXELS,
            preview_max_side=DEBUG_PREVIEW_MAX_SIDE,
        )

    def _sorted_edges(self, edges: list[WorkflowEdge]) -> list[WorkflowEdge]:
        return sorted(edges, key=lambda item: self.order_index.get(item.source, 10**9))

    def _edge_output(self, edge: WorkflowEdge) -> Any:
        source_output = self.outputs.get(edge.source)
        if source_output is None:
            raise ValueError(f"上游节点 {edge.source} 尚未执行")
        source_handle = edge.sourceHandle or "out"
        if source_handle not in source_output:
            raise ValueError(f"上游节点 {edge.source} 不存在输出端口：{source_handle}")
        return source_output[source_handle]

    def _if_selected_edges(self, node_id: str) -> tuple[list[WorkflowEdge], str]:
        by_handle: dict[str, list[WorkflowEdge]] = defaultdict(list)
        for edge in self.incoming[node_id]:
            by_handle[edge.targetHandle or "in"].append(edge)
        condition_edges = by_handle.get("condition", [])
        if len(condition_edges) != 1:
            raise ValueError("If/Else 节点必须连接且只能连接一个 condition 输入")
        condition_edge = condition_edges[0]
        if condition_edge.source not in self.outputs:
            raise ValueError("If/Else 的 condition 上游尚未执行")
        condition = _truthy(self._edge_output(condition_edge))
        selected_handle = "true_value" if condition else "false_value"
        selected_edges = by_handle.get(selected_handle, [])
        if len(selected_edges) != 1:
            raise ValueError(f"If/Else 条件为 {condition}，但缺少 {selected_handle} 输入")
        return [condition_edge, selected_edges[0]], selected_handle

    def _next_needed_for(self, node_id: str, visiting: set[str] | None = None) -> str | None:
        if node_id in self.completed_nodes:
            return None
        if node_id not in self.nodes:
            raise ValueError(f"节点不存在：{node_id}")
        active = visiting or set()
        if node_id in active:
            raise ValueError("流程中存在递归执行，请检查节点连线")
        active.add(node_id)
        try:
            node = self.nodes[node_id]
            if node.type == "LogicIfElse":
                by_handle: dict[str, list[WorkflowEdge]] = defaultdict(list)
                for edge in self.incoming[node_id]:
                    by_handle[edge.targetHandle or "in"].append(edge)
                condition_edges = by_handle.get("condition", [])
                if len(condition_edges) != 1:
                    raise ValueError("If/Else 节点必须连接且只能连接一个 condition 输入")
                condition_edge = condition_edges[0]
                needed = self._next_needed_for(condition_edge.source, active)
                if needed:
                    return needed
                condition = _truthy(self._edge_output(condition_edge))
                selected_handle = "true_value" if condition else "false_value"
                selected_edges = by_handle.get(selected_handle, [])
                if len(selected_edges) != 1:
                    raise ValueError(f"If/Else 条件为 {condition}，但缺少 {selected_handle} 输入")
                needed = self._next_needed_for(selected_edges[0].source, active)
                return needed or node_id

            for edge in self._sorted_edges(self.incoming[node_id]):
                needed = self._next_needed_for(edge.source, active)
                if needed:
                    return needed
            return node_id
        finally:
            active.discard(node_id)

    def next_node_id(self) -> str | None:
        for sink_id in self.sink_ids:
            needed = self._next_needed_for(sink_id)
            if needed:
                return needed
        return None

    def _run_ready_node(self, node_id: str, event_callback: WorkflowEventCallback | None) -> None:
        if node_id in self.completed_nodes:
            return
        if self.cancel_event.is_set():
            raise ExecutionCancelledError("调试运行已取消")
        node = self.nodes[node_id]
        metadata = OPERATOR_META.get(node.type, {})
        node_label = str(metadata.get("label", node.type))

        started_at = perf_counter()
        _emit_event(
            event_callback,
            "node_started",
            message=f"开始调试节点 {node_id} · {node_label}",
            node_id=node_id,
            node_type=node.type,
            node_label=node_label,
            node_index=self.order_index.get(node_id, 0) + 1,
            node_total=len(self.order),
            debug=True,
        )
        try:
            if node.type == "LogicIfElse":
                input_edges, selected_if_handle = self._if_selected_edges(node_id)
            else:
                input_edges = self._sorted_edges(self.incoming[node_id])
                selected_if_handle = None

            outcome = self.kernel.execute(node, input_edges, selected_if_handle=selected_if_handle)
            if outcome.preview is not None:
                self.previews_by_node[node_id] = outcome.preview

            estimated_memory = _estimate_value_bytes(self.outputs) + _estimate_value_bytes(self.previews_by_node)
            if estimated_memory > self.max_memory_bytes:
                self.outputs.pop(node_id, None)
                self.previews_by_node.pop(node_id, None)
                raise ValueError(
                    "调试会话中间结果超过内存限制："
                    f"{_format_megabytes(estimated_memory)} > {_format_megabytes(self.max_memory_bytes)}；"
                    "请重置调试、缩小输入图像或减少高分辨率中间节点"
                )

            self.completed_nodes.add(node_id)
            self.executed_order.append(node_id)
            self.last_node_id = node_id
            self._release_consumed_outputs()
            self.memory_bytes = _estimate_value_bytes(self.outputs) + _estimate_value_bytes(self.previews_by_node)
            duration_ms = round((perf_counter() - started_at) * 1000, 2)
            _emit_event(
                event_callback,
                "node_completed",
                level="success",
                message=f"调试节点 {node_id} · {node_label} 执行完成（{duration_ms:.2f} ms，{outcome.result_kind}）",
                node_id=node_id,
                node_type=node.type,
                node_label=node_label,
                node_index=self.order_index.get(node_id, 0) + 1,
                node_total=len(self.order),
                duration_ms=duration_ms,
                result_kind=outcome.result_kind,
                input_bytes=outcome.input_bytes,
                output_bytes=outcome.output_bytes,
                retained_memory_bytes=self.memory_bytes,
                released_nodes=sorted(self.released_nodes),
                debug=True,
            )
        except Exception as exc:
            duration_ms = round((perf_counter() - started_at) * 1000, 2)
            _emit_event(
                event_callback,
                "node_failed",
                level="error",
                message=f"调试节点 {node_id} · {node_label} 执行失败：{exc}",
                node_id=node_id,
                node_type=node.type,
                node_label=node_label,
                node_index=self.order_index.get(node_id, 0) + 1,
                node_total=len(self.order),
                duration_ms=duration_ms,
                error=str(exc),
                cause_type=type(exc).__name__,
                debug=True,
            )
            raise WorkflowExecutionError(
                f"节点 {node_id}（{node_label} / {node.type}）调试执行失败：{exc}",
                node_id=node_id,
                node_type=node.type,
                node_label=node_label,
                order=self.order,
                executed_order=self.executed_order,
                previews=list(self.previews_by_node.values()),
                cause_type=type(exc).__name__,
            ) from exc

    def _release_consumed_outputs(self) -> None:
        if not DEBUG_RELEASE_UNUSED_OUTPUTS:
            return
        for source_id in list(self.outputs):
            if source_id in self.sink_ids:
                continue
            targets = {edge.target for edge in self.outgoing[source_id]}
            if targets and targets.issubset(self.completed_nodes):
                self.outputs.pop(source_id, None)
                self.released_nodes.add(source_id)

    def cancel(self) -> None:
        self.cancel_event.set()

    def status(self) -> dict[str, Any]:
        next_node = None if self.cancel_event.is_set() else self.next_node_id()
        return {
            "success": True,
            "mode": "debug",
            "debug_session_id": self.session_id,
            "workflow_signature": self.signature,
            "executed_order": list(self.executed_order),
            "current_node_id": self.last_node_id,
            "next_node_id": next_node,
            "completed": next_node is None and not self.cancel_event.is_set(),
            "cancelled": self.cancel_event.is_set(),
            "memory_bytes": self.memory_bytes,
            "memory_limit_bytes": self.max_memory_bytes,
            "retained_output_nodes": list(self.outputs),
            "released_output_nodes": sorted(self.released_nodes),
        }

    def _result(self, action: DebugAction, *, target_node_id: str | None, newly_executed: list[str]) -> dict[str, Any]:
        next_node = self.next_node_id()
        completed = next_node is None
        unexecuted = [node_id for node_id in self.order if node_id not in self.completed_nodes]
        sink_data: dict[str, Any] = {}
        for node_id, result in self.outputs.items():
            if not self.outgoing[node_id] and result.get("data"):
                sink_data[node_id] = result["data"]
        return {
            "success": True,
            "mode": "debug",
            "debug_action": action,
            "debug_session_id": self.session_id,
            "workflow_signature": self.signature,
            "order": list(self.order),
            "executed_order": list(self.executed_order),
            "newly_executed": newly_executed,
            "current_node_id": self.last_node_id,
            "next_node_id": next_node,
            "target_node_id": target_node_id,
            "pending_nodes": [] if completed else unexecuted,
            "skipped_nodes": unexecuted if completed else [],
            "completed": completed,
            "previews": list(self.previews_by_node.values()),
            "data": sink_data,
            "debug_sample": self.debug_sample,
            "memory_bytes": self.memory_bytes,
            "memory_limit_bytes": self.max_memory_bytes,
            "retained_output_nodes": list(self.outputs),
            "released_output_nodes": sorted(self.released_nodes),
            "cancelled": self.cancel_event.is_set(),
        }

    def prepare_node_inputs(
        self,
        node_id: str,
        *,
        event_callback: WorkflowEventCallback | None,
    ) -> tuple[Any, dict[str, Any]]:
        """Execute only target dependencies and return validated target inputs."""

        with self.lock:
            self.touched_at = monotonic()
            if self.cancel_event.is_set():
                raise DebugSessionError(
                    "调试会话已取消，请重新开始调试",
                    status_code=409,
                    restart_required=True,
                )
            if node_id not in self.nodes:
                raise DebugSessionError(f"指定节点不存在：{node_id}", restart_required=True)

            while True:
                next_node = self._next_needed_for(node_id)
                if next_node is None or next_node == node_id:
                    break
                self._run_ready_node(next_node, event_callback)

            node = self.nodes[node_id]
            if node.type == "LogicIfElse":
                input_edges, selected_if_handle = self._if_selected_edges(node_id)
            else:
                input_edges = self._sorted_edges(self.incoming[node_id])
                selected_if_handle = None
            inputs, _inherited_data = self.kernel.prepare_inputs(
                node,
                input_edges,
                selected_if_handle=selected_if_handle,
            )
            return node, inputs

    def run(self, action: DebugAction, *, target_node_id: str | None, event_callback: WorkflowEventCallback | None) -> dict[str, Any]:
        with self.lock:
            self.touched_at = monotonic()
            if self.cancel_event.is_set():
                raise DebugSessionError("调试会话已取消，请重新开始调试", status_code=409, restart_required=True)
            newly_executed: list[str] = []
            _emit_event(
                event_callback,
                "debug_action_started",
                level="debug",
                message="开始单步执行" if action == "step" else f"开始执行到指定节点：{target_node_id or '未选择'}",
                debug_action=action,
                session_id=self.session_id,
                target_node_id=target_node_id,
            )

            if action == "step":
                next_node = self.next_node_id()
                if next_node is not None:
                    self._run_ready_node(next_node, event_callback)
                    newly_executed.append(next_node)
                else:
                    _emit_event(event_callback, "debug_already_completed", level="warning", message="调试工作流已经执行完成")
            elif action == "run_to_node":
                if not target_node_id:
                    raise DebugSessionError("请先在画布中选择目标节点")
                if target_node_id not in self.nodes:
                    raise DebugSessionError(f"指定节点不存在：{target_node_id}", restart_required=True)
                while target_node_id not in self.completed_nodes:
                    if self.cancel_event.is_set():
                        raise ExecutionCancelledError("调试运行已取消")
                    next_node = self._next_needed_for(target_node_id)
                    if next_node is None:
                        break
                    self._run_ready_node(next_node, event_callback)
                    newly_executed.append(next_node)
                _emit_event(
                    event_callback,
                    "debug_paused",
                    level="success",
                    message=f"已执行到节点 {target_node_id}，调试已暂停；可继续单步执行",
                    target_node_id=target_node_id,
                    newly_executed=newly_executed,
                )
            else:
                raise DebugSessionError(f"不支持的调试动作：{action}")

            result = self._result(action, target_node_id=target_node_id, newly_executed=newly_executed)
            if result["completed"] and not self.completion_emitted:
                self.completion_emitted = True
                _emit_event(
                    event_callback,
                    "debug_completed",
                    level="success",
                    message=f"调试工作流执行完成，共执行 {len(self.executed_order)} 个节点",
                    executed_order=list(self.executed_order),
                    skipped_nodes=result["skipped_nodes"],
                )
            elif not result["completed"]:
                _emit_event(
                    event_callback,
                    "debug_waiting",
                    level="debug",
                    message=f"调试已暂停，下一个节点：{result['next_node_id']}",
                    next_node_id=result["next_node_id"],
                    executed_count=len(self.executed_order),
                    node_total=len(self.order),
                )
            return result


class WorkflowDebugManager:
    def __init__(self, *, ttl_seconds: int = DEBUG_SESSION_TTL_SECONDS, max_sessions: int = DEBUG_SESSION_MAX_ITEMS, max_sessions_per_workspace: int = DEBUG_SESSION_MAX_PER_WORKSPACE, max_memory_bytes: int = DEBUG_SESSION_MAX_MEMORY_BYTES) -> None:
        self.ttl_seconds = max(60, int(ttl_seconds))
        self.max_sessions = max(1, int(max_sessions))
        self.max_sessions_per_workspace = max(1, int(max_sessions_per_workspace))
        self.max_memory_bytes = max(64 * 1024 * 1024, int(max_memory_bytes))
        self._sessions: OrderedDict[str, WorkflowDebugSession] = OrderedDict()
        self._lock = threading.RLock()

    def _cleanup_locked(self) -> None:
        now = monotonic()
        expired = [session_id for session_id, session in self._sessions.items() if now - session.touched_at > self.ttl_seconds]
        for session_id in expired:
            session = self._sessions.pop(session_id, None)
            if session:
                session.cancel()

    def _evict_for_workspace_locked(self, workspace_id: str) -> None:
        workspace_sessions = [
            session_id for session_id, session in self._sessions.items() if session.workspace_id == workspace_id
        ]
        while len(workspace_sessions) >= self.max_sessions_per_workspace:
            oldest = workspace_sessions.pop(0)
            session = self._sessions.pop(oldest, None)
            if session:
                session.cancel()
        while len(self._sessions) >= self.max_sessions:
            _session_id, session = self._sessions.popitem(last=False)
            session.cancel()

    def _build_context(
        self,
        workflow: WorkflowRequest,
        image_store: ImageStore,
        *,
        user_id: str,
        workspace_id: str,
        model_manager: YoloModelManager | None,
        event_callback: WorkflowEventCallback | None,
    ) -> tuple[ExecutionContext, dict[str, Any] | None]:
        has_batch_input = any(node.type == "BatchReadImages" for node in workflow.nodes)
        has_batch_saver = any(node.type == "SaveBatchResults" for node in workflow.nodes)
        if not (has_batch_input or has_batch_saver):
            return (
                ExecutionContext(
                    image_id=workflow.image_id,
                    image_store=image_store,
                    user_id=user_id,
                    workspace_id=workspace_id,
                    model_manager=model_manager,
                ),
                None,
            )

        _, _, batch_node, _ = _validate_batch_workflow(workflow)
        input_params = batch_node.params
        source_root = image_store.resolve_directory(str(input_params.get("folder_path") or ""))
        if source_root is None:
            raise DebugSessionError(f"批量图片文件夹不存在或不可访问：{input_params.get('folder_path', '')}")
        extensions = _parse_extensions(input_params.get("extensions"), image_store.allowed_extensions)
        images = image_store.list_images(
            source_root,
            extensions=extensions,
            recursive=_yes(input_params.get("recursive"), True),
            limit=max(0, _integer(input_params.get("max_images"), 0)),
        )
        if not images:
            raise DebugSessionError(f"文件夹中没有找到符合扩展名的图片：{source_root}")
        sample = images[0]
        _emit_event(
            event_callback,
            "debug_batch_sample",
            level="warning",
            message=f"批量工作流调试仅使用首张图片：{sample.name}；不会写入批量结果文件",
            source_name=sample.name,
            source_path=str(sample),
            total=len(images),
        )
        return (
            ExecutionContext(
                image_id=None,
                image_store=image_store,
                current_image_path=sample,
                source_root=source_root,
                batch_index=1,
                batch_total=len(images),
                user_id=user_id,
                workspace_id=workspace_id,
                model_manager=model_manager,
            ),
            {
                "mode": "batch_first_image",
                "source_name": sample.name,
                "source_path": str(sample),
                "batch_total": len(images),
                "writes_disabled": True,
            },
        )

    def get_or_create(
        self,
        workflow: WorkflowRequest,
        image_store: ImageStore,
        *,
        session_id: str | None,
        user_id: str,
        workspace_id: str,
        model_manager: YoloModelManager | None,
        event_callback: WorkflowEventCallback | None,
    ) -> WorkflowDebugSession:
        signature = workflow_execution_signature(workflow)
        with self._lock:
            self._cleanup_locked()
            if session_id:
                session = self._sessions.get(session_id)
                if session is None:
                    raise DebugSessionError("调试会话已过期或服务已重启，请重新开始调试", status_code=409, restart_required=True)
                if session.owner_id != user_id or session.workspace_id != workspace_id:
                    raise DebugSessionError("无权访问该调试会话", status_code=403, restart_required=True)
                if session.signature != signature:
                    raise DebugSessionError("工作流执行参数或连线已修改，请重新开始调试", status_code=409, restart_required=True)
                session.touched_at = monotonic()
                self._sessions.move_to_end(session_id)
                return session

            if not workflow.nodes:
                raise DebugSessionError("流程为空，请先添加节点")
            self._evict_for_workspace_locked(workspace_id)
            context, debug_sample = self._build_context(
                workflow,
                image_store,
                user_id=user_id,
                workspace_id=workspace_id,
                model_manager=model_manager,
                event_callback=event_callback,
            )
            new_session_id = secrets.token_urlsafe(24)
            session = WorkflowDebugSession(
                session_id=new_session_id,
                owner_id=user_id,
                workspace_id=workspace_id,
                workflow=workflow,
                signature=signature,
                context=context,
                debug_sample=debug_sample,
                max_memory_bytes=self.max_memory_bytes,
            )
            self._sessions[new_session_id] = session
            _emit_event(
                event_callback,
                "debug_session_started",
                level="debug",
                message=f"调试会话已创建：{len(session.order)} 个节点",
                session_id=new_session_id,
                node_total=len(session.order),
                expires_in_seconds=self.ttl_seconds,
            )
            return session

    def run(
        self,
        workflow: WorkflowRequest,
        image_store: ImageStore,
        *,
        action: DebugAction,
        target_node_id: str | None,
        session_id: str | None,
        user_id: str,
        workspace_id: str,
        model_manager: YoloModelManager | None,
        event_callback: WorkflowEventCallback | None,
    ) -> dict[str, Any]:
        session = self.get_or_create(
            workflow,
            image_store,
            session_id=session_id,
            user_id=user_id,
            workspace_id=workspace_id,
            model_manager=model_manager,
            event_callback=event_callback,
        )
        try:
            return session.run(action, target_node_id=target_node_id, event_callback=event_callback)
        except WorkflowExecutionError as exc:
            # 让前端保留失败现场；修复外部资源问题后可直接重试该节点。
            exc.debug_session_id = session.session_id
            exc.workflow_signature = session.signature
            exc.debug_next_node_id = exc.node_id
            raise
        finally:
            session.touched_at = monotonic()

    def prepare_node_inputs(
        self,
        workflow: WorkflowRequest,
        image_store: ImageStore,
        *,
        node_id: str,
        user_id: str,
        workspace_id: str,
        model_manager: YoloModelManager | None,
        event_callback: WorkflowEventCallback | None = None,
    ) -> tuple[WorkflowDebugSession, Any, dict[str, Any]]:
        """Prepare one node's upstream values without executing the node itself."""

        session = self.get_or_create(
            workflow,
            image_store,
            session_id=None,
            user_id=user_id,
            workspace_id=workspace_id,
            model_manager=model_manager,
            event_callback=event_callback,
        )
        node, inputs = session.prepare_node_inputs(node_id, event_callback=event_callback)
        return session, node, inputs

    def reset(self, session_id: str, *, user_id: str, workspace_id: str) -> bool:
        with self._lock:
            self._cleanup_locked()
            session = self._sessions.get(session_id)
            if session is None:
                return False
            if session.owner_id != user_id or session.workspace_id != workspace_id:
                raise DebugSessionError("无权重置该调试会话", status_code=403)
            session.cancel()
            self._sessions.pop(session_id, None)
            return True

    def cancel(self, session_id: str, *, user_id: str, workspace_id: str) -> dict[str, Any]:
        with self._lock:
            self._cleanup_locked()
            session = self._sessions.get(session_id)
            if session is None:
                raise DebugSessionError("调试会话不存在或已过期", status_code=404, restart_required=True)
            if session.owner_id != user_id or session.workspace_id != workspace_id:
                raise DebugSessionError("无权取消该调试会话", status_code=403)
            session.cancel()
            session.touched_at = monotonic()
            return session.status()

    def status(self, session_id: str, *, user_id: str, workspace_id: str) -> dict[str, Any]:
        with self._lock:
            self._cleanup_locked()
            session = self._sessions.get(session_id)
            if session is None:
                raise DebugSessionError("调试会话不存在或已过期", status_code=404, restart_required=True)
            if session.owner_id != user_id or session.workspace_id != workspace_id:
                raise DebugSessionError("无权查看该调试会话", status_code=403)
            session.touched_at = monotonic()
            self._sessions.move_to_end(session_id)
            return session.status()

    def session_count(self) -> int:
        with self._lock:
            self._cleanup_locked()
            return len(self._sessions)

    def clear(self) -> None:
        with self._lock:
            for session in self._sessions.values():
                session.cancel()
            self._sessions.clear()


workflow_debug_manager = WorkflowDebugManager()
