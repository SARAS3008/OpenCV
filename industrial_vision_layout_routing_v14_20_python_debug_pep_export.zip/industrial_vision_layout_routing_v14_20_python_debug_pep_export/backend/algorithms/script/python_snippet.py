from __future__ import annotations

import ast
import inspect
import json
import keyword
import math
import multiprocessing as mp
import os
import re
import statistics
import tempfile
import time
import traceback
from contextlib import redirect_stdout
from queue import Empty
from dataclasses import asdict, is_dataclass
from io import StringIO
from pathlib import Path
from typing import Any, Mapping, Optional, Sequence

import cv2
import numpy as np

from backend.algorithms.types import ExecutionContext, OperatorInputs, OperatorParams, OperatorResult
from backend.config import (
    PYTHON_SNIPPET_ALLOW_INLINE,
    PYTHON_SNIPPET_CPU_LIMIT_SECONDS,
    PYTHON_SNIPPET_START_METHOD,
    PYTHON_SNIPPET_STARTUP_GRACE_SECONDS,
)


_DEFAULT_CODE = """# 每个输入端口都可以配置一个 Python 参数名。\n# 例如把端口命名为 image、mask、threshold 后，可以直接这样编写：\ndef process(image=None, mask=None, threshold=128):\n    if image is None:\n        return None\n    if mask is not None:\n        mask = (mask > 0).astype(np.uint8) * 255\n        image = cv2.bitwise_and(image, image, mask=mask)\n    return image\n"""

_DEFAULT_INPUT_BINDINGS: list[dict[str, Any]] = [
    {"handle": "in", "name": "image", "label": "主图像", "type": "image", "required": False},
    {"handle": "aux", "name": "aux", "label": "辅助输入", "type": "any", "required": False},
    {"handle": "value", "name": "value", "label": "数值/对象", "type": "any", "required": False},
]
_MAX_INPUT_BINDINGS = 20
_BINDING_NAME_PATTERN = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
_RUNTIME_RESERVED_NAMES = {
    "inputs",
    "ports",
    "args",
    "params",
    "settings",
    "context",
    "input_meta",
    "np",
    "cv2",
    "math",
    "statistics",
    "json",
    "emit",
    "get_input",
    "out",
    "metrics",
    "data",
    "process",
}
_RESULT_CONTRACT_KEYS = {
    "out",
    "image",
    "value",
    "metrics",
    "data",
    "result",
    "out_color_space",
    "image_color_space",
}

_FORBIDDEN_CALLS = {
    "__import__",
    "breakpoint",
    "compile",
    "delattr",
    "dir",
    "eval",
    "exec",
    "getattr",
    "globals",
    "help",
    "input",
    "locals",
    "memoryview",
    "open",
    "setattr",
    "super",
    "vars",
}
_FORBIDDEN_NODES = (
    ast.AsyncFunctionDef,
    ast.Await,
    ast.ClassDef,
    ast.Delete,
    ast.Global,
    ast.Import,
    ast.ImportFrom,
    ast.Nonlocal,
    ast.AsyncWith,
)

# np/cv2 中包含直接文件访问、模型加载和设备访问接口。即使禁用了 open/import，
# 这些 API 仍可绕过基础 AST 限制，因此在服务端代码片段中显式禁用。
_FORBIDDEN_ATTRIBUTES = {
    "FileStorage",
    "VideoCapture",
    "VideoWriter",
    "fromfile",
    "genfromtxt",
    "imdecode",
    "imencode",
    "imread",
    "imwrite",
    "load",
    "loadtxt",
    "memmap",
    "readNet",
    "readNetFromCaffe",
    "readNetFromDarknet",
    "readNetFromONNX",
    "readNetFromTensorflow",
    "save",
    "savetxt",
    "savez",
    "savez_compressed",
    "tofile",
}

_ALLOWED_BUILTINS: dict[str, Any] = {
    "abs": abs,
    "all": all,
    "any": any,
    "bool": bool,
    "bin": bin,
    "callable": callable,
    "chr": chr,
    "complex": complex,
    "bytes": bytes,
    "bytearray": bytearray,
    "dict": dict,
    "enumerate": enumerate,
    "divmod": divmod,
    "format": format,
    "filter": filter,
    "float": float,
    "int": int,
    "hash": hash,
    "hex": hex,
    "isinstance": isinstance,
    "len": len,
    "list": list,
    "map": map,
    "max": max,
    "min": min,
    "pow": pow,
    "oct": oct,
    "ord": ord,
    "print": print,
    "range": range,
    "reversed": reversed,
    "round": round,
    "set": set,
    "frozenset": frozenset,
    "slice": slice,
    "sorted": sorted,
    "str": str,
    "sum": sum,
    "tuple": tuple,
    "type": type,
    "iter": iter,
    "next": next,
    "repr": repr,
    "zip": zip,
    "Exception": Exception,
    "ValueError": ValueError,
    "TypeError": TypeError,
    "RuntimeError": RuntimeError,
    "AssertionError": AssertionError,
    "AttributeError": AttributeError,
    "IndexError": IndexError,
    "KeyError": KeyError,
    "LookupError": LookupError,
    "NameError": NameError,
    "OverflowError": OverflowError,
    "StopIteration": StopIteration,
    "UnboundLocalError": UnboundLocalError,
    "ZeroDivisionError": ZeroDivisionError,
}


def default_input_bindings() -> list[dict[str, Any]]:
    return [dict(item) for item in _DEFAULT_INPUT_BINDINGS]


def _binding_default_enabled(binding: Mapping[str, Any]) -> bool:
    return bool(binding.get("default_enabled", False))


def normalize_input_bindings(value: Any, *, strict: bool = True) -> list[dict[str, Any]]:
    """Normalize configurable snippet ports while preserving legacy workflows."""

    raw = value
    if isinstance(raw, str):
        try:
            raw = json.loads(raw)
        except json.JSONDecodeError as exc:
            if strict:
                raise ValueError(f"输入参数配置不是有效 JSON：{exc.msg}") from exc
            raw = None
    if not isinstance(raw, list) or not raw:
        raw = default_input_bindings()
    if len(raw) > _MAX_INPUT_BINDINGS:
        raise ValueError(f"Python代码片段最多支持 {_MAX_INPUT_BINDINGS} 个输入参数")

    normalized: list[dict[str, Any]] = []
    handles: set[str] = set()
    names: set[str] = set()
    allowed_types = {"any", "image", "number", "boolean", "string", "object", "list"}
    for index, item in enumerate(raw, start=1):
        if not isinstance(item, Mapping):
            if strict:
                raise ValueError(f"第 {index} 个输入参数配置必须是对象")
            continue
        handle = str(item.get("handle") or ("in" if index == 1 else f"arg{index - 1}")).strip()
        name = str(item.get("name") or handle).strip()
        label = str(item.get("label") or name or handle).strip()[:80]
        input_type = str(item.get("type") or "any").strip().lower()
        if not _BINDING_NAME_PATTERN.fullmatch(handle):
            raise ValueError(f"输入端口 handle 无效：{handle}")
        if not _BINDING_NAME_PATTERN.fullmatch(name) or keyword.iskeyword(name):
            raise ValueError(f"输入参数名必须是有效 Python 变量名：{name}")
        if name in _RUNTIME_RESERVED_NAMES:
            raise ValueError(f"输入参数名与运行时保留变量冲突：{name}")
        if handle in handles:
            raise ValueError(f"输入端口 handle 重复：{handle}")
        if name in names:
            raise ValueError(f"输入参数名重复：{name}")
        handles.add(handle)
        names.add(name)
        normalized_item: dict[str, Any] = {
            "handle": handle,
            "name": name,
            "label": label or name,
            "type": input_type if input_type in allowed_types else "any",
            "required": bool(item.get("required", False)),
        }
        if _binding_default_enabled(item):
            normalized_item["default_enabled"] = True
            normalized_item["default"] = item.get("default")
        normalized.append(normalized_item)
    return normalized or default_input_bindings()


def _runtime_input_maps(
    raw_inputs: Mapping[str, Any],
    bindings: Sequence[Mapping[str, Any]],
) -> tuple[dict[str, Any], dict[str, Any], list[dict[str, Any]]]:
    ports = dict(raw_inputs)
    named: dict[str, Any] = {}
    input_meta: list[dict[str, Any]] = []
    for binding in bindings:
        handle = str(binding["handle"])
        name = str(binding["name"])
        connected = handle in ports
        if connected:
            value = ports[handle]
        elif _binding_default_enabled(binding):
            value = binding.get("default")
        else:
            value = None
        named[name] = value
        input_meta.append(
            {
                "handle": handle,
                "name": name,
                "label": str(binding.get("label") or name),
                "type": str(binding.get("type") or "any"),
                "required": bool(binding.get("required", False)),
                "connected": connected,
                "used_default": not connected and _binding_default_enabled(binding),
            }
        )
    combined = dict(ports)
    for name, value in named.items():
        combined.setdefault(name, value)
    return combined, named, input_meta


def _invoke_process(
    process: Any,
    *,
    named_inputs: Mapping[str, Any],
    combined_inputs: Mapping[str, Any],
    raw_inputs: Mapping[str, Any],
    params: Mapping[str, Any],
    settings: Mapping[str, Any],
    context_info: Mapping[str, Any],
    input_meta: Sequence[Mapping[str, Any]],
) -> Any:
    """Call either legacy process(inputs, params, context) or named Python arguments."""

    signature = inspect.signature(process)
    special = {
        "inputs": combined_inputs,
        "ports": raw_inputs,
        "args": named_inputs,
        "params": params,
        "settings": settings,
        "context": context_info,
        "input_meta": input_meta,
    }
    positional: list[Any] = []
    keyword_args: dict[str, Any] = {}
    consumed: set[str] = set()
    available_named_inputs = {
        str(item.get("name"))
        for item in input_meta
        if item.get("connected") or item.get("used_default")
    }
    accepts_var_kwargs = False
    for parameter in signature.parameters.values():
        if parameter.kind is inspect.Parameter.VAR_POSITIONAL:
            continue
        if parameter.kind is inspect.Parameter.VAR_KEYWORD:
            accepts_var_kwargs = True
            continue
        if parameter.name in named_inputs and (
            parameter.name in available_named_inputs or parameter.default is inspect.Parameter.empty
        ):
            value = named_inputs[parameter.name]
            consumed.add(parameter.name)
        elif parameter.name in special:
            value = special[parameter.name]
        elif parameter.default is not inspect.Parameter.empty:
            continue
        else:
            available = "、".join(sorted(named_inputs)) or "无"
            raise ValueError(
                f"process() 参数 {parameter.name} 没有对应输入；"
                f"请在节点输入配置中添加同名参数。当前可用参数：{available}"
            )
        if parameter.kind is inspect.Parameter.POSITIONAL_ONLY:
            positional.append(value)
        else:
            keyword_args[parameter.name] = value
    if accepts_var_kwargs:
        for name, value in named_inputs.items():
            if name not in consumed and name not in keyword_args:
                keyword_args[name] = value
    return process(*positional, **keyword_args)


def _to_int(value: Any, default: int, *, minimum: int | None = None, maximum: int | None = None) -> int:
    try:
        result = int(float(value))
    except (TypeError, ValueError):
        result = default
    if minimum is not None:
        result = max(minimum, result)
    if maximum is not None:
        result = min(maximum, result)
    return result


def _yes(value: Any, default: bool = False) -> bool:
    if isinstance(value, bool):
        return value
    if value is None:
        return default
    text = str(value).strip().upper()
    if text in {"YES", "TRUE", "1", "ON", "Y", "是", "启用"}:
        return True
    if text in {"NO", "FALSE", "0", "OFF", "N", "否", "禁用"}:
        return False
    return default


def _context_info(context: ExecutionContext) -> dict[str, Any]:
    # 不把服务器文件路径、用户标识等敏感运行时信息暴露给自定义代码。
    return {
        "image_id": context.image_id,
        "batch_index": context.batch_index,
        "batch_total": context.batch_total,
    }


class _SnippetSafetyVisitor(ast.NodeVisitor):
    def visit(self, node: ast.AST) -> Any:  # noqa: ANN401
        if isinstance(node, _FORBIDDEN_NODES):
            raise ValueError(f"代码片段不允许使用语法：{type(node).__name__}")
        return super().visit(node)

    def visit_Attribute(self, node: ast.Attribute) -> Any:  # noqa: ANN401
        if node.attr.startswith("__"):
            raise ValueError("代码片段不允许访问双下划线属性")
        if node.attr in _FORBIDDEN_ATTRIBUTES:
            raise ValueError(f"代码片段不允许访问文件、设备或模型加载接口：{node.attr}")
        self.generic_visit(node)

    def visit_Name(self, node: ast.Name) -> Any:  # noqa: ANN401
        if node.id.startswith("__"):
            raise ValueError("代码片段不允许访问双下划线名称")
        self.generic_visit(node)

    def visit_Call(self, node: ast.Call) -> Any:  # noqa: ANN401
        func = node.func
        if isinstance(func, ast.Name) and func.id in _FORBIDDEN_CALLS:
            raise ValueError(f"代码片段不允许调用：{func.id}")
        if isinstance(func, ast.Attribute) and func.attr in _FORBIDDEN_CALLS:
            raise ValueError(f"代码片段不允许调用：{func.attr}")
        self.generic_visit(node)


def _validate_code(code: str) -> None:
    try:
        tree = ast.parse(code, mode="exec")
    except SyntaxError as exc:
        raise ValueError(f"Python 语法错误：第 {exc.lineno} 行，{exc.msg}") from exc
    _SnippetSafetyVisitor().visit(tree)


def _json_safe(value: Any) -> Any:
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, np.ndarray):
        return {
            "array": True,
            "shape": list(value.shape),
            "dtype": str(value.dtype),
        }
    if isinstance(value, Path):
        return str(value)
    if is_dataclass(value):
        return _json_safe(asdict(value))
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, dict):
        return {str(key): _json_safe(child) for key, child in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [_json_safe(child) for child in value]
    try:
        json.dumps(value)
        return value
    except TypeError:
        return str(value)


def _normalize_result(raw_result: Any, namespace: dict[str, Any], params: dict[str, Any]) -> dict[str, Any]:
    if raw_result is None:
        if "result" in namespace:
            raw_result = namespace["result"]
        else:
            raw_result = {
                key: namespace[key]
                for key in ("out", "image", "value", "metrics", "data")
                if key in namespace
            }

    if isinstance(raw_result, dict) and set(raw_result).intersection(_RESULT_CONTRACT_KEYS):
        result = dict(raw_result)
    elif isinstance(raw_result, dict):
        # 普通业务字典不再要求用户记住 out/value/data 契约；自动作为值和结构化数据输出。
        result = {"out": raw_result, "value": raw_result, "data": {"result": raw_result}}
    elif isinstance(raw_result, np.ndarray):
        result = {"out": raw_result, "image": raw_result}
    else:
        result = {"out": raw_result, "value": raw_result, "metrics": {"value": _json_safe(raw_result)}}

    if "out" not in result:
        if isinstance(result.get("image"), np.ndarray):
            result["out"] = result["image"]
        elif "value" in result:
            result["out"] = result["value"]

    if "image" not in result and isinstance(result.get("out"), np.ndarray):
        result["image"] = result["out"]
    if "value" not in result and not isinstance(result.get("out"), np.ndarray):
        result["value"] = result.get("out")

    metrics = result.get("metrics")
    if metrics is None:
        metrics = {}
    elif not isinstance(metrics, dict):
        metrics = {"result": metrics}
    metrics = _json_safe(metrics)
    if not isinstance(metrics, dict):
        metrics = {"result": metrics}
    result["metrics"] = metrics

    data = result.get("data")
    if data is None:
        data = {}
    elif not isinstance(data, dict):
        data = {"result": data}
    data = _json_safe(data)
    if not isinstance(data, dict):
        data = {"result": data}
    result["data"] = data

    color = str(result.get("out_color_space") or params.get("output_color_space") or "AUTO").upper()
    if color in {"BGR", "RGB", "GRAY"} and isinstance(result.get("out"), np.ndarray):
        result["out_color_space"] = color
    if isinstance(result.get("image"), np.ndarray):
        image_color = str(result.get("image_color_space") or result.get("out_color_space") or color).upper()
        if image_color in {"BGR", "RGB", "GRAY"}:
            result["image_color_space"] = image_color

    return result


def _execute_snippet_worker(
    queue: mp.Queue,
    code: str,
    inputs: dict[str, Any],
    params: dict[str, Any],
    context_info: dict[str, Any],
) -> None:
    try:
        _apply_worker_limits()
        _sanitize_worker_environment()
        with tempfile.TemporaryDirectory(prefix="vision-snippet-") as working_dir:
            os.chdir(working_dir)
            bindings = normalize_input_bindings(params.get("input_bindings"), strict=True)
            combined_inputs, named_inputs, input_meta = _runtime_input_maps(inputs, bindings)
            settings = params.get("custom_params")
            if not isinstance(settings, dict):
                settings = {}

            def get_input(name: str, default: Any = None) -> Any:
                if name in named_inputs:
                    value = named_inputs[name]
                    return default if value is None else value
                if name in combined_inputs:
                    value = combined_inputs[name]
                    return default if value is None else value
                return default

            def emit(value: Any = None, **outputs: Any) -> dict[str, Any]:
                if outputs:
                    if value is not None and "out" not in outputs and "value" not in outputs:
                        outputs["out"] = value
                    return outputs
                return {"out": value}

            namespace: dict[str, Any] = {
                "inputs": combined_inputs,
                "ports": dict(inputs),
                "args": named_inputs,
                "params": params,
                "settings": settings,
                "context": context_info,
                "input_meta": input_meta,
                "np": np,
                "cv2": cv2,
                "math": math,
                "statistics": statistics,
                "json": json,
                "Any": Any,
                "Mapping": Mapping,
                "Optional": Optional,
                "Sequence": Sequence,
                "get_input": get_input,
                "emit": emit,
                "out": None,
                "metrics": {},
                "data": {},
            }
            namespace.update(named_inputs)
            globals_dict = {"__builtins__": _ALLOWED_BUILTINS, **namespace}
            stdout_buffer = StringIO()
            with redirect_stdout(stdout_buffer):
                exec(compile(code, "<PythonSnippet>", "exec"), globals_dict, namespace)
                process = namespace.get("process") or globals_dict.get("process")
                if callable(process):
                    raw_result = _invoke_process(
                        process,
                        named_inputs=named_inputs,
                        combined_inputs=combined_inputs,
                        raw_inputs=inputs,
                        params=params,
                        settings=settings,
                        context_info=context_info,
                        input_meta=input_meta,
                    )
                else:
                    raw_result = namespace.get("result") if "result" in namespace else None
            normalized = _normalize_result(raw_result, namespace, params)
            console_text = stdout_buffer.getvalue().strip()
            if console_text:
                data = normalized.get("data") if isinstance(normalized.get("data"), dict) else {}
                data["console"] = console_text[-20_000:]
                normalized["data"] = data
            queue.put({"ok": True, "result": normalized})
    except Exception as exc:  # pragma: no cover - exercised through parent process
        queue.put(
            {
                "ok": False,
                "error": str(exc),
                "cause_type": type(exc).__name__,
                "traceback": traceback.format_exc(limit=8),
            }
        )


def _sanitize_worker_environment() -> None:
    allowed = {"LANG", "LC_ALL", "TZ", "OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS"}
    preserved = {key: value for key, value in os.environ.items() if key in allowed}
    os.environ.clear()
    os.environ.update(preserved)


def _apply_worker_limits() -> None:
    try:
        import resource

        cpu_used = int(time.process_time()) + 1
        cpu_soft = cpu_used + max(1, int(PYTHON_SNIPPET_CPU_LIMIT_SECONDS))
        resource.setrlimit(resource.RLIMIT_CPU, (cpu_soft, cpu_soft + 1))
        resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
        # 保留少量临时文件额度，供运行时/标准库正常工作，同时避免代码片段
        # 意外写出大文件。文件访问 API 仍由 AST 校验单独阻断。
        file_limit = 1 * 1024 * 1024
        resource.setrlimit(resource.RLIMIT_FSIZE, (file_limit, file_limit))
        current_soft, current_hard = resource.getrlimit(resource.RLIMIT_NOFILE)
        nofile = min(64, current_soft if current_soft > 0 else 64, current_hard if current_hard > 0 else 64)
        resource.setrlimit(resource.RLIMIT_NOFILE, (nofile, nofile))
    except (ImportError, OSError, ValueError):
        # Windows 或受限容器可能不支持 resource；超时终止仍由父进程保证。
        return


def _run_in_subprocess(code: str, inputs: dict[str, Any], params: dict[str, Any], context_info: dict[str, Any], timeout_ms: int) -> dict[str, Any]:
    methods = set(mp.get_all_start_methods())
    start_method = PYTHON_SNIPPET_START_METHOD if PYTHON_SNIPPET_START_METHOD in methods else "spawn"
    mp_context = mp.get_context(start_method)
    queue: mp.Queue = mp_context.Queue(maxsize=1)
    process = mp_context.Process(target=_execute_snippet_worker, args=(queue, code, inputs, params, context_info), daemon=True)
    process.start()
    try:
        payload = queue.get(timeout=timeout_ms / 1000.0 + PYTHON_SNIPPET_STARTUP_GRACE_SECONDS)
    except Empty:
        if process.is_alive():
            process.terminate()
            process.join(1.0)
            raise TimeoutError(f"Python代码片段执行超时：{timeout_ms} ms")
        process.join(1.0)
        if process.exitcode not in (0, None):
            raise RuntimeError(f"Python代码片段子进程异常退出，exitcode={process.exitcode}")
        raise RuntimeError("Python代码片段没有返回结果")
    finally:
        process.join(1.0)
        if process.is_alive():
            process.terminate()
            process.join(1.0)
        queue.close()
    if not payload.get("ok"):
        detail = payload.get("error") or "未知错误"
        trace = str(payload.get("traceback") or "").strip()
        snippet_line = next((line.strip() for line in reversed(trace.splitlines()) if "<PythonSnippet>" in line), "")
        suffix = f"（{snippet_line}）" if snippet_line else ""
        raise ValueError(f"Python代码片段执行失败：{detail}{suffix}")
    result = payload.get("result")
    if not isinstance(result, dict):
        raise ValueError("Python代码片段返回结果必须是字典")
    return result


def _run_inline(code: str, inputs: dict[str, Any], params: dict[str, Any], context_info: dict[str, Any]) -> dict[str, Any]:
    queue: Any = type("InlineQueue", (), {})()
    payloads: list[dict[str, Any]] = []
    queue.put = payloads.append
    _execute_snippet_worker(queue, code, inputs, params, context_info)
    payload = payloads[0]
    if not payload.get("ok"):
        raise ValueError(f"Python代码片段执行失败：{payload.get('error') or '未知错误'}")
    result = payload.get("result")
    if not isinstance(result, dict):
        raise ValueError("Python代码片段返回结果必须是字典")
    return result


def op_python_snippet(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    """执行受限 Python 代码片段。"""

    code = str(params.get("code") or "").strip("\ufeff")
    if not code.strip():
        code = _DEFAULT_CODE
    _validate_code(code)

    timeout_ms = _to_int(params.get("timeout_ms", 1000), 1000, minimum=50, maximum=30000)
    isolated = _yes(params.get("isolated", "YES"), True)
    if not isolated and not PYTHON_SNIPPET_ALLOW_INLINE:
        raise ValueError(
            "为保护服务进程，Python代码片段必须使用隔离执行。"
            "如确需调试主进程模式，请由管理员显式设置 VISION_ALLOW_INLINE_PYTHON_SNIPPET=1。"
        )
    context_info = _context_info(context)

    # 传入用户代码的 params 不包含 code 本身，避免结果 data 中意外回显大量代码。
    runtime_params = {key: value for key, value in params.items() if key != "code"}
    bindings = normalize_input_bindings(runtime_params.get("input_bindings"), strict=True)
    runtime_params["input_bindings"] = bindings
    for binding in bindings:
        handle = str(binding["handle"])
        if binding.get("required") and handle not in inputs and not _binding_default_enabled(binding):
            raise ValueError(f"缺少必填输入参数：{binding['name']}（端口 {handle}）")
    started = time.perf_counter()
    result = _run_in_subprocess(code, dict(inputs), runtime_params, context_info, timeout_ms) if isolated else _run_inline(code, dict(inputs), runtime_params, context_info)
    elapsed_ms = round((time.perf_counter() - started) * 1000.0, 3)

    metrics = result.get("metrics") if isinstance(result.get("metrics"), dict) else {}
    metrics.setdefault("elapsed_ms", elapsed_ms)
    metrics.setdefault("isolated", isolated)
    result["metrics"] = metrics
    data = result.get("data") if isinstance(result.get("data"), dict) else {}
    data.setdefault("python_snippet", {"elapsed_ms": elapsed_ms, "isolated": isolated})
    result["data"] = data
    return result


