from __future__ import annotations

from typing import Callable

from backend.algorithms.industrial.metadata import INDUSTRIAL_OPERATOR_TYPES
from backend.algorithms.industrial.runtime import _industrial_execute
from backend.algorithms.types import ExecutionContext, Operator, OperatorInputs, OperatorParams, OperatorResult


def _make_operator(node_type: str) -> Operator:
    def operator(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
        del context
        return _industrial_execute(node_type, inputs, params)

    operator.__name__ = f"op_{node_type}"
    operator.__qualname__ = operator.__name__
    operator.__doc__ = f"工业视觉算子：{node_type}"
    return operator


INDUSTRIAL_OPERATORS: dict[str, Operator] = {
    node_type: _make_operator(node_type)
    for node_type in sorted(INDUSTRIAL_OPERATOR_TYPES)
}


__all__ = ["INDUSTRIAL_OPERATORS"]
