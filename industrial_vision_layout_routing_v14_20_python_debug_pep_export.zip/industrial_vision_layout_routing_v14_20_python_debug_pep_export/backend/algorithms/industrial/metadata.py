from __future__ import annotations

from typing import Any


def _port(handle: str, label: str, type_name: str = "any", required: bool = True, color_space: str = "") -> dict[str, Any]:
    item: dict[str, Any] = {"handle": handle, "label": label, "type": type_name, "required": required}
    if color_space:
        item["color_space"] = color_space
    return item


def _number(label: str, help_text: str = "", *, step: Any | None = None) -> dict[str, Any]:
    result: dict[str, Any] = {"label": label, "type": "number"}
    if help_text:
        result["help"] = help_text
    if step is not None:
        result["step"] = step
    return result


def _text(label: str, help_text: str = "", rows: int | None = None) -> dict[str, Any]:
    result: dict[str, Any] = {"label": label, "type": "textarea" if rows else "text"}
    if help_text:
        result["help"] = help_text
    if rows:
        result["rows"] = rows
    return result


def _select(label: str, values: list[tuple[str, str]], help_text: str = "") -> dict[str, Any]:
    result: dict[str, Any] = {
        "label": label,
        "type": "select",
        "options": [{"value": value, "label": item_label} for value, item_label in values],
    }
    if help_text:
        result["help"] = help_text
    return result


def _yes_no(label: str, help_text: str = "") -> dict[str, Any]:
    return _select(label, [("YES", "是"), ("NO", "否")], help_text)


def _meta(
    label: str,
    category: str,
    group: str,
    kind: str,
    description: str,
    params: dict[str, Any] | None = None,
    schema: dict[str, Any] | None = None,
    inputs: list[dict[str, Any]] | None = None,
    outputs: list[dict[str, Any]] | None = None,
    result_type: str = "image",
) -> dict[str, Any]:
    if inputs is None:
        inputs = [_port("in", "图像", "image")]
    if outputs is None:
        outputs = [_port("out", "结果", "image")]
    return {
        "label": label,
        "category": category,
        "group": group,
        "kind": kind,
        "has_input": bool(inputs),
        "has_output": bool(outputs),
        "inputs": inputs,
        "outputs": outputs,
        "result_type": result_type,
        "params": params or {},
        "param_schema": schema or {},
        "description": description,
    }


IMAGE_IN = [_port("in", "图像", "image")]
IMAGE_OUT = [_port("out", "结果", "image")]
MASK_OUT = [_port("out", "Mask", "image", color_space="GRAY"), _port("mask", "Mask", "image", color_space="GRAY")]

INDUSTRIAL_OPERATOR_META: dict[str, dict[str, Any]] = {
    # 图像增强
    "GammaCorrection": _meta("Gamma 校正", "图像", "工业增强", "enhance", "幂律灰度变换，适合补偿相机和显示系统的非线性响应。", {"gamma": 1.0}, {"gamma": _number("Gamma", "小于 1 提亮暗部，大于 1 压暗。", step=0.05)}),
    "BrightnessContrast": _meta("亮度与对比度", "图像", "工业增强", "enhance", "线性变换 output = input × contrast + brightness。", {"contrast": 1.0, "brightness": 0}, {"contrast": _number("对比度", step=0.05), "brightness": _number("亮度偏移")}),
    "GrayRangeNormalize": _meta("百分位灰度拉伸", "图像", "工业增强", "enhance", "按低/高百分位拉伸灰度，抑制少量极端亮暗像素。", {"low_percentile": 1.0, "high_percentile": 99.0}, {"low_percentile": _number("低百分位"), "high_percentile": _number("高百分位")}, outputs=[_port("out", "增强图", "image", color_space="GRAY"), _port("low_value", "低灰度", "number"), _port("high_value", "高灰度", "number")]),
    "LogTransform": _meta("对数增强", "图像", "工业增强", "enhance", "增强暗区域细节并压缩高亮动态范围。", {"scale": 1.0}, {"scale": _number("缩放系数", step=0.1)}),
    "WhiteBalance": _meta("白平衡", "图像", "工业增强", "color", "灰度世界或百分位拉伸白平衡，用于减弱光源色偏。", {"mode": "GRAY_WORLD", "percentile": 1.0}, {"mode": _select("模式", [("GRAY_WORLD", "灰度世界"), ("SIMPLE", "百分位拉伸")]), "percentile": _number("截断百分位")}, outputs=[_port("out", "平衡图", "image", color_space="BGR")]),
    "IlluminationCorrection": _meta("光照校正", "图像", "工业增强", "enhance", "估计大尺度背景并做除法或减法校正，对应工业视觉中的平场/背景校正思路。", {"background_ksize": 51, "mode": "DIVIDE"}, {"background_ksize": _number("背景核尺寸", "建议远大于缺陷尺寸。"), "mode": _select("校正方式", [("DIVIDE", "除法校正"), ("SUBTRACT", "减法校正")])}, outputs=[_port("out", "校正图", "image", color_space="GRAY"), _port("background", "背景图", "image", color_space="GRAY")]),
    "FlatFieldCorrection": _meta("平场校正", "图像", "工业增强", "enhance", "使用平场图和可选暗场图校正镜头渐晕、光照不均和传感器响应差异。", {}, {}, inputs=[_port("in", "待校正图", "image"), _port("flat", "平场图", "image"), _port("dark", "暗场图", "image", False)], outputs=[_port("out", "校正图", "image", color_space="BGR")]),
    "NonLocalMeansDenoise": _meta("非局部均值降噪", "图像", "工业增强", "filter", "OpenCV 非局部均值去噪，适合纹理保留要求较高的场景。", {"h": 10, "template_window": 7, "search_window": 21}, {"h": _number("滤波强度"), "template_window": _number("模板窗口"), "search_window": _number("搜索窗口")}),
    "UnsharpMask": _meta("反遮罩锐化", "图像", "工业增强", "filter", "高斯模糊差分锐化，比固定卷积锐化更适合精细调参。", {"ksize": 5, "sigma": 1.0, "amount": 1.5, "threshold": 0}, {"ksize": _number("核尺寸"), "sigma": _number("Sigma"), "amount": _number("锐化强度"), "threshold": _number("低对比保护阈值")}, outputs=[_port("out", "锐化图", "image"), _port("blurred", "模糊图", "image")]),
    "GaborFilter": _meta("Gabor 纹理滤波", "图像", "频域与纹理", "texture", "按指定方向和波长增强周期纹理、划痕或纤维结构。", {"ksize": 21, "sigma": 4.0, "theta": 0, "wavelength": 10, "aspect_ratio": 0.5, "phase": 0}, {"ksize": _number("核尺寸"), "sigma": _number("Sigma"), "theta": _number("方向角°"), "wavelength": _number("波长"), "aspect_ratio": _number("长宽比"), "phase": _number("相位°")}, outputs=[_port("out", "响应图", "image", color_space="GRAY"), _port("response", "浮点响应", "any")]),
    "FFTFilter": _meta("FFT 频域滤波", "图像", "频域与纹理", "frequency", "低通、高通、带通和带阻频域滤波，可用于周期噪声、背景和纹理分离。", {"mode": "LOW_PASS", "radius": 30, "inner_radius": 10}, {"mode": _select("模式", [("LOW_PASS", "低通"), ("HIGH_PASS", "高通"), ("BAND_PASS", "带通"), ("BAND_STOP", "带阻")]), "radius": _number("外半径"), "inner_radius": _number("内半径")}, outputs=[_port("out", "滤波结果", "image", color_space="GRAY"), _port("spectrum", "频谱图", "image", color_space="GRAY"), _port("frequency_mask", "频域 Mask", "image", color_space="GRAY")]),
    "DynamicThreshold": _meta("动态阈值", "图像", "区域分割", "segment", "局部背景与原图比较，对应 HALCON dyn_threshold 的常用检测思路。", {"background_ksize": 31, "offset": 10, "mode": "DARK"}, {"background_ksize": _number("背景核尺寸"), "offset": _number("灰度偏差"), "mode": _select("缺陷极性", [("DARK", "暗于背景"), ("LIGHT", "亮于背景")])}, outputs=[_port("out", "Mask", "image", color_space="GRAY"), _port("mask", "Mask", "image", color_space="GRAY"), _port("background", "局部背景", "image", color_space="GRAY")]),

    # 颜色与分割
    "ChannelExtract": _meta("提取颜色通道", "图像", "颜色通道", "color", "提取 BGR、HSV、Lab 或灰度通道。", {"channel": "GRAY"}, {"channel": _select("通道", [("GRAY", "灰度"), ("B", "B"), ("G", "G"), ("R", "R"), ("H", "HSV-H"), ("S", "HSV-S"), ("V", "HSV-V"), ("L", "Lab-L"), ("A", "Lab-a"), ("LAB_B", "Lab-b")])}, outputs=[_port("out", "通道图", "image", color_space="GRAY"), _port("channel", "通道名", "text")]),
    "ChannelMerge": _meta("合并三通道", "图像", "颜色通道", "color", "将三个单通道图合并为 BGR 或 RGB 图。", {"order": "BGR"}, {"order": _select("输出顺序", [("BGR", "BGR"), ("RGB", "RGB")])}, inputs=[_port("c1", "通道1", "image", False), _port("c2", "通道2", "image", False), _port("c3", "通道3", "image", False)], outputs=[_port("out", "彩色图", "image", color_space="BGR")]),
    "ColorRangeMask": _meta("颜色范围分割", "图像", "区域分割", "segment", "在 HSV、Lab、YCrCb 或 BGR 空间内进行三通道范围分割。", {"color_space": "HSV", "low1": 0, "high1": 179, "low2": 0, "high2": 255, "low3": 0, "high3": 255}, {"color_space": _select("颜色空间", [("HSV", "HSV"), ("LAB", "Lab"), ("YCRCB", "YCrCb"), ("BGR", "BGR")]), "low1": _number("通道1下限"), "high1": _number("通道1上限"), "low2": _number("通道2下限"), "high2": _number("通道2上限"), "low3": _number("通道3下限"), "high3": _number("通道3上限")}, outputs=[_port("out", "Mask", "image", color_space="GRAY"), _port("mask", "Mask", "image", color_space="GRAY"), _port("masked", "抠图", "image", color_space="BGR")]),
    "RangeThreshold": _meta("灰度范围阈值", "图像", "区域分割", "segment", "选择指定灰度区间，对应 HALCON threshold(Image, Region, MinGray, MaxGray)。", {"low": 0, "high": 255, "invert": "NO"}, {"low": _number("下限"), "high": _number("上限"), "invert": _yes_no("反相")}, outputs=MASK_OUT),
    "KMeansSegment": _meta("KMeans 颜色分割", "图像", "区域分割", "segment", "按像素颜色聚类生成分区图，适合颜色类别相对稳定的零件或缺陷。", {"clusters": 3, "attempts": 3, "max_iter": 20, "epsilon": 1.0}, {"clusters": _number("聚类数"), "attempts": _number("重复次数"), "max_iter": _number("最大迭代"), "epsilon": _number("收敛阈值")}, outputs=[_port("out", "分割图", "image", color_space="BGR"), _port("labels", "标签图", "image", color_space="GRAY"), _port("centers", "聚类中心", "list")]),
    "WatershedSegment": _meta("分水岭分割", "图像", "区域分割", "segment", "自动生成前景和背景标记，分离相互接触的目标。", {"invert": "NO", "ksize": 3, "iterations": 2, "background_iterations": 3, "foreground_ratio": 0.4}, {"invert": _yes_no("前景反相"), "ksize": _number("形态学核"), "iterations": _number("开运算次数"), "background_iterations": _number("背景膨胀次数"), "foreground_ratio": _number("前景距离比例")}, outputs=[_port("out", "边界标注", "image", color_space="BGR"), _port("mask", "前景 Mask", "image", color_space="GRAY"), _port("labels", "标签矩阵", "any")]),
    "RegionGrow": _meta("区域生长", "图像", "区域分割", "segment", "从种子点按灰度容差扩展连通区域。", {"seed_x": 0, "seed_y": 0, "tolerance": 10}, {"seed_x": _number("种子X"), "seed_y": _number("种子Y"), "tolerance": _number("灰度容差")}, inputs=[_port("in", "图像", "image"), _port("seed", "种子点", "any", False)], outputs=[_port("out", "Mask", "image", color_space="GRAY"), _port("mask", "Mask", "image", color_space="GRAY"), _port("annotated", "标注图", "image", color_space="BGR"), _port("seed", "种子点", "any")]),
    "GrabCutSegment": _meta("GrabCut 前景分割", "图像", "区域分割", "segment", "通过矩形或初始 Mask 进行前景/背景迭代分割。", {"x": 5, "y": 5, "width": 100, "height": 100, "iterations": 5}, {"x": _number("矩形X"), "y": _number("矩形Y"), "width": _number("矩形宽"), "height": _number("矩形高"), "iterations": _number("迭代次数")}, inputs=[_port("in", "图像", "image"), _port("mask", "初始 Mask", "image", False)], outputs=[_port("out", "前景图", "image", color_space="BGR"), _port("mask", "前景 Mask", "image", color_space="GRAY")]),

    # 形态学区域
    "MorphTopHat": _meta("顶帽变换", "图像", "形态学与区域", "morph", "提取比结构元素小的亮结构。", {"ksize": 15, "shape": "RECT", "iterations": 1}, {"ksize": _number("核尺寸"), "shape": _select("核形状", [("RECT", "矩形"), ("ELLIPSE", "椭圆"), ("CROSS", "十字")]), "iterations": _number("迭代次数")}),
    "MorphBlackHat": _meta("黑帽变换", "图像", "形态学与区域", "morph", "提取比结构元素小的暗结构。", {"ksize": 15, "shape": "RECT", "iterations": 1}, {"ksize": _number("核尺寸"), "shape": _select("核形状", [("RECT", "矩形"), ("ELLIPSE", "椭圆"), ("CROSS", "十字")]), "iterations": _number("迭代次数")}),
    "FillHoles": _meta("区域填孔", "图像", "形态学与区域", "morph", "填充前景区域内部孔洞，对应 HALCON fill_up。", {"threshold": 0}, {"threshold": _number("二值阈值", "0 表示非零像素为前景。")}, outputs=[_port("out", "填孔结果", "image", color_space="GRAY"), _port("holes", "孔洞区域", "image", color_space="GRAY")]),
    "Skeletonize": _meta("骨架提取", "图像", "形态学与区域", "morph", "迭代细化二值区域，得到单像素骨架。", {"threshold": 0, "max_iterations": 10000}, {"threshold": _number("二值阈值"), "max_iterations": _number("最大迭代")}, outputs=[_port("out", "骨架", "image", color_space="GRAY")]),
    "DistanceTransform": _meta("距离变换", "图像", "形态学与区域", "morph", "计算前景像素到最近背景的欧氏距离。", {"threshold": 0, "mask_size": "5"}, {"threshold": _number("二值阈值"), "mask_size": _select("距离模板", [("3", "3"), ("5", "5")])}, outputs=[_port("out", "可视化", "image", color_space="GRAY"), _port("distance", "浮点距离图", "any"), _port("max_distance", "最大距离", "number")]),
    "ConnectedComponents": _meta("连通区域分析", "图像", "形态学与区域", "region", "连接二值区域并输出标签、外接框、面积和中心，对应 HALCON connection + area_center。", {"threshold": 0, "connectivity": "8", "min_area": 0, "max_area": 0}, {"threshold": _number("二值阈值"), "connectivity": _select("连通性", [("4", "4邻域"), ("8", "8邻域")]), "min_area": _number("最小面积"), "max_area": _number("最大面积，0不限")}, outputs=[_port("out", "标签彩色图", "image", color_space="BGR"), _port("labels", "标签矩阵", "any"), _port("mask", "筛选 Mask", "image", color_space="GRAY"), _port("components", "区域信息", "list"), _port("count", "区域数", "number")]),
    "RemoveSmallRegions": _meta("去除小区域", "图像", "形态学与区域", "region", "按连通区域面积过滤噪声，类似 connection + select_shape(area)。", {"threshold": 0, "connectivity": "8", "min_area": 50, "max_area": 0}, {"threshold": _number("二值阈值"), "connectivity": _select("连通性", [("4", "4邻域"), ("8", "8邻域")]), "min_area": _number("最小面积"), "max_area": _number("最大面积，0不限")}, outputs=[_port("out", "过滤 Mask", "image", color_space="GRAY"), _port("mask", "过滤 Mask", "image", color_space="GRAY"), _port("components", "区域信息", "list"), _port("count", "区域数", "number")]),
    "ConvexHullMask": _meta("区域凸包", "图像", "形态学与区域", "region", "计算各连通轮廓凸包并生成区域，类似 HALCON shape_trans(...,'convex')。", {"threshold": 0, "min_area": 0}, {"threshold": _number("二值阈值"), "min_area": _number("最小轮廓面积")}, outputs=[_port("out", "凸包 Mask", "image", color_space="GRAY"), _port("mask", "凸包 Mask", "image", color_space="GRAY"), _port("annotated", "标注图", "image", color_space="BGR"), _port("hulls", "凸包点集", "list")]),
    "RegionBoundary": _meta("区域边界", "图像", "形态学与区域", "region", "从二值区域提取内边界。", {"threshold": 0, "thickness": 1}, {"threshold": _number("二值阈值"), "thickness": _number("边界厚度")}, outputs=[_port("out", "边界图", "image", color_space="GRAY")]),

    # 几何标定
    "CropROI": _meta("矩形 ROI 裁剪", "图像", "几何与标定", "geo", "按像素坐标裁剪矩形区域，对应 crop_rectangle1。", {"x": 0, "y": 0, "width": 100, "height": 100}, {"x": _number("X"), "y": _number("Y"), "width": _number("宽"), "height": _number("高")}, outputs=[_port("out", "ROI", "image"), _port("roi", "ROI", "image"), _port("bbox", "矩形", "any")]),
    "RotateArbitrary": _meta("任意角度旋转", "图像", "几何与标定", "geo", "围绕图像中心旋转，可自动扩展画布。", {"angle": 0, "scale": 1.0, "expand": "YES", "border_value": "0,0,0"}, {"angle": _number("角度°"), "scale": _number("缩放"), "expand": _yes_no("扩展画布"), "border_value": _text("边界 B,G,R")}, outputs=[_port("out", "旋转图", "image"), _port("matrix", "仿射矩阵", "any")]),
    "AffineWarp": _meta("仿射变换", "图像", "几何与标定", "geo", "由三对对应点计算仿射变换，类似 affine_trans_image。", {"source_points": "[[0,0],[100,0],[0,100]]", "target_points": "[[0,0],[100,0],[0,100]]", "output_width": 640, "output_height": 480, "border_value": "0,0,0"}, {"source_points": _text("源三点 JSON", rows=3), "target_points": _text("目标三点 JSON", rows=3), "output_width": _number("输出宽"), "output_height": _number("输出高"), "border_value": _text("边界 B,G,R")}, outputs=[_port("out", "变换图", "image"), _port("matrix", "仿射矩阵", "any")]),
    "PerspectiveWarp": _meta("透视矫正", "图像", "几何与标定", "geo", "由四对对应点完成透视矫正，类似 projective_trans_image。", {"source_points": "[[0,0],[639,0],[639,479],[0,479]]", "target_points": "[[0,0],[639,0],[639,479],[0,479]]", "output_width": 640, "output_height": 480, "border_value": "0,0,0"}, {"source_points": _text("源四点 JSON", rows=4), "target_points": _text("目标四点 JSON", rows=4), "output_width": _number("输出宽"), "output_height": _number("输出高"), "border_value": _text("边界 B,G,R")}, outputs=[_port("out", "矫正图", "image"), _port("matrix", "单应矩阵", "any")]),
    "PadImage": _meta("图像扩边", "图像", "几何与标定", "geo", "在图像四周增加固定、复制、反射或循环边界。", {"top": 0, "bottom": 0, "left": 0, "right": 0, "border_type": "CONSTANT", "value": "0,0,0"}, {"top": _number("上"), "bottom": _number("下"), "left": _number("左"), "right": _number("右"), "border_type": _select("边界类型", [("CONSTANT", "固定值"), ("REPLICATE", "复制"), ("REFLECT", "反射"), ("REFLECT101", "反射101"), ("WRAP", "循环")]), "value": _text("固定值 B,G,R")}),
    "PolarTransform": _meta("极坐标变换", "图像", "几何与标定", "geo", "将圆环、圆柱表面或旋转结构展开为直角坐标图。", {"center_x": -1, "center_y": -1, "max_radius": 100, "output_width": 100, "output_height": 360, "inverse": "NO", "log_mode": "NO"}, {"center_x": _number("中心X", "负数表示自动使用图像中心。"), "center_y": _number("中心Y", "负数表示自动使用图像中心。"), "max_radius": _number("最大半径"), "output_width": _number("输出宽"), "output_height": _number("输出高"), "inverse": _yes_no("逆变换"), "log_mode": _yes_no("对数极坐标")}, outputs=[_port("out", "极坐标图", "image"), _port("center", "中心", "any"), _port("max_radius", "最大半径", "number")]),
    "CameraUndistort": _meta("相机畸变校正", "图像", "几何与标定", "calibration", "根据相机内参和畸变系数校正径向/切向畸变。", {"camera_matrix": "[[1000,0,320],[0,1000,240],[0,0,1]]", "dist_coeffs": "[0,0,0,0,0]", "alpha": 0, "crop": "NO"}, {"camera_matrix": _text("相机矩阵 JSON", rows=3), "dist_coeffs": _text("畸变系数 JSON", rows=2), "alpha": _number("自由缩放 Alpha"), "crop": _yes_no("裁剪有效区")}, outputs=[_port("out", "校正图", "image"), _port("new_camera_matrix", "新内参", "any"), _port("roi", "有效区", "any")]),
    "CoordinateTransform": _meta("坐标单应变换", "测量", "坐标与标定", "calibration", "使用 3×3 单应矩阵转换点坐标。", {"points": "[[0,0]]", "matrix": "[[1,0,0],[0,1,0],[0,0,1]]"}, {"points": _text("默认点集 JSON", rows=2), "matrix": _text("3×3 矩阵 JSON", rows=3)}, inputs=[_port("points", "点/点集", "any", False)], outputs=[_port("out", "点集", "list"), _port("points", "点集", "list"), _port("point", "首点", "any"), _port("x", "X", "number"), _port("y", "Y", "number")], result_type="metrics"),
    "PixelToWorld": _meta("像素转世界坐标", "测量", "坐标与标定", "calibration", "通过单应矩阵和比例系数将像素点转换为世界坐标。", {"points": "[[0,0]]", "homography": "[[1,0,0],[0,1,0],[0,0,1]]", "scale": 1.0}, {"points": _text("默认点集 JSON", rows=2), "homography": _text("3×3 单应矩阵", rows=3), "scale": _number("单位缩放")}, inputs=[_port("points", "像素点集", "any", False)], outputs=[_port("out", "世界点集", "list"), _port("points", "世界点集", "list"), _port("point", "首点", "any"), _port("x", "X", "number"), _port("y", "Y", "number")], result_type="metrics"),

    # 模板与定位
    "TemplateMatchNCC": _meta("NCC 模板匹配", "图像", "模板匹配与定位", "match", "归一化相关模板匹配，适合平移定位且尺度变化较小的场景。", {"method": "CCOEFF_NORMED", "draw_color": "0,255,0", "thickness": 2}, {"method": _select("匹配方法", [("CCOEFF_NORMED", "相关系数"), ("CCORR_NORMED", "互相关"), ("SQDIFF_NORMED", "平方差")]), "draw_color": _text("标注 B,G,R"), "thickness": _number("线宽")}, inputs=[_port("in", "待匹配图", "image"), _port("template", "模板图", "image")], outputs=[_port("out", "标注图", "image", color_space="BGR"), _port("bbox", "匹配框", "any"), _port("center", "中心", "any"), _port("score", "得分", "number"), _port("scale", "尺度", "number"), _port("response", "响应热图", "image", color_space="BGR")]),
    "MultiScaleTemplateMatch": _meta("多尺度模板匹配", "图像", "模板匹配与定位", "match", "在多个尺度上执行 NCC 模板匹配，适合存在一定尺寸变化的目标。", {"method": "CCOEFF_NORMED", "min_scale": 0.5, "max_scale": 1.5, "scale_steps": 11, "draw_color": "0,255,0", "thickness": 2}, {"method": _select("匹配方法", [("CCOEFF_NORMED", "相关系数"), ("CCORR_NORMED", "互相关"), ("SQDIFF_NORMED", "平方差")]), "min_scale": _number("最小尺度"), "max_scale": _number("最大尺度"), "scale_steps": _number("尺度数量"), "draw_color": _text("标注 B,G,R"), "thickness": _number("线宽")}, inputs=[_port("in", "待匹配图", "image"), _port("template", "模板图", "image")], outputs=[_port("out", "标注图", "image", color_space="BGR"), _port("bbox", "匹配框", "any"), _port("center", "中心", "any"), _port("score", "得分", "number"), _port("scale", "尺度", "number"), _port("response", "响应热图", "image", color_space="BGR")]),
    "ShapeMatch": _meta("轮廓形状匹配", "图像", "模板匹配与定位", "match", "使用 Hu 矩比较轮廓形状，对旋转和尺度变化具有一定鲁棒性。", {"threshold": 0, "draw_color": "0,255,0"}, {"threshold": _number("二值阈值"), "draw_color": _text("标注 B,G,R")}, inputs=[_port("in", "目标二值图", "image"), _port("template", "模板二值图", "image")], outputs=[_port("out", "标注图", "image", color_space="BGR"), _port("bbox", "外接框", "any"), _port("score", "差异得分", "number"), _port("contour", "匹配轮廓", "list")]),
    "PhaseCorrelation": _meta("相位相关定位", "图像", "模板匹配与定位", "match", "通过频域相位相关估计两幅同尺寸图像的亚像素平移。", {"use_window": "YES"}, {"use_window": _yes_no("使用汉宁窗")}, inputs=[_port("in", "待对齐图", "image"), _port("reference", "参考图", "image")], outputs=[_port("out", "对齐图", "image", color_space="BGR"), _port("shift", "位移", "any"), _port("dx", "X位移", "number"), _port("dy", "Y位移", "number"), _port("response", "响应", "number"), _port("matrix", "变换矩阵", "any")]),
    "AKAZEFeatureMatch": _meta("AKAZE 特征匹配", "图像", "模板匹配与定位", "match", "基于 AKAZE 局部特征和 RANSAC 单应性进行目标定位。", {"threshold": 0.001, "ratio_test": 0.75, "min_matches": 6, "ransac_threshold": 5, "max_draw_matches": 40}, {"threshold": _number("AKAZE 阈值"), "ratio_test": _number("比率测试"), "min_matches": _number("最少匹配"), "ransac_threshold": _number("RANSAC 阈值"), "max_draw_matches": _number("最大绘制数")}, inputs=[_port("in", "待匹配图", "image"), _port("template", "模板图", "image")], outputs=[_port("out", "定位图", "image", color_space="BGR"), _port("matches", "匹配连线图", "image", color_space="BGR"), _port("match_count", "匹配数", "number"), _port("inlier_count", "内点数", "number"), _port("homography", "单应矩阵", "any"), _port("corners", "模板角点", "list"), _port("found", "找到", "boolean")]),
    "HoughLines": _meta("霍夫线段检测", "图像", "特征与几何", "feature", "从边缘图中检测直线段，输出端点、长度和角度。", {"threshold": 50, "min_line_length": 30, "max_line_gap": 10, "max_lines": 100, "draw_color": "0,0,255", "thickness": 2}, {"threshold": _number("累加阈值"), "min_line_length": _number("最短线段"), "max_line_gap": _number("最大间隙"), "max_lines": _number("最大数量"), "draw_color": _text("标注 B,G,R"), "thickness": _number("线宽")}, outputs=[_port("out", "标注图", "image", color_space="BGR"), _port("lines", "线段列表", "list"), _port("count", "数量", "number"), _port("first", "第一条线", "any")]),
    "HoughCircles": _meta("霍夫圆检测", "图像", "特征与几何", "feature", "检测圆心和半径，适合孔、圆片和同心结构定位。", {"blur_ksize": 5, "dp": 1.2, "min_distance": 20, "canny_threshold": 100, "accumulator_threshold": 30, "min_radius": 0, "max_radius": 0, "max_circles": 50, "draw_color": "0,255,0"}, {"blur_ksize": _number("预滤波核"), "dp": _number("累加器比例"), "min_distance": _number("圆心最小距离"), "canny_threshold": _number("Canny高阈值"), "accumulator_threshold": _number("累加器阈值"), "min_radius": _number("最小半径"), "max_radius": _number("最大半径"), "max_circles": _number("最大数量"), "draw_color": _text("标注 B,G,R")}, outputs=[_port("out", "标注图", "image", color_space="BGR"), _port("circles", "圆列表", "list"), _port("count", "数量", "number"), _port("first", "第一个圆", "any")]),
    "HarrisCorners": _meta("Harris 角点", "图像", "特征与几何", "feature", "检测强角点，适合标记板、棋盘和结构转角。", {"block_size": 2, "ksize": 3, "k": 0.04, "quality": 0.01, "max_corners": 200, "radius": 3, "draw_color": "0,0,255"}, {"block_size": _number("邻域大小"), "ksize": _number("Sobel核"), "k": _number("Harris K"), "quality": _number("质量阈值"), "max_corners": _number("最大角点"), "radius": _number("标记半径"), "draw_color": _text("标注 B,G,R")}, outputs=[_port("out", "标注图", "image", color_space="BGR"), _port("points", "角点列表", "list"), _port("count", "数量", "number")]),
    "ShiTomasiCorners": _meta("Shi-Tomasi 角点", "图像", "特征与几何", "feature", "Good Features to Track 角点检测。", {"max_corners": 200, "quality": 0.01, "min_distance": 10, "block_size": 3, "radius": 3, "draw_color": "0,0,255"}, {"max_corners": _number("最大角点"), "quality": _number("质量阈值"), "min_distance": _number("最小距离"), "block_size": _number("邻域大小"), "radius": _number("标记半径"), "draw_color": _text("标注 B,G,R")}, outputs=[_port("out", "标注图", "image", color_space="BGR"), _port("points", "角点列表", "list"), _port("count", "数量", "number")]),

    # 测量与缺陷
    "BlobAnalysis": _meta("Blob 区域测量", "测量", "区域与尺寸测量", "measure", "输出连通区域面积、周长、外接框、中心、圆度和实心度。", {"threshold": 0, "min_area": 0, "max_area": 0}, {"threshold": _number("二值阈值"), "min_area": _number("最小面积"), "max_area": _number("最大面积，0不限")}, outputs=[_port("out", "标注图", "image", color_space="BGR"), _port("mask", "区域 Mask", "image", color_space="GRAY"), _port("blobs", "Blob列表", "list"), _port("count", "数量", "number"), _port("largest", "最大Blob", "any")]),
    "ImageStatistics": _meta("图像统计", "测量", "灰度与统计", "measure", "计算图像或 Mask 区域的均值、标准差、极值和百分位。", {}, {}, inputs=[_port("in", "图像", "image"), _port("mask", "Mask", "image", False)], outputs=[_port("out", "统计对象", "any"), _port("statistics", "统计对象", "any")], result_type="metrics"),
    "HistogramAnalysis": _meta("直方图分析", "测量", "灰度与统计", "measure", "输出灰度直方图、归一化分布、峰值和均值。", {"bins": 256}, {"bins": _number("Bins")}, inputs=[_port("in", "图像", "image"), _port("mask", "Mask", "image", False)], outputs=[_port("out", "直方图图像", "image", color_space="BGR"), _port("histogram", "直方图", "list"), _port("normalized_histogram", "归一化直方图", "list"), _port("peak_bin", "峰值Bin", "number"), _port("mean", "均值", "number")]),
    "IntensityProfile": _meta("灰度剖面", "测量", "灰度与统计", "measure", "沿指定线段进行亚像素采样，输出一维灰度曲线。", {"x1": 0, "y1": 0, "x2": 100, "y2": 0}, {"x1": _number("起点X"), "y1": _number("起点Y"), "x2": _number("终点X"), "y2": _number("终点Y")}, inputs=[_port("in", "图像", "image"), _port("p1", "起点", "any", False), _port("p2", "终点", "any", False)], outputs=[_port("out", "标注图", "image", color_space="BGR"), _port("profile", "灰度曲线", "list"), _port("p1", "起点", "any"), _port("p2", "终点", "any"), _port("mean", "均值", "number"), _port("std", "标准差", "number")]),
    "CaliperEdgePair": _meta("卡尺边缘对测量", "测量", "亚像素与卡尺", "measure", "沿测量方向采样多个剖面，寻找两条边并输出像素距离。", {"center_x": 0, "center_y": 0, "angle": 0, "length": 100, "sample_width": 5, "gradient_threshold": 10, "polarity": "ANY"}, {"center_x": _number("中心X"), "center_y": _number("中心Y"), "angle": _number("测量方向°"), "length": _number("卡尺长度"), "sample_width": _number("平均宽度"), "gradient_threshold": _number("梯度阈值"), "polarity": _select("边缘极性", [("ANY", "任意"), ("DARK_TO_LIGHT", "暗到亮"), ("LIGHT_TO_DARK", "亮到暗")])}, inputs=[_port("in", "图像", "image"), _port("center", "中心点", "any", False)], outputs=[_port("out", "测量图", "image", color_space="BGR"), _port("edge1", "边缘1", "any"), _port("edge2", "边缘2", "any"), _port("distance", "像素距离", "number"), _port("profile", "剖面", "list"), _port("gradient", "梯度", "list")]),
    "FitCircle": _meta("轮廓拟合圆", "测量", "轮廓拟合", "measure", "最小二乘拟合轮廓圆，输出中心、半径和残差。", {"threshold": 0, "min_area": 10}, {"threshold": _number("二值阈值"), "min_area": _number("最小轮廓面积")}, outputs=[_port("out", "拟合图", "image", color_space="BGR"), _port("circle", "圆对象", "any"), _port("center", "圆心", "any"), _port("radius", "半径", "number"), _port("diameter", "直径", "number"), _port("residual", "拟合残差", "number")]),
    "FitEllipse": _meta("轮廓拟合椭圆", "测量", "轮廓拟合", "measure", "拟合轮廓椭圆，输出中心、长短轴和角度。", {"threshold": 0, "min_area": 10}, {"threshold": _number("二值阈值"), "min_area": _number("最小轮廓面积")}, outputs=[_port("out", "拟合图", "image", color_space="BGR"), _port("ellipse", "椭圆对象", "any"), _port("center", "中心", "any"), _port("size", "轴长", "any"), _port("angle", "角度", "number")]),
    "PointPointDistance": _meta("点到点距离", "测量", "几何关系", "measure", "计算两点像素距离，并支持单位/像素换算。", {"x1": 0, "y1": 0, "x2": 100, "y2": 0, "unit_per_pixel": 1.0}, {"x1": _number("点1 X"), "y1": _number("点1 Y"), "x2": _number("点2 X"), "y2": _number("点2 Y"), "unit_per_pixel": _number("单位/像素")}, inputs=[_port("p1", "点1", "any", False), _port("p2", "点2", "any", False), _port("image", "背景图", "image", False)], outputs=[_port("out", "测量图", "image", color_space="BGR"), _port("distance", "实际距离", "number"), _port("pixel_distance", "像素距离", "number"), _port("p1", "点1", "any"), _port("p2", "点2", "any"), _port("value", "距离值", "number")]),
    "LineIntersection": _meta("两直线交点", "测量", "几何关系", "measure", "计算两条无限直线交点并判断是否平行。", {"line1_x1": 0, "line1_y1": 0, "line1_x2": 100, "line1_y2": 0, "line2_x1": 50, "line2_y1": -50, "line2_x2": 50, "line2_y2": 50}, {key: _number(label) for key, label in [("line1_x1", "线1 X1"), ("line1_y1", "线1 Y1"), ("line1_x2", "线1 X2"), ("line1_y2", "线1 Y2"), ("line2_x1", "线2 X1"), ("line2_y1", "线2 Y1"), ("line2_x2", "线2 X2"), ("line2_y2", "线2 Y2")]}, inputs=[_port("line1", "直线1", "any", False), _port("line2", "直线2", "any", False), _port("image", "背景图", "image", False)], outputs=[_port("out", "交点图", "image", color_space="BGR"), _port("point", "交点", "any"), _port("parallel", "是否平行", "boolean"), _port("line1", "直线1", "any"), _port("line2", "直线2", "any")]),
    "AngleBetweenLines": _meta("两直线夹角", "测量", "几何关系", "measure", "计算两条直线的锐角夹角。", {"line1_x1": 0, "line1_y1": 0, "line1_x2": 100, "line1_y2": 0, "line2_x1": 0, "line2_y1": 0, "line2_x2": 100, "line2_y2": 100}, {key: _number(label) for key, label in [("line1_x1", "线1 X1"), ("line1_y1", "线1 Y1"), ("line1_x2", "线1 X2"), ("line1_y2", "线1 Y2"), ("line2_x1", "线2 X1"), ("line2_y1", "线2 Y1"), ("line2_x2", "线2 X2"), ("line2_y2", "线2 Y2")]}, inputs=[_port("line1", "直线1", "any", False), _port("line2", "直线2", "any", False)], outputs=[_port("out", "角度", "number"), _port("angle", "角度", "number"), _port("value", "角度值", "number")], result_type="metrics"),
    "ImageDifference": _meta("参考图差分检测", "图像", "缺陷检测", "defect", "与参考图做绝对差分并按阈值提取变化区域。", {"threshold": 20, "min_area": 5}, {"threshold": _number("差分阈值"), "min_area": _number("最小缺陷面积")}, inputs=[_port("in", "检测图", "image"), _port("reference", "参考图", "image")], outputs=[_port("out", "缺陷标注", "image", color_space="BGR"), _port("difference", "差分图", "image", color_space="BGR"), _port("mask", "缺陷 Mask", "image", color_space="GRAY"), _port("score", "平均差异", "number")]),
    "SSIMDifference": _meta("SSIM 结构差异", "图像", "缺陷检测", "defect", "计算局部结构相似度并提取结构变化区域，对亮度变化比简单差分更稳健。", {"window_size": 11, "sigma": 1.5, "threshold": 30, "min_area": 5}, {"window_size": _number("窗口尺寸"), "sigma": _number("Sigma"), "threshold": _number("差异阈值"), "min_area": _number("最小缺陷面积")}, inputs=[_port("in", "检测图", "image"), _port("reference", "参考图", "image")], outputs=[_port("out", "缺陷标注", "image", color_space="BGR"), _port("difference", "差异热图", "image", color_space="BGR"), _port("mask", "缺陷 Mask", "image", color_space="GRAY"), _port("score", "SSIM 得分", "number")]),
    "LocalVarianceDefect": _meta("局部方差缺陷", "图像", "缺陷检测", "defect", "检测局部纹理/粗糙度异常，适合表面麻点、颗粒和纹理缺陷。", {"ksize": 15, "threshold": 40}, {"ksize": _number("局部窗口"), "threshold": _number("方差阈值")}, outputs=[_port("out", "缺陷标注", "image", color_space="BGR"), _port("variance", "方差图", "image", color_space="GRAY"), _port("mask", "缺陷 Mask", "image", color_space="GRAY")]),
    "ScratchDetection": _meta("方向划痕检测", "图像", "缺陷检测", "defect", "使用线形结构元素顶帽/黑帽增强指定方向的亮/暗划痕。", {"polarity": "DARK", "length": 31, "thickness": 3, "angle": 0, "threshold": 20, "min_area": 10}, {"polarity": _select("划痕极性", [("DARK", "暗划痕"), ("LIGHT", "亮划痕")]), "length": _number("结构长度"), "thickness": _number("结构宽度"), "angle": _number("方向角°"), "threshold": _number("响应阈值"), "min_area": _number("最小面积")}, outputs=[_port("out", "缺陷标注", "image", color_space="BGR"), _port("response", "划痕响应", "image", color_space="GRAY"), _port("mask", "划痕 Mask", "image", color_space="GRAY")]),
    "FocusMeasure": _meta("清晰度评估", "图像", "质量评估", "quality", "Laplacian 方差、Tenengrad 或 Brenner 清晰度指标，可用于失焦检测。", {"method": "LAPLACIAN_VARIANCE", "minimum_score": 100}, {"method": _select("方法", [("LAPLACIAN_VARIANCE", "Laplacian 方差"), ("TENENGRAD", "Tenengrad"), ("BRENNER", "Brenner")]), "minimum_score": _number("合格阈值")}, outputs=[_port("out", "响应热图", "image", color_space="BGR"), _port("score", "清晰度", "number"), _port("passed", "是否合格", "boolean")]),

    # OCR / 码识别
    "OCRPreprocess": _meta("OCR 图像预处理", "识别", "OCR与字符", "ocr", "放大、降噪、二值化和反相，生成适合 OCR 的字符图。", {"scale": 2.0, "denoise": "YES", "denoise_h": 10, "threshold_mode": "OTSU", "block_size": 31, "c": 10, "invert": "NO"}, {"scale": _number("放大倍率"), "denoise": _yes_no("降噪"), "denoise_h": _number("降噪强度"), "threshold_mode": _select("二值化", [("OTSU", "Otsu"), ("ADAPTIVE", "自适应"), ("NONE", "不二值化")]), "block_size": _number("自适应窗口"), "c": _number("自适应 C"), "invert": _yes_no("反相")}, outputs=[_port("out", "OCR 图", "image", color_space="GRAY")]),
    "OCRRecognize": _meta("OCR 文字识别", "识别", "OCR与字符", "ocr", "使用 Tesseract 或 EasyOCR 识别字符，输出文本、字符框和置信度。", {"engine": "TESSERACT", "language": "eng", "tesseract_cmd": "", "psm": 6, "oem": 3, "whitelist": "", "min_confidence": 0, "use_gpu": "NO", "paragraph": "NO"}, {"engine": _select("识别引擎", [("TESSERACT", "Tesseract"), ("EASYOCR", "EasyOCR"), ("AUTO", "自动尝试")], "依赖为可选安装，缺失时节点会给出安装提示。"), "language": _text("语言", "Tesseract 如 eng/chi_sim；EasyOCR 如 en,ch_sim。"), "tesseract_cmd": _text("Tesseract 可执行文件", "Windows 可填写 tesseract.exe 的完整路径；已加入 PATH 时留空。"), "psm": _number("Tesseract PSM"), "oem": _number("Tesseract OEM"), "whitelist": _text("字符白名单"), "min_confidence": _number("最低置信度"), "use_gpu": _yes_no("EasyOCR 使用 GPU"), "paragraph": _yes_no("EasyOCR 段落合并")}, outputs=[_port("out", "识别标注", "image", color_space="BGR"), _port("text", "完整文本", "text"), _port("items", "识别明细", "list"), _port("count", "数量", "number"), _port("mean_confidence", "平均置信度", "number")]),
    "QRCodeDecode": _meta("二维码识别", "识别", "条码与二维码", "code", "使用 OpenCV 检测并解码一个或多个 QR Code。", {}, {}, outputs=[_port("out", "标注图", "image", color_space="BGR"), _port("texts", "文本列表", "list"), _port("text", "首个文本", "text"), _port("points", "角点", "list"), _port("count", "数量", "number"), _port("found", "找到", "boolean")]),
    "BarcodeDecode": _meta("一维条码识别", "识别", "条码与二维码", "code", "优先使用 OpenCV BarcodeDetector，必要时回退 pyzbar。", {}, {}, outputs=[_port("out", "标注图", "image", color_space="BGR"), _port("items", "条码明细", "list"), _port("texts", "文本列表", "list"), _port("text", "首个文本", "text"), _port("count", "数量", "number"), _port("found", "找到", "boolean")]),
    "TextRegionMSER": _meta("MSER 文本区域", "识别", "OCR与字符", "ocr", "使用 MSER 提取稳定字符候选区域，为 OCR 前定位和裁剪提供候选框。", {"delta": 5, "min_area": 60, "max_area": 14400, "min_aspect": 0.1, "max_aspect": 10, "max_regions": 500}, {"delta": _number("Delta"), "min_area": _number("最小面积"), "max_area": _number("最大面积"), "min_aspect": _number("最小长宽比"), "max_aspect": _number("最大长宽比"), "max_regions": _number("最大区域数")}, outputs=[_port("out", "区域标注", "image", color_space="BGR"), _port("boxes", "文本框", "list"), _port("count", "数量", "number")]),
    "CharacterSegment": _meta("字符切分", "识别", "OCR与字符", "ocr", "按连通域分割字符并按阅读方向排序，输出字符框和字符小图列表。", {"threshold": 0, "invert": "NO", "min_area": 20, "min_height": 5, "sort": "LEFT_TO_RIGHT"}, {"threshold": _number("二值阈值"), "invert": _yes_no("反相"), "min_area": _number("最小面积"), "min_height": _number("最小高度"), "sort": _select("排序", [("LEFT_TO_RIGHT", "从左到右"), ("RIGHT_TO_LEFT", "从右到左"), ("TOP_TO_BOTTOM", "从上到下"), ("BOTTOM_TO_TOP", "从下到上")])}, outputs=[_port("out", "字符标注", "image", color_space="BGR"), _port("mask", "二值图", "image", color_space="GRAY"), _port("characters", "字符信息", "list"), _port("crops", "字符图列表", "any"), _port("count", "数量", "number")]),
}


INDUSTRIAL_OPERATOR_META.update({
    "ComputeHomography": _meta(
        "计算单应矩阵", "测量", "坐标与标定", "calibration",
        "由至少四对对应点计算 3×3 单应矩阵，并输出 RANSAC 内点。",
        {
            "source_points": "[[0,0],[100,0],[100,100],[0,100]]",
            "target_points": "[[0,0],[100,0],[100,100],[0,100]]",
            "method": "RANSAC",
            "ransac_threshold": 3.0,
        },
        {
            "source_points": _text("源点集 JSON", rows=4),
            "target_points": _text("目标点集 JSON", rows=4),
            "method": _select("计算方法", [("RANSAC", "RANSAC"), ("LMEDS", "LMEDS"), ("DIRECT", "直接求解")]),
            "ransac_threshold": _number("RANSAC 阈值"),
        },
        inputs=[
            _port("source_points", "源点集", "any", False),
            _port("target_points", "目标点集", "any", False),
        ],
        outputs=[
            _port("out", "单应矩阵", "any"),
            _port("matrix", "单应矩阵", "any"),
            _port("inliers", "内点标记", "list"),
            _port("inlier_count", "内点数", "number"),
        ],
        result_type="metrics",
    ),
    "ChessboardCorners": _meta(
        "棋盘格角点", "图像", "几何与标定", "calibration",
        "检测并亚像素优化棋盘格角点，可用于相机标定和透视校正。",
        {"pattern_cols": 9, "pattern_rows": 6, "fast_check": "YES"},
        {
            "pattern_cols": _number("内角点列数"),
            "pattern_rows": _number("内角点行数"),
            "fast_check": _yes_no("快速预检查"),
        },
        outputs=[
            _port("out", "角点标注", "image", color_space="BGR"),
            _port("corners", "角点列表", "list"),
            _port("count", "角点数", "number"),
            _port("found", "找到", "boolean"),
            _port("pattern_size", "棋盘规格", "any"),
        ],
    ),
    "ArucoMarkerDetect": _meta(
        "ArUco 标记检测", "识别", "标记与定位", "code",
        "检测 ArUco 标记 ID、四角点和中心，适合治具定位、标定和机器人引导。",
        {"dictionary": "DICT_4X4_50"},
        {
            "dictionary": _select("字典", [
                ("DICT_4X4_50", "4×4 / 50"),
                ("DICT_4X4_100", "4×4 / 100"),
                ("DICT_5X5_50", "5×5 / 50"),
                ("DICT_5X5_100", "5×5 / 100"),
                ("DICT_6X6_50", "6×6 / 50"),
                ("DICT_6X6_100", "6×6 / 100"),
                ("DICT_7X7_50", "7×7 / 50"),
                ("DICT_ARUCO_ORIGINAL", "ArUco Original"),
            ]),
        },
        outputs=[
            _port("out", "标记图", "image", color_space="BGR"),
            _port("markers", "标记列表", "list"),
            _port("ids", "ID 列表", "list"),
            _port("count", "数量", "number"),
            _port("found", "找到", "boolean"),
            _port("rejected_count", "拒绝候选数", "number"),
        ],
    ),
    "DataMatrixDecode": _meta(
        "DataMatrix 识别", "识别", "条码与二维码", "code",
        "使用 pylibdmtx 解码工业现场常见的 DataMatrix 二维码。",
        {"timeout_ms": 1000, "max_count": 20, "encoding": "utf-8"},
        {
            "timeout_ms": _number("超时毫秒"),
            "max_count": _number("最大数量"),
            "encoding": _text("文本编码"),
        },
        outputs=[
            _port("out", "标注图", "image", color_space="BGR"),
            _port("items", "识别明细", "list"),
            _port("texts", "文本列表", "list"),
            _port("text", "首个文本", "text"),
            _port("count", "数量", "number"),
            _port("found", "找到", "boolean"),
        ],
    ),
})


INDUSTRIAL_OPERATOR_CATALOG: dict[str, list[dict[str, Any]]] = {}
for type_name, metadata in INDUSTRIAL_OPERATOR_META.items():
    category = str(metadata["category"])
    group = str(metadata["group"])
    groups = INDUSTRIAL_OPERATOR_CATALOG.setdefault(category, [])
    target = next((item for item in groups if item["group"] == group), None)
    if target is None:
        target = {"group": group, "items": []}
        groups.append(target)
    target["items"].append(type_name)


INDUSTRIAL_OPERATOR_TYPES = frozenset(INDUSTRIAL_OPERATOR_META)


__all__ = ["INDUSTRIAL_OPERATOR_META", "INDUSTRIAL_OPERATOR_CATALOG", "INDUSTRIAL_OPERATOR_TYPES"]
