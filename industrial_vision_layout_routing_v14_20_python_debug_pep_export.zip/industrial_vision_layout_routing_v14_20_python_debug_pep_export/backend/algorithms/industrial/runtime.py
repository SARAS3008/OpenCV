from __future__ import annotations

import json
import math
from typing import Any

import cv2
import numpy as np


_OCR_READER_CACHE: dict[tuple[Any, ...], Any] = {}


def _float(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except Exception:
        return float(default)


def _int(value: Any, default: int = 0) -> int:
    try:
        return int(float(value))
    except Exception:
        return int(default)


def _yes(value: Any, default: bool = False) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    return str(value).strip().upper() in {"1", "TRUE", "YES", "Y", "ON", "是", "启用"}


def _odd(value: Any, default: int = 3, minimum: int = 1) -> int:
    result = max(minimum, _int(value, default))
    return result if result % 2 else result + 1


def _uint8(image: np.ndarray) -> np.ndarray:
    if image.dtype == np.uint8:
        return image
    return np.clip(image, 0, 255).astype(np.uint8)


def _gray(inputs: dict[str, Any], handle: str = "in") -> np.ndarray:
    image = inputs.get(handle)
    if not isinstance(image, np.ndarray):
        raise ValueError(f"缺少图像输入：{handle}")
    if image.ndim == 2:
        return _uint8(image)
    color = str(inputs.get(f"{handle}_color_space", "BGR") or "BGR").upper()
    if color == "RGB":
        return cv2.cvtColor(_uint8(image), cv2.COLOR_RGB2GRAY)
    return cv2.cvtColor(_uint8(image), cv2.COLOR_BGR2GRAY)


def _bgr(inputs: dict[str, Any], handle: str = "in") -> np.ndarray:
    image = inputs.get(handle)
    if not isinstance(image, np.ndarray):
        raise ValueError(f"缺少图像输入：{handle}")
    image = _uint8(image)
    if image.ndim == 2:
        return cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
    color = str(inputs.get(f"{handle}_color_space", "BGR") or "BGR").upper()
    if color == "RGB":
        return cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
    return image.copy()


def _binary(inputs: dict[str, Any], handle: str = "in", threshold: int = 0) -> np.ndarray:
    gray = _gray(inputs, handle)
    if threshold <= 0:
        return ((gray > 0).astype(np.uint8)) * 255
    return cv2.threshold(gray, threshold, 255, cv2.THRESH_BINARY)[1]


def _kernel(params: dict[str, Any], key: str = "ksize", default: int = 3, shape_key: str = "shape") -> np.ndarray:
    size = _odd(params.get(key, default), default)
    shape = str(params.get(shape_key, "RECT") or "RECT").upper()
    shape_code = {
        "ELLIPSE": cv2.MORPH_ELLIPSE,
        "CROSS": cv2.MORPH_CROSS,
        "RECT": cv2.MORPH_RECT,
    }.get(shape, cv2.MORPH_RECT)
    return cv2.getStructuringElement(shape_code, (size, size))


def _color(value: Any, default: tuple[int, int, int] = (0, 255, 0)) -> tuple[int, int, int]:
    if isinstance(value, str):
        parts = [item.strip() for item in value.replace(";", ",").split(",") if item.strip()]
        if len(parts) >= 3:
            return tuple(int(np.clip(_int(item), 0, 255)) for item in parts[:3])
    if isinstance(value, (list, tuple, np.ndarray)) and len(value) >= 3:
        return tuple(int(np.clip(_int(item), 0, 255)) for item in value[:3])
    return default


def _point(value: Any, default: tuple[float, float] = (0.0, 0.0)) -> list[float]:
    if isinstance(value, dict):
        if "point" in value:
            return _point(value["point"], default)
        if "center" in value:
            return _point(value["center"], default)
        if "x" in value and "y" in value:
            return [float(value["x"]), float(value["y"])]
    if isinstance(value, (list, tuple, np.ndarray)):
        arr = np.asarray(value, dtype=np.float64).reshape(-1)
        if arr.size >= 2:
            return [float(arr[0]), float(arr[1])]
    return [float(default[0]), float(default[1])]


def _line(value: Any, params: dict[str, Any] | None = None, prefix: str = "") -> dict[str, Any]:
    params = params or {}
    if isinstance(value, dict):
        if "line" in value:
            return _line(value["line"], params, prefix)
        if "p1" in value and "p2" in value:
            p1, p2 = _point(value["p1"]), _point(value["p2"])
            return {"p1": p1, "p2": p2}
        if "abc" in value:
            abc = np.asarray(value["abc"], dtype=np.float64).reshape(-1)
            if abc.size >= 3:
                return {"abc": [float(abc[0]), float(abc[1]), float(abc[2])], "p1": value.get("p1"), "p2": value.get("p2")}
    if isinstance(value, (list, tuple, np.ndarray)):
        arr = np.asarray(value, dtype=np.float64).reshape(-1)
        if arr.size >= 4:
            return {"p1": [float(arr[0]), float(arr[1])], "p2": [float(arr[2]), float(arr[3])]}
        if arr.size == 3:
            return {"abc": [float(arr[0]), float(arr[1]), float(arr[2])]}
    return {
        "p1": [_float(params.get(f"{prefix}x1", 0)), _float(params.get(f"{prefix}y1", 0))],
        "p2": [_float(params.get(f"{prefix}x2", 100)), _float(params.get(f"{prefix}y2", 0))],
    }


def _line_abc(line: dict[str, Any]) -> tuple[float, float, float]:
    if "abc" in line:
        a, b, c = line["abc"][:3]
        return float(a), float(b), float(c)
    p1, p2 = _point(line.get("p1")), _point(line.get("p2"))
    x1, y1 = p1
    x2, y2 = p2
    return y1 - y2, x2 - x1, x1 * y2 - x2 * y1


def _json_contour(contour: np.ndarray, max_points: int = 500) -> list[list[int]]:
    points = np.asarray(contour).reshape(-1, 2)
    if max_points > 0 and len(points) > max_points:
        step = max(1, int(math.ceil(len(points) / float(max_points))))
        points = points[::step][:max_points]
    return [[int(x), int(y)] for x, y in points]


def _contours_from_binary(binary: np.ndarray, retrieval: int = cv2.RETR_EXTERNAL) -> list[np.ndarray]:
    contours, _ = cv2.findContours(_uint8(binary), retrieval, cv2.CHAIN_APPROX_SIMPLE)
    return contours


def _annotated_from_mask(inputs: dict[str, Any], mask: np.ndarray, color: tuple[int, int, int] = (0, 255, 0)) -> np.ndarray:
    canvas = _bgr(inputs)
    contours = _contours_from_binary(mask)
    if contours:
        cv2.drawContours(canvas, contours, -1, color, 2)
    return canvas


def _parse_points(params: dict[str, Any], key: str, expected: int) -> np.ndarray:
    value = params.get(key)
    if isinstance(value, str):
        try:
            value = json.loads(value)
        except Exception:
            rows = [row.strip() for row in value.split(";") if row.strip()]
            value = [[_float(item) for item in row.replace("，", ",").split(",")[:2]] for row in rows]
    arr = np.asarray(value, dtype=np.float32) if value is not None else np.empty((0, 2), dtype=np.float32)
    if arr.size != expected * 2:
        raise ValueError(f"参数 {key} 需要 {expected} 个二维点")
    return arr.reshape(expected, 2)


def _crop_rect(image: np.ndarray, params: dict[str, Any]) -> tuple[np.ndarray, list[int]]:
    h, w = image.shape[:2]
    x = int(np.clip(_int(params.get("x", 0)), 0, max(0, w - 1)))
    y = int(np.clip(_int(params.get("y", 0)), 0, max(0, h - 1)))
    width = _int(params.get("width", w - x), w - x)
    height = _int(params.get("height", h - y), h - y)
    width = max(1, min(width, w - x))
    height = max(1, min(height, h - y))
    return image[y:y + height, x:x + width].copy(), [x, y, width, height]


def _fit_circle_points(points: np.ndarray) -> tuple[float, float, float, float]:
    pts = np.asarray(points, dtype=np.float64).reshape(-1, 2)
    if len(pts) < 3:
        raise ValueError("拟合圆至少需要 3 个点")
    x = pts[:, 0]
    y = pts[:, 1]
    a = np.column_stack([2 * x, 2 * y, np.ones_like(x)])
    b = x * x + y * y
    solution, *_ = np.linalg.lstsq(a, b, rcond=None)
    cx, cy, c = solution
    radius = math.sqrt(max(0.0, c + cx * cx + cy * cy))
    residual = np.sqrt(np.mean((np.hypot(x - cx, y - cy) - radius) ** 2))
    return float(cx), float(cy), float(radius), float(residual)


def _safe_text(value: Any) -> str:
    if value is None:
        return ""
    return str(value)


def _ocr_tesseract(image: np.ndarray, params: dict[str, Any]) -> tuple[str, list[dict[str, Any]]]:
    try:
        import pytesseract
    except Exception as exc:
        raise RuntimeError("OCR Tesseract 引擎未安装。请安装 pytesseract，并在系统中安装 Tesseract OCR。") from exc
    command = str(params.get("tesseract_cmd", "") or "").strip()
    if command:
        pytesseract.pytesseract.tesseract_cmd = command
    lang = str(params.get("language", "eng") or "eng")
    psm = max(0, _int(params.get("psm", 6), 6))
    oem = max(0, _int(params.get("oem", 3), 3))
    whitelist = str(params.get("whitelist", "") or "")
    config = f"--psm {psm} --oem {oem}"
    if whitelist:
        config += f" -c tessedit_char_whitelist={whitelist}"
    data = pytesseract.image_to_data(image, lang=lang, config=config, output_type=pytesseract.Output.DICT)
    items: list[dict[str, Any]] = []
    texts: list[str] = []
    for index, text in enumerate(data.get("text", [])):
        text = str(text or "").strip()
        confidence = _float(data.get("conf", [0])[index], -1)
        if not text or confidence < _float(params.get("min_confidence", 0), 0):
            continue
        item = {
            "text": text,
            "confidence": confidence,
            "bbox": [
                _int(data.get("left", [0])[index]),
                _int(data.get("top", [0])[index]),
                _int(data.get("width", [0])[index]),
                _int(data.get("height", [0])[index]),
            ],
        }
        items.append(item)
        texts.append(text)
    return " ".join(texts).strip(), items


def _ocr_easyocr(image: np.ndarray, params: dict[str, Any]) -> tuple[str, list[dict[str, Any]]]:
    try:
        import easyocr
    except Exception as exc:
        raise RuntimeError("OCR EasyOCR 引擎未安装。请安装 easyocr。") from exc
    languages = [item.strip() for item in str(params.get("language", "en") or "en").replace(";", ",").split(",") if item.strip()]
    use_gpu = _yes(params.get("use_gpu"), False)
    cache_key = ("easyocr", tuple(languages or ["en"]), use_gpu)
    reader = _OCR_READER_CACHE.get(cache_key)
    if reader is None:
        reader = easyocr.Reader(languages or ["en"], gpu=use_gpu)
        _OCR_READER_CACHE[cache_key] = reader
    results = reader.readtext(image, detail=1, paragraph=_yes(params.get("paragraph"), False))
    items = []
    texts = []
    threshold = _float(params.get("min_confidence", 0), 0)
    for polygon, text, confidence in results:
        if float(confidence) < threshold:
            continue
        points = [[round(float(point[0]), 3), round(float(point[1]), 3)] for point in polygon]
        xs = [point[0] for point in points]
        ys = [point[1] for point in points]
        bbox = [int(min(xs)), int(min(ys)), int(max(xs) - min(xs)), int(max(ys) - min(ys))]
        items.append({"text": str(text), "confidence": float(confidence) * 100.0, "bbox": bbox, "polygon": points})
        texts.append(str(text))
    return " ".join(texts).strip(), items


def _industrial_execute(node_type: str, inputs: dict[str, Any], params: dict[str, Any] | None = None) -> dict[str, Any]:
    params = dict(params or {})

    # ---------- 图像增强与频域 ----------
    if node_type == "GammaCorrection":
        image = _uint8(inputs["in"])
        gamma = max(0.01, _float(params.get("gamma", 1.0), 1.0))
        table = np.array([((index / 255.0) ** gamma) * 255 for index in range(256)], dtype=np.uint8)
        out = cv2.LUT(image, table)
        return {"out": out, "out_color_space": inputs.get("in_color_space", "BGR"), "metrics": {"gamma": gamma}}

    if node_type == "BrightnessContrast":
        image = _uint8(inputs["in"])
        alpha = _float(params.get("contrast", 1.0), 1.0)
        beta = _float(params.get("brightness", 0.0), 0.0)
        out = cv2.convertScaleAbs(image, alpha=alpha, beta=beta)
        return {"out": out, "out_color_space": inputs.get("in_color_space", "BGR"), "metrics": {"contrast": alpha, "brightness": beta}}

    if node_type == "GrayRangeNormalize":
        gray = _gray(inputs)
        low = _float(params.get("low_percentile", 1.0), 1.0)
        high = _float(params.get("high_percentile", 99.0), 99.0)
        if high <= low:
            raise ValueError("高百分位必须大于低百分位")
        lo, hi = np.percentile(gray, [low, high])
        if hi <= lo:
            out = np.zeros_like(gray)
        else:
            out = np.clip((gray.astype(np.float32) - lo) * 255.0 / (hi - lo), 0, 255).astype(np.uint8)
        return {"out": out, "out_color_space": "GRAY", "low_value": float(lo), "high_value": float(hi), "metrics": {"low": float(lo), "high": float(hi)}}

    if node_type == "LogTransform":
        image = _uint8(inputs["in"])
        scale = _float(params.get("scale", 1.0), 1.0)
        normalized = np.log1p(image.astype(np.float32))
        out = cv2.normalize(normalized * scale, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
        return {"out": out, "out_color_space": inputs.get("in_color_space", "BGR")}

    if node_type == "WhiteBalance":
        image = _bgr(inputs)
        mode = str(params.get("mode", "GRAY_WORLD") or "GRAY_WORLD").upper()
        work = image.astype(np.float32)
        if mode == "SIMPLE":
            percentile = float(np.clip(_float(params.get("percentile", 1.0), 1.0), 0.0, 20.0))
            channels = []
            for channel in cv2.split(work):
                low, high = np.percentile(channel, [percentile, 100.0 - percentile])
                channels.append(np.clip((channel - low) * 255.0 / max(1e-6, high - low), 0, 255))
            out = cv2.merge(channels).astype(np.uint8)
        else:
            means = np.mean(work.reshape(-1, 3), axis=0)
            target = float(np.mean(means))
            gains = target / np.maximum(means, 1e-6)
            out = np.clip(work * gains.reshape(1, 1, 3), 0, 255).astype(np.uint8)
        return {"out": out, "out_color_space": "BGR"}

    if node_type == "IlluminationCorrection":
        gray = _gray(inputs)
        size = _odd(params.get("background_ksize", 51), 51, 3)
        mode = str(params.get("mode", "DIVIDE") or "DIVIDE").upper()
        background = cv2.GaussianBlur(gray, (size, size), 0)
        if mode == "SUBTRACT":
            corrected = cv2.subtract(gray, background)
            out = cv2.normalize(corrected, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
        else:
            corrected = gray.astype(np.float32) / np.maximum(background.astype(np.float32), 1.0)
            out = cv2.normalize(corrected, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
        return {"out": out, "background": background, "out_color_space": "GRAY"}

    if node_type == "FlatFieldCorrection":
        image = _bgr(inputs).astype(np.float32)
        flat = _bgr(inputs, "flat").astype(np.float32)
        if flat.shape != image.shape:
            flat = cv2.resize(flat, (image.shape[1], image.shape[0]), interpolation=cv2.INTER_LINEAR)
        if isinstance(inputs.get("dark"), np.ndarray):
            dark = _bgr(inputs, "dark").astype(np.float32)
            if dark.shape != image.shape:
                dark = cv2.resize(dark, (image.shape[1], image.shape[0]), interpolation=cv2.INTER_LINEAR)
        else:
            dark = np.zeros_like(image)
        numerator = np.maximum(image - dark, 0.0)
        denominator = np.maximum(flat - dark, 1.0)
        scale = np.mean(denominator, axis=(0, 1), keepdims=True)
        out = np.clip(numerator / denominator * scale, 0, 255).astype(np.uint8)
        return {"out": out, "out_color_space": "BGR"}

    if node_type == "NonLocalMeansDenoise":
        image = _uint8(inputs["in"])
        h = _float(params.get("h", 10.0), 10.0)
        template = _odd(params.get("template_window", 7), 7)
        search = _odd(params.get("search_window", 21), 21)
        if image.ndim == 2:
            out = cv2.fastNlMeansDenoising(image, None, h, template, search)
            color = "GRAY"
        else:
            out = cv2.fastNlMeansDenoisingColored(_bgr(inputs), None, h, h, template, search)
            color = "BGR"
        return {"out": out, "out_color_space": color}

    if node_type == "UnsharpMask":
        image = _uint8(inputs["in"])
        size = _odd(params.get("ksize", 5), 5)
        sigma = _float(params.get("sigma", 1.0), 1.0)
        amount = _float(params.get("amount", 1.5), 1.5)
        threshold = max(0, _int(params.get("threshold", 0), 0))
        blurred = cv2.GaussianBlur(image, (size, size), sigma)
        sharpened = cv2.addWeighted(image, 1.0 + amount, blurred, -amount, 0)
        if threshold > 0:
            low_contrast = np.abs(image.astype(np.int16) - blurred.astype(np.int16)) < threshold
            sharpened[low_contrast] = image[low_contrast]
        return {"out": sharpened, "blurred": blurred, "out_color_space": inputs.get("in_color_space", "BGR")}

    if node_type == "GaborFilter":
        gray = _gray(inputs)
        size = _odd(params.get("ksize", 21), 21)
        sigma = max(0.1, _float(params.get("sigma", 4.0), 4.0))
        theta = math.radians(_float(params.get("theta", 0.0), 0.0))
        wavelength = max(0.1, _float(params.get("wavelength", 10.0), 10.0))
        gamma = max(0.01, _float(params.get("aspect_ratio", 0.5), 0.5))
        phase = math.radians(_float(params.get("phase", 0.0), 0.0))
        kernel = cv2.getGaborKernel((size, size), sigma, theta, wavelength, gamma, phase, ktype=cv2.CV_32F)
        response = cv2.filter2D(gray, cv2.CV_32F, kernel)
        out = cv2.normalize(response, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
        return {"out": out, "response": response, "out_color_space": "GRAY", "metrics": {"mean_response": float(np.mean(np.abs(response)))}}

    if node_type == "FFTFilter":
        gray = _gray(inputs).astype(np.float32)
        mode = str(params.get("mode", "LOW_PASS") or "LOW_PASS").upper()
        radius = max(1.0, _float(params.get("radius", 30), 30.0))
        inner = max(0.0, _float(params.get("inner_radius", 10), 10.0))
        rows, cols = gray.shape
        cy, cx = rows // 2, cols // 2
        yy, xx = np.ogrid[:rows, :cols]
        distance = np.sqrt((yy - cy) ** 2 + (xx - cx) ** 2)
        if mode == "HIGH_PASS":
            mask = (distance >= radius).astype(np.float32)
        elif mode == "BAND_PASS":
            low, high = sorted((inner, radius))
            mask = ((distance >= low) & (distance <= high)).astype(np.float32)
        elif mode == "BAND_STOP":
            low, high = sorted((inner, radius))
            mask = ((distance < low) | (distance > high)).astype(np.float32)
        else:
            mask = (distance <= radius).astype(np.float32)
        spectrum = np.fft.fftshift(np.fft.fft2(gray))
        filtered = spectrum * mask
        restored = np.real(np.fft.ifft2(np.fft.ifftshift(filtered)))
        out = cv2.normalize(restored, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
        spectrum_image = cv2.normalize(np.log1p(np.abs(spectrum)), None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
        mask_image = (mask * 255).astype(np.uint8)
        return {"out": out, "spectrum": spectrum_image, "frequency_mask": mask_image, "out_color_space": "GRAY"}

    if node_type == "DynamicThreshold":
        gray = _gray(inputs)
        size = _odd(params.get("background_ksize", 31), 31, 3)
        offset = _float(params.get("offset", 10), 10.0)
        mode = str(params.get("mode", "DARK") or "DARK").upper()
        background = cv2.blur(gray, (size, size))
        if mode == "LIGHT":
            mask = (gray.astype(np.float32) > background.astype(np.float32) + offset).astype(np.uint8) * 255
        else:
            mask = (gray.astype(np.float32) < background.astype(np.float32) - offset).astype(np.uint8) * 255
        return {"out": mask, "mask": mask, "background": background, "out_color_space": "GRAY", "metrics": {"foreground_pixels": int(np.count_nonzero(mask))}}

    # ---------- 颜色、分割 ----------
    if node_type == "ChannelExtract":
        image = _bgr(inputs)
        channel = str(params.get("channel", "B") or "B").upper()
        if channel in {"B", "G", "R"}:
            index = {"B": 0, "G": 1, "R": 2}[channel]
            out = image[:, :, index]
        elif channel in {"H", "S", "V"}:
            hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
            out = hsv[:, :, {"H": 0, "S": 1, "V": 2}[channel]]
        elif channel in {"L", "A", "LAB_B"}:
            lab = cv2.cvtColor(image, cv2.COLOR_BGR2LAB)
            out = lab[:, :, {"L": 0, "A": 1, "LAB_B": 2}[channel]]
        else:
            out = _gray(inputs)
        return {"out": out, "channel": channel, "out_color_space": "GRAY"}

    if node_type == "ChannelMerge":
        channels = []
        for handle in ("c1", "c2", "c3"):
            if isinstance(inputs.get(handle), np.ndarray):
                channel = _gray(inputs, handle)
            else:
                reference = next((value for value in inputs.values() if isinstance(value, np.ndarray)), None)
                if reference is None:
                    raise ValueError("通道合并至少需要一个图像输入")
                channel = np.zeros(reference.shape[:2], dtype=np.uint8)
            channels.append(channel)
        shape = channels[0].shape[:2]
        channels = [cv2.resize(item, (shape[1], shape[0]), interpolation=cv2.INTER_NEAREST) if item.shape[:2] != shape else item for item in channels]
        order = str(params.get("order", "BGR") or "BGR").upper()
        merged = cv2.merge(channels)
        if order == "RGB":
            return {"out": merged, "out_color_space": "RGB"}
        return {"out": merged, "out_color_space": "BGR"}

    if node_type == "ColorRangeMask":
        image = _bgr(inputs)
        space = str(params.get("color_space", "HSV") or "HSV").upper()
        converted = {
            "BGR": image,
            "HSV": cv2.cvtColor(image, cv2.COLOR_BGR2HSV),
            "LAB": cv2.cvtColor(image, cv2.COLOR_BGR2LAB),
            "YCRCB": cv2.cvtColor(image, cv2.COLOR_BGR2YCrCb),
        }.get(space, cv2.cvtColor(image, cv2.COLOR_BGR2HSV))
        lower = np.array([_int(params.get(f"low{i}", 0), 0) for i in range(1, 4)], dtype=np.uint8)
        upper = np.array([_int(params.get(f"high{i}", 255), 255) for i in range(1, 4)], dtype=np.uint8)
        mask = cv2.inRange(converted, lower, upper)
        masked = cv2.bitwise_and(image, image, mask=mask)
        return {"out": mask, "mask": mask, "masked": masked, "out_color_space": "GRAY", "metrics": {"pixel_count": int(np.count_nonzero(mask)), "area_ratio": float(np.count_nonzero(mask) / mask.size)}}

    if node_type == "RangeThreshold":
        gray = _gray(inputs)
        low = int(np.clip(_int(params.get("low", 0), 0), 0, 255))
        high = int(np.clip(_int(params.get("high", 255), 255), 0, 255))
        low, high = min(low, high), max(low, high)
        mask = cv2.inRange(gray, low, high)
        if _yes(params.get("invert"), False):
            mask = cv2.bitwise_not(mask)
        return {"out": mask, "mask": mask, "out_color_space": "GRAY", "metrics": {"pixel_count": int(np.count_nonzero(mask))}}

    if node_type == "KMeansSegment":
        image = _bgr(inputs)
        clusters = int(np.clip(_int(params.get("clusters", 3), 3), 2, 12))
        attempts = int(np.clip(_int(params.get("attempts", 3), 3), 1, 10))
        pixels = image.reshape(-1, 3).astype(np.float32)
        criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, max(1, _int(params.get("max_iter", 20), 20)), max(1e-6, _float(params.get("epsilon", 1.0), 1.0)))
        compactness, labels, centers = cv2.kmeans(pixels, clusters, None, criteria, attempts, cv2.KMEANS_PP_CENTERS)
        segmented = centers.astype(np.uint8)[labels.flatten()].reshape(image.shape)
        label_image = labels.reshape(image.shape[:2]).astype(np.uint8)
        return {"out": segmented, "labels": label_image, "centers": centers.round(3).tolist(), "out_color_space": "BGR", "metrics": {"compactness": float(compactness), "clusters": clusters}}

    if node_type == "WatershedSegment":
        image = _bgr(inputs)
        gray = _gray(inputs)
        _, binary = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV if _yes(params.get("invert"), False) else cv2.THRESH_BINARY, cv2.THRESH_OTSU)
        kernel = _kernel(params, default=3)
        opening = cv2.morphologyEx(binary, cv2.MORPH_OPEN, kernel, iterations=max(1, _int(params.get("iterations", 2), 2)))
        sure_bg = cv2.dilate(opening, kernel, iterations=max(1, _int(params.get("background_iterations", 3), 3)))
        distance = cv2.distanceTransform(opening, cv2.DIST_L2, 5)
        ratio = float(np.clip(_float(params.get("foreground_ratio", 0.4), 0.4), 0.01, 0.99))
        sure_fg = cv2.threshold(distance, ratio * float(distance.max() or 1.0), 255, 0)[1].astype(np.uint8)
        unknown = cv2.subtract(sure_bg, sure_fg)
        count, markers = cv2.connectedComponents(sure_fg)
        markers = markers + 1
        markers[unknown == 255] = 0
        markers = cv2.watershed(image.copy(), markers.astype(np.int32))
        mask = (markers > 1).astype(np.uint8) * 255
        annotated = image.copy()
        annotated[markers == -1] = (0, 0, 255)
        return {"out": annotated, "mask": mask, "labels": markers.astype(np.int32), "out_color_space": "BGR", "metrics": {"region_count": max(0, int(count - 1))}}

    if node_type == "RegionGrow":
        gray = _gray(inputs)
        seed_value = inputs.get("seed")
        default_seed = (_float(params.get("seed_x", gray.shape[1] / 2), gray.shape[1] / 2), _float(params.get("seed_y", gray.shape[0] / 2), gray.shape[0] / 2))
        sx, sy = _point(seed_value, default_seed)
        sx = int(np.clip(round(sx), 0, gray.shape[1] - 1))
        sy = int(np.clip(round(sy), 0, gray.shape[0] - 1))
        tolerance = max(0, _int(params.get("tolerance", 10), 10))
        flags = 4 | cv2.FLOODFILL_MASK_ONLY | (255 << 8)
        flood_mask = np.zeros((gray.shape[0] + 2, gray.shape[1] + 2), dtype=np.uint8)
        cv2.floodFill(gray.copy(), flood_mask, (sx, sy), 255, tolerance, tolerance, flags)
        mask = flood_mask[1:-1, 1:-1]
        annotated = _annotated_from_mask(inputs, mask)
        return {"out": mask, "mask": mask, "annotated": annotated, "seed": [sx, sy], "out_color_space": "GRAY", "metrics": {"area": int(np.count_nonzero(mask))}}

    if node_type == "GrabCutSegment":
        image = _bgr(inputs)
        h, w = image.shape[:2]
        if isinstance(inputs.get("mask"), np.ndarray):
            source_mask = _gray(inputs, "mask")
            gc_mask = np.where(source_mask > 0, cv2.GC_PR_FGD, cv2.GC_BGD).astype(np.uint8)
            mode = cv2.GC_INIT_WITH_MASK
            rect = (0, 0, w, h)
        else:
            x = int(np.clip(_int(params.get("x", 5), 5), 0, max(0, w - 2)))
            y = int(np.clip(_int(params.get("y", 5), 5), 0, max(0, h - 2)))
            rw = int(np.clip(_int(params.get("width", w - 10), w - 10), 1, w - x))
            rh = int(np.clip(_int(params.get("height", h - 10), h - 10), 1, h - y))
            rect = (x, y, rw, rh)
            gc_mask = np.zeros((h, w), np.uint8)
            mode = cv2.GC_INIT_WITH_RECT
        background = np.zeros((1, 65), np.float64)
        foreground = np.zeros((1, 65), np.float64)
        cv2.grabCut(image, gc_mask, rect, background, foreground, max(1, _int(params.get("iterations", 5), 5)), mode)
        mask = np.where((gc_mask == cv2.GC_FGD) | (gc_mask == cv2.GC_PR_FGD), 255, 0).astype(np.uint8)
        segmented = cv2.bitwise_and(image, image, mask=mask)
        return {"out": segmented, "mask": mask, "out_color_space": "BGR", "metrics": {"foreground_pixels": int(np.count_nonzero(mask))}}

    # ---------- 形态学与区域 ----------
    if node_type in {"MorphTopHat", "MorphBlackHat"}:
        operation = cv2.MORPH_TOPHAT if node_type == "MorphTopHat" else cv2.MORPH_BLACKHAT
        out = cv2.morphologyEx(_uint8(inputs["in"]), operation, _kernel(params), iterations=max(1, _int(params.get("iterations", 1), 1)))
        return {"out": out, "out_color_space": inputs.get("in_color_space", "BGR")}

    if node_type == "FillHoles":
        binary = _binary(inputs, threshold=_int(params.get("threshold", 0), 0))
        padded = binary.copy()
        flood = np.zeros((binary.shape[0] + 2, binary.shape[1] + 2), np.uint8)
        cv2.floodFill(padded, flood, (0, 0), 255)
        holes = cv2.bitwise_not(padded)
        out = cv2.bitwise_or(binary, holes)
        return {"out": out, "holes": holes, "out_color_space": "GRAY", "metrics": {"filled_pixels": int(np.count_nonzero(holes))}}

    if node_type == "Skeletonize":
        binary = _binary(inputs, threshold=_int(params.get("threshold", 0), 0))
        skeleton = np.zeros_like(binary)
        element = cv2.getStructuringElement(cv2.MORPH_CROSS, (3, 3))
        work = binary.copy()
        max_iterations = max(1, _int(params.get("max_iterations", 10000), 10000))
        count = 0
        while count < max_iterations:
            eroded = cv2.erode(work, element)
            opened = cv2.dilate(eroded, element)
            temp = cv2.subtract(work, opened)
            skeleton = cv2.bitwise_or(skeleton, temp)
            work = eroded
            count += 1
            if cv2.countNonZero(work) == 0:
                break
        return {"out": skeleton, "out_color_space": "GRAY", "metrics": {"iterations": count, "skeleton_pixels": int(np.count_nonzero(skeleton))}}

    if node_type == "DistanceTransform":
        binary = _binary(inputs, threshold=_int(params.get("threshold", 0), 0))
        distance = cv2.distanceTransform(binary, cv2.DIST_L2, max(3, _int(params.get("mask_size", 5), 5)))
        normalized = cv2.normalize(distance, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
        return {"out": normalized, "distance": distance, "max_distance": float(distance.max()), "out_color_space": "GRAY", "metrics": {"max_distance": float(distance.max())}}

    if node_type in {"ConnectedComponents", "RemoveSmallRegions"}:
        binary = _binary(inputs, threshold=_int(params.get("threshold", 0), 0))
        connectivity = 8 if _int(params.get("connectivity", 8), 8) != 4 else 4
        count, labels, stats, centroids = cv2.connectedComponentsWithStats(binary, connectivity=connectivity)
        min_area = max(0, _int(params.get("min_area", 0), 0))
        max_area = max(0, _int(params.get("max_area", 0), 0))
        kept = []
        out_mask = np.zeros_like(binary)
        components = []
        for label in range(1, count):
            x, y, w, h, area = [int(v) for v in stats[label]]
            if area < min_area or (max_area > 0 and area > max_area):
                continue
            out_mask[labels == label] = 255
            item = {"label": label, "bbox": [x, y, w, h], "area": area, "center": [float(centroids[label][0]), float(centroids[label][1])]}
            components.append(item)
            kept.append(label)
        if node_type == "RemoveSmallRegions":
            return {"out": out_mask, "mask": out_mask, "components": components, "count": len(components), "out_color_space": "GRAY", "metrics": {"count": len(components)}}
        canvas = cv2.applyColorMap(((labels.astype(np.float32) / max(1, count - 1)) * 255).astype(np.uint8), cv2.COLORMAP_JET)
        canvas[labels == 0] = 0
        return {"out": canvas, "labels": labels.astype(np.int32), "mask": out_mask, "components": components, "count": len(components), "out_color_space": "BGR", "metrics": {"count": len(components)}}

    if node_type == "ConvexHullMask":
        binary = _binary(inputs, threshold=_int(params.get("threshold", 0), 0))
        contours = _contours_from_binary(binary)
        mask = np.zeros_like(binary)
        hulls = []
        for contour in contours:
            if cv2.contourArea(contour) < _float(params.get("min_area", 0), 0):
                continue
            hull = cv2.convexHull(contour)
            hulls.append(hull)
            cv2.drawContours(mask, [hull], -1, 255, cv2.FILLED)
        annotated = _annotated_from_mask(inputs, mask)
        return {"out": mask, "mask": mask, "annotated": annotated, "hulls": [_json_contour(item) for item in hulls], "out_color_space": "GRAY", "metrics": {"count": len(hulls)}}

    if node_type == "RegionBoundary":
        binary = _binary(inputs, threshold=_int(params.get("threshold", 0), 0))
        thickness = max(1, _int(params.get("thickness", 1), 1))
        eroded = cv2.erode(binary, np.ones((3, 3), np.uint8), iterations=thickness)
        boundary = cv2.subtract(binary, eroded)
        return {"out": boundary, "out_color_space": "GRAY", "metrics": {"boundary_pixels": int(np.count_nonzero(boundary))}}

    # ---------- 几何与标定 ----------
    if node_type == "CropROI":
        image = _uint8(inputs["in"])
        roi, bbox = _crop_rect(image, params)
        return {"out": roi, "roi": roi, "bbox": bbox, "out_color_space": inputs.get("in_color_space", "BGR")}

    if node_type == "RotateArbitrary":
        image = _uint8(inputs["in"])
        h, w = image.shape[:2]
        angle = _float(params.get("angle", 0), 0.0)
        scale = max(0.01, _float(params.get("scale", 1.0), 1.0))
        expand = _yes(params.get("expand"), True)
        matrix = cv2.getRotationMatrix2D((w / 2.0, h / 2.0), angle, scale)
        if expand:
            cos = abs(matrix[0, 0])
            sin = abs(matrix[0, 1])
            nw = int(h * sin + w * cos)
            nh = int(h * cos + w * sin)
            matrix[0, 2] += nw / 2.0 - w / 2.0
            matrix[1, 2] += nh / 2.0 - h / 2.0
        else:
            nw, nh = w, h
        border = _color(params.get("border_value"), (0, 0, 0))
        out = cv2.warpAffine(image, matrix, (nw, nh), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT, borderValue=border)
        return {"out": out, "matrix": matrix.round(8).tolist(), "out_color_space": inputs.get("in_color_space", "BGR")}

    if node_type == "AffineWarp":
        image = _uint8(inputs["in"])
        source = _parse_points(params, "source_points", 3)
        target = _parse_points(params, "target_points", 3)
        matrix = cv2.getAffineTransform(source, target)
        width = max(1, _int(params.get("output_width", image.shape[1]), image.shape[1]))
        height = max(1, _int(params.get("output_height", image.shape[0]), image.shape[0]))
        out = cv2.warpAffine(image, matrix, (width, height), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT, borderValue=_color(params.get("border_value"), (0, 0, 0)))
        return {"out": out, "matrix": matrix.round(8).tolist(), "out_color_space": inputs.get("in_color_space", "BGR")}

    if node_type == "PerspectiveWarp":
        image = _uint8(inputs["in"])
        source = _parse_points(params, "source_points", 4)
        target = _parse_points(params, "target_points", 4)
        matrix = cv2.getPerspectiveTransform(source, target)
        width = max(1, _int(params.get("output_width", image.shape[1]), image.shape[1]))
        height = max(1, _int(params.get("output_height", image.shape[0]), image.shape[0]))
        out = cv2.warpPerspective(image, matrix, (width, height), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT, borderValue=_color(params.get("border_value"), (0, 0, 0)))
        return {"out": out, "matrix": matrix.round(8).tolist(), "out_color_space": inputs.get("in_color_space", "BGR")}

    if node_type == "PadImage":
        image = _uint8(inputs["in"])
        border_type = str(params.get("border_type", "CONSTANT") or "CONSTANT").upper()
        code = {"REPLICATE": cv2.BORDER_REPLICATE, "REFLECT": cv2.BORDER_REFLECT, "REFLECT101": cv2.BORDER_REFLECT_101, "WRAP": cv2.BORDER_WRAP}.get(border_type, cv2.BORDER_CONSTANT)
        out = cv2.copyMakeBorder(image, max(0, _int(params.get("top", 0))), max(0, _int(params.get("bottom", 0))), max(0, _int(params.get("left", 0))), max(0, _int(params.get("right", 0))), code, value=_color(params.get("value"), (0, 0, 0)))
        return {"out": out, "out_color_space": inputs.get("in_color_space", "BGR")}

    if node_type == "PolarTransform":
        image = _uint8(inputs["in"])
        h, w = image.shape[:2]
        center_x = _float(params.get("center_x", -1), -1)
        center_y = _float(params.get("center_y", -1), -1)
        center = (w / 2 if center_x < 0 else center_x, h / 2 if center_y < 0 else center_y)
        radius = max(1.0, _float(params.get("max_radius", min(w, h) / 2), min(w, h) / 2))
        width = max(1, _int(params.get("output_width", int(radius)), int(radius)))
        height = max(1, _int(params.get("output_height", 360), 360))
        inverse = _yes(params.get("inverse"), False)
        log_mode = _yes(params.get("log_mode"), False)
        flags = cv2.INTER_LINEAR | (cv2.WARP_POLAR_LOG if log_mode else cv2.WARP_POLAR_LINEAR)
        if inverse:
            flags |= cv2.WARP_INVERSE_MAP
        out = cv2.warpPolar(image, (width, height), center, radius, flags)
        return {"out": out, "center": [float(center[0]), float(center[1])], "max_radius": radius, "out_color_space": inputs.get("in_color_space", "BGR")}

    if node_type == "CameraUndistort":
        image = _uint8(inputs["in"])
        matrix_value = params.get("camera_matrix")
        coeff_value = params.get("dist_coeffs")
        if isinstance(matrix_value, str):
            matrix_value = json.loads(matrix_value)
        if isinstance(coeff_value, str):
            coeff_value = json.loads(coeff_value)
        matrix = np.asarray(matrix_value, dtype=np.float64).reshape(3, 3)
        coeffs = np.asarray(coeff_value, dtype=np.float64).reshape(-1)
        alpha = float(np.clip(_float(params.get("alpha", 0.0), 0.0), 0.0, 1.0))
        h, w = image.shape[:2]
        new_matrix, roi = cv2.getOptimalNewCameraMatrix(matrix, coeffs, (w, h), alpha, (w, h))
        out = cv2.undistort(image, matrix, coeffs, None, new_matrix)
        if _yes(params.get("crop"), False):
            x, y, rw, rh = roi
            out = out[y:y + rh, x:x + rw]
        return {"out": out, "new_camera_matrix": new_matrix.round(10).tolist(), "roi": [int(v) for v in roi], "out_color_space": inputs.get("in_color_space", "BGR")}

    if node_type in {"CoordinateTransform", "PixelToWorld"}:
        value = inputs.get("points", inputs.get("in"))
        if value is None:
            value = params.get("points", [[_float(params.get("x", 0)), _float(params.get("y", 0))]])
        if isinstance(value, dict) and "points" in value:
            value = value["points"]
        if isinstance(value, str):
            value = json.loads(value)
        points = np.asarray(value, dtype=np.float64).reshape(-1, 2)
        matrix_value = params.get("matrix") or params.get("homography")
        if isinstance(matrix_value, str):
            matrix_value = json.loads(matrix_value)
        matrix = np.asarray(matrix_value, dtype=np.float64).reshape(3, 3)
        homogeneous = np.column_stack([points, np.ones(len(points))])
        transformed = homogeneous @ matrix.T
        transformed = transformed[:, :2] / np.maximum(np.abs(transformed[:, 2:3]), 1e-12)
        result = transformed.round(9).tolist()
        scale = _float(params.get("scale", 1.0), 1.0)
        if node_type == "PixelToWorld":
            result = (transformed * scale).round(9).tolist()
        first = result[0] if result else [0.0, 0.0]
        return {"out": result, "points": result, "point": first, "x": float(first[0]), "y": float(first[1]), "metrics": {"count": len(result)}}

    if node_type == "ComputeHomography":
        source_value = inputs.get("source_points", params.get("source_points"))
        target_value = inputs.get("target_points", params.get("target_points"))
        if isinstance(source_value, str):
            source_value = json.loads(source_value)
        if isinstance(target_value, str):
            target_value = json.loads(target_value)
        source_points = np.asarray(source_value, dtype=np.float64).reshape(-1, 2)
        target_points = np.asarray(target_value, dtype=np.float64).reshape(-1, 2)
        if len(source_points) != len(target_points) or len(source_points) < 4:
            raise ValueError("计算单应矩阵需要至少 4 对对应点，且点数必须一致")
        method_name = str(params.get("method", "RANSAC") or "RANSAC").upper()
        method = {"RANSAC": cv2.RANSAC, "LMEDS": cv2.LMEDS, "DIRECT": 0}.get(method_name, cv2.RANSAC)
        matrix, inlier_mask = cv2.findHomography(
            source_points.astype(np.float32),
            target_points.astype(np.float32),
            method,
            max(0.1, _float(params.get("ransac_threshold", 3.0), 3.0)),
        )
        if matrix is None:
            raise ValueError("无法从输入点计算单应矩阵")
        inliers = inlier_mask.reshape(-1).astype(int).tolist() if inlier_mask is not None else [1] * len(source_points)
        return {
            "out": matrix.round(10).tolist(),
            "matrix": matrix.round(10).tolist(),
            "inliers": inliers,
            "inlier_count": int(sum(inliers)),
            "metrics": {"point_count": len(source_points), "inlier_count": int(sum(inliers))},
        }

    if node_type == "ChessboardCorners":
        image = _bgr(inputs)
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        columns = max(2, _int(params.get("pattern_cols", 9), 9))
        rows = max(2, _int(params.get("pattern_rows", 6), 6))
        flags = cv2.CALIB_CB_ADAPTIVE_THRESH | cv2.CALIB_CB_NORMALIZE_IMAGE
        if _yes(params.get("fast_check"), True):
            flags |= cv2.CALIB_CB_FAST_CHECK
        found, corners = cv2.findChessboardCorners(gray, (columns, rows), flags)
        points: list[list[float]] = []
        canvas = image.copy()
        if found and corners is not None:
            criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 30, 0.001)
            refined = cv2.cornerSubPix(gray, corners, (11, 11), (-1, -1), criteria)
            points = [[float(item[0][0]), float(item[0][1])] for item in refined]
            cv2.drawChessboardCorners(canvas, (columns, rows), refined, True)
        return {
            "out": canvas,
            "corners": points,
            "count": len(points),
            "found": bool(found),
            "pattern_size": [columns, rows],
            "out_color_space": "BGR",
            "metrics": {"found": bool(found), "count": len(points)},
        }

    # ---------- 模板匹配、定位、特征 ----------
    if node_type in {"TemplateMatchNCC", "MultiScaleTemplateMatch"}:
        image = _bgr(inputs)
        template = _bgr(inputs, "template")
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        template_gray = cv2.cvtColor(template, cv2.COLOR_BGR2GRAY)
        method_name = str(params.get("method", "CCOEFF_NORMED") or "CCOEFF_NORMED").upper()
        method = {"CCORR_NORMED": cv2.TM_CCORR_NORMED, "SQDIFF_NORMED": cv2.TM_SQDIFF_NORMED}.get(method_name, cv2.TM_CCOEFF_NORMED)
        scales = [1.0]
        if node_type == "MultiScaleTemplateMatch":
            minimum = max(0.05, _float(params.get("min_scale", 0.5), 0.5))
            maximum = max(minimum, _float(params.get("max_scale", 1.5), 1.5))
            steps = max(2, _int(params.get("scale_steps", 11), 11))
            scales = np.linspace(minimum, maximum, steps).tolist()
        best = None
        for scale in scales:
            tw = max(2, int(round(template_gray.shape[1] * scale)))
            th = max(2, int(round(template_gray.shape[0] * scale)))
            if tw > gray.shape[1] or th > gray.shape[0]:
                continue
            resized = cv2.resize(template_gray, (tw, th), interpolation=cv2.INTER_AREA if scale < 1 else cv2.INTER_CUBIC)
            response = cv2.matchTemplate(gray, resized, method)
            min_value, max_value, min_location, max_location = cv2.minMaxLoc(response)
            score = 1.0 - min_value if method == cv2.TM_SQDIFF_NORMED else max_value
            location = min_location if method == cv2.TM_SQDIFF_NORMED else max_location
            if best is None or score > best[0]:
                best = (float(score), location, tw, th, float(scale), response)
        if best is None:
            raise ValueError("模板尺寸大于待检测图，无法匹配")
        score, (x, y), tw, th, scale, response = best
        bbox = [int(x), int(y), int(tw), int(th)]
        center = [float(x + tw / 2), float(y + th / 2)]
        canvas = image.copy()
        color = _color(params.get("draw_color"), (0, 255, 0))
        cv2.rectangle(canvas, (x, y), (x + tw, y + th), color, max(1, _int(params.get("thickness", 2), 2)))
        heatmap = cv2.applyColorMap(cv2.normalize(response, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8), cv2.COLORMAP_JET)
        return {"out": canvas, "bbox": bbox, "center": center, "score": score, "scale": scale, "response": heatmap, "out_color_space": "BGR", "metrics": {"score": score, "scale": scale}}

    if node_type == "ShapeMatch":
        image_binary = _binary(inputs)
        template_binary = _binary(inputs, "template")
        image_contours = _contours_from_binary(image_binary)
        template_contours = _contours_from_binary(template_binary)
        if not image_contours or not template_contours:
            raise ValueError("形状匹配需要前景轮廓")
        template_contour = max(template_contours, key=cv2.contourArea)
        best_contour = min(image_contours, key=lambda contour: cv2.matchShapes(template_contour, contour, cv2.CONTOURS_MATCH_I1, 0.0))
        score = float(cv2.matchShapes(template_contour, best_contour, cv2.CONTOURS_MATCH_I1, 0.0))
        x, y, w, h = cv2.boundingRect(best_contour)
        canvas = _bgr(inputs)
        cv2.drawContours(canvas, [best_contour], -1, _color(params.get("draw_color"), (0, 255, 0)), 2)
        return {"out": canvas, "bbox": [x, y, w, h], "score": score, "contour": _json_contour(best_contour), "out_color_space": "BGR", "metrics": {"score": score}}

    if node_type == "PhaseCorrelation":
        reference = _gray(inputs, "reference").astype(np.float32)
        image = _gray(inputs).astype(np.float32)
        if reference.shape != image.shape:
            reference = cv2.resize(reference, (image.shape[1], image.shape[0]), interpolation=cv2.INTER_LINEAR)
        window = cv2.createHanningWindow((image.shape[1], image.shape[0]), cv2.CV_32F) if _yes(params.get("use_window"), True) else None
        shift, response = cv2.phaseCorrelate(reference, image, window)
        dx, dy = float(shift[0]), float(shift[1])
        matrix = np.float32([[1, 0, -dx], [0, 1, -dy]])
        aligned = cv2.warpAffine(_bgr(inputs), matrix, (image.shape[1], image.shape[0]))
        return {"out": aligned, "shift": [dx, dy], "dx": dx, "dy": dy, "response": float(response), "matrix": matrix.tolist(), "out_color_space": "BGR", "metrics": {"dx": dx, "dy": dy, "response": float(response)}}

    if node_type == "AKAZEFeatureMatch":
        image = _bgr(inputs)
        template = _bgr(inputs, "template")
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        tgray = cv2.cvtColor(template, cv2.COLOR_BGR2GRAY)
        detector = cv2.AKAZE_create(threshold=max(1e-6, _float(params.get("threshold", 0.001), 0.001)))
        key1, desc1 = detector.detectAndCompute(tgray, None)
        key2, desc2 = detector.detectAndCompute(gray, None)
        good = []
        if desc1 is not None and desc2 is not None:
            matcher = cv2.BFMatcher(cv2.NORM_HAMMING)
            ratio = float(np.clip(_float(params.get("ratio_test", 0.75), 0.75), 0.05, 0.99))
            for pair in matcher.knnMatch(desc1, desc2, k=2):
                if len(pair) >= 2 and pair[0].distance < ratio * pair[1].distance:
                    good.append(pair[0])
        matrix = None
        inliers = 0
        corners = []
        canvas = image.copy()
        if len(good) >= max(4, _int(params.get("min_matches", 6), 6)):
            src = np.float32([key1[item.queryIdx].pt for item in good]).reshape(-1, 1, 2)
            dst = np.float32([key2[item.trainIdx].pt for item in good]).reshape(-1, 1, 2)
            matrix, inlier_mask = cv2.findHomography(src, dst, cv2.RANSAC, max(0.1, _float(params.get("ransac_threshold", 5), 5.0)))
            inliers = int(inlier_mask.sum()) if inlier_mask is not None else 0
            if matrix is not None:
                h, w = tgray.shape
                quad = np.float32([[0, 0], [w - 1, 0], [w - 1, h - 1], [0, h - 1]]).reshape(-1, 1, 2)
                projected = cv2.perspectiveTransform(quad, matrix).reshape(-1, 2)
                corners = [[float(x), float(y)] for x, y in projected]
                cv2.polylines(canvas, [np.int32(projected)], True, (0, 255, 0), 2)
        matches_image = cv2.drawMatches(template, key1, image, key2, good[:max(0, _int(params.get("max_draw_matches", 40), 40))], None, flags=cv2.DrawMatchesFlags_NOT_DRAW_SINGLE_POINTS)
        return {"out": canvas, "matches": matches_image, "match_count": len(good), "inlier_count": inliers, "homography": matrix.round(8).tolist() if matrix is not None else None, "corners": corners, "found": matrix is not None, "out_color_space": "BGR", "metrics": {"match_count": len(good), "inlier_count": inliers}}

    if node_type == "HoughLines":
        edges = _gray(inputs)
        threshold = max(1, _int(params.get("threshold", 50), 50))
        min_length = max(0, _float(params.get("min_line_length", 30), 30))
        max_gap = max(0, _float(params.get("max_line_gap", 10), 10))
        lines = cv2.HoughLinesP(edges, 1, np.pi / 180.0, threshold, minLineLength=min_length, maxLineGap=max_gap)
        values = []
        canvas = _bgr(inputs)
        if lines is not None:
            for raw in lines[:max(1, _int(params.get("max_lines", 100), 100))]:
                x1, y1, x2, y2 = [int(v) for v in raw[0]]
                values.append({"p1": [x1, y1], "p2": [x2, y2], "length": float(math.hypot(x2 - x1, y2 - y1)), "angle": float(math.degrees(math.atan2(y2 - y1, x2 - x1)))})
                cv2.line(canvas, (x1, y1), (x2, y2), _color(params.get("draw_color"), (0, 0, 255)), max(1, _int(params.get("thickness", 2), 2)))
        return {"out": canvas, "lines": values, "count": len(values), "first": values[0] if values else None, "out_color_space": "BGR", "metrics": {"count": len(values)}}

    if node_type == "HoughCircles":
        gray = cv2.medianBlur(_gray(inputs), _odd(params.get("blur_ksize", 5), 5))
        circles = cv2.HoughCircles(gray, cv2.HOUGH_GRADIENT, dp=max(1.0, _float(params.get("dp", 1.2), 1.2)), minDist=max(1.0, _float(params.get("min_distance", 20), 20)), param1=max(1.0, _float(params.get("canny_threshold", 100), 100)), param2=max(1.0, _float(params.get("accumulator_threshold", 30), 30)), minRadius=max(0, _int(params.get("min_radius", 0), 0)), maxRadius=max(0, _int(params.get("max_radius", 0), 0)))
        values = []
        canvas = _bgr(inputs)
        if circles is not None:
            for x, y, radius in np.round(circles[0, :max(1, _int(params.get("max_circles", 50), 50))]).astype(int):
                values.append({"center": [int(x), int(y)], "radius": int(radius), "diameter": int(radius * 2)})
                cv2.circle(canvas, (x, y), radius, _color(params.get("draw_color"), (0, 255, 0)), 2)
                cv2.circle(canvas, (x, y), 2, (0, 0, 255), -1)
        return {"out": canvas, "circles": values, "count": len(values), "first": values[0] if values else None, "out_color_space": "BGR", "metrics": {"count": len(values)}}

    if node_type in {"HarrisCorners", "ShiTomasiCorners"}:
        gray = _gray(inputs)
        canvas = _bgr(inputs)
        points: list[list[float]] = []
        if node_type == "HarrisCorners":
            response = cv2.cornerHarris(np.float32(gray), max(2, _int(params.get("block_size", 2), 2)), _odd(params.get("ksize", 3), 3), _float(params.get("k", 0.04), 0.04))
            threshold = _float(params.get("quality", 0.01), 0.01) * float(response.max() or 1.0)
            ys, xs = np.where(response > threshold)
            max_points = max(1, _int(params.get("max_corners", 200), 200))
            indices = np.argsort(response[ys, xs])[::-1][:max_points]
            points = [[float(xs[i]), float(ys[i])] for i in indices]
        else:
            corners = cv2.goodFeaturesToTrack(gray, maxCorners=max(1, _int(params.get("max_corners", 200), 200)), qualityLevel=max(1e-6, _float(params.get("quality", 0.01), 0.01)), minDistance=max(1.0, _float(params.get("min_distance", 10), 10)), blockSize=max(2, _int(params.get("block_size", 3), 3)), useHarrisDetector=False)
            if corners is not None:
                points = [[float(item[0][0]), float(item[0][1])] for item in corners]
        for x, y in points:
            cv2.circle(canvas, (int(round(x)), int(round(y))), max(1, _int(params.get("radius", 3), 3)), _color(params.get("draw_color"), (0, 0, 255)), -1)
        return {"out": canvas, "points": points, "count": len(points), "out_color_space": "BGR", "metrics": {"count": len(points)}}

    if node_type == "ArucoMarkerDetect":
        aruco = getattr(cv2, "aruco", None)
        if aruco is None:
            raise RuntimeError("当前 OpenCV 不包含 ArUco 模块，请安装 opencv-contrib-python。")
        image = _bgr(inputs)
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        dictionary_name = str(params.get("dictionary", "DICT_4X4_50") or "DICT_4X4_50").upper()
        dictionary_id = getattr(aruco, dictionary_name, getattr(aruco, "DICT_4X4_50"))
        dictionary = aruco.getPredefinedDictionary(dictionary_id)
        if hasattr(aruco, "DetectorParameters") and hasattr(aruco, "ArucoDetector"):
            detector = aruco.ArucoDetector(dictionary, aruco.DetectorParameters())
            corners, ids, rejected = detector.detectMarkers(gray)
        else:
            parameters = aruco.DetectorParameters_create()
            corners, ids, rejected = aruco.detectMarkers(gray, dictionary, parameters=parameters)
        canvas = image.copy()
        markers = []
        if ids is not None and len(ids):
            aruco.drawDetectedMarkers(canvas, corners, ids)
            for marker_id, polygon in zip(ids.reshape(-1), corners):
                points = [[float(x), float(y)] for x, y in np.asarray(polygon).reshape(-1, 2)]
                center = np.mean(np.asarray(points), axis=0).tolist()
                markers.append({"id": int(marker_id), "corners": points, "center": [float(center[0]), float(center[1])]})
        return {
            "out": canvas,
            "markers": markers,
            "ids": [item["id"] for item in markers],
            "count": len(markers),
            "found": bool(markers),
            "rejected_count": len(rejected or []),
            "out_color_space": "BGR",
            "metrics": {"count": len(markers), "rejected_count": len(rejected or [])},
        }

    # ---------- 测量与缺陷 ----------
    if node_type == "BlobAnalysis":
        binary = _binary(inputs, threshold=_int(params.get("threshold", 0), 0))
        contours = _contours_from_binary(binary)
        minimum = max(0.0, _float(params.get("min_area", 0), 0.0))
        maximum = max(0.0, _float(params.get("max_area", 0), 0.0))
        blobs = []
        canvas = _bgr(inputs)
        mask = np.zeros_like(binary)
        for index, contour in enumerate(contours):
            area = float(cv2.contourArea(contour))
            if area < minimum or (maximum > 0 and area > maximum):
                continue
            perimeter = float(cv2.arcLength(contour, True))
            x, y, w, h = cv2.boundingRect(contour)
            moments = cv2.moments(contour)
            cx = float(moments["m10"] / moments["m00"]) if moments["m00"] else x + w / 2
            cy = float(moments["m01"] / moments["m00"]) if moments["m00"] else y + h / 2
            circularity = float(4 * np.pi * area / (perimeter * perimeter)) if perimeter else 0.0
            hull_area = float(cv2.contourArea(cv2.convexHull(contour)))
            solidity = float(area / hull_area) if hull_area else 0.0
            item = {"index": index, "area": area, "perimeter": perimeter, "bbox": [x, y, w, h], "center": [cx, cy], "circularity": circularity, "solidity": solidity}
            blobs.append(item)
            cv2.drawContours(mask, [contour], -1, 255, cv2.FILLED)
            cv2.drawContours(canvas, [contour], -1, (0, 255, 0), 2)
            cv2.putText(canvas, str(len(blobs)), (x, max(12, y - 3)), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0, 180, 255), 1, cv2.LINE_AA)
        return {"out": canvas, "mask": mask, "blobs": blobs, "count": len(blobs), "largest": max(blobs, key=lambda item: item["area"]) if blobs else None, "out_color_space": "BGR", "metrics": {"count": len(blobs), "total_area": float(sum(item["area"] for item in blobs))}}

    if node_type == "ImageStatistics":
        image = _uint8(inputs["in"])
        mask = _binary(inputs, "mask") if isinstance(inputs.get("mask"), np.ndarray) else None
        values = image[mask > 0] if mask is not None and image.ndim == 2 else None
        if image.ndim == 2:
            source = values if values is not None and values.size else image.reshape(-1)
            stats = {"mean": float(np.mean(source)), "std": float(np.std(source)), "min": float(np.min(source)), "max": float(np.max(source)), "median": float(np.median(source)), "percentile_10": float(np.percentile(source, 10)), "percentile_90": float(np.percentile(source, 90)), "pixel_count": int(source.size)}
        else:
            bgr = _bgr(inputs)
            selected = bgr[mask > 0] if mask is not None else bgr.reshape(-1, 3)
            means = np.mean(selected, axis=0)
            stds = np.std(selected, axis=0)
            stats = {"mean_b": float(means[0]), "mean_g": float(means[1]), "mean_r": float(means[2]), "std_b": float(stds[0]), "std_g": float(stds[1]), "std_r": float(stds[2]), "pixel_count": int(len(selected))}
        return {"out": stats, "statistics": stats, "metrics": stats}

    if node_type == "HistogramAnalysis":
        gray = _gray(inputs)
        bins = int(np.clip(_int(params.get("bins", 256), 256), 2, 256))
        mask = _binary(inputs, "mask") if isinstance(inputs.get("mask"), np.ndarray) else None
        hist = cv2.calcHist([gray], [0], mask, [bins], [0, 256]).reshape(-1)
        normalized = hist / max(1.0, float(hist.sum()))
        peak = int(np.argmax(hist))
        mean = float(cv2.mean(gray, mask=mask)[0])
        canvas = np.zeros((240, 512, 3), dtype=np.uint8)
        points = []
        maximum = float(hist.max() or 1.0)
        for index, value in enumerate(hist):
            x = int(index * (canvas.shape[1] - 1) / max(1, bins - 1))
            y = int(canvas.shape[0] - 1 - value / maximum * (canvas.shape[0] - 20))
            points.append((x, y))
        if len(points) >= 2:
            cv2.polylines(canvas, [np.asarray(points, dtype=np.int32)], False, (0, 255, 0), 1)
        return {"out": canvas, "histogram": hist.astype(float).tolist(), "normalized_histogram": normalized.astype(float).tolist(), "peak_bin": peak, "mean": mean, "out_color_space": "BGR", "metrics": {"peak_bin": peak, "mean": mean}}

    if node_type == "IntensityProfile":
        gray = _gray(inputs)
        p1 = _point(inputs.get("p1"), (_float(params.get("x1", 0)), _float(params.get("y1", gray.shape[0] / 2))))
        p2 = _point(inputs.get("p2"), (_float(params.get("x2", gray.shape[1] - 1)), _float(params.get("y2", gray.shape[0] / 2))))
        length = max(2, int(round(math.hypot(p2[0] - p1[0], p2[1] - p1[1]))) + 1)
        xs = np.linspace(p1[0], p2[0], length)
        ys = np.linspace(p1[1], p2[1], length)
        map_x = xs.astype(np.float32).reshape(1, -1)
        map_y = ys.astype(np.float32).reshape(1, -1)
        profile = cv2.remap(gray, map_x, map_y, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE).reshape(-1)
        canvas = _bgr(inputs)
        cv2.line(canvas, tuple(np.int32(np.round(p1))), tuple(np.int32(np.round(p2))), (0, 255, 0), 2)
        return {"out": canvas, "profile": profile.astype(float).tolist(), "p1": p1, "p2": p2, "mean": float(np.mean(profile)), "std": float(np.std(profile)), "out_color_space": "BGR", "metrics": {"mean": float(np.mean(profile)), "std": float(np.std(profile)), "length": len(profile)}}

    if node_type == "CaliperEdgePair":
        gray = _gray(inputs)
        center = _point(inputs.get("center"), (_float(params.get("center_x", gray.shape[1] / 2)), _float(params.get("center_y", gray.shape[0] / 2))))
        angle = math.radians(_float(params.get("angle", 0), 0.0))
        length = max(5, _int(params.get("length", min(gray.shape) / 2), min(gray.shape) / 2))
        sample_width = max(1, _int(params.get("sample_width", 5), 5))
        normal = np.array([-math.sin(angle), math.cos(angle)], dtype=np.float32)
        direction = np.array([math.cos(angle), math.sin(angle)], dtype=np.float32)
        positions = np.linspace(-length / 2, length / 2, length + 1)
        profiles = []
        for offset in np.linspace(-(sample_width - 1) / 2, (sample_width - 1) / 2, sample_width):
            points = np.asarray(center, dtype=np.float32) + positions[:, None] * direction + offset * normal
            values = cv2.remap(gray, points[:, 0].astype(np.float32).reshape(1, -1), points[:, 1].astype(np.float32).reshape(1, -1), cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE).reshape(-1)
            profiles.append(values)
        profile = np.mean(np.vstack(profiles), axis=0)
        gradient = np.gradient(profile)
        threshold = max(0.0, _float(params.get("gradient_threshold", 10), 10.0))
        candidates = np.where(np.abs(gradient) >= threshold)[0]
        if len(candidates) < 2:
            first, second = int(np.argmin(gradient)), int(np.argmax(gradient))
        else:
            polarity = str(params.get("polarity", "ANY") or "ANY").upper()
            if polarity == "DARK_TO_LIGHT":
                candidates = candidates[gradient[candidates] > 0]
            elif polarity == "LIGHT_TO_DARK":
                candidates = candidates[gradient[candidates] < 0]
            if len(candidates) < 2:
                first, second = int(np.argmin(gradient)), int(np.argmax(gradient))
            else:
                first, second = int(candidates[0]), int(candidates[-1])
        edge1 = (np.asarray(center) + positions[first] * direction).tolist()
        edge2 = (np.asarray(center) + positions[second] * direction).tolist()
        distance = float(abs(positions[second] - positions[first]))
        canvas = _bgr(inputs)
        cv2.line(canvas, tuple(np.int32(np.round(edge1))), tuple(np.int32(np.round(edge2))), (0, 255, 0), 2)
        cv2.circle(canvas, tuple(np.int32(np.round(edge1))), 4, (0, 0, 255), -1)
        cv2.circle(canvas, tuple(np.int32(np.round(edge2))), 4, (255, 0, 0), -1)
        return {"out": canvas, "edge1": edge1, "edge2": edge2, "distance": distance, "profile": profile.astype(float).tolist(), "gradient": gradient.astype(float).tolist(), "out_color_space": "BGR", "metrics": {"distance": distance}}

    if node_type in {"FitCircle", "FitEllipse"}:
        binary = _binary(inputs, threshold=_int(params.get("threshold", 0), 0))
        raw_contours, _ = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
        contours = [item for item in raw_contours if cv2.contourArea(item) >= _float(params.get("min_area", 10), 10)]
        if not contours:
            raise ValueError("没有找到可拟合的轮廓")
        contour = max(contours, key=cv2.contourArea)
        canvas = _bgr(inputs)
        if node_type == "FitCircle":
            cx, cy, radius, residual = _fit_circle_points(contour.reshape(-1, 2))
            cv2.circle(canvas, (int(round(cx)), int(round(cy))), int(round(radius)), (0, 255, 0), 2)
            circle = {"center": [cx, cy], "radius": radius, "diameter": radius * 2, "residual": residual}
            return {"out": canvas, "circle": circle, "center": circle["center"], "radius": radius, "diameter": radius * 2, "residual": residual, "out_color_space": "BGR", "metrics": {"radius": radius, "residual": residual}}
        if len(contour) < 5:
            raise ValueError("拟合椭圆至少需要 5 个轮廓点")
        ellipse = cv2.fitEllipse(contour)
        (cx, cy), (width, height), angle = ellipse
        cv2.ellipse(canvas, ellipse, (0, 255, 0), 2)
        value = {"center": [float(cx), float(cy)], "size": [float(width), float(height)], "angle": float(angle), "major_axis": float(max(width, height)), "minor_axis": float(min(width, height))}
        return {"out": canvas, "ellipse": value, "center": value["center"], "size": value["size"], "angle": float(angle), "out_color_space": "BGR", "metrics": {"major_axis": value["major_axis"], "minor_axis": value["minor_axis"], "angle": float(angle)}}

    if node_type == "PointPointDistance":
        p1 = _point(inputs.get("p1"), (_float(params.get("x1", 0)), _float(params.get("y1", 0))))
        p2 = _point(inputs.get("p2"), (_float(params.get("x2", 100)), _float(params.get("y2", 0))))
        pixel_distance = float(math.hypot(p2[0] - p1[0], p2[1] - p1[1]))
        scale = _float(params.get("unit_per_pixel", 1.0), 1.0)
        distance = pixel_distance * scale
        if isinstance(inputs.get("image"), np.ndarray):
            canvas = _bgr(inputs, "image")
        else:
            width = max(200, int(max(p1[0], p2[0]) + 40))
            height = max(160, int(max(p1[1], p2[1]) + 40))
            canvas = np.zeros((height, width, 3), dtype=np.uint8)
        cv2.line(canvas, tuple(np.int32(np.round(p1))), tuple(np.int32(np.round(p2))), (0, 255, 0), 2)
        return {"out": canvas, "distance": distance, "pixel_distance": pixel_distance, "p1": p1, "p2": p2, "value": distance, "out_color_space": "BGR", "metrics": {"distance": distance, "pixel_distance": pixel_distance}}

    if node_type == "LineIntersection":
        line1 = _line(inputs.get("line1"), params, "line1_")
        line2 = _line(inputs.get("line2"), params, "line2_")
        a1, b1, c1 = _line_abc(line1)
        a2, b2, c2 = _line_abc(line2)
        determinant = a1 * b2 - a2 * b1
        parallel = abs(determinant) < 1e-12
        point = None if parallel else [float((b1 * c2 - b2 * c1) / determinant), float((c1 * a2 - c2 * a1) / determinant)]
        if isinstance(inputs.get("image"), np.ndarray):
            canvas = _bgr(inputs, "image")
        else:
            canvas = np.zeros((480, 640, 3), dtype=np.uint8)
        if point is not None:
            cv2.circle(canvas, tuple(np.int32(np.round(point))), 5, (0, 0, 255), -1)
        return {"out": canvas, "point": point, "parallel": parallel, "line1": line1, "line2": line2, "out_color_space": "BGR", "metrics": {"parallel": parallel}}

    if node_type == "AngleBetweenLines":
        line1 = _line(inputs.get("line1"), params, "line1_")
        line2 = _line(inputs.get("line2"), params, "line2_")
        def direction(line: dict[str, Any]) -> np.ndarray:
            if line.get("p1") is not None and line.get("p2") is not None:
                return np.asarray(_point(line["p2"])) - np.asarray(_point(line["p1"]))
            a, b, _ = _line_abc(line)
            return np.asarray([b, -a], dtype=np.float64)
        d1, d2 = direction(line1), direction(line2)
        norm = np.linalg.norm(d1) * np.linalg.norm(d2)
        if norm <= 1e-12:
            raise ValueError("输入直线长度不能为 0")
        angle = math.degrees(math.acos(float(np.clip(abs(np.dot(d1, d2)) / norm, -1.0, 1.0))))
        acute = min(angle, 180.0 - angle)
        return {"out": acute, "angle": acute, "value": acute, "metrics": {"angle": acute}}

    if node_type in {"ImageDifference", "SSIMDifference"}:
        image = _bgr(inputs)
        reference = _bgr(inputs, "reference")
        if reference.shape != image.shape:
            reference = cv2.resize(reference, (image.shape[1], image.shape[0]), interpolation=cv2.INTER_LINEAR)
        if node_type == "ImageDifference":
            difference = cv2.absdiff(image, reference)
            gray_diff = cv2.cvtColor(difference, cv2.COLOR_BGR2GRAY)
            threshold = max(0, _int(params.get("threshold", 20), 20))
            mask = cv2.threshold(gray_diff, threshold, 255, cv2.THRESH_BINARY)[1]
            score = float(np.mean(gray_diff))
        else:
            gray1 = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY).astype(np.float64)
            gray2 = cv2.cvtColor(reference, cv2.COLOR_BGR2GRAY).astype(np.float64)
            size = _odd(params.get("window_size", 11), 11, 3)
            sigma = max(0.1, _float(params.get("sigma", 1.5), 1.5))
            c1, c2 = (0.01 * 255) ** 2, (0.03 * 255) ** 2
            mu1 = cv2.GaussianBlur(gray1, (size, size), sigma)
            mu2 = cv2.GaussianBlur(gray2, (size, size), sigma)
            sigma1 = cv2.GaussianBlur(gray1 * gray1, (size, size), sigma) - mu1 * mu1
            sigma2 = cv2.GaussianBlur(gray2 * gray2, (size, size), sigma) - mu2 * mu2
            covariance = cv2.GaussianBlur(gray1 * gray2, (size, size), sigma) - mu1 * mu2
            ssim_map = ((2 * mu1 * mu2 + c1) * (2 * covariance + c2)) / ((mu1 * mu1 + mu2 * mu2 + c1) * (sigma1 + sigma2 + c2) + 1e-12)
            score = float(np.mean(ssim_map))
            gray_diff = np.clip((1.0 - ssim_map) * 127.5, 0, 255).astype(np.uint8)
            threshold = max(0, _int(params.get("threshold", 30), 30))
            mask = cv2.threshold(gray_diff, threshold, 255, cv2.THRESH_BINARY)[1]
            difference = cv2.applyColorMap(gray_diff, cv2.COLORMAP_JET)
        annotated = image.copy()
        contours = _contours_from_binary(mask)
        for contour in contours:
            if cv2.contourArea(contour) < _float(params.get("min_area", 5), 5):
                continue
            x, y, w, h = cv2.boundingRect(contour)
            cv2.rectangle(annotated, (x, y), (x + w, y + h), (0, 0, 255), 2)
        return {"out": annotated, "difference": difference, "mask": mask, "score": score, "out_color_space": "BGR", "metrics": {"score": score, "defect_pixels": int(np.count_nonzero(mask))}}

    if node_type == "LocalVarianceDefect":
        gray = _gray(inputs).astype(np.float32)
        size = _odd(params.get("ksize", 15), 15, 3)
        mean = cv2.blur(gray, (size, size))
        mean_square = cv2.blur(gray * gray, (size, size))
        variance = np.maximum(mean_square - mean * mean, 0)
        variance_image = cv2.normalize(variance, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
        threshold = max(0, _int(params.get("threshold", 40), 40))
        mask = cv2.threshold(variance_image, threshold, 255, cv2.THRESH_BINARY)[1]
        annotated = _annotated_from_mask(inputs, mask, (0, 0, 255))
        return {"out": annotated, "variance": variance_image, "mask": mask, "out_color_space": "BGR", "metrics": {"mean_variance": float(np.mean(variance)), "defect_pixels": int(np.count_nonzero(mask))}}

    if node_type == "ScratchDetection":
        gray = _gray(inputs)
        mode = str(params.get("polarity", "DARK") or "DARK").upper()
        kernel_length = max(3, _int(params.get("length", 31), 31))
        thickness = max(1, _int(params.get("thickness", 3), 3))
        angle = math.radians(_float(params.get("angle", 0), 0.0))
        kernel = np.zeros((kernel_length, kernel_length), np.uint8)
        center = kernel_length // 2
        dx = int(math.cos(angle) * (kernel_length - 1) / 2)
        dy = int(math.sin(angle) * (kernel_length - 1) / 2)
        cv2.line(kernel, (center - dx, center - dy), (center + dx, center + dy), 1, thickness)
        response = cv2.morphologyEx(gray, cv2.MORPH_BLACKHAT if mode == "DARK" else cv2.MORPH_TOPHAT, kernel)
        threshold = max(0, _int(params.get("threshold", 20), 20))
        mask = cv2.threshold(response, threshold, 255, cv2.THRESH_BINARY)[1]
        if _int(params.get("min_area", 0), 0) > 0:
            count, labels, stats, _ = cv2.connectedComponentsWithStats(mask)
            filtered = np.zeros_like(mask)
            for label in range(1, count):
                if stats[label, cv2.CC_STAT_AREA] >= _int(params.get("min_area", 10), 10):
                    filtered[labels == label] = 255
            mask = filtered
        annotated = _annotated_from_mask(inputs, mask, (0, 0, 255))
        return {"out": annotated, "response": response, "mask": mask, "out_color_space": "BGR", "metrics": {"defect_pixels": int(np.count_nonzero(mask))}}

    if node_type == "FocusMeasure":
        gray = _gray(inputs)
        method = str(params.get("method", "LAPLACIAN_VARIANCE") or "LAPLACIAN_VARIANCE").upper()
        if method == "TENENGRAD":
            gx = cv2.Sobel(gray, cv2.CV_64F, 1, 0, ksize=3)
            gy = cv2.Sobel(gray, cv2.CV_64F, 0, 1, ksize=3)
            response = gx * gx + gy * gy
            score = float(np.mean(response))
        elif method == "BRENNER":
            diff = gray[:, 2:].astype(np.float64) - gray[:, :-2].astype(np.float64)
            response = diff * diff
            score = float(np.mean(response))
        else:
            response = cv2.Laplacian(gray, cv2.CV_64F)
            score = float(response.var())
        passed = score >= _float(params.get("minimum_score", 100), 100.0)
        heatmap = cv2.applyColorMap(cv2.normalize(np.abs(response), None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8), cv2.COLORMAP_JET)
        return {"out": heatmap, "score": score, "passed": passed, "out_color_space": "BGR", "metrics": {"score": score, "passed": passed}}

    # ---------- OCR、字符、码识别 ----------
    if node_type == "OCRPreprocess":
        gray = _gray(inputs)
        scale = max(0.1, _float(params.get("scale", 2.0), 2.0))
        resized = cv2.resize(gray, None, fx=scale, fy=scale, interpolation=cv2.INTER_CUBIC)
        if _yes(params.get("denoise"), True):
            resized = cv2.fastNlMeansDenoising(resized, None, _float(params.get("denoise_h", 10), 10.0), 7, 21)
        mode = str(params.get("threshold_mode", "OTSU") or "OTSU").upper()
        if mode == "ADAPTIVE":
            processed = cv2.adaptiveThreshold(resized, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, _odd(params.get("block_size", 31), 31, 3), _float(params.get("c", 10), 10.0))
        elif mode == "NONE":
            processed = resized
        else:
            processed = cv2.threshold(resized, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1]
        if _yes(params.get("invert"), False):
            processed = cv2.bitwise_not(processed)
        return {"out": processed, "out_color_space": "GRAY"}

    if node_type == "OCRRecognize":
        image = _uint8(inputs["in"])
        engine = str(params.get("engine", "TESSERACT") or "TESSERACT").upper()
        if engine == "EASYOCR":
            text, items = _ocr_easyocr(image, params)
        elif engine == "AUTO":
            try:
                text, items = _ocr_easyocr(image, params)
            except Exception:
                text, items = _ocr_tesseract(image, params)
        else:
            text, items = _ocr_tesseract(image, params)
        canvas = _bgr(inputs)
        for item in items:
            x, y, w, h = item["bbox"]
            cv2.rectangle(canvas, (x, y), (x + w, y + h), (0, 255, 0), 2)
            cv2.putText(canvas, str(item["text"])[:24], (x, max(12, y - 3)), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 180, 255), 1, cv2.LINE_AA)
        mean_conf = float(np.mean([item["confidence"] for item in items])) if items else 0.0
        return {"out": canvas, "text": text, "items": items, "count": len(items), "mean_confidence": mean_conf, "out_color_space": "BGR", "metrics": {"count": len(items), "mean_confidence": mean_conf}}

    if node_type == "QRCodeDecode":
        image = _bgr(inputs)
        detector = cv2.QRCodeDetector()
        decoded = []
        points_list = []
        try:
            ok, values, points, _ = detector.detectAndDecodeMulti(image)
        except Exception:
            ok, values, points = False, [], None
        if ok and points is not None:
            for value, polygon in zip(values, points):
                decoded.append(str(value))
                polygon_list = [[float(x), float(y)] for x, y in polygon]
                points_list.append(polygon_list)
        else:
            value, points, _ = detector.detectAndDecode(image)
            if value and points is not None:
                decoded.append(str(value))
                points_list.append([[float(x), float(y)] for x, y in np.asarray(points).reshape(-1, 2)])
        canvas = image.copy()
        for polygon in points_list:
            cv2.polylines(canvas, [np.int32(np.round(polygon))], True, (0, 255, 0), 2)
        return {"out": canvas, "texts": decoded, "text": decoded[0] if decoded else "", "points": points_list, "count": len(decoded), "found": bool(decoded), "out_color_space": "BGR", "metrics": {"count": len(decoded)}}

    if node_type == "BarcodeDecode":
        image = _bgr(inputs)
        items = []
        detector_class = getattr(cv2, "barcode_BarcodeDetector", None)
        if detector_class is not None:
            detector = detector_class()
            try:
                ok, decoded_info, decoded_type, points = detector.detectAndDecodeWithType(image)
                if ok:
                    for index, text in enumerate(decoded_info):
                        polygon = [] if points is None else [[float(x), float(y)] for x, y in np.asarray(points[index]).reshape(-1, 2)]
                        items.append({"text": str(text), "type": str(decoded_type[index]), "polygon": polygon})
            except Exception:
                pass
        if not items:
            try:
                from pyzbar.pyzbar import decode as pyzbar_decode
                for result in pyzbar_decode(image):
                    x, y, w, h = result.rect
                    items.append({"text": result.data.decode("utf-8", errors="replace"), "type": str(result.type), "bbox": [x, y, w, h], "polygon": [[point.x, point.y] for point in result.polygon]})
            except Exception as exc:
                if detector_class is None:
                    raise RuntimeError("当前 OpenCV 不包含条码模块，且 pyzbar 不可用。请安装 opencv-contrib-python 或 pyzbar + zbar。") from exc
        canvas = image.copy()
        for item in items:
            polygon = item.get("polygon") or []
            if polygon:
                cv2.polylines(canvas, [np.int32(np.round(polygon))], True, (0, 255, 0), 2)
            elif item.get("bbox"):
                x, y, w, h = item["bbox"]
                cv2.rectangle(canvas, (x, y), (x + w, y + h), (0, 255, 0), 2)
        return {"out": canvas, "items": items, "texts": [item["text"] for item in items], "text": items[0]["text"] if items else "", "count": len(items), "found": bool(items), "out_color_space": "BGR", "metrics": {"count": len(items)}}

    if node_type == "DataMatrixDecode":
        image = _bgr(inputs)
        try:
            from pylibdmtx.pylibdmtx import decode as dmtx_decode
        except Exception as exc:
            raise RuntimeError("DataMatrix 解码依赖 pylibdmtx，并需要系统安装 libdmtx。") from exc
        timeout = max(1, _int(params.get("timeout_ms", 1000), 1000))
        max_count = max(1, _int(params.get("max_count", 20), 20))
        results = dmtx_decode(image, timeout=timeout, max_count=max_count)
        items = []
        canvas = image.copy()
        image_height = image.shape[0]
        for result in results:
            rect = result.rect
            # pylibdmtx 使用左下角为原点，转换为 OpenCV 左上角坐标。
            x = int(rect.left)
            width = int(rect.width)
            height = int(rect.height)
            y = int(image_height - rect.top - height)
            x = max(0, x)
            y = max(0, y)
            text = result.data.decode(str(params.get("encoding", "utf-8") or "utf-8"), errors="replace")
            item = {"text": text, "bbox": [x, y, width, height]}
            items.append(item)
            cv2.rectangle(canvas, (x, y), (x + width, y + height), (0, 255, 0), 2)
        return {
            "out": canvas,
            "items": items,
            "texts": [item["text"] for item in items],
            "text": items[0]["text"] if items else "",
            "count": len(items),
            "found": bool(items),
            "out_color_space": "BGR",
            "metrics": {"count": len(items)},
        }

    if node_type == "TextRegionMSER":
        gray = _gray(inputs)
        detector = cv2.MSER_create(
            max(1, _int(params.get("delta", 5), 5)),
            max(1, _int(params.get("min_area", 60), 60)),
            max(2, _int(params.get("max_area", 14400), 14400)),
        )
        regions, boxes = detector.detectRegions(gray)
        canvas = _bgr(inputs)
        items = []
        for box in boxes[:max(1, _int(params.get("max_regions", 500), 500))]:
            x, y, w, h = [int(v) for v in box]
            ratio = w / max(1.0, h)
            if ratio < _float(params.get("min_aspect", 0.1), 0.1) or ratio > _float(params.get("max_aspect", 10.0), 10.0):
                continue
            items.append([x, y, w, h])
            cv2.rectangle(canvas, (x, y), (x + w, y + h), (0, 255, 0), 1)
        return {"out": canvas, "boxes": items, "count": len(items), "out_color_space": "BGR", "metrics": {"count": len(items)}}

    if node_type == "CharacterSegment":
        binary = _binary(inputs, threshold=_int(params.get("threshold", 0), 0))
        if _yes(params.get("invert"), False):
            binary = cv2.bitwise_not(binary)
        count, labels, stats, _ = cv2.connectedComponentsWithStats(binary, connectivity=8)
        characters = []
        crops = []
        canvas = _bgr(inputs)
        min_area = max(1, _int(params.get("min_area", 20), 20))
        min_height = max(1, _int(params.get("min_height", 5), 5))
        for label in range(1, count):
            x, y, w, h, area = [int(value) for value in stats[label]]
            if area < min_area or h < min_height:
                continue
            characters.append({"bbox": [x, y, w, h], "area": area})
            crops.append(binary[y:y + h, x:x + w].copy())
        order = str(params.get("sort", "LEFT_TO_RIGHT") or "LEFT_TO_RIGHT").upper()
        reverse = order in {"RIGHT_TO_LEFT", "BOTTOM_TO_TOP"}
        axis = 1 if order in {"TOP_TO_BOTTOM", "BOTTOM_TO_TOP"} else 0
        zipped = sorted(zip(characters, crops), key=lambda item: item[0]["bbox"][axis], reverse=reverse)
        characters = [item[0] for item in zipped]
        crops = [item[1] for item in zipped]
        for index, item in enumerate(characters):
            x, y, w, h = item["bbox"]
            cv2.rectangle(canvas, (x, y), (x + w, y + h), (0, 255, 0), 1)
            cv2.putText(canvas, str(index), (x, max(12, y - 2)), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 180, 255), 1)
        return {"out": canvas, "mask": binary, "characters": characters, "crops": crops, "count": len(characters), "out_color_space": "BGR", "metrics": {"count": len(characters)}}

    raise ValueError(f"未知工业算子：{node_type}")


__all__ = ["_industrial_execute"]
