// 拆分自 app.bundle.legacy.js：第 352-496 行。
function renderOperatorPanel(){
  renderCategoryOperatorPanel({
    categories:["图像", "测量", "识别"],
    panelId:"operatorPanel",
    searchId:"opSearch",
    collapsedGroups:collapsedOperatorGroups,
    showCategoryTitles:true,
  });
  renderCategoryOperatorPanel({
    categories:["逻辑"],
    panelId:"logicOperatorPanel",
    searchId:"logicSearch",
    collapsedGroups:collapsedLogicOperatorGroups,
    showCategoryTitles:false,
  });
}

function renderCategoryOperatorPanel({ categories, category, panelId, searchId, collapsedGroups, showCategoryTitles = false }){
  const panel = document.getElementById(panelId);
  if(!panel) return;
  panel.innerHTML = "";
  const search = document.getElementById(searchId);
  const query = (search?.value || "").trim().toLowerCase();
  const resolvedCategories = Array.isArray(categories) && categories.length ? categories : [category];
  resolvedCategories.forEach(currentCategory => {
    const groups = OPERATOR_CATALOG[currentCategory] || [];
    const matchedGroups = groups.map(groupInfo => ({
      ...groupInfo,
      matched:groupInfo.items.filter(type => {
        const meta = OPERATOR_META[type] || {};
        if(meta.hidden) return false;
        const haystack = `${type} ${meta.label || ""} ${meta.description || ""} ${groupInfo.group} ${currentCategory}`.toLowerCase();
        return !query || haystack.includes(query);
      }),
    })).filter(groupInfo => groupInfo.matched.length);
    if(!matchedGroups.length) return;
    if(showCategoryTitles){
      const count = matchedGroups.reduce((sum, item) => sum + item.matched.length, 0);
      const categoryTitle = document.createElement("div");
      categoryTitle.className = "op-category-title";
      categoryTitle.innerHTML = `<span>${escapeHtml(currentCategory)}</span><b>${count}</b>`;
      panel.appendChild(categoryTitle);
    }
    matchedGroups.forEach(groupInfo => {
      const matched = groupInfo.matched;
      const groupKey = `${currentCategory}:${groupInfo.group}`;
    const group = document.createElement("div");
    group.className = `op-group${collapsedGroups.has(groupKey) ? " closed" : ""}`;
    const title = document.createElement("div");
    title.className = "group-title";
    title.setAttribute("role", "button");
    title.setAttribute("tabindex", "0");
    title.setAttribute("aria-expanded", String(!collapsedGroups.has(groupKey)));
    title.innerHTML = `<span class="chev">▾</span>${escapeHtml(groupInfo.group)}<span style="color:#707b8d;font-weight:700">${matched.length}</span>`;
    const toggleGroup = () => {
      if(collapsedGroups.has(groupKey)) collapsedGroups.delete(groupKey);
      else collapsedGroups.add(groupKey);
      group.classList.toggle("closed", collapsedGroups.has(groupKey));
      title.setAttribute("aria-expanded", String(!collapsedGroups.has(groupKey)));
    };
    title.onclick = toggleGroup;
    title.onkeydown = event => {
      if(event.key === "Enter" || event.key === " "){
        event.preventDefault();
        toggleGroup();
      }
    };

    const ops = document.createElement("div");
    ops.className = "ops";
    matched.forEach(type => {
      const meta = OPERATOR_META[type];
      const op = document.createElement("div");
      op.className = `op ${currentCategory === "逻辑" ? "logic-op" : ""}`;
      op.draggable = true;
      op.dataset.type = type;
      op.innerHTML = `<div class="op-icon" style="background:${kindColor(meta.kind)}">${ICONS[meta.kind] || "□"}</div><div><div class="op-name">${escapeHtml(meta.label)}</div><div class="op-desc">${escapeHtml(meta.description || type)}</div></div><div class="op-type">${escapeHtml(type)}</div>`;
      op.ondragstart = event => event.dataTransfer.setData("operator/type", type);
      op.ondblclick = () => addNodeAtViewportCenter(type);
      ops.appendChild(op);
    });
      group.append(title, ops);
      panel.appendChild(group);
    });
  });
}

function kindColor(kind){
  return {
    io:"#6c7177", color:"#555987", enhance:"#536f92", filter:"#406c88",
    texture:"#765b93", frequency:"#5a668f", segment:"#80604a", morph:"#47705f",
    region:"#3e786a", geo:"#72547f", calibration:"#6d568a", match:"#446d96",
    feature:"#4f7782", measure:"#7a4c59", defect:"#924f54", quality:"#7e6841",
    ocr:"#82634a", code:"#4d7b70", ai:"#3f6e9f", custom:"#576b7a", logic:"#6b5c91",
  }[kind] || "#555a61";
}

function normalizeSidePanelMode(mode){
  return mode === "nodes" || mode === "structure" ? mode : null;
}
function setSidePanelMode(mode){
  activeSidePanel = normalizeSidePanelMode(mode);
  nodeLibraryVisible = Boolean(activeSidePanel);
  workflowExplorerVisible = activeSidePanel === "structure";
  const main = document.querySelector(".main");
  const library = document.getElementById("nodeLibrary");
  const nodeToggle = document.getElementById("nodeLibraryToggle");
  const explorerToggle = document.getElementById("workflowExplorerToggle");
  main.classList.toggle("nodes-panel-hidden", !activeSidePanel);
  library.classList.toggle("panel-mode-nodes", activeSidePanel === "nodes");
  library.classList.toggle("panel-mode-structure", activeSidePanel === "structure");
  library.setAttribute("aria-hidden", String(!activeSidePanel));
  nodeToggle.classList.toggle("active", activeSidePanel === "nodes");
  nodeToggle.setAttribute("aria-expanded", String(activeSidePanel === "nodes"));
  nodeToggle.title = activeSidePanel === "nodes" ? "隐藏节点库" : "显示节点库";
  if(explorerToggle){
    explorerToggle.classList.toggle("active", activeSidePanel === "structure");
    explorerToggle.setAttribute("aria-expanded", String(activeSidePanel === "structure"));
    explorerToggle.title = activeSidePanel === "structure" ? "隐藏工作流结构" : "显示工作流结构";
  }
  if(activeSidePanel === "structure" && typeof renderWorkflowExplorer === "function") renderWorkflowExplorer();
  window.requestAnimationFrame(updateMinimap);
  if(!suppressDocumentSync) persistActiveWorkflowView();
}
function setNodeLibraryVisible(visible){ setSidePanelMode(visible ? "nodes" : null); }
function toggleNodeLibrary(){ setSidePanelMode(activeSidePanel === "nodes" ? null : "nodes"); }

function collapseAllOperatorGroups(){
  ["图像", "测量", "识别"].forEach(category => {
    (OPERATOR_CATALOG[category] || []).forEach(groupInfo => collapsedOperatorGroups.add(`${category}:${groupInfo.group}`));
  });
  renderOperatorPanel();
  setStatus("已按类别折叠工业视觉算子库");
}
function expandAllOperatorGroups(){
  collapsedOperatorGroups.clear();
  renderOperatorPanel();
  setStatus("已展开工业视觉算子库中的全部类别");
}
function collapseAllLogicOperatorGroups(){
  (OPERATOR_CATALOG["逻辑"] || []).forEach(groupInfo => collapsedLogicOperatorGroups.add(`逻辑:${groupInfo.group}`));
  renderOperatorPanel();
  setStatus("已按类别折叠逻辑节点库");
}
function expandAllLogicOperatorGroups(){
  collapsedLogicOperatorGroups.clear();
  renderOperatorPanel();
  setStatus("已展开逻辑节点库中的全部类别");
}

function defaultParams(type){
  return JSON.parse(JSON.stringify((OPERATOR_META[type] && OPERATOR_META[type].params) || {}));
}

function normalizeNodeType(type, params = {}){
  if(type === "Gray") return { type:"ColorConvert", params:{ ...params, mode:"GRAY" } };
  if(type === "BGR2RGB") return { type:"ColorConvert", params:{ ...params, mode:"RGB" } };
  return { type, params };
}

function addNode(type, x, y, options = {}){
  const normalized = normalizeNodeType(type, defaultParams(type));
  if(!OPERATOR_META[normalized.type]){
    toast("不能添加节点", `${type} 尚未实现`);
    return;
  }
  const id = `n${nodeSeq++}`;
  const node = {
    id,
    type:normalized.type,
    position:{ x:Math.round(x), y:Math.round(y) },
    params:Object.keys(normalized.params).length ? normalized.params : defaultParams(normalized.type),
    collapsed:false,
    color:DEFAULT_NODE_COLOR,
  };
  nodes.push(node);
  selectedNodeId = id;
  selectedEdgeId = null;
  colorPaletteNodeId = null;

  if(options.centerOnPoint){
    // 先渲染一次取得节点真实边界，再按屏幕中心校正；避免动态参数、字体和预览区域
    // 造成首次估算高度与最终高度不一致。
    render();
    centerRenderedNodeOnWorldPoint(id, options.centerOnPoint);
  }

  render();
  commitActiveWorkflowChange();
  if(options.centerOnPoint) stabilizeNodeAtViewportCenter(id);
  setStatus(`已添加节点：${id} · ${OPERATOR_META[normalized.type].label}`);
}

function addNodeAtViewportCenter(type){
  const center = typeof getViewportCenterWorldPoint === "function"
    ? getViewportCenterWorldPoint()
    : { x:460 + nodes.length * 28, y:240 + nodes.length * 22 };
  addNode(type, center.x, center.y, { centerOnPoint:center });
}

