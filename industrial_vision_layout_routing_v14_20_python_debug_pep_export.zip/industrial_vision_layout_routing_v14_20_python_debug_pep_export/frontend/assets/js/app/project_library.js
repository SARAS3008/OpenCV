/**
 * v14.20 共享项目库。
 * 共享工作流始终以新副本打开，避免浏览者覆盖原作者项目。
 */
(() => {
  let activeTab = "mine";
  let searchTimer = null;
  let loading = false;

  function dialog(){ return document.getElementById("projectLibraryDialog"); }
  function content(){ return document.getElementById("projectLibraryContent"); }
  function searchInput(){ return document.getElementById("projectLibrarySearch"); }

  function formatDate(value){
    if(!value) return "时间未知";
    const date = new Date(value);
    return Number.isNaN(date.getTime()) ? String(value) : date.toLocaleString();
  }

  function setLoading(message = "正在加载项目库…"){
    const container = content();
    if(container) container.innerHTML = `<div class="project-library-empty">${escapeHtml(message)}</div>`;
  }

  function sharedCard(item){
    const ownerBadge = item.is_own_workspace ? `<span class="project-library-badge own">当前工作区</span>` : `<span class="project-library-badge">已共享</span>`;
    return `<article class="project-library-item">
      <div class="project-library-item-head">
        <div class="project-library-item-title">
          <strong title="${escapeHtml(item.name || "Vision Workflow")}">${escapeHtml(item.name || "Vision Workflow")}</strong>
          <small>${escapeHtml(item.author_name || item.author_id || "匿名用户")} · ${escapeHtml(formatDate(item.shared_at || item.updated_at))}</small>
        </div>
        ${ownerBadge}
      </div>
      <div class="project-library-description">${escapeHtml(item.description || "作者暂未填写项目说明。")}</div>
      <div class="project-library-stats">
        <span class="project-library-stat">节点 ${Number(item.node_count || 0)}</span>
        <span class="project-library-stat">连线 ${Number(item.edge_count || 0)}</span>
        <span class="project-library-stat">模块 ${Number(item.module_count || 0)}</span>
        <span class="project-library-stat">版本 ${escapeHtml(item.shared_version_id || "当前快照")}</span>
      </div>
      <div class="project-library-actions">
        ${item.is_own_workspace ? `<button class="danger" type="button" onclick="unshareProjectFromLibrary('${escapeHtml(item.project_id)}')">取消共享</button>` : ""}
        <button class="primary" type="button" onclick="openSharedProjectCopy('${escapeHtml(item.project_id)}','${escapeHtml(item.owner_scope)}')">打开完整工作流</button>
      </div>
    </article>`;
  }

  function ownCard(item){
    const shared = item.is_shared === true;
    return `<article class="project-library-item">
      <div class="project-library-item-head">
        <div class="project-library-item-title">
          <strong title="${escapeHtml(item.name || "Vision Workflow")}">${escapeHtml(item.name || "Vision Workflow")}</strong>
          <small>更新于 ${escapeHtml(formatDate(item.updated_at))}</small>
        </div>
        <span class="project-library-badge ${shared ? "" : "private"}">${shared ? "已共享" : "私有"}</span>
      </div>
      <div class="project-library-description">${escapeHtml(item.description || "尚未填写项目说明。分享前建议补充用途、输入数据和关键节点说明。")}</div>
      <div class="project-library-stats">
        <span class="project-library-stat">节点 ${Number(item.node_count || 0)}</span>
        <span class="project-library-stat">连线 ${Number(item.edge_count || 0)}</span>
        <span class="project-library-stat">最新 ${escapeHtml(item.latest_version_id || "未创建版本")}</span>
        ${shared ? `<span class="project-library-stat">共享 ${escapeHtml(item.shared_version_id || "快照")}</span>` : ""}
      </div>
      <div class="project-library-actions">
        <button type="button" onclick="openOwnProjectFromLibrary('${escapeHtml(item.project_id)}')">打开</button>
        ${shared
          ? `<button class="danger" type="button" onclick="unshareProjectFromLibrary('${escapeHtml(item.project_id)}')">取消共享</button>`
          : `<button class="warning" type="button" onclick="shareProjectFromLibrary('${escapeHtml(item.project_id)}')">共享到项目库</button>`}
        <button class="danger project-delete-button" type="button" onclick="deleteOwnProjectFromLibrary('${escapeHtml(item.project_id)}','${escapeHtml(item.name || "Vision Workflow")}')">删除项目</button>
      </div>
    </article>`;
  }

  async function refresh(){
    if(loading) return;
    loading = true;
    setLoading();
    try{
      const query = String(searchInput()?.value || "").trim();
      const data = activeTab === "shared" ? await VisionApi.listSharedProjects(query) : await VisionApi.listProjects();
      let projects = data.projects || [];
      if(activeTab === "mine" && query){
        const needle = query.toLowerCase();
        projects = projects.filter(item => `${item.name || ""} ${item.description || ""}`.toLowerCase().includes(needle));
      }
      const container = content();
      if(!projects.length){
        container.innerHTML = `<div class="project-library-empty">${activeTab === "shared" ? "暂无匹配的共享项目。" : "当前工作区暂无项目。可点击上方“保存当前项目”创建项目。"}</div>`;
      }else{
        container.innerHTML = projects.map(item => activeTab === "shared" ? sharedCard(item) : ownCard(item)).join("");
      }
    }catch(error){
      setLoading(`项目库加载失败：${error.message || error}`);
      toast("项目库加载失败", error.message || String(error));
    }finally{
      loading = false;
    }
  }

  window.showProjectLibrary = async function showProjectLibrary(){
    const element = dialog();
    if(!element) return;
    element.classList.add("open");
    element.setAttribute("aria-hidden", "false");
    document.body.classList.add("project-library-open");
    activeTab = "mine";
    document.getElementById("sharedProjectsTab")?.classList.remove("active");
    document.getElementById("myProjectsTab")?.classList.add("active");
    document.getElementById("saveCurrentProjectButton")?.classList.remove("hidden");
    const notice = document.getElementById("projectLibraryNotice");
    if(notice) notice.textContent = "当前工作区的项目统一在此保存、打开、共享和删除。删除会同时移除项目版本历史。";
    if(searchInput()) searchInput().value = "";
    await refresh();
  };

  window.closeProjectLibrary = function closeProjectLibrary(){
    const element = dialog();
    if(!element) return;
    element.classList.remove("open");
    element.setAttribute("aria-hidden", "true");
    document.body.classList.remove("project-library-open");
  };

  window.switchProjectLibraryTab = async function switchProjectLibraryTab(tab){
    activeTab = tab === "mine" ? "mine" : "shared";
    document.getElementById("sharedProjectsTab")?.classList.toggle("active", activeTab === "shared");
    document.getElementById("myProjectsTab")?.classList.toggle("active", activeTab === "mine");
    document.getElementById("saveCurrentProjectButton")?.classList.toggle("hidden", activeTab !== "mine");
    const notice = document.getElementById("projectLibraryNotice");
    if(notice){
      notice.textContent = activeTab === "shared"
        ? "共享项目只包含所有者明确发布的版本，不会显示对方的私有草稿。"
        : "当前工作区的项目统一在此保存、打开、共享和删除。删除会同时移除项目版本历史。";
    }
    await refresh();
  };

  window.refreshProjectLibrary = refresh;
  window.scheduleProjectLibrarySearch = function scheduleProjectLibrarySearch(){
    window.clearTimeout(searchTimer);
    searchTimer = window.setTimeout(refresh, 260);
  };

  window.saveCurrentProjectFromLibrary = async function saveCurrentProjectFromLibrary(){
    const documentInfo = getActiveWorkflowDocument();
    if(!documentInfo){
      toast("保存失败", "当前没有可保存的工作流");
      return;
    }
    const project = await saveWorkflowLocal();
    if(project) await refresh();
  };

  window.openSharedProjectCopy = async function openSharedProjectCopy(projectId, ownerScope){
    try{
      const data = await VisionApi.getSharedProject(projectId, ownerScope);
      const project = data.project || {};
      const documentInfo = VisionWorkspaceStore.makeDocument(project.workflow, {
        id:VisionWorkspaceStore.createWorkflowId(),
        name:`参考 · ${project.name || "共享工作流"}`,
        saved:false,
      });
      captureActiveWorkflowDocument(true);
      workflowDocuments.push(documentInfo);
      activeWorkflowId = documentInfo.id;
      restoreWorkflowDocument(documentInfo);
      renderWorkflowTabs();
      persistWorkspace();
      closeProjectLibrary();
      toast("共享项目已打开", `${project.author_name || "团队成员"} · 已作为可编辑副本打开`, true);
      setStatus(`已打开共享工作流副本：${project.name || "共享工作流"}`);
    }catch(error){
      toast("打开共享项目失败", error.message || String(error));
    }
  };

  window.openOwnProjectFromLibrary = async function openOwnProjectFromLibrary(projectId){
    try{
      const documentInfo = await VisionWorkspaceStore.openServerProject(projectId);
      captureActiveWorkflowDocument(true);
      const existingIndex = workflowDocuments.findIndex(item => item.projectId === documentInfo.projectId);
      if(existingIndex >= 0) workflowDocuments[existingIndex] = documentInfo;
      else workflowDocuments.push(documentInfo);
      activeWorkflowId = documentInfo.id;
      restoreWorkflowDocument(documentInfo);
      renderWorkflowTabs();
      persistWorkspace();
      closeProjectLibrary();
      toast("项目已打开", documentInfo.name, true);
    }catch(error){
      toast("打开项目失败", error.message || String(error));
    }
  };

  function removeDeletedProjectDocuments(projectId){
    const removed = workflowDocuments.filter(item => item.projectId === projectId);
    if(!removed.length) return;
    const activeWasRemoved = removed.some(item => item.id === activeWorkflowId);
    workflowDocuments = workflowDocuments.filter(item => item.projectId !== projectId);
    if(!workflowDocuments.length){
      const replacement = createWorkflowDocument(emptyWorkflow());
      workflowDocuments.push(replacement);
      activeWorkflowId = replacement.id;
      restoreWorkflowDocument(replacement);
    }else if(activeWasRemoved){
      activeWorkflowId = workflowDocuments[0].id;
      restoreWorkflowDocument(workflowDocuments[0]);
    }
    renderWorkflowTabs();
    persistWorkspace();
  }

  window.deleteOwnProjectFromLibrary = async function deleteOwnProjectFromLibrary(projectId, projectName){
    const opened = workflowDocuments.filter(item => item.projectId === projectId);
    const dirtyCount = opened.filter(item => item.dirty).length;
    const details = [
      `确定永久删除“${projectName || "该项目"}”吗？`,
      "项目本体、全部版本历史及共享快照都会被删除，且无法撤销。",
    ];
    if(opened.length){
      details.push(`该项目当前打开了 ${opened.length} 个标签页，删除后会同步关闭。`);
    }
    if(dirtyCount){
      details.push(`其中 ${dirtyCount} 个标签页含未保存修改，这些修改也会丢失。`);
    }
    if(!window.confirm(details.join("\n\n"))) return;
    try{
      await VisionApi.deleteProject(projectId);
      removeDeletedProjectDocuments(projectId);
      toast("项目已删除", projectName || "项目及版本历史已移除", true);
      setStatus(`已删除项目：${projectName || projectId}`);
      await refresh();
    }catch(error){
      toast("删除项目失败", error.message || String(error));
    }
  };

  window.shareProjectFromLibrary = async function shareProjectFromLibrary(projectId){
    const description = window.prompt("填写共享说明（建议说明用途、输入数据和关键节点；可留空）：", "");
    if(description === null) return;
    try{
      await VisionApi.shareProject(projectId, "", description);
      toast("项目已共享", "团队成员现在可以在项目库中打开该版本的完整工作流。", true);
      await refresh();
    }catch(error){
      toast("共享项目失败", error.message || String(error));
    }
  };

  window.unshareProjectFromLibrary = async function unshareProjectFromLibrary(projectId){
    if(!window.confirm("取消共享后，其他用户将无法再从项目库打开该工作流。继续吗？")) return;
    try{
      await VisionApi.unshareProject(projectId);
      toast("已取消共享", "项目仍保留在当前工作区。", true);
      await refresh();
    }catch(error){
      toast("取消共享失败", error.message || String(error));
    }
  };

  document.addEventListener("keydown", event => {
    if(event.key === "Escape" && dialog()?.classList.contains("open")) closeProjectLibrary();
  });
})();
