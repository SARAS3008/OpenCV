# Python 自定义算子开发界面

开发界面把工作流端口转换为普通 Python 函数参数，使图像处理工程师可以按照本地开发习惯编写代码。

## 典型流程

1. 在左侧“命名输入参数”中添加输入。
2. 为每个输入填写 Python 参数名，例如 `image`、`mask`、`threshold`。
3. 在画布上把上游节点连接到对应端口。
4. 点击“函数骨架”生成当前接口。
5. 编写代码并直接返回处理结果。
6. 点击“保存并运行到此节点”执行依赖链并查看结果。

## 三栏布局

### 左侧

- 命名输入参数管理；
- 当前 `process()` 接口；
- 端口连接来源；
- 运行时 API 说明。

### 中间

- Python 编辑器；
- 按当前输入生成的模板；
- 语法、安全限制和参数映射校验；
- 行号、自动缩进、注释和行列状态。

### 右侧

- `settings` JSON 参数；
- 超时、隔离执行、导出类型和颜色空间；
- 自动输出规则；
- 最近一次 `metrics`、`data` 和 `print()` 控制台输出。

## 快捷键

| 快捷键 | 作用 |
|---|---|
| `Tab` | 缩进当前行或选区 |
| `Shift + Tab` | 反缩进当前行或选区 |
| `Ctrl/⌘ + /` | 切换行注释 |
| `Ctrl/⌘ + S` | 保存代码 |
| `Ctrl/⌘ + Enter` | 保存并运行到当前节点 |

## 返回值

日常开发不需要手写接口包装：

```python
def process(image):
    return cv2.Canny(image, 50, 150)
```

复杂输出才使用保留字段：

```python
def process(image):
    result = cv2.Canny(image, 50, 150)
    return {
        "out": result,
        "metrics": {"pixels": int(np.count_nonzero(result))},
        "data": {"shape": list(result.shape)},
    }
```
