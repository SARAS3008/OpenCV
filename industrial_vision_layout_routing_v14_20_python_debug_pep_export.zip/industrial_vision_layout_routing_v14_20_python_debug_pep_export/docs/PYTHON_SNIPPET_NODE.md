# Python 自定义算子节点

`PythonSnippet` 用于在工作流中补充算子库尚未覆盖的图像处理逻辑。节点面向熟悉 VS Code 和 Python 的图像处理工程师设计：先配置输入参数名，再按普通 Python 函数方式开发，不需要记忆工作流内部端口字典和固定返回协议。

## 节点位置

- 逻辑节点库
- 脚本扩展
- Python自定义算子

## 推荐开发方式

假设节点配置了三个输入：

| 端口显示名 | 稳定端口 | Python 参数名 | 类型 |
|---|---|---|---|
| 原图 | `in` | `image` | image |
| 缺陷 Mask | `arg1` | `defect_mask` | image |
| 最小面积 | `arg2` | `min_area` | number |

代码中直接定义同名参数：

```python
def process(image, defect_mask=None, min_area=100):
    if defect_mask is None:
        return image

    mask = (defect_mask > 0).astype(np.uint8) * 255
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    valid = [item for item in contours if cv2.contourArea(item) >= min_area]

    result = image.copy()
    cv2.drawContours(result, valid, -1, (0, 0, 255), 2)
    return {
        "out": result,
        "metrics": {"defect_count": len(valid)},
        "data": {"areas": [float(cv2.contourArea(item)) for item in valid]},
    }
```

运行时会把每个端口值自动注入 `process()` 的同名参数。未连接的可选输入会使用代码函数默认值；也可以在输入配置中设置节点级默认值。

## 动态输入参数

开发界面左侧支持最多 20 个输入参数。每个输入包含：

- 稳定端口 handle：用于保存工作流连线，新增时自动生成 `arg1`、`arg2` 等；
- Python 参数名：例如 `image`、`mask`、`threshold`；
- 端口显示名；
- 数据类型：图像、数值、布尔、字符串、对象、列表或任意；
- 是否必填；
- 未连接时的 JSON 默认值。

修改 Python 参数名或显示名不会改变稳定端口 handle，因此不会破坏已有连线。删除已连接参数时，前端会提示并同步删除对应连线。

## 自动输出规则

多数代码只需要直接 `return`：

| Python 返回值 | 节点自动行为 |
|---|---|
| `numpy.ndarray` | 自动填充 `out` 和 `image` |
| 数值、布尔、字符串 | 自动填充 `out` 和 `value` |
| 普通业务字典 | 自动填充 `out`、`value`，并写入 `data.result` |
| 包含 `out/image/value/metrics/data` 的字典 | 按高级输出协议处理 |

简单图像处理可以直接写：

```python
def process(image):
    return cv2.GaussianBlur(image, (5, 5), 0)
```

简单业务对象也可以直接返回：

```python
def process(score):
    return {
        "score": score,
        "passed": score >= 0.8,
    }
```

只有需要图像、指标和结构化数据同时输出时，才需要使用保留字段：

```python
return {
    "out": result_image,
    "metrics": {"count": 3},
    "data": {"boxes": boxes},
}
```

## 运行时对象

除命名输入外，代码还可以使用：

- `args`：仅包含命名输入的字典；
- `inputs`：同时支持端口 handle 和参数名，兼容 `inputs['in']`；
- `ports`：只按稳定端口 handle 访问的原始输入；
- `settings`：开发界面中配置的代码参数 JSON；
- `params`：节点全部运行参数；
- `context`：最小化运行上下文，包含 `image_id`、`batch_index`、`batch_total`；
- `input_meta`：各输入是否已连接、是否使用默认值等元数据；
- `get_input(name, default)`：按名称安全取值；
- `emit(value, **outputs)`：可选的高级输出助手；
- `np`、`cv2`、`math`、`statistics`、`json`；
- 类型标注可使用 `Any`、`Mapping`、`Optional`、`Sequence`。

旧接口继续兼容：

```python
def process(inputs, params, context):
    image = inputs.get("in")
    return image
```

也继续支持顶层代码直接使用命名变量并给 `out`、`metrics`、`data` 赋值。

## 调试体验

开发界面提供：

- 输入参数增删、命名、类型、必填和默认值配置；
- 根据当前连线自动生成参数名；
- 按当前参数生成 `process()` 函数骨架；
- 自动缩进、选区缩进/反缩进、快捷行注释；
- 行号、行列状态；
- 语法、安全限制和 `process()` 参数映射校验；
- `settings` JSON 编辑；
- `print()` 输出捕获，显示在最近运行的 `data.console`；
- “保存并运行到此节点”，只执行依赖链并停在当前节点。

## 安全限制

节点默认在独立子进程中执行并带超时保护。仍禁止：

- `import` / `from import`；
- `open`、`eval`、`exec`、`compile`、`__import__`；
- 双下划线名称或属性；
- NumPy/OpenCV 文件读写、设备访问和模型加载接口；
- `class`、`with`、`try`、`global`、`nonlocal` 等复杂语法。

这不是完整安全沙箱。多人生产部署仍建议把代码执行迁移到禁网、只读文件系统、低权限和资源受限的独立容器 Worker。

## 独立脚本导出

命名输入、函数参数自动注入和普通返回值自动适配均已同步到独立算法脚本导出。`output_kind` 仍用于静态导出时声明最终 `out` 类型，图像流程建议设为 `IMAGE`。
