# 独立脚本导出支持清单

本版本的独立脚本导出覆盖全部内置节点，并通过注册表自动回归检查。新增内置节点后，如果没有同步加入导出器，测试会直接失败，避免再次出现“平台能运行、导出时报错”的情况。

## 已完整支持

### 输入、输出与批量

- 读取图像
- 批量读取图片
- 保存批量结果
- 结果显示
- 多个“读取图像”节点：通过 `--input 节点ID=图片路径` 传入
- 无图像流程：纯逻辑、纯参数几何测量可直接运行，不强制传入图片

### 颜色、增强、滤波、阈值、边缘和形态学

- 灰度、BGR 转 RGB、颜色转换、反色、归一化
- 直方图均衡、CLAHE
- 均值、高斯、中值、双边滤波、锐化
- 普通阈值、Otsu、自适应阈值
- Canny、Sobel、Laplacian
- 腐蚀、膨胀、开运算、闭运算、形态学梯度
- 缩放、翻转、90 度旋转

### 轮廓、Mask 与几何测量

- 查找轮廓
- 轮廓筛选：完整保留 `out / mask / roi / roi_mask / bbox / contour / contours / contour_infos`
- Mask 最小外接旋转矩形：完整保留矩形、角点、边、角度、中心、尺寸
- 旋转矩形取点/取边：支持参数输入、上游 `rect` 输入及可选背景图
- 应用 Mask：支持双图像输入，并完整输出抠图、Mask、ROI、ROI Mask 与外接框
- 边缘拟合直线：完整输出直线对象、端点、一般式参数和角度
- 点到直线距离：支持无图像参数模式、上游点/线输入及可选背景图
- ORB 特征匹配：支持 `template`、`mask` 连线输入，也支持 `template_path`、`mask_path`

### AI 与 YOLO

- YOLO Detect、Segment、Classify、Pose、OBB
- YOLO 目标筛选、动态 `mask1 / mask2 / ...`
- ROI 边缘距离
- 单图与批量模式
- 模型路径覆盖、设备覆盖、模型缓存

### 逻辑与脚本

- 常量、比较、布尔、非、条件分支
- For Loop、While Loop
- Python 自定义算子：动态命名输入、普通返回值、多输出、默认参数
- 提供 `script_compiler` 的自定义插件节点

## 多图像输入脚本

工作流中存在多个“读取图像”节点时，导出的函数签名为：

```python
def run_algorithm(input_image=None, image_inputs=None):
    ...
```

Python 调用：

```python
result = run_algorithm(
    image_inputs={
        "source": source_image,
        "mask_source": mask_image,
    }
)
```

命令行调用：

```bash
python vision_algorithm.py \
  --input source=D:/images/source.png \
  --input mask_source=D:/images/mask.png \
  --output D:/results/result.png
```

也可省略节点 ID，图片会按“读取图像”节点顺序绑定：

```bash
python vision_algorithm.py \
  --input D:/images/source.png \
  --input D:/images/mask.png
```

## YOLO 依赖

```bash
pip install "ultralytics>=8.3,<9.0" "opencv-python>=4.10,<5.0" "numpy>=2.0,<3.0"
```

单模型覆盖：

```bash
python vision_algorithm.py --input test.png --model D:/models/best.pt
```

多模型覆盖：

```bash
python vision_algorithm.py \
  --input test.png \
  --model detector_a=D:/models/a.pt \
  --model detector_b=D:/models/b.pt
```

## 自动防回归

测试会检查：

1. 中央注册表中的全部内置节点都出现在导出支持矩阵中；
2. 多输出节点声明的全部端口均有独立脚本映射；
3. 所有 `examples/*.json` 都能生成并编译；
4. 复杂测量节点、双图像节点、ORB 连线输入和无图像流程可以实际执行；
5. 新增节点未实现导出时，导出接口会一次性返回明确的节点名称，而不是在流程中途给出模糊错误。
