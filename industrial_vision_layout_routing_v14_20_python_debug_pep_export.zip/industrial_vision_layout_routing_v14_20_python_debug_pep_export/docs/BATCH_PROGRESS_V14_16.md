# v14.16 批量处理实时进度条

## 功能

批量整体运行开始后，右侧实时日志面板下方显示进度区域：

- 当前完成百分比；
- 已处理图片数 / 总图片数；
- 成功和失败数量；
- 当前正在处理或刚处理完成的图片；
- 完成、部分失败、异常中断和用户取消状态。

单图整体运行、单步运行和运行到节点不会显示批量进度区域。进度条固定在日志下方，日志滚动不会将其移出视图；折叠日志面板时进度条同步隐藏。

## 流式事件字段

以下批量事件现在统一包含进度字段：

```text
batch_started
batch_item_started
batch_item_completed
batch_item_failed
batch_completed
```

关键字段：

```json
{
  "total": 100,
  "processed": 37,
  "succeeded": 35,
  "failed": 2,
  "progress_percent": 37.0
}
```

前端直接消费 `/api/run-stream` 的 NDJSON 事件，不需要额外轮询接口。

## 主要文件

```text
backend/services/workflow_engine.py
frontend/index.html
frontend/assets/js/app/run_controller.js
frontend/assets/css/styles.css
tests/test_batch_workflow.py
tests/test_live_run_log.py
```
