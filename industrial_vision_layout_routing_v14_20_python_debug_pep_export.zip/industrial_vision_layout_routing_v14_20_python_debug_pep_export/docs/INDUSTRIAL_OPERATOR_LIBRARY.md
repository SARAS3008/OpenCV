# 工业视觉算子库

本版本在原有 OpenCV、YOLO、逻辑和 Python 自定义算子基础上，新增 **72 个工业视觉算子**。当前平台注册内置节点共 **122 个**。新增算子统一支持：

- 工作流画布拖拽与参数配置；
- 单图、批量和调试运行；
- 多输入、多输出端口；
- 独立 Python 脚本导出；
- 节点元数据、搜索和分类展示；
- 算子契约与导出回归测试。

> 说明：文档中的“HALCON 对应”表示实现了相近的工业视觉概念和使用方式，底层采用 OpenCV、NumPy 及可选开源引擎，不调用 HALCON，也不保证与 HALCON 专有算子的数值结果逐像素一致。

## 算子分类

### 图像 · 几何与标定（8）

| 节点 | 类型标识 | 典型用途 |
|---|---|---|
| 矩形 ROI 裁剪 | `CropROI` | 按像素坐标裁剪矩形区域，对应 crop_rectangle1。 |
| 任意角度旋转 | `RotateArbitrary` | 围绕图像中心旋转，可自动扩展画布。 |
| 仿射变换 | `AffineWarp` | 由三对对应点计算仿射变换，类似 affine_trans_image。 |
| 透视矫正 | `PerspectiveWarp` | 由四对对应点完成透视矫正，类似 projective_trans_image。 |
| 图像扩边 | `PadImage` | 在图像四周增加固定、复制、反射或循环边界。 |
| 极坐标变换 | `PolarTransform` | 将圆环、圆柱表面或旋转结构展开为直角坐标图。 |
| 相机畸变校正 | `CameraUndistort` | 根据相机内参和畸变系数校正径向/切向畸变。 |
| 棋盘格角点 | `ChessboardCorners` | 检测并亚像素优化棋盘格角点，可用于相机标定和透视校正。 |

### 图像 · 区域分割（7）

| 节点 | 类型标识 | 典型用途 |
|---|---|---|
| 动态阈值 | `DynamicThreshold` | 局部背景与原图比较，对应 HALCON dyn_threshold 的常用检测思路。 |
| 颜色范围分割 | `ColorRangeMask` | 在 HSV、Lab、YCrCb 或 BGR 空间内进行三通道范围分割。 |
| 灰度范围阈值 | `RangeThreshold` | 选择指定灰度区间，对应 HALCON threshold(Image, Region, MinGray, MaxGray)。 |
| KMeans 颜色分割 | `KMeansSegment` | 按像素颜色聚类生成分区图，适合颜色类别相对稳定的零件或缺陷。 |
| 分水岭分割 | `WatershedSegment` | 自动生成前景和背景标记，分离相互接触的目标。 |
| 区域生长 | `RegionGrow` | 从种子点按灰度容差扩展连通区域。 |
| GrabCut 前景分割 | `GrabCutSegment` | 通过矩形或初始 Mask 进行前景/背景迭代分割。 |

### 图像 · 工业增强（9）

| 节点 | 类型标识 | 典型用途 |
|---|---|---|
| Gamma 校正 | `GammaCorrection` | 幂律灰度变换，适合补偿相机和显示系统的非线性响应。 |
| 亮度与对比度 | `BrightnessContrast` | 线性变换 output = input × contrast + brightness。 |
| 百分位灰度拉伸 | `GrayRangeNormalize` | 按低/高百分位拉伸灰度，抑制少量极端亮暗像素。 |
| 对数增强 | `LogTransform` | 增强暗区域细节并压缩高亮动态范围。 |
| 白平衡 | `WhiteBalance` | 灰度世界或百分位拉伸白平衡，用于减弱光源色偏。 |
| 光照校正 | `IlluminationCorrection` | 估计大尺度背景并做除法或减法校正，对应工业视觉中的平场/背景校正思路。 |
| 平场校正 | `FlatFieldCorrection` | 使用平场图和可选暗场图校正镜头渐晕、光照不均和传感器响应差异。 |
| 非局部均值降噪 | `NonLocalMeansDenoise` | OpenCV 非局部均值去噪，适合纹理保留要求较高的场景。 |
| 反遮罩锐化 | `UnsharpMask` | 高斯模糊差分锐化，比固定卷积锐化更适合精细调参。 |

### 图像 · 形态学与区域（9）

| 节点 | 类型标识 | 典型用途 |
|---|---|---|
| 顶帽变换 | `MorphTopHat` | 提取比结构元素小的亮结构。 |
| 黑帽变换 | `MorphBlackHat` | 提取比结构元素小的暗结构。 |
| 区域填孔 | `FillHoles` | 填充前景区域内部孔洞，对应 HALCON fill_up。 |
| 骨架提取 | `Skeletonize` | 迭代细化二值区域，得到单像素骨架。 |
| 距离变换 | `DistanceTransform` | 计算前景像素到最近背景的欧氏距离。 |
| 连通区域分析 | `ConnectedComponents` | 连接二值区域并输出标签、外接框、面积和中心，对应 HALCON connection + area_center。 |
| 去除小区域 | `RemoveSmallRegions` | 按连通区域面积过滤噪声，类似 connection + select_shape(area)。 |
| 区域凸包 | `ConvexHullMask` | 计算各连通轮廓凸包并生成区域，类似 HALCON shape_trans(...,'convex')。 |
| 区域边界 | `RegionBoundary` | 从二值区域提取内边界。 |

### 图像 · 模板匹配与定位（5）

| 节点 | 类型标识 | 典型用途 |
|---|---|---|
| NCC 模板匹配 | `TemplateMatchNCC` | 归一化相关模板匹配，适合平移定位且尺度变化较小的场景。 |
| 多尺度模板匹配 | `MultiScaleTemplateMatch` | 在多个尺度上执行 NCC 模板匹配，适合存在一定尺寸变化的目标。 |
| 轮廓形状匹配 | `ShapeMatch` | 使用 Hu 矩比较轮廓形状，对旋转和尺度变化具有一定鲁棒性。 |
| 相位相关定位 | `PhaseCorrelation` | 通过频域相位相关估计两幅同尺寸图像的亚像素平移。 |
| AKAZE 特征匹配 | `AKAZEFeatureMatch` | 基于 AKAZE 局部特征和 RANSAC 单应性进行目标定位。 |

### 图像 · 特征与几何（4）

| 节点 | 类型标识 | 典型用途 |
|---|---|---|
| 霍夫线段检测 | `HoughLines` | 从边缘图中检测直线段，输出端点、长度和角度。 |
| 霍夫圆检测 | `HoughCircles` | 检测圆心和半径，适合孔、圆片和同心结构定位。 |
| Harris 角点 | `HarrisCorners` | 检测强角点，适合标记板、棋盘和结构转角。 |
| Shi-Tomasi 角点 | `ShiTomasiCorners` | Good Features to Track 角点检测。 |

### 图像 · 缺陷检测（4）

| 节点 | 类型标识 | 典型用途 |
|---|---|---|
| 参考图差分检测 | `ImageDifference` | 与参考图做绝对差分并按阈值提取变化区域。 |
| SSIM 结构差异 | `SSIMDifference` | 计算局部结构相似度并提取结构变化区域，对亮度变化比简单差分更稳健。 |
| 局部方差缺陷 | `LocalVarianceDefect` | 检测局部纹理/粗糙度异常，适合表面麻点、颗粒和纹理缺陷。 |
| 方向划痕检测 | `ScratchDetection` | 使用线形结构元素顶帽/黑帽增强指定方向的亮/暗划痕。 |

### 图像 · 质量评估（1）

| 节点 | 类型标识 | 典型用途 |
|---|---|---|
| 清晰度评估 | `FocusMeasure` | Laplacian 方差、Tenengrad 或 Brenner 清晰度指标，可用于失焦检测。 |

### 图像 · 频域与纹理（2）

| 节点 | 类型标识 | 典型用途 |
|---|---|---|
| Gabor 纹理滤波 | `GaborFilter` | 按指定方向和波长增强周期纹理、划痕或纤维结构。 |
| FFT 频域滤波 | `FFTFilter` | 低通、高通、带通和带阻频域滤波，可用于周期噪声、背景和纹理分离。 |

### 图像 · 颜色通道（2）

| 节点 | 类型标识 | 典型用途 |
|---|---|---|
| 提取颜色通道 | `ChannelExtract` | 提取 BGR、HSV、Lab 或灰度通道。 |
| 合并三通道 | `ChannelMerge` | 将三个单通道图合并为 BGR 或 RGB 图。 |

### 测量 · 亚像素与卡尺（1）

| 节点 | 类型标识 | 典型用途 |
|---|---|---|
| 卡尺边缘对测量 | `CaliperEdgePair` | 沿测量方向采样多个剖面，寻找两条边并输出像素距离。 |

### 测量 · 几何关系（3）

| 节点 | 类型标识 | 典型用途 |
|---|---|---|
| 点到点距离 | `PointPointDistance` | 计算两点像素距离，并支持单位/像素换算。 |
| 两直线交点 | `LineIntersection` | 计算两条无限直线交点并判断是否平行。 |
| 两直线夹角 | `AngleBetweenLines` | 计算两条直线的锐角夹角。 |

### 测量 · 区域与尺寸测量（1）

| 节点 | 类型标识 | 典型用途 |
|---|---|---|
| Blob 区域测量 | `BlobAnalysis` | 输出连通区域面积、周长、外接框、中心、圆度和实心度。 |

### 测量 · 坐标与标定（3）

| 节点 | 类型标识 | 典型用途 |
|---|---|---|
| 坐标单应变换 | `CoordinateTransform` | 使用 3×3 单应矩阵转换点坐标。 |
| 像素转世界坐标 | `PixelToWorld` | 通过单应矩阵和比例系数将像素点转换为世界坐标。 |
| 计算单应矩阵 | `ComputeHomography` | 由至少四对对应点计算 3×3 单应矩阵，并输出 RANSAC 内点。 |

### 测量 · 灰度与统计（3）

| 节点 | 类型标识 | 典型用途 |
|---|---|---|
| 图像统计 | `ImageStatistics` | 计算图像或 Mask 区域的均值、标准差、极值和百分位。 |
| 直方图分析 | `HistogramAnalysis` | 输出灰度直方图、归一化分布、峰值和均值。 |
| 灰度剖面 | `IntensityProfile` | 沿指定线段进行亚像素采样，输出一维灰度曲线。 |

### 测量 · 轮廓拟合（2）

| 节点 | 类型标识 | 典型用途 |
|---|---|---|
| 轮廓拟合圆 | `FitCircle` | 最小二乘拟合轮廓圆，输出中心、半径和残差。 |
| 轮廓拟合椭圆 | `FitEllipse` | 拟合轮廓椭圆，输出中心、长短轴和角度。 |

### 识别 · OCR与字符（4）

| 节点 | 类型标识 | 典型用途 |
|---|---|---|
| OCR 图像预处理 | `OCRPreprocess` | 放大、降噪、二值化和反相，生成适合 OCR 的字符图。 |
| OCR 文字识别 | `OCRRecognize` | 使用 Tesseract 或 EasyOCR 识别字符，输出文本、字符框和置信度。 |
| MSER 文本区域 | `TextRegionMSER` | 使用 MSER 提取稳定字符候选区域，为 OCR 前定位和裁剪提供候选框。 |
| 字符切分 | `CharacterSegment` | 按连通域分割字符并按阅读方向排序，输出字符框和字符小图列表。 |

### 识别 · 条码与二维码（3）

| 节点 | 类型标识 | 典型用途 |
|---|---|---|
| 二维码识别 | `QRCodeDecode` | 使用 OpenCV 检测并解码一个或多个 QR Code。 |
| 一维条码识别 | `BarcodeDecode` | 优先使用 OpenCV BarcodeDetector，必要时回退 pyzbar。 |
| DataMatrix 识别 | `DataMatrixDecode` | 使用 pylibdmtx 解码工业现场常见的 DataMatrix 二维码。 |

### 识别 · 标记与定位（1）

| 节点 | 类型标识 | 典型用途 |
|---|---|---|
| ArUco 标记检测 | `ArucoMarkerDetect` | 检测 ArUco 标记 ID、四角点和中心，适合治具定位、标定和机器人引导。 |

## 常见 HALCON 概念映射

| HALCON 常见概念/算子族 | 平台可组合节点 |
|---|---|
| `scale_image`、`emphasize`、`illuminate` | 亮度与对比度、反遮罩锐化、光照校正、Gamma 校正 |
| `dyn_threshold`、`threshold` | 动态阈值、灰度范围阈值、现有阈值节点 |
| `connection`、`select_shape` | 连通区域分析、去除小区域、Blob 区域测量、现有轮廓筛选 |
| `fill_up`、`skeleton`、`shape_trans` | 区域填孔、骨架提取、区域凸包 |
| `reduce_domain`、`crop_domain` | 应用 Mask、矩形 ROI 裁剪 |
| `affine_trans_image`、`projective_trans_image` | 仿射变换、透视矫正、计算单应矩阵 |
| `polar_trans_image_ext` | 极坐标变换 |
| `find_shape_model`、`find_ncc_model` | 轮廓形状匹配、NCC 模板匹配、多尺度模板匹配 |
| `edges_sub_pix`、`measure_pairs` | 现有边缘拟合直线、卡尺边缘对测量 |
| `fit_circle_contour_xld`、`fit_ellipse_contour_xld` | 轮廓拟合圆、轮廓拟合椭圆 |
| `area_center`、`intensity`、`gray_histo` | Blob 区域测量、图像统计、直方图分析 |
| `camera_calibration` 基础步骤 | 棋盘格角点、相机畸变校正、计算单应矩阵、像素转世界坐标 |
| OCR / 条码 | OCR 预处理、Tesseract/EasyOCR、QR、一维条码、DataMatrix、字符切分 |

## OCR 与码识别安装

基础平台不强制安装重量级 OCR 引擎。按项目需要安装：

```bash
pip install -r requirements-ocr.txt
```

还需根据操作系统安装对应原生组件：

- Tesseract OCR 和语言包；
- `zbar`（pyzbar）；
- `libdmtx`（DataMatrix）；
- ArUco 或 OpenCV BarcodeDetector 缺失时，使用与当前版本一致的 `opencv-contrib-python`。

EasyOCR Reader 会按语言和 GPU 配置缓存，批量运行时不会逐张重新初始化。

## 高速工业检测的搭建原则

1. **尽早缩小数据域**：先做 ROI 裁剪、颜色通道提取或 Mask，再运行复杂匹配、OCR 和 AI。
2. **固定参数优先**：生产环境固定模板、阈值、标定矩阵和模型路径，减少运行时解析。
3. **传统视觉先筛选**：用光照校正、动态阈值、Blob 和模板定位过滤明显不合格样本，再进入 OCR/YOLO。
4. **避免重复初始化**：模型、EasyOCR Reader 和模板应复用缓存；批量工作流天然复用当前进程资源。
5. **独立脚本部署**：工作流验证完成后导出独立脚本，接入相机 SDK、PLC、机器人或专用 Worker。
6. **按真实节拍基准测试**：在目标相机分辨率、CPU/GPU、照明和并发条件下测量 P50/P95 延迟。

## 当前边界

- 不能用一个通用节点库覆盖所有行业、镜头、光源和工艺；极特殊算法仍建议使用“Python 自定义算子”或自定义插件。
- 当前亚像素测量、标定和模板匹配以 OpenCV 实现为主，极限精度需结合标定板、远心镜头、稳定照明和专用算法验证。
- OCR 准确率取决于字体、字符高度、运动模糊、反光、训练语言包和字符集约束；生产上线前应使用真实样本评估。
- 高速并不只取决于节点数量。相机曝光、图像传输、模型推理、结果通信和日志写入都应纳入节拍评估。

## 示例工作流

- `examples/industrial_surface_defect_inspection.json`：光照校正 → 动态阈值 → 区域过滤 → Blob 测量。
- `examples/industrial_ocr_workflow.json`：ROI 裁剪 → OCR 预处理 → OCR 识别。
