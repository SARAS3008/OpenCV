# Python 自定义算子断点调试与结构化脚本导出

## 1. Python 语法能力

Python 自定义算子支持常用复杂语法，包括：

- `lambda` 表达式；
- 列表、字典、集合推导式；
- 生成器表达式；
- `try / except / else / finally`；
- `with` 上下文管理器；
- 嵌套函数和闭包；
- `match / case`、`assert`、`raise` 等普通控制语句。

示例：

```python
def process(values=None):
    values = list(values or [])
    normalize = lambda item: float(item) if item is not None else 0.0

    try:
        with np.errstate(divide="ignore", invalid="ignore"):
            normalized = [normalize(item) for item in values]
            total = sum(item for item in normalized if np.isfinite(item))
    except (TypeError, ValueError) as error:
        return {
            "out": 0.0,
            "metrics": {"error": str(error)},
        }

    return {
        "out": total,
        "metrics": {
            "count": len(normalized),
            "total": total,
        },
        "data": {"normalized": normalized},
    }
```

为保证多人平台安全，仍然禁止任意 `import`、文件和设备访问、动态 `eval/exec`、类定义以及危险反射 API。可直接使用 `np`、`cv2`、`math`、`statistics` 和 `json`。

## 2. 行级断点调试

在 Python 开发界面的行号区域单击即可设置或取消断点，也可以使用：

| 快捷键 | 功能 |
|---|---|
| `F9` | 切换当前行断点 |
| `F5` | 启动调试或继续运行 |
| `F10` | 单步跳过 |
| `F11` | 单步进入 |
| `Shift + F11` | 跳出当前函数 |

调试开始时，平台会先执行当前 Python 节点所依赖的上游节点，再把实际输入注入隔离调试进程。暂停时右侧面板显示：

- 当前行和暂停原因；
- Python 自定义算子内部调用栈；
- 局部变量；
- NumPy 数组的形状、类型、大小和统计摘要；
- `print()` 控制台输出。

断点与节点参数一起保存。断点调试不会调用用户代码中的 `breakpoint()`，后者仍被禁用。

## 3. 结构化独立脚本

导出的 `.py` 文件按 PEP 8 和 PEP 257 的可读性原则分区组织：

```text
模块说明与依赖
  ↓
PipelineMetadata / PIPELINE_METADATA
  ↓
run_algorithm(...)
  ↓
VisionPipeline 可复用类接口
  ↓
图像读取、结果保存、批量和 CSV 辅助函数
  ↓
main() 命令行入口
```

原有公共函数保持兼容：

```python
result = run_algorithm(image)
```

也可以使用面向对象接口：

```python
pipeline = VisionPipeline()
result = pipeline.run(image)
print(pipeline.metadata.as_dict())
```

批量脚本额外提供：

```python
summary = pipeline.run_directory(
    input_dir="inputs",
    output_dir="outputs",
)
```

命令行入口返回整数退出码，并采用：

```python
if __name__ == "__main__":
    raise SystemExit(main())
```

生成器继续输出单文件，便于部署和拷贝，但内部已经按公共 API、运行时、I/O 和 CLI 职责分区。复杂节点、YOLO、OCR 和传统视觉运行时仍会嵌入脚本，因此不依赖平台 `backend` 包。
