# ComfyCV Python Web v1

这是一个 **Web 界面 + 只写 Python 代码** 的 ComfyUI 风格图像处理工作流工具。

它不使用 React / Vite / npm，也不需要你写 JavaScript。界面由 NiceGUI 提供，底层仍然是浏览器访问，所以启动后局域网内其他人也可以打开使用。

## 运行

```bash
cd comfycv-python-web-v1
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python run_web.py --host 0.0.0.0 --port 8080
```

本机访问：

```text
http://127.0.0.1:8080
```

局域网其他人访问：

```text
http://你的电脑局域网IP:8080
```

例如：

```text
http://192.168.1.23:8080
```

Windows 防火墙如果弹出提示，需要允许 Python 访问局域网。

## 功能

- Web 页面访问
- 代码侧只需要 Python
- 上传图片
- 新建工作流
- 加载示例工作流
- 添加 OpenCV 算子节点
- 用连接面板连接节点输出和输入
- 运行 workflow
- 点击每个节点查看该节点输出预览
- 中英文切换
- 算子库按类别折叠
- 预留 YOLODetect 节点

## 使用方式

1. 启动 `python run_web.py --host 0.0.0.0 --port 8080`
2. 打开浏览器访问页面
3. 上传图片
4. 添加节点，比如 `ImageInput`, `CvtColor`, `GaussianBlur`, `Canny`, `Preview`
5. 在“连接节点”面板里选择：
   - 源节点
   - 输出端口
   - 目标节点
   - 输入端口
6. 点击“添加/替换连线”
7. 点击“运行工作流”
8. 点击任意节点查看该节点处理结果

## 推荐测试链路

```text
ImageInput.image
  → CvtColor.image
  → GaussianBlur.image
  → Canny.image
  → Preview.image
```

注意：Canny 的输出端口是 `edges`，所以连接 Canny 到 Preview 时应选择：

```text
Canny.edges → Preview.image
```

## 扩展 OpenCV 算子

新增节点主要改：

```text
app/nodes/
app/nodes/registry.py
```

新增节点示例：

```python
import cv2

from app.core.models import ParamSpec, PortSpec
from app.nodes.base import CvNode, RunContext, ensure_odd

class BoxBlur(CvNode):
    type = "BoxBlur"
    title = "Box Blur"
    category = "Filter"
    description = "Simple box blur."
    inputs = [PortSpec(name="image", type="Image", label="Image")]
    outputs = [PortSpec(name="image", type="Image", label="Image")]
    params = {
        "ksize": ParamSpec(type="int", default=3, min=1, max=99, step=2, label="Kernel size")
    }

    def run(self, ctx: RunContext, image, ksize=3, **_):
        k = ensure_odd(int(ksize))
        return {"image": cv2.blur(image, (k, k))}
```

然后在 `app/nodes/registry.py` 注册。

## 关于“Web 前端但不用 JS”

严格来说，任何浏览器页面底层都会运行 HTML/CSS/JavaScript。但这个版本的特点是：

- 你不需要写 JS
- 项目里没有 React/Vite/npm
- 业务逻辑、算子、UI 都用 Python 写
- 启动后别人可以通过浏览器访问

如果以后需要更像 ComfyUI 那种拖拽式自由连线画布，可以继续基于 Python Web 做两种路线：

1. 保持纯 Python 业务，少量封装前端交互组件。
2. 使用 Python 后端 + 专业前端画布。体验最好，但会重新引入前端技术栈。
