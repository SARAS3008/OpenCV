from __future__ import annotations

import time
from collections import defaultdict, deque
from typing import Any

from app.core.models import NodeRunResult, OutputPreview, WorkflowEdge, WorkflowNode, WorkflowRunResult
from app.core.preview import image_to_data_url, is_image_like, summarize_value
from app.nodes.base import RunContext
from app.nodes.registry import registry


class WorkflowExecutor:
    def __init__(self) -> None:
        self.ctx = RunContext()

    def run(self, nodes: list[WorkflowNode], edges: list[WorkflowEdge], preview_max_size: int = 1200) -> WorkflowRunResult:
        node_map = {n.id: n for n in nodes}
        results: dict[str, NodeRunResult] = {}
        outputs_by_node: dict[str, dict[str, Any]] = {}

        try:
            order = self._topological_order(nodes, edges)
        except Exception as exc:
            return WorkflowRunResult(ok=False, order=[], node_results={}, error=str(exc))

        incoming: dict[str, dict[str, tuple[str, str]]] = defaultdict(dict)
        for edge in edges:
            incoming[edge.to_node][edge.to_input] = (edge.from_node, edge.from_output)

        for node_id in order:
            node = node_map[node_id]
            node_cls = registry.get(node.type)
            definition = node_cls.definition()
            kwargs: dict[str, Any] = {}

            # Params first, then connected inputs. Connected input names can intentionally
            # override params with the same name, though node definitions should avoid this.
            kwargs.update(node.params or {})
            try:
                for port in definition.inputs:
                    if port.name not in incoming[node_id]:
                        raise ValueError(f"Node {node_id} ({node.type}) missing required input: {port.name}")
                    source_node, source_output = incoming[node_id][port.name]
                    if source_node not in outputs_by_node:
                        raise ValueError(f"Source node {source_node} has no outputs yet")
                    if source_output not in outputs_by_node[source_node]:
                        raise ValueError(f"Source output {source_node}.{source_output} does not exist")
                    kwargs[port.name] = outputs_by_node[source_node][source_output]

                start = time.perf_counter()
                outputs = node_cls().run(self.ctx, **kwargs)
                elapsed_ms = (time.perf_counter() - start) * 1000.0
                outputs_by_node[node_id] = outputs
                results[node_id] = NodeRunResult(
                    node_id=node_id,
                    node_type=node.type,
                    ok=True,
                    elapsed_ms=elapsed_ms,
                    outputs=outputs,
                    previews=self._serialize_outputs(outputs, preview_max_size=preview_max_size),
                )
            except Exception as exc:
                results[node_id] = NodeRunResult(
                    node_id=node_id,
                    node_type=node.type,
                    ok=False,
                    elapsed_ms=0.0,
                    outputs={},
                    previews=[],
                    error=str(exc),
                )
                return WorkflowRunResult(ok=False, order=order, node_results=results, error=f"{node_id}: {exc}")

        return WorkflowRunResult(ok=True, order=order, node_results=results)

    def _serialize_outputs(self, outputs: dict[str, Any], preview_max_size: int) -> list[OutputPreview]:
        previews: list[OutputPreview] = []
        for name, value in outputs.items():
            value_type, summary = summarize_value(value)
            preview_url = None
            if is_image_like(value):
                preview_url = image_to_data_url(value, max_size=preview_max_size)
            previews.append(OutputPreview(output_name=name, type=value_type, summary=summary, preview_data_url=preview_url))
        return previews

    def _topological_order(self, nodes: list[WorkflowNode], edges: list[WorkflowEdge]) -> list[str]:
        node_ids = {n.id for n in nodes}
        for edge in edges:
            if edge.from_node not in node_ids:
                raise ValueError(f"Edge source node does not exist: {edge.from_node}")
            if edge.to_node not in node_ids:
                raise ValueError(f"Edge target node does not exist: {edge.to_node}")

        indegree = {node_id: 0 for node_id in node_ids}
        graph: dict[str, list[str]] = defaultdict(list)
        for edge in edges:
            graph[edge.from_node].append(edge.to_node)
            indegree[edge.to_node] += 1

        queue = deque([n.id for n in nodes if indegree[n.id] == 0])
        order: list[str] = []
        while queue:
            node_id = queue.popleft()
            order.append(node_id)
            for nxt in graph[node_id]:
                indegree[nxt] -= 1
                if indegree[nxt] == 0:
                    queue.append(nxt)

        if len(order) != len(nodes):
            raise ValueError("Workflow contains a cycle. Please remove circular connections.")
        return order
