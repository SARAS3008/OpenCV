from __future__ import annotations

import base64
from io import BytesIO
from typing import Any

import cv2
import numpy as np


def is_image_like(value: Any) -> bool:
    return isinstance(value, np.ndarray) and value.ndim in (2, 3)


def normalize_for_preview(image: np.ndarray) -> np.ndarray:
    """Convert OpenCV/NumPy image to an RGB/gray uint8 image for Qt/browser previews."""
    arr = image
    if arr.dtype != np.uint8:
        finite = np.nan_to_num(arr.astype(np.float32), nan=0.0, posinf=0.0, neginf=0.0)
        min_v = float(finite.min()) if finite.size else 0.0
        max_v = float(finite.max()) if finite.size else 1.0
        if max_v > min_v:
            finite = (finite - min_v) / (max_v - min_v) * 255.0
        arr = np.clip(finite, 0, 255).astype(np.uint8)

    if arr.ndim == 2:
        return arr
    if arr.ndim == 3 and arr.shape[2] == 1:
        return arr[:, :, 0]
    if arr.ndim == 3 and arr.shape[2] == 3:
        # Most internal images are OpenCV BGR. Convert to RGB for preview.
        return cv2.cvtColor(arr, cv2.COLOR_BGR2RGB)
    if arr.ndim == 3 and arr.shape[2] == 4:
        return cv2.cvtColor(arr, cv2.COLOR_BGRA2RGBA)
    return arr


def downscale(image: np.ndarray, max_size: int = 1200) -> np.ndarray:
    h, w = image.shape[:2]
    longest = max(h, w)
    if longest <= max_size:
        return image
    scale = max_size / float(longest)
    return cv2.resize(image, (int(w * scale), int(h * scale)), interpolation=cv2.INTER_AREA)


def image_to_png_bytes(image: np.ndarray, max_size: int = 1200) -> bytes:
    preview = normalize_for_preview(downscale(image, max_size=max_size))
    if preview.ndim == 3 and preview.shape[2] == 3:
        # cv2.imencode expects BGR; preview is RGB.
        enc_input = cv2.cvtColor(preview, cv2.COLOR_RGB2BGR)
    elif preview.ndim == 3 and preview.shape[2] == 4:
        enc_input = cv2.cvtColor(preview, cv2.COLOR_RGBA2BGRA)
    else:
        enc_input = preview
    ok, buf = cv2.imencode(".png", enc_input)
    if not ok:
        raise RuntimeError("Failed to encode preview image")
    return bytes(buf)


def image_to_data_url(image: np.ndarray, max_size: int = 1200) -> str:
    raw = image_to_png_bytes(image, max_size=max_size)
    b64 = base64.b64encode(raw).decode("ascii")
    return f"data:image/png;base64,{b64}"


def summarize_value(value: Any) -> tuple[str, str]:
    if is_image_like(value):
        arr = value
        dtype = str(arr.dtype)
        shape = "×".join(str(x) for x in arr.shape)
        return "Image", f"shape={shape}, dtype={dtype}"
    if isinstance(value, np.ndarray):
        return "Array", f"shape={value.shape}, dtype={value.dtype}"
    if isinstance(value, (list, tuple)):
        return "List", f"length={len(value)}"
    if isinstance(value, dict):
        return "Object", f"keys={list(value.keys())[:8]}"
    return type(value).__name__, repr(value)[:240]
