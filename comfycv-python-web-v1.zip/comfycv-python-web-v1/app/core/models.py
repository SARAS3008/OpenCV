from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal


ParamType = Literal["int", "float", "bool", "select", "text"]


@dataclass
class PortSpec:
    name: str
    type: str = "Any"
    label: str | None = None


@dataclass
class ParamSpec:
    type: ParamType
    default: Any = None
    label: str | None = None
    min: float | None = None
    max: float | None = None
    step: float | None = None
    options: list[Any] | None = None
    help: str | None = None


@dataclass
class NodeDefinition:
    type: str
    title: str
    category: str
    description: str = ""
    inputs: list[PortSpec] = field(default_factory=list)
    outputs: list[PortSpec] = field(default_factory=list)
    params: dict[str, ParamSpec] = field(default_factory=dict)


@dataclass
class WorkflowNode:
    id: str
    type: str
    params: dict[str, Any] = field(default_factory=dict)


@dataclass
class WorkflowEdge:
    from_node: str
    from_output: str
    to_node: str
    to_input: str


@dataclass
class OutputPreview:
    output_name: str
    type: str
    summary: str
    preview_data_url: str | None = None


@dataclass
class NodeRunResult:
    node_id: str
    node_type: str
    ok: bool
    elapsed_ms: float
    outputs: dict[str, Any] = field(default_factory=dict)
    previews: list[OutputPreview] = field(default_factory=list)
    error: str | None = None


@dataclass
class WorkflowRunResult:
    ok: bool
    order: list[str]
    node_results: dict[str, NodeRunResult]
    error: str | None = None
