from __future__ import annotations

import argparse
import shutil
import uuid
from collections import defaultdict
from pathlib import Path
from typing import Any

from nicegui import events, ui

from app.core.executor import WorkflowExecutor
from app.core.models import WorkflowEdge, WorkflowNode
from app.nodes.registry import registry

ROOT = Path(__file__).resolve().parents[2]
UPLOAD_DIR = ROOT / "runtime_assets" / "uploads"
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

Locale = str

TEXT = {
    "zh": {
        "title": "ComfyCV Python Web",
        "new": "新建空白",
        "demo": "加载示例",
        "run": "运行工作流",
        "upload": "上传图片",
        "library": "算子库",
        "workflow": "工作流",
        "connect": "连接节点",
        "params": "参数",
        "preview": "预览",
        "edges": "连线",
        "delete": "删除",
        "selected": "当前选中",
        "add": "添加",
        "source": "源节点",
        "output": "输出端口",
        "target": "目标节点",
        "input": "输入端口",
        "add_edge": "添加/替换连线",
        "no_node": "请选择节点",
        "no_preview": "暂无预览，运行工作流后点击节点查看每个节点结果。",
        "ok": "工作流执行完成",
        "failed": "工作流执行失败",
        "uploaded": "图片已上传",
        "help": "这是纯 Python Web UI。用下方连接面板选择源节点输出和目标节点输入来连线；运行后点击任意节点查看该节点输出预览。",
        "language": "English",
    },
    "en": {
        "title": "ComfyCV Python Web",
        "new": "New",
        "demo": "Demo",
        "run": "Run Workflow",
        "upload": "Upload Image",
        "library": "Operator Library",
        "workflow": "Workflow",
        "connect": "Connect Nodes",
        "params": "Parameters",
        "preview": "Preview",
        "edges": "Edges",
        "delete": "Delete",
        "selected": "Selected",
        "add": "Add",
        "source": "Source node",
        "output": "Output port",
        "target": "Target node",
        "input": "Input port",
        "add_edge": "Add / replace edge",
        "no_node": "Select a node",
        "no_preview": "No preview yet. Run the workflow and click a node to inspect its outputs.",
        "ok": "Workflow finished",
        "failed": "Workflow failed",
        "uploaded": "Image uploaded",
        "help": "This is a Python-only web UI. Use the connection panel to choose a source output and target input. After running, click any node to preview that node's result.",
        "language": "中文",
    },
}

CATEGORY_ZH = {
    "IO": "输入输出",
    "Basic": "基础处理",
    "Filter": "滤波",
    "Edge": "边缘检测",
    "Threshold": "阈值分割",
    "Morphology": "形态学",
    "Contours": "轮廓分析",
    "AI / YOLO": "AI / YOLO",
}

NODE_ZH = {
    "ImageInput": "图像输入",
    "Preview": "预览",
    "CvtColor": "颜色转换",
    "Resize": "缩放",
    "GaussianBlur": "高斯模糊",
    "MedianBlur": "中值滤波",
    "Canny": "Canny 边缘",
    "Threshold": "阈值分割",
    "AdaptiveThreshold": "自适应阈值",
    "Erode": "腐蚀",
    "Dilate": "膨胀",
    "MorphologyEx": "形态学操作",
    "FindContours": "查找轮廓",
    "FilterContours": "过滤轮廓",
    "DrawContours": "绘制轮廓",
    "YOLODetect": "YOLO 检测",
}

PARAM_ZH = {
    "path": "图像路径",
    "code": "转换方式",
    "ksize": "核大小",
    "sigmaX": "Sigma X",
    "threshold1": "阈值 1",
    "threshold2": "阈值 2",
    "apertureSize": "孔径大小",
    "L2gradient": "L2 梯度",
    "thresh": "阈值",
    "maxval": "最大值",
    "maxValue": "最大值",
    "type": "类型",
    "method": "方法",
    "thresholdType": "阈值类型",
    "blockSize": "块大小",
    "C": "C 常量",
    "scale": "缩放比例",
    "interpolation": "插值方式",
    "shape": "结构元素形状",
    "iterations": "迭代次数",
    "op": "操作",
    "mode": "检索模式",
    "min_area": "最小面积",
    "max_area": "最大面积",
    "thickness": "线宽",
    "draw_rect": "绘制外接矩形",
    "model_path": "模型路径",
    "conf": "置信度",
    "iou": "IoU",
    "imgsz": "输入尺寸",
}


def tr(locale: Locale, key: str) -> str:
    return TEXT.get(locale, TEXT["zh"]).get(key, key)


def category_label(locale: Locale, category: str) -> str:
    return CATEGORY_ZH.get(category, category) if locale == "zh" else category


def node_label(locale: Locale, node_type: str, fallback: str) -> str:
    return NODE_ZH.get(node_type, fallback) if locale == "zh" else fallback


def param_label(locale: Locale, name: str, fallback: str | None = None) -> str:
    return PARAM_ZH.get(name, fallback or name) if locale == "zh" else (fallback or name)


def default_params(node_type: str) -> dict[str, Any]:
    definition = registry.get(node_type).definition()
    return {name: spec.default for name, spec in definition.params.items()}


class WebAppState:
    def __init__(self) -> None:
        self.locale: Locale = "zh"
        self.executor = WorkflowExecutor()
        self.nodes: list[WorkflowNode] = []
        self.edges: list[WorkflowEdge] = []
        self.selected_node_id: str | None = None
        self.result = None
        self.counter = 1
        self.current_image_path: str | None = None

    def add_node(self, node_type: str, *, x_index: int | None = None) -> WorkflowNode:
        node = WorkflowNode(id=f"{node_type}_{self.counter}", type=node_type, params=default_params(node_type))
        self.counter += 1
        if node_type == "ImageInput" and self.current_image_path:
            node.params["path"] = self.current_image_path
        self.nodes.append(node)
        self.selected_node_id = node.id
        return node

    def delete_node(self, node_id: str) -> None:
        self.nodes = [n for n in self.nodes if n.id != node_id]
        self.edges = [e for e in self.edges if e.from_node != node_id and e.to_node != node_id]
        if self.selected_node_id == node_id:
            self.selected_node_id = self.nodes[0].id if self.nodes else None

    def add_or_replace_edge(self, edge: WorkflowEdge) -> None:
        self.edges = [e for e in self.edges if not (e.to_node == edge.to_node and e.to_input == edge.to_input)]
        self.edges.append(edge)

    def selected_node(self) -> WorkflowNode | None:
        if not self.selected_node_id:
            return None
        return next((n for n in self.nodes if n.id == self.selected_node_id), None)

    def definition(self, node_type: str):
        return registry.get(node_type).definition()


state = WebAppState()

# Refreshable UI sections. They are assigned in build_ui().
render_library = None
render_graph = None
render_edges = None
render_connection_panel = None
render_params = None
render_preview = None


def refresh_all() -> None:
    for section in [render_library, render_graph, render_edges, render_connection_panel, render_params, render_preview]:
        if section:
            section.refresh()


def node_options() -> dict[str, str]:
    return {n.id: f"{n.id} · {node_label(state.locale, n.type, state.definition(n.type).title)}" for n in state.nodes}


def output_options(node_id: str | None) -> list[str]:
    node = next((n for n in state.nodes if n.id == node_id), None)
    if not node:
        return []
    return [p.name for p in state.definition(node.type).outputs]


def input_options(node_id: str | None) -> list[str]:
    node = next((n for n in state.nodes if n.id == node_id), None)
    if not node:
        return []
    return [p.name for p in state.definition(node.type).inputs]


def create_demo() -> None:
    state.nodes.clear()
    state.edges.clear()
    state.result = None
    state.selected_node_id = None
    image = state.add_node("ImageInput")
    gray = state.add_node("CvtColor")
    blur = state.add_node("GaussianBlur")
    canny = state.add_node("Canny")
    preview = state.add_node("Preview")
    state.edges.extend([
        WorkflowEdge(image.id, "image", gray.id, "image"),
        WorkflowEdge(gray.id, "image", blur.id, "image"),
        WorkflowEdge(blur.id, "image", canny.id, "image"),
        WorkflowEdge(canny.id, "edges", preview.id, "image"),
    ])
    state.selected_node_id = image.id
    refresh_all()


def new_workflow() -> None:
    state.nodes.clear()
    state.edges.clear()
    state.result = None
    state.selected_node_id = None
    refresh_all()


def run_workflow() -> None:
    if not state.nodes:
        ui.notify("No nodes", type="warning")
        return
    state.result = state.executor.run(state.nodes, state.edges)
    ui.notify(tr(state.locale, "ok") if state.result.ok else f"{tr(state.locale, 'failed')}: {state.result.error}", type="positive" if state.result.ok else "negative")
    refresh_all()


def on_upload(e: events.UploadEventArguments) -> None:
    suffix = Path(e.name).suffix or ".png"
    dst = UPLOAD_DIR / f"{uuid.uuid4().hex}{suffix}"
    with dst.open("wb") as f:
        shutil.copyfileobj(e.content, f)
    state.current_image_path = str(dst)
    image_nodes = [n for n in state.nodes if n.type == "ImageInput"]
    if image_nodes:
        image_nodes[0].params["path"] = str(dst)
        state.selected_node_id = image_nodes[0].id
    else:
        node = state.add_node("ImageInput")
        node.params["path"] = str(dst)
    ui.notify(tr(state.locale, "uploaded"), type="positive")
    refresh_all()


def get_node_preview(node_id: str | None) -> str | None:
    if not node_id or not state.result or node_id not in state.result.node_results:
        return None
    node_result = state.result.node_results[node_id]
    for preview in node_result.previews:
        if preview.preview_data_url:
            return preview.preview_data_url
    return None


def get_node_summaries(node_id: str | None) -> list[str]:
    if not node_id or not state.result or node_id not in state.result.node_results:
        return []
    node_result = state.result.node_results[node_id]
    if not node_result.ok:
        return [f"Error: {node_result.error}"]
    return [f"{p.output_name}: {p.type} · {p.summary}" for p in node_result.previews]


def build_ui() -> None:
    global render_library, render_graph, render_edges, render_connection_panel, render_params, render_preview

    ui.add_head_html("""
    <style>
      body { background: #0b1020; color: #e5e7eb; }
      .cv-card { background: linear-gradient(180deg,#1f2937,#111827); border: 1px solid #374151; border-radius: 14px; padding: 12px; }
      .cv-node { min-width: 190px; max-width: 220px; cursor: pointer; position: relative; }
      .cv-node.selected { border-color: #a78bfa; box-shadow: 0 0 0 2px rgba(167,139,250,.25); }
      .port { display: inline-flex; align-items: center; gap: 5px; font-size: 12px; color: #cbd5e1; margin: 2px 0; }
      .dot { width: 10px; height: 10px; border-radius: 999px; background: #a78bfa; border: 2px solid #e9d5ff; display: inline-block; }
      .muted { color: #94a3b8; font-size: 12px; }
      .edge-pill { border: 1px solid #334155; background: #0f172a; padding: 6px 8px; border-radius: 10px; margin: 4px 0; }
    </style>
    """)

    with ui.header().classes("bg-slate-950 text-white items-center"):
        ui.label().bind_text_from(state, "locale", lambda _: tr(state.locale, "title")).classes("text-xl font-bold")
        ui.space()
        ui.button().bind_text_from(state, "locale", lambda _: tr(state.locale, "new")).on("click", new_workflow)
        ui.button().bind_text_from(state, "locale", lambda _: tr(state.locale, "demo")).on("click", create_demo)
        ui.button().bind_text_from(state, "locale", lambda _: tr(state.locale, "run")).props("color=positive").on("click", run_workflow)
        ui.button().bind_text_from(state, "locale", lambda _: tr(state.locale, "language")).on("click", lambda: (setattr(state, "locale", "en" if state.locale == "zh" else "zh"), refresh_all()))

    with ui.row().classes("w-full p-3 gap-3 no-wrap"):
        with ui.column().classes("w-72 gap-3"):
            with ui.card().classes("cv-card w-full"):
                ui.label().bind_text_from(state, "locale", lambda _: tr(state.locale, "upload")).classes("text-lg font-bold")
                ui.upload(on_upload=on_upload, auto_upload=True, max_files=1).props("accept=image/*").classes("w-full")
                ui.label().bind_text_from(state, "locale", lambda _: tr(state.locale, "help")).classes("muted")

            @ui.refreshable
            def _library() -> None:
                with ui.card().classes("cv-card w-full"):
                    ui.label(tr(state.locale, "library")).classes("text-lg font-bold")
                    grouped: dict[str, list] = defaultdict(list)
                    for d in registry.definitions():
                        grouped[d.category].append(d)
                    order = ["IO", "Basic", "Filter", "Edge", "Threshold", "Morphology", "Contours", "AI / YOLO"]
                    for category in order + sorted(k for k in grouped if k not in order):
                        if category not in grouped:
                            continue
                        with ui.expansion(category_label(state.locale, category), value=category in {"IO", "Basic", "Filter", "Edge"}).classes("w-full"):
                            for d in grouped[category]:
                                ui.button(node_label(state.locale, d.type, d.title), on_click=lambda _=None, t=d.type: (state.add_node(t), refresh_all())).props("flat align=left").classes("w-full justify-start")
            render_library = _library
            _library()

        with ui.column().classes("grow gap-3"):
            @ui.refreshable
            def _graph() -> None:
                with ui.card().classes("cv-card w-full"):
                    ui.label(tr(state.locale, "workflow")).classes("text-lg font-bold")
                    if not state.nodes:
                        ui.label("Empty workflow / 空白工作流").classes("muted")
                        return
                    with ui.row().classes("items-start gap-3"):
                        incoming = {(e.to_node, e.to_input): e for e in state.edges}
                        for idx, node in enumerate(state.nodes):
                            d = state.definition(node.type)
                            selected = node.id == state.selected_node_id
                            with ui.card().classes("cv-card cv-node" + (" selected" if selected else "")).on("click", lambda _=None, nid=node.id: (setattr(state, "selected_node_id", nid), refresh_all())):
                                ui.label(node_label(state.locale, node.type, d.title)).classes("font-bold")
                                ui.label(node.id).classes("muted")
                                preview = get_node_preview(node.id)
                                if preview:
                                    ui.image(preview).classes("w-full rounded-md border border-slate-700")
                                if d.inputs:
                                    ui.label("Inputs").classes("muted")
                                    for p in d.inputs:
                                        connected = incoming.get((node.id, p.name))
                                        text = f"{p.name}: {p.type}"
                                        if connected:
                                            text += f" ← {connected.from_node}.{connected.from_output}"
                                        ui.html(f'<div class="port"><span class="dot"></span>{text}</div>')
                                if d.outputs:
                                    ui.label("Outputs").classes("muted")
                                    for p in d.outputs:
                                        ui.html(f'<div class="port">{p.name}: {p.type}<span class="dot"></span></div>')
                                summaries = get_node_summaries(node.id)
                                for s in summaries[:2]:
                                    ui.label(s).classes("muted")
                                ui.button(tr(state.locale, "delete"), on_click=lambda _=None, nid=node.id: (state.delete_node(nid), refresh_all())).props("flat dense color=negative")
                            if idx < len(state.nodes) - 1:
                                ui.label("→").classes("text-3xl text-purple-300 mt-16")
            render_graph = _graph
            _graph()

            @ui.refreshable
            def _edges() -> None:
                with ui.card().classes("cv-card w-full"):
                    ui.label(tr(state.locale, "edges")).classes("text-lg font-bold")
                    if not state.edges:
                        ui.label("No edges / 暂无线").classes("muted")
                    for idx, e in enumerate(state.edges):
                        with ui.row().classes("edge-pill items-center w-full"):
                            ui.label(f"{e.from_node}.{e.from_output}  →  {e.to_node}.{e.to_input}").classes("grow")
                            ui.button(tr(state.locale, "delete"), on_click=lambda _=None, i=idx: (state.edges.pop(i), refresh_all())).props("flat dense color=negative")
            render_edges = _edges
            _edges()

            @ui.refreshable
            def _connection_panel() -> None:
                with ui.card().classes("cv-card w-full"):
                    ui.label(tr(state.locale, "connect")).classes("text-lg font-bold")
                    if len(state.nodes) < 2:
                        ui.label("Add at least two nodes / 请至少添加两个节点").classes("muted")
                        return
                    src = ui.select(node_options(), label=tr(state.locale, "source"), value=state.nodes[0].id).classes("w-full")
                    out = ui.select(output_options(src.value), label=tr(state.locale, "output"), value=(output_options(src.value) or [None])[0]).classes("w-full")
                    tgt_default = state.nodes[1].id if len(state.nodes) > 1 else state.nodes[0].id
                    tgt = ui.select(node_options(), label=tr(state.locale, "target"), value=tgt_default).classes("w-full")
                    inp = ui.select(input_options(tgt.value), label=tr(state.locale, "input"), value=(input_options(tgt.value) or [None])[0]).classes("w-full")

                    def update_src() -> None:
                        opts = output_options(src.value)
                        out.options = opts
                        out.value = opts[0] if opts else None
                        out.update()

                    def update_tgt() -> None:
                        opts = input_options(tgt.value)
                        inp.options = opts
                        inp.value = opts[0] if opts else None
                        inp.update()

                    src.on_value_change(lambda _: update_src())
                    tgt.on_value_change(lambda _: update_tgt())

                    def add_edge() -> None:
                        if not all([src.value, out.value, tgt.value, inp.value]):
                            ui.notify("Invalid edge / 连线无效", type="warning")
                            return
                        state.add_or_replace_edge(WorkflowEdge(str(src.value), str(out.value), str(tgt.value), str(inp.value)))
                        refresh_all()

                    ui.button(tr(state.locale, "add_edge"), on_click=add_edge).props("color=primary")
            render_connection_panel = _connection_panel
            _connection_panel()

        with ui.column().classes("w-96 gap-3"):
            @ui.refreshable
            def _params() -> None:
                with ui.card().classes("cv-card w-full"):
                    ui.label(tr(state.locale, "params")).classes("text-lg font-bold")
                    node = state.selected_node()
                    if not node:
                        ui.label(tr(state.locale, "no_node")).classes("muted")
                        return
                    d = state.definition(node.type)
                    ui.label(f"{node_label(state.locale, node.type, d.title)} · {node.id}").classes("font-bold")
                    if not d.params:
                        ui.label("No parameters / 无参数").classes("muted")
                    for name, spec in d.params.items():
                        label = param_label(state.locale, name, spec.label)
                        value = node.params.get(name, spec.default)
                        if spec.type in ("int", "float"):
                            step = spec.step or (1 if spec.type == "int" else 0.1)
                            ctrl = ui.number(label=label, value=value, min=spec.min, max=spec.max, step=step).classes("w-full")
                            ctrl.on_value_change(lambda e, n=name, typ=spec.type: (node.params.__setitem__(n, int(e.value) if typ == "int" and e.value is not None else e.value), refresh_all()))
                        elif spec.type == "bool":
                            ctrl = ui.checkbox(label, value=bool(value))
                            ctrl.on_value_change(lambda e, n=name: (node.params.__setitem__(n, bool(e.value)), refresh_all()))
                        elif spec.type == "select":
                            ctrl = ui.select(spec.options or [], label=label, value=value).classes("w-full")
                            ctrl.on_value_change(lambda e, n=name: (node.params.__setitem__(n, e.value), refresh_all()))
                        else:
                            ctrl = ui.input(label=label, value=str(value or "")).classes("w-full")
                            ctrl.on_value_change(lambda e, n=name: node.params.__setitem__(n, e.value))
            render_params = _params
            _params()

            @ui.refreshable
            def _preview() -> None:
                with ui.card().classes("cv-card w-full"):
                    ui.label(tr(state.locale, "preview")).classes("text-lg font-bold")
                    node = state.selected_node()
                    if not node:
                        ui.label(tr(state.locale, "no_preview")).classes("muted")
                        return
                    preview = get_node_preview(node.id)
                    if preview:
                        ui.image(preview).classes("w-full rounded-md border border-slate-700")
                    else:
                        ui.label(tr(state.locale, "no_preview")).classes("muted")
                    for s in get_node_summaries(node.id):
                        ui.label(s).classes("muted")
                    if state.result and not state.result.ok:
                        ui.label(state.result.error or "").classes("text-red-300")
            render_preview = _preview
            _preview()

    create_demo()


def main() -> None:
    parser = argparse.ArgumentParser(description="ComfyCV Python-only Web UI")
    parser.add_argument("--host", default="0.0.0.0", help="Bind host. Use 0.0.0.0 for LAN access.")
    parser.add_argument("--port", default=8080, type=int, help="Web port")
    parser.add_argument("--no-browser", action="store_true", help="Do not automatically open browser")
    args = parser.parse_args()

    build_ui()
    ui.run(host=args.host, port=args.port, reload=False, show=not args.no_browser, title="ComfyCV Python Web")


if __name__ == "__main__":
    main()
