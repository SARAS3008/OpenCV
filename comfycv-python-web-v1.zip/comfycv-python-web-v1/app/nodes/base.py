from __future__ import annotations

from typing import Any

from app.core.models import NodeDefinition, ParamSpec, PortSpec


class RunContext:
    """Shared runtime resources passed to every node.

    Keep this lightweight for now. Later you can put model caches, GPU settings,
    temporary directories, and logging hooks here.
    """

    def __init__(self) -> None:
        self.model_cache: dict[str, Any] = {}


class CvNode:
    type = "CvNode"
    title = "CV Node"
    category = "Base"
    description = ""
    inputs: list[PortSpec] = []
    outputs: list[PortSpec] = []
    params: dict[str, ParamSpec] = {}

    @classmethod
    def definition(cls) -> NodeDefinition:
        return NodeDefinition(
            type=cls.type,
            title=cls.title,
            category=cls.category,
            description=cls.description,
            inputs=list(cls.inputs),
            outputs=list(cls.outputs),
            params=dict(cls.params),
        )

    def run(self, ctx: RunContext, **kwargs: Any) -> dict[str, Any]:
        raise NotImplementedError


def ensure_odd(value: int, minimum: int = 1) -> int:
    value = max(int(value), minimum)
    if value % 2 == 0:
        value += 1
    return value


def clamp_int(value: int, min_value: int, max_value: int) -> int:
    return max(min_value, min(int(value), max_value))
