from __future__ import annotations

import cv2

from app.core.models import ParamSpec, PortSpec
from app.nodes.base import CvNode, RunContext, ensure_odd


SHAPES = {
    "RECT": cv2.MORPH_RECT,
    "ELLIPSE": cv2.MORPH_ELLIPSE,
    "CROSS": cv2.MORPH_CROSS,
}

MORPH_OPS = {
    "OPEN": cv2.MORPH_OPEN,
    "CLOSE": cv2.MORPH_CLOSE,
    "GRADIENT": cv2.MORPH_GRADIENT,
    "TOPHAT": cv2.MORPH_TOPHAT,
    "BLACKHAT": cv2.MORPH_BLACKHAT,
}


def make_kernel(shape: str, ksize: int):
    k = ensure_odd(int(ksize))
    return cv2.getStructuringElement(SHAPES[shape], (k, k))


class Erode(CvNode):
    type = "Erode"
    title = "Erode"
    category = "Morphology"
    description = "Morphological erosion."
    inputs = [PortSpec(name="image", type="Image", label="Image")]
    outputs = [PortSpec(name="image", type="Image", label="Image")]
    params = {
        "ksize": ParamSpec(type="int", default=3, min=1, max=99, step=2, label="Kernel size"),
        "shape": ParamSpec(type="select", default="RECT", options=list(SHAPES.keys()), label="Kernel shape"),
        "iterations": ParamSpec(type="int", default=1, min=1, max=20, step=1, label="Iterations"),
    }

    def run(self, ctx: RunContext, image, ksize=3, shape="RECT", iterations=1, **_) -> dict:
        return {"image": cv2.erode(image, make_kernel(shape, ksize), iterations=int(iterations))}


class Dilate(CvNode):
    type = "Dilate"
    title = "Dilate"
    category = "Morphology"
    description = "Morphological dilation."
    inputs = [PortSpec(name="image", type="Image", label="Image")]
    outputs = [PortSpec(name="image", type="Image", label="Image")]
    params = {
        "ksize": ParamSpec(type="int", default=3, min=1, max=99, step=2, label="Kernel size"),
        "shape": ParamSpec(type="select", default="RECT", options=list(SHAPES.keys()), label="Kernel shape"),
        "iterations": ParamSpec(type="int", default=1, min=1, max=20, step=1, label="Iterations"),
    }

    def run(self, ctx: RunContext, image, ksize=3, shape="RECT", iterations=1, **_) -> dict:
        return {"image": cv2.dilate(image, make_kernel(shape, ksize), iterations=int(iterations))}


class MorphologyEx(CvNode):
    type = "MorphologyEx"
    title = "Morphology Ex"
    category = "Morphology"
    description = "Open, close, gradient, top-hat and black-hat."
    inputs = [PortSpec(name="image", type="Image", label="Image")]
    outputs = [PortSpec(name="image", type="Image", label="Image")]
    params = {
        "op": ParamSpec(type="select", default="OPEN", options=list(MORPH_OPS.keys()), label="Operation"),
        "ksize": ParamSpec(type="int", default=3, min=1, max=99, step=2, label="Kernel size"),
        "shape": ParamSpec(type="select", default="RECT", options=list(SHAPES.keys()), label="Kernel shape"),
        "iterations": ParamSpec(type="int", default=1, min=1, max=20, step=1, label="Iterations"),
    }

    def run(self, ctx: RunContext, image, op="OPEN", ksize=3, shape="RECT", iterations=1, **_) -> dict:
        result = cv2.morphologyEx(image, MORPH_OPS[op], make_kernel(shape, ksize), iterations=int(iterations))
        return {"image": result}
