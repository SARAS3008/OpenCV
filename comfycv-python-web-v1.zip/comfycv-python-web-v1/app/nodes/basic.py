from __future__ import annotations

import cv2

from app.core.models import ParamSpec, PortSpec
from app.nodes.base import CvNode, RunContext, ensure_odd


COLOR_CODES = {
    "BGR2GRAY": cv2.COLOR_BGR2GRAY,
    "GRAY2BGR": cv2.COLOR_GRAY2BGR,
    "BGR2RGB": cv2.COLOR_BGR2RGB,
    "RGB2BGR": cv2.COLOR_RGB2BGR,
    "BGR2HSV": cv2.COLOR_BGR2HSV,
    "HSV2BGR": cv2.COLOR_HSV2BGR,
    "BGR2LAB": cv2.COLOR_BGR2LAB,
    "LAB2BGR": cv2.COLOR_LAB2BGR,
}


class CvtColor(CvNode):
    type = "CvtColor"
    title = "Convert Color"
    category = "Basic"
    description = "Convert image color space."
    inputs = [PortSpec(name="image", type="Image", label="Image")]
    outputs = [PortSpec(name="image", type="Image", label="Image")]
    params = {
        "code": ParamSpec(type="select", default="BGR2GRAY", options=list(COLOR_CODES.keys()), label="Code"),
    }

    def run(self, ctx: RunContext, image, code="BGR2GRAY", **_) -> dict:
        return {"image": cv2.cvtColor(image, COLOR_CODES[code])}


class GaussianBlur(CvNode):
    type = "GaussianBlur"
    title = "Gaussian Blur"
    category = "Filter"
    description = "Gaussian smoothing."
    inputs = [PortSpec(name="image", type="Image", label="Image")]
    outputs = [PortSpec(name="image", type="Image", label="Image")]
    params = {
        "ksize": ParamSpec(type="int", default=5, min=1, max=99, step=2, label="Kernel size"),
        "sigmaX": ParamSpec(type="float", default=1.0, min=0.0, max=50.0, step=0.1, label="Sigma X"),
    }

    def run(self, ctx: RunContext, image, ksize=5, sigmaX=1.0, **_) -> dict:
        k = ensure_odd(int(ksize))
        return {"image": cv2.GaussianBlur(image, (k, k), float(sigmaX))}


class MedianBlur(CvNode):
    type = "MedianBlur"
    title = "Median Blur"
    category = "Filter"
    description = "Median smoothing, useful for salt-and-pepper noise."
    inputs = [PortSpec(name="image", type="Image", label="Image")]
    outputs = [PortSpec(name="image", type="Image", label="Image")]
    params = {
        "ksize": ParamSpec(type="int", default=5, min=1, max=99, step=2, label="Kernel size"),
    }

    def run(self, ctx: RunContext, image, ksize=5, **_) -> dict:
        k = ensure_odd(int(ksize))
        return {"image": cv2.medianBlur(image, k)}


class Canny(CvNode):
    type = "Canny"
    title = "Canny"
    category = "Edge"
    description = "Canny edge detector."
    inputs = [PortSpec(name="image", type="Image", label="Image")]
    outputs = [PortSpec(name="edges", type="Image.Mask", label="Edges")]
    params = {
        "threshold1": ParamSpec(type="int", default=80, min=0, max=500, step=1, label="Threshold 1"),
        "threshold2": ParamSpec(type="int", default=160, min=0, max=500, step=1, label="Threshold 2"),
        "apertureSize": ParamSpec(type="select", default=3, options=[3, 5, 7], label="Aperture"),
        "L2gradient": ParamSpec(type="bool", default=False, label="L2 gradient"),
    }

    def run(self, ctx: RunContext, image, threshold1=80, threshold2=160, apertureSize=3, L2gradient=False, **_) -> dict:
        gray = image if image.ndim == 2 else cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        edges = cv2.Canny(gray, int(threshold1), int(threshold2), apertureSize=int(apertureSize), L2gradient=bool(L2gradient))
        return {"edges": edges}


THRESHOLD_TYPES = {
    "BINARY": cv2.THRESH_BINARY,
    "BINARY_INV": cv2.THRESH_BINARY_INV,
    "TRUNC": cv2.THRESH_TRUNC,
    "TOZERO": cv2.THRESH_TOZERO,
    "TOZERO_INV": cv2.THRESH_TOZERO_INV,
    "OTSU": cv2.THRESH_BINARY | cv2.THRESH_OTSU,
}


class Threshold(CvNode):
    type = "Threshold"
    title = "Threshold"
    category = "Threshold"
    description = "Fixed threshold or Otsu threshold."
    inputs = [PortSpec(name="image", type="Image", label="Image")]
    outputs = [PortSpec(name="mask", type="Image.Mask", label="Mask")]
    params = {
        "thresh": ParamSpec(type="int", default=127, min=0, max=255, step=1, label="Threshold"),
        "maxval": ParamSpec(type="int", default=255, min=0, max=255, step=1, label="Max value"),
        "type": ParamSpec(type="select", default="BINARY", options=list(THRESHOLD_TYPES.keys()), label="Type"),
    }

    def run(self, ctx: RunContext, image, thresh=127, maxval=255, type="BINARY", **_) -> dict:
        gray = image if image.ndim == 2 else cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        _, mask = cv2.threshold(gray, int(thresh), int(maxval), THRESHOLD_TYPES[type])
        return {"mask": mask}


ADAPTIVE_METHODS = {
    "MEAN_C": cv2.ADAPTIVE_THRESH_MEAN_C,
    "GAUSSIAN_C": cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
}


class AdaptiveThreshold(CvNode):
    type = "AdaptiveThreshold"
    title = "Adaptive Threshold"
    category = "Threshold"
    description = "Adaptive threshold for uneven illumination."
    inputs = [PortSpec(name="image", type="Image", label="Image")]
    outputs = [PortSpec(name="mask", type="Image.Mask", label="Mask")]
    params = {
        "maxValue": ParamSpec(type="int", default=255, min=0, max=255, step=1, label="Max value"),
        "method": ParamSpec(type="select", default="GAUSSIAN_C", options=list(ADAPTIVE_METHODS.keys()), label="Method"),
        "thresholdType": ParamSpec(type="select", default="BINARY", options=["BINARY", "BINARY_INV"], label="Threshold type"),
        "blockSize": ParamSpec(type="int", default=11, min=3, max=99, step=2, label="Block size"),
        "C": ParamSpec(type="float", default=2.0, min=-50.0, max=50.0, step=0.5, label="C"),
    }

    def run(self, ctx: RunContext, image, maxValue=255, method="GAUSSIAN_C", thresholdType="BINARY", blockSize=11, C=2.0, **_) -> dict:
        gray = image if image.ndim == 2 else cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        b = ensure_odd(int(blockSize), minimum=3)
        t = cv2.THRESH_BINARY if thresholdType == "BINARY" else cv2.THRESH_BINARY_INV
        mask = cv2.adaptiveThreshold(gray, int(maxValue), ADAPTIVE_METHODS[method], t, b, float(C))
        return {"mask": mask}


INTERPOLATIONS = {
    "NEAREST": cv2.INTER_NEAREST,
    "LINEAR": cv2.INTER_LINEAR,
    "AREA": cv2.INTER_AREA,
    "CUBIC": cv2.INTER_CUBIC,
    "LANCZOS4": cv2.INTER_LANCZOS4,
}


class Resize(CvNode):
    type = "Resize"
    title = "Resize"
    category = "Basic"
    description = "Scale image."
    inputs = [PortSpec(name="image", type="Image", label="Image")]
    outputs = [PortSpec(name="image", type="Image", label="Image")]
    params = {
        "scale": ParamSpec(type="float", default=1.0, min=0.05, max=4.0, step=0.05, label="Scale"),
        "interpolation": ParamSpec(type="select", default="LINEAR", options=list(INTERPOLATIONS.keys()), label="Interpolation"),
    }

    def run(self, ctx: RunContext, image, scale=1.0, interpolation="LINEAR", **_) -> dict:
        scale = float(scale)
        h, w = image.shape[:2]
        size = (max(1, int(w * scale)), max(1, int(h * scale)))
        return {"image": cv2.resize(image, size, interpolation=INTERPOLATIONS[interpolation])}
