from __future__ import annotations

import cv2

from app.core.models import ParamSpec, PortSpec
from app.nodes.base import CvNode, RunContext


class YOLODetect(CvNode):
    type = "YOLODetect"
    title = "YOLO Detect"
    category = "AI / YOLO"
    description = "YOLO interface placeholder. Supports ultralytics if installed."
    inputs = [PortSpec(name="image", type="Image.BGR", label="Image")]
    outputs = [
        PortSpec(name="image", type="Image.BGR", label="Image"),
        PortSpec(name="detections", type="Detections", label="Detections"),
    ]
    params = {
        "model_path": ParamSpec(type="text", default="", label="Model path"),
        "conf": ParamSpec(type="float", default=0.25, min=0.0, max=1.0, step=0.01, label="Confidence"),
        "iou": ParamSpec(type="float", default=0.45, min=0.0, max=1.0, step=0.01, label="IoU"),
        "imgsz": ParamSpec(type="int", default=640, min=64, max=2048, step=32, label="Image size"),
    }

    def run(self, ctx: RunContext, image, model_path="", conf=0.25, iou=0.45, imgsz=640, **_) -> dict:
        if not model_path:
            return {"image": image, "detections": []}

        try:
            from ultralytics import YOLO  # type: ignore
        except Exception as exc:  # pragma: no cover - optional dependency
            raise RuntimeError("Install ultralytics to use YOLODetect: pip install ultralytics") from exc

        cache_key = f"ultralytics:{model_path}"
        if cache_key not in ctx.model_cache:
            ctx.model_cache[cache_key] = YOLO(model_path)
        model = ctx.model_cache[cache_key]

        rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB) if image.ndim == 3 else image
        results = model.predict(rgb, conf=float(conf), iou=float(iou), imgsz=int(imgsz), verbose=False)
        canvas = image.copy()
        detections = []
        if results:
            boxes = results[0].boxes
            names = getattr(results[0], "names", {})
            if boxes is not None:
                for box in boxes:
                    xyxy = box.xyxy[0].tolist()
                    cls_id = int(box.cls[0]) if box.cls is not None else -1
                    score = float(box.conf[0]) if box.conf is not None else 0.0
                    label = names.get(cls_id, str(cls_id)) if isinstance(names, dict) else str(cls_id)
                    x1, y1, x2, y2 = map(int, xyxy)
                    cv2.rectangle(canvas, (x1, y1), (x2, y2), (0, 255, 255), 2)
                    cv2.putText(canvas, f"{label} {score:.2f}", (x1, max(0, y1 - 6)), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 255), 2)
                    detections.append({"bbox": [x1, y1, x2, y2], "class_id": cls_id, "label": label, "score": score})
        return {"image": canvas, "detections": detections}
