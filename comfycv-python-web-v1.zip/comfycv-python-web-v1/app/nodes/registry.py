from __future__ import annotations

from app.core.models import NodeDefinition
from app.nodes.base import CvNode
from app.nodes.basic import AdaptiveThreshold, Canny, CvtColor, GaussianBlur, MedianBlur, Resize, Threshold
from app.nodes.contours import DrawContours, FilterContours, FindContours
from app.nodes.io import ImageInput, Preview
from app.nodes.morphology import Dilate, Erode, MorphologyEx
from app.nodes.yolo import YOLODetect


class NodeRegistry:
    def __init__(self) -> None:
        self._nodes: dict[str, type[CvNode]] = {}

    def register(self, node_cls: type[CvNode]) -> None:
        if node_cls.type in self._nodes:
            raise ValueError(f"Duplicate node type: {node_cls.type}")
        self._nodes[node_cls.type] = node_cls

    def get(self, node_type: str) -> type[CvNode]:
        try:
            return self._nodes[node_type]
        except KeyError as exc:
            raise KeyError(f"Unknown node type: {node_type}") from exc

    def definitions(self) -> list[NodeDefinition]:
        return [cls.definition() for cls in self._nodes.values()]


registry = NodeRegistry()

for cls in [
    ImageInput,
    Preview,
    CvtColor,
    Resize,
    GaussianBlur,
    MedianBlur,
    Canny,
    Threshold,
    AdaptiveThreshold,
    Erode,
    Dilate,
    MorphologyEx,
    FindContours,
    FilterContours,
    DrawContours,
    YOLODetect,
]:
    registry.register(cls)
