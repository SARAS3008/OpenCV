from __future__ import annotations

import cv2

from app.core.models import ParamSpec, PortSpec
from app.nodes.base import CvNode, RunContext


RETRIEVAL_MODES = {
    "EXTERNAL": cv2.RETR_EXTERNAL,
    "LIST": cv2.RETR_LIST,
    "TREE": cv2.RETR_TREE,
}

CHAIN_METHODS = {
    "SIMPLE": cv2.CHAIN_APPROX_SIMPLE,
    "NONE": cv2.CHAIN_APPROX_NONE,
}


class FindContours(CvNode):
    type = "FindContours"
    title = "Find Contours"
    category = "Contours"
    description = "Find contours from a binary mask."
    inputs = [PortSpec(name="mask", type="Image.Mask", label="Mask")]
    outputs = [
        PortSpec(name="contours", type="Contours", label="Contours"),
        PortSpec(name="debug", type="Image.BGR", label="Debug"),
    ]
    params = {
        "mode": ParamSpec(type="select", default="EXTERNAL", options=list(RETRIEVAL_MODES.keys()), label="Mode"),
        "method": ParamSpec(type="select", default="SIMPLE", options=list(CHAIN_METHODS.keys()), label="Method"),
    }

    def run(self, ctx: RunContext, mask, mode="EXTERNAL", method="SIMPLE", **_) -> dict:
        gray = mask if mask.ndim == 2 else cv2.cvtColor(mask, cv2.COLOR_BGR2GRAY)
        contours, hierarchy = cv2.findContours(gray.copy(), RETRIEVAL_MODES[mode], CHAIN_METHODS[method])
        debug = cv2.cvtColor(gray, cv2.COLOR_GRAY2BGR)
        cv2.drawContours(debug, contours, -1, (0, 255, 0), 2)
        return {"contours": contours, "debug": debug, "hierarchy": hierarchy}


class FilterContours(CvNode):
    type = "FilterContours"
    title = "Filter Contours"
    category = "Contours"
    description = "Filter contours by area."
    inputs = [PortSpec(name="contours", type="Contours", label="Contours")]
    outputs = [PortSpec(name="contours", type="Contours", label="Contours")]
    params = {
        "min_area": ParamSpec(type="float", default=100.0, min=0.0, max=1000000.0, step=10.0, label="Min area"),
        "max_area": ParamSpec(type="float", default=1000000.0, min=0.0, max=10000000.0, step=100.0, label="Max area"),
    }

    def run(self, ctx: RunContext, contours, min_area=100.0, max_area=1000000.0, **_) -> dict:
        out = []
        for c in contours:
            area = cv2.contourArea(c)
            if float(min_area) <= area <= float(max_area):
                out.append(c)
        return {"contours": out}


class DrawContours(CvNode):
    type = "DrawContours"
    title = "Draw Contours"
    category = "Contours"
    description = "Draw contours on an image."
    inputs = [
        PortSpec(name="image", type="Image", label="Image"),
        PortSpec(name="contours", type="Contours", label="Contours"),
    ]
    outputs = [PortSpec(name="image", type="Image.BGR", label="Image")]
    params = {
        "thickness": ParamSpec(type="int", default=2, min=1, max=20, step=1, label="Thickness"),
        "draw_rect": ParamSpec(type="bool", default=False, label="Draw bounding rectangles"),
    }

    def run(self, ctx: RunContext, image, contours, thickness=2, draw_rect=False, **_) -> dict:
        canvas = image.copy()
        if canvas.ndim == 2:
            canvas = cv2.cvtColor(canvas, cv2.COLOR_GRAY2BGR)
        cv2.drawContours(canvas, contours, -1, (0, 255, 0), int(thickness))
        if draw_rect:
            for c in contours:
                x, y, w, h = cv2.boundingRect(c)
                cv2.rectangle(canvas, (x, y), (x + w, y + h), (0, 180, 255), int(thickness))
        return {"image": canvas}
