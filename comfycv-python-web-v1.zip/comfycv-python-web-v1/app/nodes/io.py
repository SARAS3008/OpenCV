from __future__ import annotations

import cv2

from app.core.models import ParamSpec, PortSpec
from app.nodes.base import CvNode, RunContext


class ImageInput(CvNode):
    type = "ImageInput"
    title = "Image Input"
    category = "IO"
    description = "Load an image from local disk."
    inputs = []
    outputs = [PortSpec(name="image", type="Image.BGR", label="Image")]
    params = {
        "path": ParamSpec(type="text", default="", label="Image path", help="Local image path"),
    }

    def run(self, ctx: RunContext, path: str = "", **_) -> dict:
        if not path:
            raise ValueError("ImageInput requires a local image path. Use Open Image first.")
        image = cv2.imread(path, cv2.IMREAD_COLOR)
        if image is None:
            raise ValueError(f"Failed to load image: {path}")
        return {"image": image}


class Preview(CvNode):
    type = "Preview"
    title = "Preview"
    category = "IO"
    description = "Pass-through node used to preview an image."
    inputs = [PortSpec(name="image", type="Image", label="Image")]
    outputs = [PortSpec(name="image", type="Image", label="Image")]
    params = {}

    def run(self, ctx: RunContext, image, **_) -> dict:
        return {"image": image}
