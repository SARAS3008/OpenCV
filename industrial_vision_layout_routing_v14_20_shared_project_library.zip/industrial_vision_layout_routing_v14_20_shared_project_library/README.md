# 工业视觉流程编辑器

这是一个基于 FastAPI、OpenCV 和原生 Web 技术实现的节点式工业视觉流程编辑器。前端、API 通信层、后端工作流调度、OpenCV 算法、批量测试以及独立脚本导出均已分层。

## 启动

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS / Linux: source .venv/bin/activate
pip install -r requirements.txt
python run.py
```

浏览器打开 `http://127.0.0.1:8000`。

## 运行与调试模式

顶部运行区域提供三种执行方式：

- **整体运行**：从头运行完整工作流，与原有运行方式一致；
- **单步运行**：每次只执行一个新的节点，并保留上一步的中间结果；
- **运行到节点**：先在画布中选中目标节点，系统执行其依赖和目标节点后暂停，随后自动切换为继续单步。

调试时，已执行节点、当前暂停节点、下一步节点和目标节点会使用不同的画布高亮。修改执行参数或连线会自动结束旧调试会话；仅移动、折叠或换色不会中断调试。`If / Else` 仍采用惰性分支执行。批量工作流的调试模式只使用第一张图片且不会写入批量结果，整体运行不受影响。

完整说明见：[docs/DEBUG_EXECUTION_MODES_V14_14.md](docs/DEBUG_EXECUTION_MODES_V14_14.md)。

## v14.20 共享项目库

左侧“模型”下方新增“项目库”入口。登录用户可以浏览、搜索并打开其他用户或团队工作区主动共享的完整工作流。共享内容采用版本快照，私有草稿不会暴露；他人项目会作为新的可编辑副本打开，不携带原项目 ID，无法覆盖原作者项目。

项目库同时提供“我的项目”标签页，拥有工作区管理权限的用户可将当前发布版本或最新版本共享到项目库，也可随时取消共享。完整说明见：[docs/SHARED_PROJECT_LIBRARY_V14_20.md](docs/SHARED_PROJECT_LIBRARY_V14_20.md)。

## v14.19 批量 CSV 多节点变量选择

“保存批量结果”节点现在支持一个结果图输入和最多 20 个独立的 `CSV变量` 输入。每个变量输入都可以连接任意节点的数值、文本、布尔、列表或字典输出，并在参数面板中单独勾选、取消或重命名 CSV 列。

- `自动保存全部上游数据`：兼容已有工作流，继续汇总沿主流程传递的全部 `metrics/data`；
- `只保存已选择的输入变量`：适合分支流程和多个测量节点，CSV 只写入明确连接并启用的变量；
- 标量直接写入单列，列表保存为 JSON 文本，字典按自定义列名前缀展开；
- 重复列名、无效端口和图像/数组误接会给出明确错误，不会静默覆盖；
- CSV 列顺序按照变量输入端口顺序保留。

可直接导入示例：`examples/batch_csv_multi_input_selection.json`。完整说明见：[docs/BATCH_CSV_MULTI_INPUT_V14_19.md](docs/BATCH_CSV_MULTI_INPUT_V14_19.md)。

## v14.18 整体运行暂停、继续与结束

整体运行模式新增独立的**暂停/继续**和**结束**控制：

- 点击“暂停”后，当前 OpenCV/YOLO 算子会先安全完成，再在节点边界进入暂停；
- 点击“继续”后，从现有节点进度或下一张批量图片继续，不重新执行已完成节点；
- 点击“结束”后，解除可能存在的暂停，并停止调度后续节点或后续图片；
- 单图运行结束时会返回已经完成的节点预览，批量运行会保留已生成图片、CSV 与当前进度；
- 运行控制会话按用户和工作区隔离，浏览器断开时也会自动结束后台运行。

完整说明见：[docs/FULL_RUN_PAUSE_STOP_V14_18.md](docs/FULL_RUN_PAUSE_STOP_V14_18.md)。

## v14.17 点到直线距离可视化增强

`PointLineDistance` 节点的结果图现会同时绘制：

- 贯穿当前画布的**直线延长线**；
- 上游提供 `p1/p2` 时对应的**原始线段高亮**；
- **点到垂足的垂线段**；
- 更醒目的**垂足十字标记**与 `H` 标签。

这样在测量时可以同时看清“原始线段来源”和“数学上的整条直线”，尤其适合线段较短、测量点落在线段延长区域的场景。完整说明见：[docs/POINT_LINE_DISTANCE_VISUAL_V14_17.md](docs/POINT_LINE_DISTANCE_VISUAL_V14_17.md)。

## v14.16 批量处理实时进度条

批量整体运行时，右侧实时日志下方会自动显示固定进度条，实时展示完成百分比、已处理/总数、成功/失败数量和当前图片。单图运行与调试模式会自动隐藏该区域；批量完成、部分失败、异常中断或用户取消时会保留对应状态。

后端 NDJSON 批量事件新增 `processed` 与 `progress_percent` 字段，前端不依赖轮询即可随每张图片完成实时更新。完整说明见：[docs/BATCH_PROGRESS_V14_16.md](docs/BATCH_PROGRESS_V14_16.md)。

## v14.15 P0–P4 优化

v14.15 将整体运行与调试运行统一到同一个节点执行内核，并增加调试输出释放、资源预算、主动取消、前端运行状态机、PostgreSQL/Redis/S3-MinIO 可选适配、健康检查、Prometheus 指标、Docker Compose 和 CI。默认仍使用本地文件模式，原有单机部署无需外部服务。

完整变更、环境变量、迁移步骤和当前分布式边界见：[docs/P0_P4_OPTIMIZATION_V14_15.md](docs/P0_P4_OPTIMIZATION_V14_15.md)。

生产基础设施示例：

```bash
cp .env.example .env
# 修改密码和连接信息
docker compose -f docker-compose.production.yml up --build -d
```

健康与监控接口：

```text
GET /api/health/live
GET /api/health/ready
GET /api/metrics
```

调试会话和算子执行目前仍属于单进程资源，生产 Compose 保持一个 Uvicorn Worker。需要横向扩展时，应先拆分专用调试、任务和推理 Worker。

## 单图流程

单图流程以 `ReadImage` 开始，通过节点内的 `image_path` 参数读取运行 FastAPI 后端的计算机上的图片：

```text
相对路径：samples/part.png
绝对路径：D:\images\part.png
```

相对路径以项目根目录为基准。

## 批量测试

节点库新增“批量处理”分组。可直接导入示例：`examples/batch_workflow.json`。


```text
批量读取图片 → 图像算法/测量算子 → 保存批量结果
```

### 批量读取图片

- `folder_path`：服务器上的图片目录；
- `recursive`：是否读取子目录；
- `extensions`：扩展名列表，例如 `.png,.jpg`；
- `max_images`：最大处理数量，`0` 表示不限制；
- `continue_on_error`：单张失败后是否继续。

### 保存批量结果

- 用户可填写结果保存目录；
- 可选择是否保存结果图；
- 可选择 PNG、JPEG、WebP 或沿用原图格式；
- 可保留输入目录的子目录结构；
- 可生成 UTF-8 BOM CSV，Excel 直接打开中文不会乱码。

CSV 基础列包括：

```text
source_path, source_name, relative_path, output_path, status, error
```

CSV 有两种字段模式：

- **自动保存全部上游数据**：测量算子的 `metrics/data` 会继续自动追加为动态列，兼容旧工作流；
- **只保存已选择的输入变量**：增加 `CSV变量输入数` 后，把不同节点的具体输出端口连接到 `CSV变量 1/2/3...`，再在变量选择器中决定是否保存并设置列名。

一个图片可以包含多个结果，也可以从不同分支节点同时选择变量。标量写入单列，列表保存为 JSON，字典自动展开为多列。

批量运行时，右侧“实时运行日志”会逐张显示当前进度、耗时、成功或失败状态，并在结束时记录总数量、结果目录和 CSV 路径；节点下方只显示最后一张成功图片的完整处理效果，避免一次返回大量 Base64 图片占用内存。

## 自定义算子

项目会自动扫描：

```text
backend/custom_operators/*.py
```

复制 `_template.py`、修改后重启服务，新算子就会自动出现在左侧“自定义算子”分组，不需要修改前端或注册表。

完整说明见：[docs/CUSTOM_OPERATORS.md](docs/CUSTOM_OPERATORS.md)。项目自带 `MeanBrightness` 示例，它会输出平均亮度和标准差，并自动进入批量 CSV。

## 结果展示规则

- 图像型算子只在节点底部显示完整缩略图，避免右侧重复展示；
- 数值型算子通过元数据 `result_type: "metrics"` 声明，并在节点底部直接显示全部数值指标；
- 右侧区域用于实时运行日志，按时间显示工作流、节点、批量图片、警告和错误事件；
- 所有数值指标采用相同字号和相同行式布局，不再把第一个指标放大显示；
- 同时产生图像和测量数据的算子会在同一结果区依次显示完整图像缩略图和全部数值，测量数据也会继续进入批量 CSV；
- `MeanBrightness` 示例已声明为数值型结果节点。

顶部不再提供重复的“保存”和“加载”按钮。当前工作流通过 `Ctrl+S` / `Command+S` 保存，JSON 导入和导出功能继续保留。选中节点任意区域或节点内参数控件时，上方操作栏都会立即出现，删除按钮使用垃圾桶图标。

## 节点库分类控制

左侧“图像节点库”标题右侧的两个按钮只控制节点库本身：

- `▸`：按类别折叠节点库中罗列的所有算子；
- `▾`：展开节点库中的所有算子类别。

它们不会再折叠或展开画布中的节点。每个类别标题仍可单独点击切换。


## 逻辑节点库

左侧侧栏在“图像节点库”下方新增了同级的“逻辑节点库”。两个节点库分别拥有搜索框、分类折叠按钮和独立滚动区域。

目前包含：

- **常量**：产生数值、布尔值或文本；
- **比较**：支持 `>`、`>=`、`<`、`<=`、`==`、`!=`；
- **布尔运算**：AND、OR、XOR、NAND、NOR；
- **NOT 取反**：对布尔输入取反；
- **If / Else 选择**：根据条件从两个候选输入中选择结果；
- **For 循环**：按固定次数对数值执行加、减、乘、除更新；
- **While 循环**：条件成立时持续更新数值，并通过最大循环次数防止死循环。

逻辑节点支持多输入端口和端口类型提示。端口颜色用于区分图像、数值、布尔值、文本和通用数据。连接不兼容的端口时，前端会直接给出提示。

示例逻辑关系：

```text
常量 A ─┐
        ├→ 比较 → If / Else 选择 → 结果
常量 B ─┘          ↑        ↑
                 If 值   Else 值
```

可导入示例：`examples/logic_workflow.json`。

### 当前控制流语义

该编辑器采用无环数据流模型：

- `If / Else` 先计算条件，只执行被选中的上游候选分支；未选中的分支不会执行。
- `For` 和 `While` 当前是安全的**数值循环节点**，适合计数、阈值迭代和参数计算；不是将任意画布子流程反复执行的循环容器。
- `While` 默认有最大循环次数，并且后端强制限制最多 10000 次，避免死循环。

这些逻辑节点也支持导出为独立算法脚本。导出时会生成普通 Python 的条件表达式、`for` 和 `while` 语句，不会附带工作流解释器。

## 导航视图

右下角导航视图会动态计算当前画布节点和可视区域的实际边界，不再使用固定比例。白色矩形表示当前画布视口，彩色小块表示节点。点击导航视图中的任意位置后，主画布会把对应世界坐标移动到视口中心。

### 自动美化排线

画布顶部新增“美化排线”按钮。点击后，前端会根据当前节点连线关系计算拓扑运行层级，把上游节点放在左侧、下游节点逐层向右排列，并在同一层内根据上下游重心排序，减少交叉线。节点参数、节点 ID、连线关系和实际执行顺序不会被修改，只会调整节点坐标和连线显示方式。

连线显示已改为带圆角的正交折线路径；配合自动布局后，连线会优先走在层级之间的空白通道中，复杂工作流会更清晰。如果工作流存在环，系统会提示先删除循环依赖，而不会强制重排。

拖动节点时，画布会按浏览器动画帧节流，并暂时使用轻量连线路径；鼠标释放后再执行完整避障。这样可以减少大型工作流拖动时的重复几何计算，同时保证最终连线仍避开其他节点。

## 稳定性与安全说明

- `PointLineDistance` 的 `point` 和 `line` 端口可以不连接；未连接时使用节点参数中的手动坐标。
- JSON 持久化采用唯一临时文件、`fsync` 和原子替换，避免进程中断留下半写文件。
- 登录与会话文件增加跨进程文件锁，并限制会话刷新写入频率。
- 模型上传先写入 `.part` 临时文件，计算 SHA-256 后再原子落盘和注册。
- Python 代码片段在服务端强制使用独立进程，隐藏服务器路径，并阻止常见文件、设备和模型加载 API。

文件式项目、工作区和会话存储适合单机或小团队部署。生产环境建议使用单个 Uvicorn Worker；需要多实例或高并发时，应把用户、会话、项目和任务状态迁移到 PostgreSQL/Redis，并将模型与图片迁移到对象存储。

稳定性加固见：[docs/STABILITY_HARDENING_V14_12.md](docs/STABILITY_HARDENING_V14_12.md)。实时运行日志改造见：[docs/LIVE_RUN_LOG_V14_13.md](docs/LIVE_RUN_LOG_V14_13.md)。三种调试执行模式见：[docs/DEBUG_EXECUTION_MODES_V14_14.md](docs/DEBUG_EXECUTION_MODES_V14_14.md)。P0–P4 优化与生产适配见：[docs/P0_P4_OPTIMIZATION_V14_15.md](docs/P0_P4_OPTIMIZATION_V14_15.md)。批量进度条见：[docs/BATCH_PROGRESS_V14_16.md](docs/BATCH_PROGRESS_V14_16.md)。 点线距离可视化增强见：[docs/POINT_LINE_DISTANCE_VISUAL_V14_17.md](docs/POINT_LINE_DISTANCE_VISUAL_V14_17.md)。 整体运行暂停/继续/结束见：[docs/FULL_RUN_PAUSE_STOP_V14_18.md](docs/FULL_RUN_PAUSE_STOP_V14_18.md)。 多节点 CSV 变量选择见：[docs/BATCH_CSV_MULTI_INPUT_V14_19.md](docs/BATCH_CSV_MULTI_INPUT_V14_19.md)。

## 节点缩略图

节点底部的预览使用图片自身宽高并限制最大尺寸：

```css
width: auto;
height: auto;
max-width: 100%;
max-height: 100%;
object-fit: contain;
```

因此缩略图会完整显示，不裁切，也不会为了填满预览框而拉伸。点击缩略图后可以下载或查看原始分辨率图片。

## 颜色转换

“灰度化”和“BGR 转 RGB”统一为 `ColorConvert` 节点，通过 `mode` 参数选择 `GRAY` 或 `RGB`。导入旧工作流时，`Gray` 和 `BGR2RGB` 会自动迁移。

## 导出为独立算法脚本

点击左侧“导出脚本”，当前流程会通过 AST 编译为普通、顺序执行的 OpenCV 代码，并下载为 `vision_algorithm.py`。

生成脚本中不包含节点、连线、工作流 JSON、拓扑排序、FastAPI 或项目模块引用。批量输入节点在导出时被视为普通图像输入，批量保存节点被视为算法终点，因此生成文件仍是可复用的单图算法函数。

```bash
pip install opencv-python numpy
python vision_algorithm.py --input input.png --output result.png
```

## 多工作流标签

- `＋` 新建空白工作流；
- 点击标签切换；
- 双击标签名称重命名；
- 白点表示已保存，橙点表示有未保存修改；
- `Ctrl+S` / `Command+S` 保存当前工作流；
- 刷新后恢复多个标签及草稿。

## 目录结构

```text
industrial_vision_refactored/
├── backend/
│   ├── api/                    # FastAPI 路由
│   ├── algorithms/             # 图像算子、逻辑算子、元数据、插件加载器
│   ├── custom_operators/       # 用户自定义算子与模板
│   ├── models/                 # Pydantic 工作流模型
│   └── services/               # 单图/批量执行、图片路径、AST 导出
├── docs/
│   └── CUSTOM_OPERATORS.md
├── frontend/
│   ├── index.html
│   └── assets/
│       ├── css/styles.css
│       └── js/
│           ├── api.js
│           └── app.js
├── tests/
├── requirements.txt
└── run.py
```

## API

- `GET /api/operators`
- `POST /api/run`：兼容接口，完成后一次性返回单图或批量结果
- `POST /api/run-stream`：NDJSON 流式接口，实时推送节点/批量进度，最后返回完整结果
- `POST /api/debug/run-stream`：创建或继续调试会话，支持单步执行与运行到指定节点
- `POST /api/debug/reset`：释放调试会话和服务端中间结果
- `POST /api/export-script`
- `POST /api/upload`：仅保留旧版兼容

## 节点级错误定位与部分结果保留

工作流按拓扑顺序逐个执行。某个节点失败时，接口会返回：

- 已成功执行节点的结果预览；
- 失败节点的 ID、名称、类型和原始错误；
- 已完成节点顺序；
- 尚未执行的节点列表。

前端会保留失败前的图像和数值结果，并将失败节点标红、自动选中。节点结果区保留具体错误，右侧实时日志记录失败时间、失败节点、已完成节点和未执行节点，而不是清空已有结果。

示例错误响应字段：

```json
{
  "success": false,
  "executed_order": ["n1", "n2"],
  "pending_nodes": ["n4", "n5"],
  "failed_node": {
    "node_id": "n3",
    "type": "GaussianBlur",
    "label": "高斯滤波",
    "error": "节点 n3（高斯滤波 / GaussianBlur）执行失败：..."
  },
  "previews": []
}
```

## 节点错误追踪与数值端口修复

本版本修复了“节点已经执行，但最终只显示 HTTP 500，已完成节点没有预览”的问题。

根因是某些逻辑节点把 NumPy 图像数组放入 `metrics` 或 `data` 后，错误直到 FastAPI
序列化整个响应时才发生。现在执行器会在当前节点内部检查返回数据是否可 JSON 序列化：

- 已完成节点的预览会保留；
- 失败节点会返回结构化错误并在前端标红；
- 浏览器不再只收到无法解析的 HTTP 500 页面；
- NumPy 标量会自动转换为普通 Python 数值；
- 图像数组只能从图像输出端口传递，不能混入数值指标。

“平均亮度统计”节点现在具有三个输出端口：

- `out`：原图像，供图像处理链继续连接；
- `mean_brightness`：平均亮度数值；
- `brightness_std`：亮度标准差数值。

连接比较节点时，应从 `mean_brightness` 或 `brightness_std` 数值端口连线，不能从
`out` 图像端口连接。修正后的示例见 `examples/logic_workflow_fixed.json`。

## YOLO 推理算子

图像节点库新增 `AI推理 / YOLO推理` 节点。节点参数中的“模型文件”支持直接选择本地模型上传，也支持填写后端服务器可访问的模型路径。上传后的模型会保存到：

```text
models/uploads/
```

支持的任务包括：自动识别、目标检测、实例分割、图像分类、姿态估计和旋转框 OBB。节点会输出标注图、结构化结果列表、结果数量、最高类别、最高置信度和最终任务类型；这些摘要会显示在节点预览中，完整结果会进入 `data.yolo`，批量处理时可汇总到 CSV。

首次使用前需安装依赖：

```bash
pip install -r requirements.txt
```



### 按类别分别筛选目标并输出 Mask

`YOLO目标筛选` 节点已支持按类别 index 分别筛选目标。设置方式：

```text
selection_mode = PER_CLASS_BEST
class_indices = 0,1,8
min_confidence = 0.85
top_k = 3
```

此时节点不会把所有类别混在一起取 Top-K，而是对 `0`、`1`、`8` 每个类别分别寻找该类别内置信度最高且大于等于阈值的目标。如果某个 index 没有达到阈值的目标，`require_exact_count=YES` 时会报错；`require_exact_count=NO` 时会把缺失信息写入 `missing_indices`。

把原图连接到该节点的可选 `image` 输入后，节点还会输出二值图：`mask` 为所有已选目标的合并 Mask，`mask1` / `mask2` / ... 为单个目标区域 Mask。单目标 Mask 输出端口会根据参数自动适配：填写 `class_indices=0,1` 时显示 `mask1`、`mask2`，填写 `class_indices=0,1,8` 时显示 `mask1`、`mask2`、`mask3`；未填写 `class_indices` 时按 `top_k` 生成。普通检测模型会用检测框填充目标区域，分割模型会优先使用分割多边形。
示例 `examples/yolo_dynamic_mask_outputs_workflow.json` 展示了 `class_indices=0,1,8` 时自动生成 `mask1`、`mask2`、`mask3` 并分别接到显示节点的用法。


## YOLO Top2 ROI 边缘距离快速测试

导入 `examples/yolo_top2_roi_edge_distance_workflow.json` 可测试完整链路：读取图片、YOLO 检测、筛选置信度大于 0.35 的前两个目标、分别做 ROI Canny 边缘检测，并输出两个 ROI 中心点距离。

默认图片为 `examples/images/bus.jpg`，默认模型为 `yolov8n.pt`。如果运行环境联网，Ultralytics 会在首次使用 `yolov8n.pt` 时自动下载模型。也可以先运行：

```bash
python scripts/download_yolov8n.py
```

然后把工作流中 `YOLO推理.model_path` 改为：

```text
models/uploads/yolov8n.pt
```


## v12 连线避障与可见性修复

- 修复节点移动到画布上方后 SVG 连线被裁剪不可见的问题。
- 美化排线后的连线增加避障正交路由，优先绕开节点区域，避免线段藏在节点下方形成盲区。
- 连线增加方向箭头、圆角和更宽点击命中区域。


## v13 架构增强

本版本新增 YOLO 算子分模块、统一算子注册表、模型 LRU/TTL 缓存、轻量多用户模型隔离、服务端项目保存，以及前端 `VisionWorkspaceStore` 状态持久化模块。详细说明见 `docs/ARCHITECTURE_REFACTOR_V13.md`。
