import os
from pathlib import Path


def _env_bool(name: str, default: bool = False) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}

PROJECT_ROOT = Path(__file__).resolve().parents[1]
FRONTEND_DIR = PROJECT_ROOT / "frontend"
UPLOAD_DIR = PROJECT_ROOT / "uploads"
MODEL_DIR = PROJECT_ROOT / "models" / "uploads"
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
MODEL_DIR.mkdir(parents=True, exist_ok=True)

ALLOWED_IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff", ".webp"}
ALLOWED_MODEL_EXTENSIONS = {".pt", ".onnx", ".engine", ".torchscript", ".mlmodel", ".tflite", ".pb", ".xml", ".bin", ".yaml", ".yml"}
MAX_UPLOAD_BYTES = 20 * 1024 * 1024
MAX_MODEL_UPLOAD_BYTES = 512 * 1024 * 1024

PROJECTS_DIR = PROJECT_ROOT / "projects"
MODEL_METADATA_PATH = MODEL_DIR / "models.json"
MODEL_CACHE_MAX_ITEMS = 4
MODEL_CACHE_TTL_SECONDS = 30 * 60
PROJECTS_DIR.mkdir(parents=True, exist_ok=True)

# PythonSnippet 不是完整安全沙箱。服务端强制使用独立进程，只有在明确了解
# 风险并设置环境变量时才允许退回主进程执行。
PYTHON_SNIPPET_ALLOW_INLINE = _env_bool("VISION_ALLOW_INLINE_PYTHON_SNIPPET", False)
PYTHON_SNIPPET_START_METHOD = os.getenv("VISION_PYTHON_SNIPPET_START_METHOD", "forkserver").strip().lower() or "forkserver"
PYTHON_SNIPPET_CPU_LIMIT_SECONDS = max(1, int(os.getenv("VISION_PYTHON_SNIPPET_CPU_LIMIT_SECONDS", "5")))
PYTHON_SNIPPET_STARTUP_GRACE_SECONDS = max(0.0, float(os.getenv("VISION_PYTHON_SNIPPET_STARTUP_GRACE_SECONDS", "2.0")))

# 节点调试会话保存在当前服务进程内，需要限制生命周期和内存占用。
DEBUG_SESSION_TTL_SECONDS = max(60, int(os.getenv("VISION_DEBUG_SESSION_TTL_SECONDS", "1800")))
DEBUG_SESSION_MAX_ITEMS = max(1, int(os.getenv("VISION_DEBUG_SESSION_MAX_ITEMS", "8")))
DEBUG_SESSION_MAX_PER_WORKSPACE = max(1, int(os.getenv("VISION_DEBUG_SESSION_MAX_PER_WORKSPACE", "2")))
DEBUG_SESSION_MAX_MEMORY_BYTES = max(64 * 1024 * 1024, int(os.getenv("VISION_DEBUG_SESSION_MAX_MEMORY_BYTES", str(512 * 1024 * 1024))))


# 团队级功能：这些仍是文件系统实现，后续可替换为数据库/对象存储。
WORKSPACES_DIR = PROJECT_ROOT / "workspaces"
DATASETS_DIR = PROJECT_ROOT / "datasets"
RUN_HISTORY_DIR = PROJECT_ROOT / "run_history"
JOBS_DIR = PROJECT_ROOT / "jobs"
AUTH_DIR = PROJECT_ROOT / "auth"
for _directory in (WORKSPACES_DIR, DATASETS_DIR, RUN_HISTORY_DIR, JOBS_DIR, AUTH_DIR):
    _directory.mkdir(parents=True, exist_ok=True)
