from __future__ import annotations

import json
from queue import Queue
from threading import Thread
from typing import Any, Iterator

from fastapi import APIRouter, Depends
from fastapi.responses import JSONResponse, StreamingResponse

from backend.api.dependencies import get_image_store, get_model_manager, get_run_history_store, get_user_id, require_workspace_run
from backend.algorithms.ai.yolo.model_manager import YoloModelManager
from backend.models.workflow import WorkflowDebugRequest, WorkflowDebugResetRequest, WorkflowRequest
from backend.services.image_store import ImageStore
from backend.services.run_history_store import RunHistoryStore
from backend.services.workflow_debugger import DebugSessionError, workflow_debug_manager
from backend.services.workflow_engine import WorkflowExecutionError, run_workflow

router = APIRouter()


def _failure_payload(exc: Exception) -> tuple[dict[str, Any], int]:
    if isinstance(exc, WorkflowExecutionError):
        payload = exc.to_response()
        debug_session_id = getattr(exc, "debug_session_id", None)
        if debug_session_id:
            payload.update({
                "mode": "debug",
                "debug_session_id": debug_session_id,
                "workflow_signature": getattr(exc, "workflow_signature", ""),
                "current_node_id": exc.node_id,
                "next_node_id": getattr(exc, "debug_next_node_id", exc.node_id),
                "completed": False,
            })
        return payload, 400
    if isinstance(exc, DebugSessionError):
        return exc.to_response(), exc.status_code
    if isinstance(exc, (ValueError, KeyError, TypeError, OSError)):
        return {"success": False, "error": str(exc)}, 400
    return {
        "success": False,
        "error": f"服务端未处理异常：{type(exc).__name__}: {exc}",
    }, 500


@router.post("/run")
def execute_workflow(
    workflow: WorkflowRequest,
    image_store: ImageStore = Depends(get_image_store),
    model_manager: YoloModelManager = Depends(get_model_manager),
    run_history: RunHistoryStore = Depends(get_run_history_store),
    user_id: str = Depends(get_user_id),
    workspace_id: str = Depends(require_workspace_run),
):
    try:
        result = run_workflow(workflow, image_store, user_id=user_id, workspace_id=workspace_id, model_manager=model_manager)
        run_history.record_run(owner_id=workspace_id, workflow=workflow.model_dump(), result=result, kind="workflow")
        return result
    except Exception as exc:
        payload, status_code = _failure_payload(exc)
        run_history.record_run(
            owner_id=workspace_id,
            workflow=workflow.model_dump(),
            result=payload,
            kind="workflow",
            status="failed",
            error=payload.get("error"),
        )
        return JSONResponse(status_code=status_code, content=payload)


@router.post("/run-stream")
def execute_workflow_stream(
    workflow: WorkflowRequest,
    image_store: ImageStore = Depends(get_image_store),
    model_manager: YoloModelManager = Depends(get_model_manager),
    run_history: RunHistoryStore = Depends(get_run_history_store),
    user_id: str = Depends(get_user_id),
    workspace_id: str = Depends(require_workspace_run),
):
    """以 NDJSON 流推送工作流执行日志，并在最后发送完整结果。

    保留原有 ``/run`` 接口，便于脚本和旧版前端继续使用。流式接口始终以
    HTTP 200 建立连接，执行期错误通过 ``kind=error`` 的最后一条消息返回。
    """

    messages: Queue[dict[str, Any] | object] = Queue()
    sentinel = object()

    def emit(event: dict[str, Any]) -> None:
        messages.put({"kind": "log", "data": event})

    def worker() -> None:
        try:
            result = run_workflow(
                workflow,
                image_store,
                user_id=user_id,
                workspace_id=workspace_id,
                model_manager=model_manager,
                event_callback=emit,
            )
            run_history.record_run(owner_id=workspace_id, workflow=workflow.model_dump(), result=result, kind="workflow")
            messages.put({"kind": "result", "data": result})
        except Exception as exc:
            payload, status_code = _failure_payload(exc)
            run_history.record_run(
                owner_id=workspace_id,
                workflow=workflow.model_dump(),
                result=payload,
                kind="workflow",
                status="failed",
                error=payload.get("error"),
            )
            messages.put({"kind": "error", "status": status_code, "data": payload})
        finally:
            messages.put(sentinel)

    def stream() -> Iterator[str]:
        thread = Thread(target=worker, name=f"workflow-stream-{workspace_id}", daemon=True)
        thread.start()
        while True:
            item = messages.get()
            if item is sentinel:
                break
            yield json.dumps(item, ensure_ascii=False, separators=(",", ":")) + "\n"

    return StreamingResponse(
        stream(),
        media_type="application/x-ndjson; charset=utf-8",
        headers={
            "Cache-Control": "no-cache, no-transform",
            "X-Accel-Buffering": "no",
        },
    )

@router.post("/debug/run-stream")
def execute_debug_stream(
    request: WorkflowDebugRequest,
    image_store: ImageStore = Depends(get_image_store),
    model_manager: YoloModelManager = Depends(get_model_manager),
    run_history: RunHistoryStore = Depends(get_run_history_store),
    user_id: str = Depends(get_user_id),
    workspace_id: str = Depends(require_workspace_run),
):
    """流式执行单步调试或运行到指定节点。

    调试状态保存在当前服务进程内，已执行节点不会在后续单步中重复计算。
    服务重启、会话过期或工作流执行参数变化时，客户端需要重新开始调试。
    """

    messages: Queue[dict[str, Any] | object] = Queue()
    sentinel = object()

    def emit(event: dict[str, Any]) -> None:
        messages.put({"kind": "log", "data": event})

    def worker() -> None:
        try:
            result = workflow_debug_manager.run(
                request.workflow,
                image_store,
                action=request.action,
                target_node_id=request.target_node_id,
                session_id=request.session_id,
                user_id=user_id,
                workspace_id=workspace_id,
                model_manager=model_manager,
                event_callback=emit,
            )
            run_history.record_run(
                owner_id=workspace_id,
                workflow=request.workflow.model_dump(),
                result=result,
                kind=f"debug_{request.action}",
            )
            messages.put({"kind": "result", "data": result})
        except Exception as exc:
            payload, status_code = _failure_payload(exc)
            run_history.record_run(
                owner_id=workspace_id,
                workflow=request.workflow.model_dump(),
                result=payload,
                kind=f"debug_{request.action}",
                status="failed",
                error=payload.get("error"),
            )
            messages.put({"kind": "error", "status": status_code, "data": payload})
        finally:
            messages.put(sentinel)

    def stream() -> Iterator[str]:
        thread = Thread(target=worker, name=f"workflow-debug-{workspace_id}", daemon=True)
        thread.start()
        while True:
            item = messages.get()
            if item is sentinel:
                break
            yield json.dumps(item, ensure_ascii=False, separators=(",", ":")) + "\n"

    return StreamingResponse(
        stream(),
        media_type="application/x-ndjson; charset=utf-8",
        headers={
            "Cache-Control": "no-cache, no-transform",
            "X-Accel-Buffering": "no",
        },
    )


@router.post("/debug/reset")
def reset_debug_session(
    request: WorkflowDebugResetRequest,
    user_id: str = Depends(get_user_id),
    workspace_id: str = Depends(require_workspace_run),
):
    removed = workflow_debug_manager.reset(request.session_id, user_id=user_id, workspace_id=workspace_id)
    return {"success": True, "removed": removed}

