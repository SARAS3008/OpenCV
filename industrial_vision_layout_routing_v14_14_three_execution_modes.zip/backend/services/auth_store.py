from __future__ import annotations

import base64
import hashlib
import hmac
import json
import secrets
import threading
import time
from pathlib import Path
from typing import Any

from backend.algorithms.utils import safe_user_id
from backend.config import AUTH_DIR
from backend.services.file_io import atomic_write_json, exclusive_file_lock


def _now_ts() -> int:
    return int(time.time())


def _now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _normalize_email(value: str | None) -> str:
    return str(value or "").strip().lower()


class AuthStore:
    """轻量用户登录/会话服务。

    使用 PBKDF2-HMAC-SHA256 保存密码哈希，使用 Bearer token 维护会话。
    这是文件系统实现，便于当前项目直接运行；后续可以替换为数据库 + 企业 SSO。
    """

    def __init__(
        self,
        root_dir: Path = AUTH_DIR,
        *,
        session_ttl_seconds: int = 12 * 60 * 60,
        session_touch_interval_seconds: int = 5 * 60,
    ) -> None:
        self.root_dir = root_dir.resolve()
        self.root_dir.mkdir(parents=True, exist_ok=True)
        self.users_path = self.root_dir / "users.json"
        self.sessions_path = self.root_dir / "sessions.json"
        self.lock_path = self.root_dir / ".auth-store.lock"
        self.session_ttl_seconds = max(300, int(session_ttl_seconds))
        self.session_touch_interval_seconds = max(30, int(session_touch_interval_seconds))
        self._lock = threading.RLock()
        self._users: dict[str, dict[str, Any]] = self._load_records(self.users_path, "users")
        self._sessions: dict[str, dict[str, Any]] = self._load_records(self.sessions_path, "sessions")

    def _load_records(self, path: Path, key: str) -> dict[str, dict[str, Any]]:
        if not path.is_file():
            return {}
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return {}
        items = payload.get(key) if isinstance(payload, dict) else None
        if not isinstance(items, list):
            return {}
        id_key = "token" if key == "sessions" else "user_id"
        return {str(item.get(id_key)): dict(item) for item in items if isinstance(item, dict) and item.get(id_key)}

    def _write_json(self, path: Path, key: str, records: dict[str, dict[str, Any]]) -> None:
        payload = {"version": 1, key: sorted(records.values(), key=lambda item: str(item.get("created_at", "")))}
        atomic_write_json(path, payload)

    def _reload_locked(self) -> None:
        self._users = self._load_records(self.users_path, "users")
        self._sessions = self._load_records(self.sessions_path, "sessions")

    def _save_users(self) -> None:
        self._write_json(self.users_path, "users", self._users)

    def _save_sessions(self) -> None:
        self._write_json(self.sessions_path, "sessions", self._sessions)

    def _hash_password(self, password: str, salt_b64: str | None = None) -> tuple[str, str]:
        salt = base64.b64decode(salt_b64.encode("ascii")) if salt_b64 else secrets.token_bytes(16)
        digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 260_000)
        return base64.b64encode(salt).decode("ascii"), base64.b64encode(digest).decode("ascii")

    def _verify_password(self, password: str, salt_b64: str, expected_b64: str) -> bool:
        _salt, actual_b64 = self._hash_password(password, salt_b64)
        return hmac.compare_digest(actual_b64, expected_b64)

    def _find_by_email(self, email: str) -> dict[str, Any] | None:
        normalized = _normalize_email(email)
        for user in self._users.values():
            if _normalize_email(user.get("email")) == normalized:
                return user
        return None

    def register(self, *, email: str, password: str, display_name: str | None = None) -> dict[str, Any]:
        normalized_email = _normalize_email(email)
        if not normalized_email or "@" not in normalized_email:
            raise ValueError("请输入有效邮箱")
        if len(password or "") < 6:
            raise ValueError("密码至少需要 6 位")
        with self._lock:
            with exclusive_file_lock(self.lock_path):
                self._reload_locked()
                if self._find_by_email(normalized_email):
                    raise ValueError("该邮箱已注册")
                base_user_id = safe_user_id(normalized_email)
                user_id = base_user_id
                suffix = 2
                while user_id in self._users:
                    user_id = safe_user_id(f"{base_user_id}_{suffix}")
                    suffix += 1
                salt, password_hash = self._hash_password(password)
                now = _now_iso()
                user = {
                    "user_id": user_id,
                    "email": normalized_email,
                    "display_name": str(display_name or normalized_email.split("@", 1)[0])[:120],
                    "password_salt": salt,
                    "password_hash": password_hash,
                    "created_at": now,
                    "updated_at": now,
                    "default_workspace_id": f"ws_{user_id}",
                    "disabled": False,
                }
                self._users[user_id] = user
                self._save_users()
                return self.public_user(user)

    def authenticate(self, *, email: str, password: str) -> dict[str, Any]:
        with self._lock:
            with exclusive_file_lock(self.lock_path):
                self._reload_locked()
                user = self._find_by_email(email)
                if not user or user.get("disabled"):
                    raise ValueError("邮箱或密码不正确")
                if not self._verify_password(password or "", str(user.get("password_salt") or ""), str(user.get("password_hash") or "")):
                    raise ValueError("邮箱或密码不正确")
                token = secrets.token_urlsafe(32)
                now_ts = _now_ts()
                session = {
                    "token": token,
                    "user_id": user["user_id"],
                    "created_at": _now_iso(),
                    "last_seen_at": _now_iso(),
                    "last_seen_ts": now_ts,
                    "expires_at": now_ts + self.session_ttl_seconds,
                }
                self._sessions[token] = session
                self._save_sessions()
                return {"token": token, "user": self.public_user(user), "expires_at": session["expires_at"]}

    def get_user_by_token(self, token: str | None, *, touch: bool = True) -> dict[str, Any] | None:
        if not token:
            return None
        with self._lock:
            with exclusive_file_lock(self.lock_path):
                self._reload_locked()
                session = self._sessions.get(str(token))
                if not session:
                    return None
                now_ts = _now_ts()
                if int(session.get("expires_at") or 0) < now_ts:
                    self._sessions.pop(str(token), None)
                    self._save_sessions()
                    return None
                user = self._users.get(str(session.get("user_id") or ""))
                if not user or user.get("disabled"):
                    return None
                last_seen_ts = int(session.get("last_seen_ts") or 0)
                should_persist_touch = touch and (
                    now_ts - last_seen_ts >= self.session_touch_interval_seconds
                    or int(session.get("expires_at") or 0) - now_ts <= self.session_touch_interval_seconds
                )
                if should_persist_touch:
                    session["last_seen_at"] = _now_iso()
                    session["last_seen_ts"] = now_ts
                    session["expires_at"] = now_ts + self.session_ttl_seconds
                    self._save_sessions()
                return self.public_user(user)

    def logout(self, token: str | None) -> None:
        if not token:
            return
        with self._lock:
            with exclusive_file_lock(self.lock_path):
                self._reload_locked()
                self._sessions.pop(str(token), None)
                self._save_sessions()

    def get_public_user(self, user_id: str) -> dict[str, Any] | None:
        with self._lock:
            with exclusive_file_lock(self.lock_path):
                self._reload_locked()
                user = self._users.get(safe_user_id(user_id))
                return self.public_user(user) if user else None

    def public_user(self, user: dict[str, Any] | None) -> dict[str, Any]:
        if not user:
            return {}
        return {
            "user_id": user.get("user_id"),
            "email": user.get("email") or "",
            "display_name": user.get("display_name") or user.get("user_id"),
            "default_workspace_id": user.get("default_workspace_id") or f"ws_{user.get('user_id')}",
            "created_at": user.get("created_at") or "",
        }
