// 拆分自 app.bundle.legacy.js：第 497-1211 行。
let nodeDragRenderFrame = 0;

function clampZoom(value){ return Math.min(2.6, Math.max(0.18, value)); }
function applyTransform(){
  world.style.transform = `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`;
  document.getElementById("zoomLabel").textContent = `${Math.round(zoom * 100)}%`;
  const small = 20 * zoom;
  const large = 100 * zoom;
  viewport.style.backgroundSize = `${small}px ${small}px, ${small}px ${small}px, ${large}px ${large}px, ${large}px ${large}px`;
  viewport.style.backgroundPosition = `${pan.x}px ${pan.y}px, ${pan.x}px ${pan.y}px, ${pan.x}px ${pan.y}px, ${pan.x}px ${pan.y}px`;
  updateMinimap();
}
function screenToWorld(clientX, clientY){
  const rect = viewport.getBoundingClientRect();
  return { x:(clientX - rect.left - pan.x) / zoom, y:(clientY - rect.top - pan.y) / zoom, sx:clientX - rect.left, sy:clientY - rect.top };
}
function getViewportCenterWorldPoint(){
  const rect = viewport.getBoundingClientRect();
  return screenToWorld(rect.left + rect.width / 2, rect.top + rect.height / 2);
}
function setZoom(value, center){
  const next = clampZoom(value);
  if(center){
    pan.x = center.sx - center.x * next;
    pan.y = center.sy - center.y * next;
  }
  zoom = next;
  applyTransform();
  persistActiveWorkflowView();
}
function zoomBy(delta, clientX, clientY){
  const center = screenToWorld(clientX, clientY);
  setZoom(zoom * (delta > 0 ? 1.1 : 1 / 1.1), center);
}
function isCanvasEmptyTarget(target){
  if(!target) return false;
  if(target.closest && target.closest(".node,.workflow-module-frame,.port,.canvas-toolbar,.bottom-controls,.toast,button,input,label,textarea,select")) return false;
  return target === viewport || target === world || target === nodeLayer || target === edgeLayer || target.tagName === "svg" || target.tagName === "path";
}

viewport.addEventListener("wheel", event => {
  event.preventDefault();
  zoomBy(event.deltaY < 0 ? 1 : -1, event.clientX, event.clientY);
}, { passive:false });
viewport.addEventListener("dragover", event => event.preventDefault());
viewport.addEventListener("drop", event => {
  event.preventDefault();
  const type = event.dataTransfer.getData("operator/type");
  if(!type) return;
  const point = screenToWorld(event.clientX, event.clientY);
  addNode(type, point.x, point.y);
});
viewport.addEventListener("mousedown", event => {
  if(!isCanvasEmptyTarget(event.target)) return;
  if(event.button === 1 || (event.button === 0 && isSpacePanning)){
    startCanvasPan(event);
    return;
  }
  if(event.button !== 0) return;
  startModuleSelection(event);
});

function startCanvasPan(event){
  event.preventDefault();
  selectedNodeId = null;
  selectedEdgeId = null;
  selectedModuleId = null;
  previewActionNodeId = null;
  colorPaletteNodeId = null;
  render();
  const startX = event.clientX;
  const startY = event.clientY;
  const start = { ...pan };
  viewport.classList.add("panning");
  function move(moveEvent){
    pan.x = start.x + moveEvent.clientX - startX;
    pan.y = start.y + moveEvent.clientY - startY;
    applyTransform();
  }
  function up(){
    viewport.classList.remove("panning");
    window.removeEventListener("mousemove", move);
    window.removeEventListener("mouseup", up);
    persistActiveWorkflowView();
  }
  window.addEventListener("mousemove", move);
  window.addEventListener("mouseup", up);
}

function startModuleSelection(event){
  event.preventDefault();
  selectedNodeId = null;
  selectedEdgeId = null;
  selectedModuleId = null;
  previewActionNodeId = null;
  colorPaletteNodeId = null;
  render();
  const viewportRect = viewport.getBoundingClientRect();
  const startScreen = { x:event.clientX - viewportRect.left, y:event.clientY - viewportRect.top };
  const overlay = document.createElement("div");
  overlay.className = "module-selection-rect";
  overlay.style.left = `${startScreen.x}px`;
  overlay.style.top = `${startScreen.y}px`;
  overlay.style.width = "0px";
  overlay.style.height = "0px";
  viewport.appendChild(overlay);
  moduleSelectionRect = overlay;

  function move(moveEvent){
    const current = { x:moveEvent.clientX - viewportRect.left, y:moveEvent.clientY - viewportRect.top };
    const left = Math.min(startScreen.x, current.x);
    const top = Math.min(startScreen.y, current.y);
    const width = Math.abs(current.x - startScreen.x);
    const height = Math.abs(current.y - startScreen.y);
    overlay.style.left = `${left}px`;
    overlay.style.top = `${top}px`;
    overlay.style.width = `${width}px`;
    overlay.style.height = `${height}px`;
  }
  function up(upEvent){
    window.removeEventListener("mousemove", move);
    window.removeEventListener("mouseup", up);
    const endScreen = { x:upEvent.clientX - viewportRect.left, y:upEvent.clientY - viewportRect.top };
    const screenRect = {
      left:Math.min(startScreen.x, endScreen.x),
      top:Math.min(startScreen.y, endScreen.y),
      width:Math.abs(endScreen.x - startScreen.x),
      height:Math.abs(endScreen.y - startScreen.y),
    };
    if(moduleSelectionRect){
      moduleSelectionRect.remove();
      moduleSelectionRect = null;
    }
    if(screenRect.width < 12 || screenRect.height < 12){
      setStatus("已取消选择。按住空格并拖拽可以平移画布。");
      return;
    }
    const worldRect = {
      x:(screenRect.left - pan.x) / zoom,
      y:(screenRect.top - pan.y) / zoom,
      width:screenRect.width / zoom,
      height:screenRect.height / zoom,
    };
    const selectedIds = nodesInWorldRect(worldRect);
    if(!selectedIds.length){
      toast("没有选中节点", "请从节点外侧开始拖拽，并覆盖至少一个节点");
      return;
    }
    openModuleEditor({ mode:"create", nodeIds:selectedIds });
  }
  window.addEventListener("mousemove", move);
  window.addEventListener("mouseup", up);
}

function render(){
  renderNodes();
  renderEdges();
  renderParams();
  renderWorkflowExplorer();
  updateMinimap();
}

function buildLayoutGraph(){
  const nodeIds = new Set(nodes.map(node => node.id));
  const incoming = new Map(nodes.map(node => [node.id, []]));
  const outgoing = new Map(nodes.map(node => [node.id, []]));
  edges.forEach(edge => {
    if(!nodeIds.has(edge.source) || !nodeIds.has(edge.target)) return;
    incoming.get(edge.target).push(edge);
    outgoing.get(edge.source).push(edge);
  });
  return { incoming, outgoing };
}
function topologicalNodeOrderForLayout(){
  const { incoming, outgoing } = buildLayoutGraph();
  const nodeIndex = new Map(nodes.map((node, index) => [node.id, index]));
  const indegree = new Map(nodes.map(node => [node.id, incoming.get(node.id).length]));
  const queue = nodes
    .filter(node => indegree.get(node.id) === 0)
    .sort((a, b) => nodeIndex.get(a.id) - nodeIndex.get(b.id));
  const order = [];
  while(queue.length){
    const current = queue.shift();
    order.push(current.id);
    (outgoing.get(current.id) || []).forEach(edge => {
      const nextDegree = (indegree.get(edge.target) || 0) - 1;
      indegree.set(edge.target, nextDegree);
      if(nextDegree === 0){
        const target = nodes.find(node => node.id === edge.target);
        if(target) queue.push(target);
        queue.sort((a, b) => nodeIndex.get(a.id) - nodeIndex.get(b.id));
      }
    });
  }
  if(order.length !== nodes.length) return null;
  return order;
}
function compareByCurrentCanvasOrder(a, b){
  const nodeA = nodes.find(node => node.id === a);
  const nodeB = nodes.find(node => node.id === b);
  if(!nodeA || !nodeB) return 0;
  if(Math.abs(nodeA.position.y - nodeB.position.y) > 8) return nodeA.position.y - nodeB.position.y;
  return nodeA.position.x - nodeB.position.x;
}
function orderLayersByBarycenter(layers, graph){
  const layerById = new Map();
  layers.forEach((layer, index) => layer.forEach(id => layerById.set(id, index)));
  let positions = new Map();
  const refreshPositions = () => {
    positions = new Map();
    layers.forEach(layer => layer.forEach((id, index) => positions.set(id, index)));
  };
  refreshPositions();
  const scoreFromNeighbors = (id, direction) => {
    const relatedEdges = direction === "parents" ? graph.incoming.get(id) || [] : graph.outgoing.get(id) || [];
    const scores = relatedEdges
      .map(edge => direction === "parents" ? edge.source : edge.target)
      .filter(relatedId => layerById.has(relatedId))
      .map(relatedId => {
        const layerDelta = Math.abs((layerById.get(id) || 0) - (layerById.get(relatedId) || 0)) || 1;
        const position = positions.get(relatedId);
        return typeof position === "number" ? position / layerDelta : null;
      })
      .filter(value => value !== null);
    if(!scores.length) return positions.get(id) ?? 0;
    return scores.reduce((sum, value) => sum + value, 0) / scores.length;
  };
  for(let pass = 0; pass < 4; pass += 1){
    for(let layerIndex = 1; layerIndex < layers.length; layerIndex += 1){
      layers[layerIndex].sort((a, b) => scoreFromNeighbors(a, "parents") - scoreFromNeighbors(b, "parents") || compareByCurrentCanvasOrder(a, b));
    }
    refreshPositions();
    for(let layerIndex = layers.length - 2; layerIndex >= 0; layerIndex -= 1){
      layers[layerIndex].sort((a, b) => scoreFromNeighbors(a, "children") - scoreFromNeighbors(b, "children") || compareByCurrentCanvasOrder(a, b));
    }
    refreshPositions();
  }
  return layers;
}
function measureNodeForLayout(node){
  const element = nodeLayer.querySelector(`.node[data-id="${CSS.escape(node.id)}"]`);
  const width = element?.offsetWidth || NODE_WIDTH;
  const height = element?.offsetHeight || (typeof nodeHeight === "function" ? nodeHeight(node) : 240);
  return { width, height };
}
function getLayoutBounds(){
  if(!nodes.length) return null;
  let minX = Infinity;
  let minY = Infinity;
  let maxX = -Infinity;
  let maxY = -Infinity;
  nodes.forEach(node => {
    const size = measureNodeForLayout(node);
    minX = Math.min(minX, node.position.x);
    minY = Math.min(minY, node.position.y);
    maxX = Math.max(maxX, node.position.x + size.width);
    maxY = Math.max(maxY, node.position.y + size.height);
  });
  return { minX, minY, maxX, maxY, width:maxX - minX, height:maxY - minY };
}
function centerLayoutOnCurrentViewport(){
  const bounds = getLayoutBounds();
  if(!bounds) return;
  const center = typeof getViewportCenterWorldPoint === "function"
    ? getViewportCenterWorldPoint()
    : { x:bounds.minX + bounds.width / 2, y:bounds.minY + bounds.height / 2 };
  const dx = Math.round(center.x - (bounds.minX + bounds.width / 2));
  const dy = Math.round(center.y - (bounds.minY + bounds.height / 2));
  nodes.forEach(node => {
    node.position.x += dx;
    node.position.y += dy;
  });
}
function beautifyWorkflowLayout(){
  if(!nodes.length){
    toast("无需美化", "当前工作流还没有节点");
    return;
  }
  const order = topologicalNodeOrderForLayout();
  if(!order){
    toast("无法美化排线", "当前工作流存在环或非法连线，请先删除循环依赖");
    return;
  }
  const graph = buildLayoutGraph();
  const layerById = new Map();
  order.forEach(id => {
    const parents = (graph.incoming.get(id) || []).map(edge => edge.source).filter(source => layerById.has(source));
    const layer = parents.length ? Math.max(...parents.map(source => layerById.get(source))) + 1 : 0;
    layerById.set(id, layer);
  });
  const maxLayer = Math.max(...Array.from(layerById.values()), 0);
  const layers = Array.from({ length:maxLayer + 1 }, () => []);
  order.forEach(id => layers[layerById.get(id)].push(id));
  layers.forEach(layer => layer.sort(compareByCurrentCanvasOrder));
  orderLayersByBarycenter(layers, graph);

  renderNodes();
  const sizes = new Map(nodes.map(node => [node.id, measureNodeForLayout(node)]));
  const columnGap = 190;
  const rowGap = 92;
  const baseX = 260;
  const baseY = 180;
  const columnWidths = layers.map(layer => Math.max(NODE_WIDTH, ...layer.map(id => sizes.get(id)?.width || NODE_WIDTH)));
  const layerX = [];
  let cursorX = baseX;
  columnWidths.forEach(width => {
    layerX.push(cursorX);
    cursorX += width + columnGap;
  });
  const layerHeights = layers.map(layer => layer.reduce((sum, id, index) => sum + (sizes.get(id)?.height || 240) + (index ? rowGap : 0), 0));
  const maxLayerHeight = Math.max(...layerHeights, 0);
  layers.forEach((layer, layerIndex) => {
    let cursorY = baseY + Math.max(0, (maxLayerHeight - layerHeights[layerIndex]) / 2);
    layer.forEach(id => {
      const node = nodes.find(item => item.id === id);
      const size = sizes.get(id) || { width:NODE_WIDTH, height:240 };
      if(node){
        node.position = {
          x:Math.round(layerX[layerIndex] + (columnWidths[layerIndex] - size.width) / 2),
          y:Math.round(cursorY),
        };
      }
      cursorY += size.height + rowGap;
    });
  });
  centerLayoutOnCurrentViewport();
  selectedEdgeId = null;
  connectingSourceId = null;
  connectingSourceHandle = "out";
  render();
  commitActiveWorkflowChange();
  setStatus(`已美化排线：${nodes.length} 个节点按 ${layers.length} 个运行层级重新排布，${edges.length} 条连线已优化显示。`);
  toast("美化排线完成", `已按运行顺序整理 ${nodes.length} 个节点和 ${edges.length} 条连线`, true);
}

function nodeInputPorts(meta, node = null){
  if(Array.isArray(meta?.inputs)) return meta.inputs.map((port, index) => ({
    handle:String(port.handle || `in${index + 1}`),
    label:String(port.label || port.handle || "输入"),
    type:String(port.type || "any"),
    required:port.required !== false,
  }));
  return meta?.has_input ? [{ handle:"in", label:"图像", type:"image", required:true }] : [];
}
function parseDynamicOutputIndexList(value){
  const seen = new Set();
  return String(value || "")
    .split(/[\s,;，；]+/)
    .map(part => part.trim())
    .filter(Boolean)
    .map(part => Number.parseInt(part, 10))
    .filter(Number.isFinite)
    .filter(index => {
      if(index < 0 || seen.has(index)) return false;
      seen.add(index);
      return true;
    });
}
function clampDynamicOutputCount(value, maxCount){
  const parsed = Number.parseInt(value, 10);
  if(!Number.isFinite(parsed) || parsed <= 0) return 0;
  return Math.min(parsed, maxCount);
}
function resolveDynamicOutputCount(meta, node, spec){
  const params = { ...(meta?.params || {}), ...(node?.params || {}) };
  const maxCount = clampDynamicOutputCount(spec.max_count || spec.maxCount || 20, 50) || 20;
  const indexParam = spec.class_indices_param || spec.classIndicesParam;
  if(indexParam){
    const indices = parseDynamicOutputIndexList(params[indexParam]);
    if(indices.length) return Math.min(indices.length, maxCount);
  }
  const countParam = spec.count_param || spec.countParam || "top_k";
  return clampDynamicOutputCount(params[countParam], maxCount);
}
function nodeOutputPorts(meta, node = null){
  const ports = [];
  if(Array.isArray(meta?.outputs)){
    meta.outputs.forEach((port, index) => ports.push({
      handle:String(port.handle || `out${index + 1}`),
      label:String(port.label || port.handle || "输出"),
      type:String(port.type || "any"),
    }));
  }else if(meta?.has_output){
    ports.push({ handle:"out", label:"图像", type:"image" });
  }

  const existingHandles = new Set(ports.map(port => port.handle));
  if(Array.isArray(meta?.dynamic_outputs)){
    meta.dynamic_outputs.forEach(spec => {
      const prefix = String(spec.prefix || "out");
      const count = resolveDynamicOutputCount(meta, node, spec);
      for(let index = 1; index <= count; index += 1){
        const handle = `${prefix}${index}`;
        if(existingHandles.has(handle)) continue;
        const template = String(spec.label_template || spec.labelTemplate || `${prefix}{index}`);
        ports.push({
          handle,
          label:template.replaceAll("{index}", String(index)),
          type:String(spec.type || "any"),
        });
        existingHandles.add(handle);
      }
    });
  }
  return ports;
}
function portTypeClass(type){
  const normalized = String(type || "any").toLowerCase();
  return ["image", "number", "boolean", "text", "list", "any"].includes(normalized) ? normalized : "any";
}
function portRows(meta, node = null){ return Math.max(1, nodeInputPorts(meta, node).length, nodeOutputPorts(meta, node).length); }
function portTop(index){ return 70 + index * 31; }
function renderNodePortsHtml(meta, node = null){
  const inputs = nodeInputPorts(meta, node);
  const outputs = nodeOutputPorts(meta, node);
  const rows = Math.max(inputs.length, outputs.length, 1);
  const bodyRows = [];
  const ports = [];
  for(let index = 0; index < rows; index += 1){
    const input = inputs[index];
    const output = outputs[index];
    bodyRows.push(`<div class="node-port-row"><span>${input ? escapeHtml(input.label) : ""}</span><span>${output ? escapeHtml(output.label) : ""}</span></div>`);
    if(input){
      ports.push(`<div class="port in ${portTypeClass(input.type)}" data-handle="${escapeHtml(input.handle)}" data-port-index="${index}" data-port-type="${escapeHtml(input.type)}" style="top:${portTop(index)}px" title="输入：${escapeHtml(input.label)}${input.required ? "" : "（可选）"}"></div>`);
    }
    if(output){
      ports.push(`<div class="port out ${portTypeClass(output.type)}" data-handle="${escapeHtml(output.handle)}" data-port-index="${index}" data-port-type="${escapeHtml(output.type)}" style="top:${portTop(index)}px" title="输出：${escapeHtml(output.label)}"></div>`);
    }
  }
  return { rowsHtml:`<div class="node-port-list">${bodyRows.join("")}</div>`, portsHtml:ports.join("") };
}
function nodeHeight(node){
  if(node.collapsed) return 58;
  const meta = OPERATOR_META[node.type] || { params:{} };
  const count = Object.keys(meta.params || {}).length;
  return 170 + portRows(meta, node) * 31 + Math.max(1, count) * 48 + 206;
}

const MODULE_COLORS = ["#526b75", "#3f7149", "#70476c", "#8b6c37", "#3d7374", "#4b4b7d", "#8a4b4d", "#2f5f98"];

function normalizeModuleOpacity(value){
  const parsed = Number(value);
  if(!Number.isFinite(parsed)) return 0.18;
  return Math.min(0.45, Math.max(0.05, parsed));
}
function moduleNodeIds(moduleInfo){
  return (moduleInfo?.node_ids || moduleInfo?.nodeIds || []).map(String);
}
function collapsedModuleForNode(nodeId){
  return (workflowModules || []).find(moduleInfo => moduleInfo.collapsed && moduleNodeIds(moduleInfo).includes(nodeId)) || null;
}
function hiddenNodeIdsByCollapsedModules(){
  const hidden = new Set();
  (workflowModules || []).forEach(moduleInfo => {
    if(moduleInfo.collapsed) moduleNodeIds(moduleInfo).forEach(id => hidden.add(id));
  });
  return hidden;
}
function collapsedModuleMapByNodeId(){
  const map = new Map();
  (workflowModules || []).forEach(moduleInfo => {
    if(!moduleInfo.collapsed) return;
    moduleNodeIds(moduleInfo).forEach(nodeId => {
      if(!map.has(nodeId)) map.set(nodeId, moduleInfo);
    });
  });
  return map;
}
function clampNumber(value, minValue, maxValue){
  return Math.min(maxValue, Math.max(minValue, value));
}
function moduleEdgePortPoint(moduleInfo, role, referencePoint = null, fallbackY = null){
  const bounds = computeModuleBounds(moduleInfo);
  if(!bounds) return null;
  const centerY = bounds.y + bounds.height / 2;
  const y = clampNumber(Number.isFinite(fallbackY) ? fallbackY : centerY, bounds.y + 24, bounds.y + Math.max(24, bounds.height - 18));
  const centerX = bounds.x + bounds.width / 2;
  const refX = referencePoint?.x;
  let x = role === "out" ? bounds.x + bounds.width : bounds.x;
  if(Number.isFinite(refX)){
    if(role === "out" && refX < centerX) x = bounds.x;
    if(role === "in" && refX > centerX) x = bounds.x + bounds.width;
  }
  return { x, y };
}
function nodeBounds(node){
  return {
    x:node.position.x,
    y:node.position.y,
    width:NODE_WIDTH,
    height:typeof nodeHeight === "function" ? nodeHeight(node) : 240,
  };
}
function rectsIntersect(a, b){
  return a.x < b.x + b.width && a.x + a.width > b.x && a.y < b.y + b.height && a.y + a.height > b.y;
}
function nodesInWorldRect(rect){
  const hidden = hiddenNodeIdsByCollapsedModules();
  return nodes
    .filter(node => !hidden.has(node.id))
    .filter(node => rectsIntersect(rect, nodeBounds(node)))
    .map(node => node.id);
}
function computeModuleBounds(moduleInfo){
  const nodeById = new Map(nodes.map(node => [node.id, node]));
  const moduleNodes = moduleNodeIds(moduleInfo).map(id => nodeById.get(id)).filter(Boolean);
  if(!moduleNodes.length) return null;
  let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
  moduleNodes.forEach(node => {
    const bounds = nodeBounds(node);
    minX = Math.min(minX, bounds.x);
    minY = Math.min(minY, bounds.y);
    maxX = Math.max(maxX, bounds.x + bounds.width);
    maxY = Math.max(maxY, bounds.y + bounds.height);
  });
  const pad = 42;
  const natural = {
    x:minX - pad,
    y:minY - pad - 24,
    width:Math.max(260, maxX - minX + pad * 2),
    height:Math.max(130, maxY - minY + pad * 2 + 24),
    nodeCount:moduleNodes.length,
  };
  if(moduleInfo.collapsed){
    return {
      ...natural,
      width:Math.max(300, Math.min(540, natural.width)),
      height:86,
      collapsedNatural:natural,
    };
  }
  return natural;
}
function focusWorldRect(bounds){
  if(!bounds) return;
  const rect = viewport.getBoundingClientRect();
  const targetZoom = Math.min(1.05, Math.max(0.38, Math.min(rect.width / Math.max(1, bounds.width + 240), rect.height / Math.max(1, bounds.height + 200))));
  zoom = targetZoom;
  pan.x = rect.width / 2 - (bounds.x + bounds.width / 2) * zoom;
  pan.y = rect.height / 2 - (bounds.y + bounds.height / 2) * zoom;
  applyTransform();
  persistActiveWorkflowView();
}
function focusNodeInCanvas(nodeId){
  const moduleInfo = collapsedModuleForNode(nodeId);
  if(moduleInfo){
    moduleInfo.collapsed = false;
    commitActiveWorkflowChange();
  }
  const node = nodes.find(item => item.id === nodeId);
  if(!node) return;
  selectedNodeId = nodeId;
  selectedEdgeId = null;
  selectedModuleId = null;
  render();
  focusWorldRect(nodeBounds(node));
  setStatus(`已定位到节点：${nodeId}`);
}
function focusModuleInCanvas(moduleId){
  const moduleInfo = workflowModules.find(item => item.id === moduleId);
  if(!moduleInfo) return;
  selectedModuleId = moduleId;
  selectedNodeId = null;
  selectedEdgeId = null;
  render();
  focusWorldRect(computeModuleBounds(moduleInfo));
  setStatus(`已定位到模块：${moduleInfo.name || moduleId}`);
}
function moduleElementById(moduleId){
  return Array.from(document.querySelectorAll(".workflow-module-frame")).find(element => element.dataset.moduleId === moduleId) || null;
}
function startDragCollapsedModule(event, moduleId){
  const moduleInfo = workflowModules.find(item => item.id === moduleId);
  if(!moduleInfo || !moduleInfo.collapsed || event.button !== 0) return false;
  if(event.target.closest("button,input,textarea,select")) return false;
  event.preventDefault();
  event.stopPropagation();
  const nodeIds = new Set(moduleNodeIds(moduleInfo));
  const draggedNodes = nodes.filter(node => nodeIds.has(node.id));
  if(!draggedNodes.length) return false;
  selectedModuleId = moduleId;
  selectedNodeId = null;
  selectedEdgeId = null;
  previewActionNodeId = null;
  colorPaletteNodeId = null;
  const startClient = { x:event.clientX, y:event.clientY };
  const startPositions = new Map(draggedNodes.map(node => [node.id, { x:node.position.x, y:node.position.y }]));
  let moved = false;
  viewport.classList.add("panning");
  function move(moveEvent){
    const dx = (moveEvent.clientX - startClient.x) / zoom;
    const dy = (moveEvent.clientY - startClient.y) / zoom;
    if(Math.abs(dx) > 0.5 || Math.abs(dy) > 0.5) moved = true;
    draggedNodes.forEach(node => {
      const original = startPositions.get(node.id);
      node.position = { x:Math.round(original.x + dx), y:Math.round(original.y + dy) };
    });
    render();
    const element = moduleElementById(moduleId);
    if(element) element.classList.add("dragging");
  }
  function up(){
    viewport.classList.remove("panning");
    window.removeEventListener("mousemove", move);
    window.removeEventListener("mouseup", up);
    const element = moduleElementById(moduleId);
    if(element) element.classList.remove("dragging");
    render();
    if(moved){
      commitActiveWorkflowChange();
      setStatus(`已移动折叠模块：${moduleInfo.name || moduleId}`);
    }
  }
  render();
  window.addEventListener("mousemove", move);
  window.addEventListener("mouseup", up);
  return true;
}
function renderWorkflowModules(){
  (workflowModules || []).forEach(moduleInfo => {
    const bounds = computeModuleBounds(moduleInfo);
    if(!bounds) return;
    const element = document.createElement("div");
    element.className = `workflow-module-frame ${selectedModuleId === moduleInfo.id ? "selected" : ""} ${moduleInfo.collapsed ? "collapsed" : ""}`;
    element.dataset.moduleId = moduleInfo.id;
    element.style.left = `${bounds.x}px`;
    element.style.top = `${bounds.y}px`;
    element.style.width = `${bounds.width}px`;
    element.style.height = `${bounds.height}px`;
    element.style.setProperty("--module-accent", safeColor(moduleInfo.color || "#526b75"));
    element.style.setProperty("--module-opacity", String(normalizeModuleOpacity(moduleInfo.opacity)));
    element.style.setProperty("--module-opacity-percent", `${Math.round(normalizeModuleOpacity(moduleInfo.opacity) * 100)}%`);
    const nodeCount = bounds.nodeCount || moduleNodeIds(moduleInfo).length;
    const summary = moduleInfo.collapsed ? `已折叠 · ${nodeCount} 节点` : `${nodeCount} 节点`;
    element.innerHTML = `<div class="workflow-module-head">
      <button type="button" data-module-action="toggle" title="折叠/展开模块">${moduleInfo.collapsed ? "▸" : "▾"}</button>
      <strong title="${escapeHtml(moduleInfo.description || moduleInfo.name || "功能模块")}">${escapeHtml(moduleInfo.name || "功能模块")}</strong>
      <span>${escapeHtml(summary)}</span>
      <button type="button" data-module-action="focus" title="定位模块">⌖</button>
      <button type="button" data-module-action="edit" title="编辑模块样式">⚙</button>
      <button type="button" data-module-action="delete" title="解除模块">×</button>
    </div>
    ${moduleInfo.collapsed ? `<div class="workflow-module-collapsed-body"><b>${escapeHtml(moduleInfo.name || "功能模块")}</b><small>点击 ▸ 展开内部节点</small></div>` : ""}`;
    element.addEventListener("mousedown", event => {
      if(startDragCollapsedModule(event, moduleInfo.id)) return;
      event.stopPropagation();
      selectedModuleId = moduleInfo.id;
      selectedNodeId = null;
      selectedEdgeId = null;
      render();
    });
    element.addEventListener("dblclick", event => {
      event.stopPropagation();
      openModuleEditor({ mode:"edit", moduleId:moduleInfo.id });
    });
    element.querySelectorAll("button[data-module-action]").forEach(button => {
      button.addEventListener("mousedown", event => event.stopPropagation());
      button.addEventListener("click", event => {
        event.stopPropagation();
        const action = button.dataset.moduleAction;
        if(action === "edit") openModuleEditor({ mode:"edit", moduleId:moduleInfo.id });
        else if(action === "delete") deleteWorkflowModule(moduleInfo.id);
        else if(action === "toggle") toggleWorkflowModule(moduleInfo.id);
        else if(action === "focus") focusModuleInCanvas(moduleInfo.id);
      });
    });
    nodeLayer.appendChild(element);
  });
}

function renderNodes(){
  nodeLayer.innerHTML = "";
  const hiddenNodes = hiddenNodeIdsByCollapsedModules();
  if(selectedNodeId && hiddenNodes.has(selectedNodeId)) selectedNodeId = null;
  renderWorkflowModules();
  nodes.filter(node => !hiddenNodes.has(node.id)).forEach(node => {
    const meta = OPERATOR_META[node.type] || { label:node.type, params:{}, has_input:true, has_output:true };
    const selected = selectedNodeId === node.id;
    const preview = nodePreviews.get(node.id);
    const accent = safeColor(node.color || DEFAULT_NODE_COLOR);
    const portMarkup = renderNodePortsHtml(meta, node);
    const element = document.createElement("div");
    const executionClass = preview?.status === "error" ? "execution-error" : preview?.status === "success" ? "execution-success" : "";
    const debugClasses = [
      debugExecutedNodeIds.has(node.id) ? "debug-completed" : "",
      debugCurrentNodeId === node.id ? "debug-current" : "",
      debugNextNodeId === node.id ? "debug-next" : "",
      debugTargetNodeId === node.id ? "debug-target" : "",
    ].filter(Boolean).join(" ");
    element.className = `node ${selected ? "selected" : ""} ${node.collapsed ? "collapsed" : ""} ${executionClass} ${debugClasses}`;
    element.dataset.id = node.id;
    element.style.left = `${node.position.x}px`;
    element.style.top = `${node.position.y}px`;
    element.style.setProperty("--node-accent", accent);

    element.innerHTML = `
      ${renderNodeToolbarHtml(node)}
      ${selected && colorPaletteNodeId === node.id ? renderColorPaletteHtml(node) : ""}
      <div class="node-head">
        <div class="node-title"><button class="fold-btn" type="button" title="折叠/展开">▾</button><span>${escapeHtml(meta.label)}</span></div>
        <div class="node-badge">${escapeHtml(node.id)}</div>
      </div>
      ${portMarkup.portsHtml}
      <div class="node-body">
        ${portMarkup.rowsHtml}
        <div class="node-param-list"></div>
        <div class="node-effect ${nodeResultType(node, preview)}-result">
          <div class="node-effect-title"><span>${resultTypeLabel(nodeResultType(node, preview), node)}</span><span class="${preview ? (preview.status === "error" ? "result-error" : "result-ready") : ""}">${preview ? (preview.status === "error" ? "失败" : "已生成") : "等待运行"}</span></div>
          ${renderNodePreviewHtml(node, preview)}
        </div>
      </div>`;

    attachNodeEvents(element, node, meta);
    renderNodeParameterControls(element.querySelector(".node-param-list"), node, meta);
    nodeLayer.appendChild(element);
  });
  if(typeof updateRunModeUi === "function") updateRunModeUi();
}

function renderNodeToolbarHtml(node){
  return `<div class="node-toolbar" data-stop-node-drag>
    <button type="button" data-node-action="delete" title="删除节点" aria-label="删除节点">🗑</button>
    <span class="divider"></span>
    <button type="button" data-node-action="info" title="查看节点信息">ⓘ</button>
    <button type="button" class="node-color-button" data-node-action="color" title="更改节点配色">●</button>
    <button type="button" data-node-action="duplicate" title="复制节点">⧉</button>
    <button type="button" data-node-action="collapse" title="${node.collapsed ? "展开节点" : "折叠节点"}">↕</button>
  </div>`;
}

function renderColorPaletteHtml(node){
  const current = safeColor(node.color || DEFAULT_NODE_COLOR);
  return `<div class="node-color-palette" data-stop-node-drag>${NODE_COLORS.map(color => `<button type="button" class="node-color-swatch ${color === current ? "active" : ""}" style="background:${color}" data-node-color="${color}" title="使用 ${color}"></button>`).join("")}</div>`;
}

function previewMetricEntries(preview){
  if(!preview || !preview.metrics || typeof preview.metrics !== "object" || Array.isArray(preview.metrics)) return [];
  return Object.entries(preview.metrics);
}

function nodeResultType(node, preview){
  if(preview?.result_type === "error" || preview?.status === "error") return "error";
  const hasImage = Boolean(preview?.image);
  const hasMetrics = previewMetricEntries(preview).length > 0;
  if(hasImage && hasMetrics) return "combined";
  if(hasMetrics || preview?.result_type === "metrics") return "metrics";
  if(hasImage || preview?.result_type === "image") return "image";
  const meta = OPERATOR_META[node.type] || {};
  return meta.result_type === "metrics" || meta.kind === "logic" ? "metrics" : "image";
}

function resultTypeLabel(resultType, node = null){
  const meta = node ? (OPERATOR_META[node.type] || {}) : {};
  if(resultType === "error") return "执行错误";
  if(resultType === "combined") return meta.kind === "logic" ? "图像与逻辑结果" : "图像与数值结果";
  if(resultType === "metrics") return meta.kind === "logic" ? "逻辑结果" : "数值结果";
  return "图像结果";
}

function renderNodeErrorHtml(preview){
  const message = preview?.error || "节点执行失败";
  return `<div class="node-error-frame"><div class="node-error-title">该节点执行失败</div><div class="node-error-message">${escapeHtml(message)}</div></div>`;
}

function humanizeMetricName(name){
  const labels = {
    mean_brightness:"平均亮度",
    brightness_std:"亮度标准差",
    contour_count:"轮廓数量",
    contour_area_total:"轮廓总面积",
    contour_area_max:"最大轮廓面积",
  };
  return labels[name] || String(name).replace(/[_-]+/g, " ");
}

function formatMetricValue(value){
  if(typeof value === "number"){
    if(!Number.isFinite(value)) return String(value);
    return Number.isInteger(value) ? String(value) : value.toFixed(4).replace(/0+$/, "").replace(/\.$/, "");
  }
  if(typeof value === "boolean") return value ? "是" : "否";
  if(value === null || value === undefined) return "—";
  if(typeof value === "object") return JSON.stringify(value);
  return String(value);
}

function renderMetricResultHtml(preview, compact = false){
  const entries = previewMetricEntries(preview);
  const frameClass = compact ? "preview-metric-frame" : "node-metric-frame";
  if(!entries.length){
    return `<div class="${frameClass}"><div class="node-effect-empty">运行流程后，这里会显示数值结果</div></div>`;
  }
  const rows = entries.map(([key, value]) => `<div class="metric-row"><span>${escapeHtml(humanizeMetricName(key))}</span><strong>${escapeHtml(formatMetricValue(value))}</strong></div>`).join("");
  return `<div class="${frameClass}"><div class="metric-list">${rows}</div></div>`;
}

function renderImageResultHtml(node, preview){
  if(!preview || !preview.image){
    return `<div class="node-effect-frame" data-preview-node="${escapeHtml(node.id)}"><div class="node-effect-empty">运行流程后，这里会显示当前节点的完整缩略图</div></div>`;
  }
  const showActions = previewActionNodeId === node.id;
  return `<div class="node-effect-frame" data-preview-node="${escapeHtml(node.id)}" title="点击显示图片操作">
    <img src="${preview.image}" alt="${escapeHtml(preview.label || node.id)} 的处理结果" />
    <span class="node-effect-hint">点击显示下载和放大按钮</span>
    ${showActions ? `<div class="node-effect-actions" data-stop-node-drag>
      <button type="button" data-preview-action="download">⇩ 下载</button>
      <button type="button" class="primary" data-preview-action="zoom">⛶ 放大</button>
    </div>` : ""}
  </div>`;
}

function renderNodePreviewHtml(node, preview){
  const resultType = nodeResultType(node, preview);
  if(resultType === "error") return renderNodeErrorHtml(preview);
  if(resultType === "combined"){
    return `<div class="node-combined-result">${renderImageResultHtml(node, preview)}${renderMetricResultHtml(preview)}</div>`;
  }
  if(resultType === "metrics") return renderMetricResultHtml(preview);
  return renderImageResultHtml(node, preview);
}


function incomingEdgeFor(nodeId, handle){
  return edges.find(item => item.target === nodeId && (item.targetHandle || "in") === handle) || null;
}
function connectedInputHandles(nodeId){
  const handles = new Set();
  edges.forEach(edge => {
    if(edge.target === nodeId) handles.add(edge.targetHandle || "in");
  });
  return handles;
}
function nodeDisplayName(nodeId){
  const node = nodes.find(item => item.id === nodeId);
  if(!node) return nodeId;
  const meta = OPERATOR_META[node.type] || {};
  return `${meta.label || node.type} · ${node.id}`;
}
function edgeSourceText(edge){
  if(!edge) return "未连接";
  return `${nodeDisplayName(edge.source)}.${edge.sourceHandle || "out"}`;
}
function normalizedFallbackHandles(schema){
  const raw = schema?.fallback_for ?? schema?.fallback_input ?? schema?.fallback_inputs;
  if(!raw) return [];
  return Array.isArray(raw) ? raw.map(item => String(item)) : [String(raw)];
}
function paramOverrideInfo(node, schema){
  const handles = normalizedFallbackHandles(schema);
  for(const handle of handles){
    const edge = incomingEdgeFor(node.id, handle);
    if(edge){
      return { overridden:true, handle, edge, source:edgeSourceText(edge) };
    }
  }
  return { overridden:false, handle:handles[0] || "", edge:null, source:"" };
}
function disableParamControl(control, disabled){
  control.classList.toggle("overridden", Boolean(disabled));
  control.querySelectorAll("input, select, textarea, button").forEach(element => {
    element.disabled = Boolean(disabled);
    element.setAttribute("aria-disabled", disabled ? "true" : "false");
  });
  control.querySelectorAll("label.node-file-button").forEach(element => {
    element.classList.toggle("disabled", Boolean(disabled));
    element.setAttribute("aria-disabled", disabled ? "true" : "false");
  });
}
function renderNodeInputInspectorHtml(node, meta){
  const inputPorts = nodeInputPorts(meta, node);
  if(!inputPorts.length){
    return `<div class="node-inspector-section"><div class="node-inspector-title">输入来源</div><div class="node-inspector-empty">该节点没有输入端口。</div></div>`;
  }
  const rows = inputPorts.map(port => {
    const handle = port.handle || "in";
    const edge = incomingEdgeFor(node.id, handle);
    const stateClass = edge ? "connected" : (port.required ? "missing" : "optional");
    const stateText = edge ? "已连接" : (port.required ? "未连接" : "可选");
    const source = edge ? edgeSourceText(edge) : "—";
    const requiredText = port.required ? "必需" : "可选";
    return `<div class="node-input-inspector-row ${stateClass}">
      <div><b>${escapeHtml(port.label || handle)}</b><span>${escapeHtml(handle)} · ${escapeHtml(port.type || "any")} · ${requiredText}</span></div>
      <div><em>${stateText}</em><span>${escapeHtml(source)}</span></div>
    </div>`;
  }).join("");
  const policyRows = (meta.input_policy?.rules || []).map(rule => {
    const edge = incomingEdgeFor(node.id, rule.input);
    const params = (rule.fallback_params || []).join(", ");
    const state = edge ? `当前使用端口输入：${edgeSourceText(edge)}` : `当前使用手动参数：${params}`;
    return `<div class="node-input-policy-row ${edge ? "using-input" : "using-params"}">
      <b>${escapeHtml(rule.input)}</b>
      <span>${escapeHtml(state)}</span>
      <small>${escapeHtml(rule.description || "端口连接时覆盖对应手动参数。")}</small>
    </div>`;
  }).join("");
  return `<div class="node-inspector-section">
    <div class="node-inspector-title">输入来源</div>
    <div class="node-input-inspector">${rows}</div>
    ${policyRows ? `<div class="node-inspector-title secondary">输入优先级</div><div class="node-input-policy">${policyRows}</div>` : ""}
  </div>`;
}

function attachNodeEvents(element, node, meta){
  element.addEventListener("mousedown", event => {
    if(event.target.closest("input,select,button,.node-effect-frame,.node-color-palette")) return;
    if(selectedNodeId !== node.id){
      selectedNodeId = node.id;
      selectedEdgeId = null;
      colorPaletteNodeId = null;
      render();
    }
  });

  const head = element.querySelector(".node-head");
  head.addEventListener("mousedown", event => startDragNode(event, node.id));
  element.querySelector(".fold-btn").addEventListener("click", event => {
    event.stopPropagation();
    node.collapsed = !node.collapsed;
    render();
    commitActiveWorkflowChange();
  });

  element.querySelectorAll("[data-node-action]").forEach(button => {
    button.addEventListener("mousedown", event => event.stopPropagation());
    button.addEventListener("click", event => {
      event.stopPropagation();
      const action = button.dataset.nodeAction;
      if(action === "delete") deleteNode(node.id);
      else if(action === "info"){
        setStatus(`${node.id} · ${meta.label}：${meta.description || "暂无说明"}`);
        toast("节点说明", meta.description || meta.label, true);
      }else if(action === "color"){
        colorPaletteNodeId = colorPaletteNodeId === node.id ? null : node.id;
        renderNodes();
      }else if(action === "duplicate") duplicateNode(node.id);
      else if(action === "collapse"){
        node.collapsed = !node.collapsed;
        render();
        commitActiveWorkflowChange();
      }
    });
  });

  element.querySelectorAll("[data-node-color]").forEach(button => {
    button.addEventListener("mousedown", event => event.stopPropagation());
    button.addEventListener("click", event => {
      event.stopPropagation();
      node.color = safeColor(button.dataset.nodeColor);
      colorPaletteNodeId = null;
      renderNodes();
      commitActiveWorkflowChange();
      setStatus(`已更新 ${node.id} 的节点配色`);
    });
  });

  const previewFrame = element.querySelector(".node-effect-frame");
  if(previewFrame){
    previewFrame.addEventListener("mousedown", event => event.stopPropagation());
    previewFrame.addEventListener("click", event => {
      event.stopPropagation();
      selectedNodeId = node.id;
      selectedEdgeId = null;
      if(!nodePreviews.has(node.id)){
        render();
        return;
      }
      previewActionNodeId = previewActionNodeId === node.id ? null : node.id;
      renderNodes();
      renderParams();
    });
  }
  const downloadButton = element.querySelector('[data-preview-action="download"]');
  if(downloadButton){
    downloadButton.addEventListener("click", event => {
      event.stopPropagation();
      downloadNodePreview(node.id);
    });
  }
  const zoomButton = element.querySelector('[data-preview-action="zoom"]');
  if(zoomButton){
    zoomButton.addEventListener("click", event => {
      event.stopPropagation();
      openImageLightbox(node.id);
    });
  }

  element.querySelectorAll(".port.out").forEach(outPort => {
    const handle = outPort.dataset.handle || "out";
    outPort.onclick = event => { event.stopPropagation(); startConnect(node.id, handle); };
    outPort.addEventListener("mousedown", event => startConnectDrag(event, node.id, handle));
  });
  element.querySelectorAll(".port.in").forEach(inPort => {
    const handle = inPort.dataset.handle || "in";
    inPort.onclick = event => {
      event.stopPropagation();
      if(connectingSourceId) finishConnect(node.id, handle);
      else selectIncomingEdge(node.id, handle);
    };
    inPort.addEventListener("mousedown", event => {
      if(connectingSourceId){
        event.stopPropagation();
        finishConnect(node.id, handle);
      }
    });
  });
}

function renderNodeParameterControls(container, node, meta){
  const keys = Object.keys(meta.params || {});
  if(!keys.length){
    const empty = document.createElement("div");
    empty.className = "node-no-params";
    empty.textContent = "该节点没有可调参数";
    container.appendChild(empty);
    return;
  }

  keys.forEach(key => {
    const schema = (meta.param_schema || {})[key] || {};
    const value = node.params[key] ?? meta.params[key];
    const overrideInfo = paramOverrideInfo(node, schema);
    const row = document.createElement("div");
    row.className = "node-param-row";
    if(overrideInfo.overridden) row.classList.add("param-overridden");
    if(node.type === "PythonSnippet" && key === "code") row.classList.add("python-code-param-row");
    const label = document.createElement("div");
    label.className = "node-param-label";
    label.textContent = schema.label || humanizeParam(key);
    label.title = schema.label || key;
    const control = document.createElement("div");
    control.className = "node-param-control";

    if(node.type === "PythonSnippet" && key === "code" && typeof window.renderPythonSnippetInlineEditor === "function"){
      window.renderPythonSnippetInlineEditor(control, node, key, value, schema);
    }else if(schema.type === "file"){
      const picker = document.createElement("div");
      picker.className = "node-file-param";
      const pathInput = document.createElement("input");
      pathInput.className = "node-param-input node-file-path";
      pathInput.type = "text";
      pathInput.value = value ?? "";
      pathInput.placeholder = schema.placeholder || "选择文件或填写服务器路径";
      pathInput.addEventListener("mousedown", event => selectNodeWithoutRerender(node.id, event));
      pathInput.onchange = () => updateNodeParam(node.id, key, pathInput.value);

      const fileId = `file_${node.id}_${key}`.replace(/[^A-Za-z0-9_\-]/g, "_");
      const fileInput = document.createElement("input");
      fileInput.type = "file";
      fileInput.id = fileId;
      fileInput.accept = schema.accept || "";
      fileInput.addEventListener("mousedown", event => selectNodeWithoutRerender(node.id, event));
      fileInput.onchange = async () => {
        const file = fileInput.files && fileInput.files[0];
        if(!file) return;
        try{
          setStatus(`正在上传模型文件：${file.name}...`);
          const data = await VisionApi.uploadModel(file);
          updateNodeParam(node.id, key, data.model_path || "");
          toast("模型上传完成", data.model_path || file.name, true);
        }catch(error){
          const message = error?.message || String(error);
          toast("模型上传失败", message);
          setStatus(`模型上传失败：${message}`);
        }finally{
          fileInput.value = "";
        }
      };

      const button = document.createElement("label");
      button.className = "node-file-button";
      button.htmlFor = fileId;
      button.textContent = "选择";
      button.title = "选择并上传模型文件";
      picker.append(pathInput, fileInput, button);
      control.appendChild(picker);
    }else if(schema.type === "select"){
      const select = document.createElement("select");
      select.className = "node-param-select";
      (schema.options || []).forEach(optionInfo => {
        const option = document.createElement("option");
        option.value = optionInfo.value;
        option.textContent = optionInfo.label;
        option.selected = String(optionInfo.value) === String(value);
        select.appendChild(option);
      });
      select.addEventListener("mousedown", event => selectNodeWithoutRerender(node.id, event));
      select.onchange = () => updateNodeParam(node.id, key, select.value);
      control.appendChild(select);
    }else if(schema.type === "textarea"){
      const textarea = document.createElement("textarea");
      textarea.className = "node-param-textarea";
      textarea.value = value ?? "";
      textarea.placeholder = schema.placeholder || "";
      textarea.rows = Math.max(4, Number(schema.rows || 8));
      textarea.spellcheck = false;
      textarea.addEventListener("mousedown", event => selectNodeWithoutRerender(node.id, event));
      textarea.addEventListener("keydown", event => {
        if((event.ctrlKey || event.metaKey) && event.key === "Enter"){
          event.preventDefault();
          updateNodeParam(node.id, key, textarea.value);
        }
      });
      textarea.onchange = () => updateNodeParam(node.id, key, textarea.value);
      control.appendChild(textarea);
    }else if(schema.type === "text" || typeof value === "string"){
      const input = document.createElement("input");
      input.className = "node-param-input";
      input.type = "text";
      input.value = value ?? "";
      input.placeholder = schema.placeholder || "";
      input.addEventListener("mousedown", event => selectNodeWithoutRerender(node.id, event));
      input.onchange = () => updateNodeParam(node.id, key, input.value);
      control.appendChild(input);
    }else{
      const stepper = document.createElement("div");
      stepper.className = "node-param-stepper";
      const minus = document.createElement("button");
      minus.type = "button";
      minus.textContent = "−";
      const input = document.createElement("input");
      input.type = "number";
      input.value = value;
      input.step = numericStep(value, key);
      const plus = document.createElement("button");
      plus.type = "button";
      plus.textContent = "+";
      [minus, input, plus].forEach(item => item.addEventListener("mousedown", event => selectNodeWithoutRerender(node.id, event)));
      minus.onclick = event => {
        event.stopPropagation();
        const step = Number(input.step) || 1;
        updateNodeParam(node.id, key, numberValue(value) - step);
      };
      plus.onclick = event => {
        event.stopPropagation();
        const step = Number(input.step) || 1;
        updateNodeParam(node.id, key, numberValue(value) + step);
      };
      input.onchange = () => updateNodeParam(node.id, key, Number(input.value));
      stepper.append(minus, input, plus);
      control.appendChild(stepper);
    }

    disableParamControl(control, overrideInfo.overridden);
    row.append(label, control);
    if(schema.help || overrideInfo.overridden || normalizedFallbackHandles(schema).length){
      const help = document.createElement("div");
      help.className = "node-param-help";
      if(overrideInfo.overridden){
        help.innerHTML = `<b>已被输入端口覆盖：</b>${escapeHtml(overrideInfo.handle)} ← ${escapeHtml(overrideInfo.source)}。断开该连线后此参数才会生效。`;
      }else{
        help.textContent = schema.help || `未连接 ${normalizedFallbackHandles(schema).join("/")} 输入端口时，此参数会作为兜底值生效。`;
      }
      row.appendChild(help);
    }
    container.appendChild(row);
  });
}

function selectNodeWithoutRerender(nodeId, event){
  event.stopPropagation();
  selectedNodeId = nodeId;
  selectedEdgeId = null;
  colorPaletteNodeId = null;
  document.querySelectorAll(".node").forEach(element => element.classList.toggle("selected", element.dataset.id === nodeId));
  renderParams();
  if(typeof updateRunModeUi === "function") updateRunModeUi();
}

function humanizeParam(key){
  const names = {
    image_path:"图片路径", mode:"转换模式", ksize:"核尺寸", sigma:"Sigma", clip_limit:"裁剪限制",
    tile_grid:"网格大小", d:"邻域直径", sigma_color:"颜色 Sigma", sigma_space:"空间 Sigma",
    amount:"锐化强度", threshold:"阈值", max_value:"最大值", block_size:"块大小", c:"常数 C",
    threshold1:"低阈值", threshold2:"高阈值", dx:"X 阶数", dy:"Y 阶数", iterations:"迭代次数",
    scale_percent:"缩放百分比", flip_code:"翻转模式", direction:"旋转方向", min_area:"最小面积", model_path:"模型文件", task:"推理任务", confidence:"置信度阈值", iou:"IoU 阈值", imgsz:"输入尺寸", max_det:"最大检测数", max_results:"输出结果上限", class_filter:"类别过滤", class_indices:"类别Index", selection_mode:"筛选模式", min_confidence:"最低置信度", top_k:"保留数量", sort_by:"排序方式", require_exact_count:"目标缺失时报错", include_geometry:"输出几何数据", max_geometry_points:"几何点上限", output_mode:"图像输出", device:"设备",
  };
  return names[key] || key;
}
function numericStep(value, key){
  if(["sigma", "clip_limit", "amount", "min_area", "confidence", "iou", "min_confidence", "top_confidence"].includes(key) || !Number.isInteger(Number(value))) return "0.1";
  return "1";
}
function numberValue(value){
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : 0;
}
function pruneInvalidEdgesForNode(nodeId){
  const node = nodes.find(item => item.id === nodeId);
  if(!node) return 0;
  const meta = OPERATOR_META[node.type] || {};
  const outputHandles = new Set(nodeOutputPorts(meta, node).map(port => port.handle));
  const inputHandles = new Set(nodeInputPorts(meta, node).map(port => port.handle));
  const before = edges.length;
  edges = edges.filter(edge => {
    if(edge.source === nodeId && !outputHandles.has(edge.sourceHandle || "out")) return false;
    if(edge.target === nodeId && !inputHandles.has(edge.targetHandle || "in")) return false;
    return true;
  });
  return before - edges.length;
}
function updateNodeParam(nodeId, key, value){
  const node = nodes.find(item => item.id === nodeId);
  if(!node) return;
  node.params[key] = value;
  invalidateNodeAndDownstreamPreviews(nodeId);
  const removedEdges = pruneInvalidEdgesForNode(nodeId);
  selectedNodeId = nodeId;
  selectedEdgeId = null;
  render();
  commitActiveWorkflowChange();
  const edgeText = removedEdges ? `，并移除了 ${removedEdges} 条已失效连线` : "";
  setStatus(`已更新参数：${node.id}.${key} = ${value}${edgeText}；请重新运行流程`);
}
function invalidateNodeAndDownstreamPreviews(nodeId){
  const pending = [nodeId];
  const affected = new Set();
  while(pending.length){
    const current = pending.shift();
    if(affected.has(current)) continue;
    affected.add(current);
    edges.filter(edge => edge.source === current).forEach(edge => pending.push(edge.target));
  }
  affected.forEach(id => nodePreviews.delete(id));
  if(affected.has(previewActionNodeId)) previewActionNodeId = null;
  if(affected.has(lightboxNodeId)) closeImageLightbox();
}

function findPortDefinition(nodeId, direction, handle){
  const node = nodes.find(item => item.id === nodeId);
  const meta = OPERATOR_META[node?.type] || {};
  const ports = direction === "out" ? nodeOutputPorts(meta, node) : nodeInputPorts(meta, node);
  return ports.find(port => port.handle === handle) || null;
}
function portsAreCompatible(sourceType, targetType){
  const source = String(sourceType || "any").toLowerCase();
  const target = String(targetType || "any").toLowerCase();
  if(source === "any" || target === "any") return true;
  if(source === target) return true;
  return source === "number" && target === "boolean";
}
function startConnect(id, handle = "out"){
  const sourcePort = findPortDefinition(id, "out", handle);
  if(!sourcePort){ toast("连线失败", `源节点不存在输出端口：${handle}`); return; }
  connectingSourceId = id;
  connectingSourceHandle = handle;
  selectedEdgeId = null;
  renderEdges();
  setStatus(`请选择目标节点输入端口：${id}.${handle} → ?`);
}
function startConnectDrag(event, id, handle = "out"){
  if(event.button !== 0) return;
  event.stopPropagation();
  event.preventDefault();
  startConnect(id, handle);
  connectDrag = { source:id, sourceHandle:handle };
  drawTempEdge(event.clientX, event.clientY);
  function move(moveEvent){ drawTempEdge(moveEvent.clientX, moveEvent.clientY); }
  function up(upEvent){
    window.removeEventListener("mousemove", move);
    window.removeEventListener("mouseup", up);
    clearTempEdge();
    const target = document.elementFromPoint(upEvent.clientX, upEvent.clientY);
    const port = target && target.closest ? target.closest(".port.in") : null;
    const nodeElement = port && port.closest ? port.closest(".node") : null;
    const targetId = nodeElement ? nodeElement.dataset.id : null;
    const targetHandle = port?.dataset.handle || "in";
    if(targetId) finishConnect(targetId, targetHandle);
    else setStatus(`已选择源端口：${id}.${handle}，请点击目标节点输入端口`);
    connectDrag = null;
  }
  window.addEventListener("mousemove", move);
  window.addEventListener("mouseup", up);
}
function finishConnect(targetId, targetHandle = "in"){
  if(!connectingSourceId || connectingSourceId === targetId) return;
  const sourcePort = findPortDefinition(connectingSourceId, "out", connectingSourceHandle);
  const targetPort = findPortDefinition(targetId, "in", targetHandle);
  if(!sourcePort){ toast("连线失败", "源输出端口不存在"); connectingSourceId = null; return; }
  if(!targetPort){ toast("连线失败", "目标输入端口不存在"); connectingSourceId = null; return; }
  if(!portsAreCompatible(sourcePort.type, targetPort.type)){
    toast("端口类型不兼容", `${sourcePort.label}（${sourcePort.type}）不能连接到 ${targetPort.label}（${targetPort.type}）`);
    connectingSourceId = null;
    connectingSourceHandle = "out";
    clearTempEdge();
    return;
  }
  edges = edges.filter(edge => !(edge.target === targetId && edge.targetHandle === targetHandle));
  const edgeId = `e${Date.now()}_${Math.random().toString(16).slice(2, 7)}`;
  edges.push({
    id:edgeId,
    source:connectingSourceId,
    sourceHandle:connectingSourceHandle,
    target:targetId,
    targetHandle,
  });
  const message = `${connectingSourceId}.${connectingSourceHandle} → ${targetId}.${targetHandle}`;
  invalidateNodeAndDownstreamPreviews(targetId);
  connectingSourceId = null;
  connectingSourceHandle = "out";
  selectedEdgeId = edgeId;
  selectedNodeId = null;
  render();
  commitActiveWorkflowChange();
  setStatus(`已创建连线：${message}`);
  toast("已创建连线", message, true);
}

function startDragNode(event, nodeId){
  if(event.button !== 0 || event.target.closest("button,input,select")) return;
  event.stopPropagation();
  selectedNodeId = nodeId;
  selectedEdgeId = null;
  colorPaletteNodeId = null;
  document.querySelectorAll(".node").forEach(element => element.classList.toggle("selected", element.dataset.id === nodeId));
  renderParams();
  if(typeof updateRunModeUi === "function") updateRunModeUi();
  const node = nodes.find(item => item.id === nodeId);
  const startX = event.clientX;
  const startY = event.clientY;
  const start = { ...node.position };
  function scheduleDragRender(){
    if(nodeDragRenderFrame) return;
    nodeDragRenderFrame = window.requestAnimationFrame(() => {
      nodeDragRenderFrame = 0;
      renderNodes();
      renderEdges({ fast:true });
      updateMinimap();
    });
  }
  function move(moveEvent){
    node.position.x = Math.round(start.x + (moveEvent.clientX - startX) / zoom);
    node.position.y = Math.round(start.y + (moveEvent.clientY - startY) / zoom);
    scheduleDragRender();
  }
  function up(){
    window.removeEventListener("mousemove", move);
    window.removeEventListener("mouseup", up);
    if(nodeDragRenderFrame){
      window.cancelAnimationFrame(nodeDragRenderFrame);
      nodeDragRenderFrame = 0;
    }
    renderNodes();
    renderEdges();
    updateMinimap();
    renderParams();
    if(node.position.x !== start.x || node.position.y !== start.y) commitActiveWorkflowChange();
  }
  window.addEventListener("mousemove", move);
  window.addEventListener("mouseup", up);
}
function getPortPoint(node, kind, handle){
  const meta = OPERATOR_META[node.type] || {};
  const ports = kind === "out" ? nodeOutputPorts(meta, node) : nodeInputPorts(meta, node);
  const index = Math.max(0, ports.findIndex(port => port.handle === handle));
  const size = measureNodeForLayout(node);
  const y = node.position.y + (node.collapsed ? 27 : portTop(index) + 8);
  return { x:node.position.x + (kind === "out" ? size.width : 0), y };
}
function getRouteNodeRect(node, padding = 28){
  const size = measureNodeForLayout(node);
  return {
    id:node.id,
    left:node.position.x - padding,
    top:node.position.y - padding,
    right:node.position.x + size.width + padding,
    bottom:node.position.y + size.height + padding,
  };
}
function normalizeSegmentRange(a, b){ return a <= b ? [a, b] : [b, a]; }
function segmentIntersectsRect(a, b, rect){
  const epsilon = 0.001;
  if(Math.abs(a.x - b.x) <= epsilon){
    const [y1, y2] = normalizeSegmentRange(a.y, b.y);
    return a.x >= rect.left && a.x <= rect.right && y2 >= rect.top && y1 <= rect.bottom;
  }
  if(Math.abs(a.y - b.y) <= epsilon){
    const [x1, x2] = normalizeSegmentRange(a.x, b.x);
    return a.y >= rect.top && a.y <= rect.bottom && x2 >= rect.left && x1 <= rect.right;
  }
  return false;
}
function polylineCollidesWithRects(points, rects){
  for(let index = 1; index < points.length; index += 1){
    const a = points[index - 1];
    const b = points[index];
    if(Math.abs(a.x - b.x) < 0.001 && Math.abs(a.y - b.y) < 0.001) continue;
    if(rects.some(rect => segmentIntersectsRect(a, b, rect))) return true;
  }
  return false;
}
function compactPolylinePoints(points){
  const rounded = points
    .map(point => ({ x:Math.round(point.x), y:Math.round(point.y) }))
    .filter((point, index, list) => index === 0 || point.x !== list[index - 1].x || point.y !== list[index - 1].y);
  const compacted = [];
  rounded.forEach(point => {
    compacted.push(point);
    while(compacted.length >= 3){
      const a = compacted[compacted.length - 3];
      const b = compacted[compacted.length - 2];
      const c = compacted[compacted.length - 1];
      const sameHorizontal = a.y === b.y && b.y === c.y;
      const sameVertical = a.x === b.x && b.x === c.x;
      if(!sameHorizontal && !sameVertical) break;
      compacted.splice(compacted.length - 2, 1);
    }
  });
  return compacted;
}
function roundedOrthogonalPath(points){
  const compacted = compactPolylinePoints(points);
  if(compacted.length <= 1) return "";
  if(compacted.length === 2) return `M ${compacted[0].x} ${compacted[0].y} L ${compacted[1].x} ${compacted[1].y}`;
  const parts = [`M ${compacted[0].x} ${compacted[0].y}`];
  for(let index = 1; index < compacted.length - 1; index += 1){
    const prev = compacted[index - 1];
    const current = compacted[index];
    const next = compacted[index + 1];
    const inDx = current.x - prev.x;
    const inDy = current.y - prev.y;
    const outDx = next.x - current.x;
    const outDy = next.y - current.y;
    const radius = Math.min(18, Math.abs(inDx || inDy) / 2, Math.abs(outDx || outDy) / 2);
    if(radius < 1){
      parts.push(`L ${current.x} ${current.y}`);
      continue;
    }
    const before = {
      x:current.x - Math.sign(inDx) * radius,
      y:current.y - Math.sign(inDy) * radius,
    };
    const after = {
      x:current.x + Math.sign(outDx) * radius,
      y:current.y + Math.sign(outDy) * radius,
    };
    parts.push(`L ${Math.round(before.x)} ${Math.round(before.y)}`);
    parts.push(`Q ${current.x} ${current.y} ${Math.round(after.x)} ${Math.round(after.y)}`);
  }
  const last = compacted[compacted.length - 1];
  parts.push(`L ${last.x} ${last.y}`);
  return parts.join(" ");
}
function routeScore(points){
  let length = 0;
  let bends = Math.max(0, points.length - 2);
  for(let index = 1; index < points.length; index += 1){
    length += Math.abs(points[index].x - points[index - 1].x) + Math.abs(points[index].y - points[index - 1].y);
  }
  return length + bends * 45;
}
function getEdgeRoutingBounds(rects, start, end){
  const allXs = [start.x, end.x];
  const allYs = [start.y, end.y];
  rects.forEach(rect => {
    allXs.push(rect.left, rect.right);
    allYs.push(rect.top, rect.bottom);
  });
  return {
    left:Math.min(...allXs),
    right:Math.max(...allXs),
    top:Math.min(...allYs),
    bottom:Math.max(...allYs),
  };
}
function candidateVerticalLanes(start, end, bounds){
  const dx = end.x - start.x;
  const minX = Math.min(start.x, end.x);
  const maxX = Math.max(start.x, end.x);
  const midX = Math.round(start.x + dx / 2);
  return [...new Set([
    midX,
    start.x + 72,
    start.x + 120,
    end.x - 72,
    end.x - 120,
    minX - 90,
    maxX + 90,
    bounds.left - 90,
    bounds.right + 90,
  ].map(value => Math.round(value)))]
    .filter(value => end.x - start.x >= 140 && value >= start.x + 40 && value <= end.x - 40);
}
function candidateBusLanes(start, end, bounds, edgeIndex = 0){
  const centerY = (start.y + end.y) / 2;
  const step = 34;
  const offset = (edgeIndex % 6) * step;
  const lanes = [
    bounds.top - 84 - offset,
    bounds.bottom + 84 + offset,
    Math.min(start.y, end.y) - 96 - offset,
    Math.max(start.y, end.y) + 96 + offset,
    centerY - 130 - offset,
    centerY + 130 + offset,
  ].map(value => Math.round(value));
  return [...new Set(lanes)].sort((a, b) => Math.abs(a - centerY) - Math.abs(b - centerY));
}
function buildBusRoute(start, end, clearXStart, clearXEnd, busY){
  return [start, { x:clearXStart, y:start.y }, { x:clearXStart, y:busY }, { x:clearXEnd, y:busY }, { x:clearXEnd, y:end.y }, end];
}
function calculateFastEdgeWaypoints(start, end, edgeIndex = 0){
  const clearXStart = Math.round(start.x + 56);
  const clearXEnd = Math.round(end.x - 56);
  if(clearXEnd >= clearXStart + 32){
    const laneX = Math.round((clearXStart + clearXEnd) / 2);
    return compactPolylinePoints([start, { x:clearXStart, y:start.y }, { x:laneX, y:start.y }, { x:laneX, y:end.y }, { x:clearXEnd, y:end.y }, end]);
  }
  const laneOffset = 76 + (edgeIndex % 6) * 22;
  const busY = Math.round(Math.min(start.y, end.y) - laneOffset);
  return compactPolylinePoints(buildBusRoute(start, end, clearXStart, clearXEnd, busY));
}
function calculateEdgeWaypoints(start, end, edge = null, edgeIndex = 0, options = {}){
  if(options.fast) return calculateFastEdgeWaypoints(start, end, edgeIndex);
  const ignored = new Set(edge ? [edge.source, edge.target] : []);
  const allRects = Array.isArray(options.routingRects) ? options.routingRects : nodes.map(node => getRouteNodeRect(node, 30));
  const rects = allRects.filter(rect => !ignored.has(rect.id));
  const bounds = getEdgeRoutingBounds(rects, start, end);
  const candidates = [];

  candidateVerticalLanes(start, end, bounds).forEach(laneX => {
    candidates.push([start, { x:laneX, y:start.y }, { x:laneX, y:end.y }, end]);
  });

  // 输出端始终先向右离开源节点，输入端始终从左侧进入目标节点。
  // 这可以避免反向连线从端口向左穿过源节点本体。
  const startClearCandidates = [56, 86, 124].map(value => Math.round(start.x + value));
  const endClearCandidates = [56, 86, 124].map(value => Math.round(end.x - value));
  candidateBusLanes(start, end, bounds, edgeIndex).forEach(busY => {
    startClearCandidates.forEach(clearXStart => {
      endClearCandidates.forEach(clearXEnd => {
        candidates.push(buildBusRoute(start, end, clearXStart, clearXEnd, busY));
      });
    });
  });

  const fallbackTop = Math.round(bounds.top - 150 - (edgeIndex % 8) * 28);
  const fallbackBottom = Math.round(bounds.bottom + 150 + (edgeIndex % 8) * 28);
  const leftOutside = Math.round(bounds.left - 130);
  const rightOutside = Math.round(bounds.right + 130);
  [fallbackTop, fallbackBottom].forEach(busY => {
    candidates.push(buildBusRoute(start, end, rightOutside, rightOutside, busY));
    candidates.push(buildBusRoute(start, end, leftOutside, leftOutside, busY));
  });

  const cleanCandidates = candidates
    .map(compactPolylinePoints)
    .filter(points => points.length >= 2)
    .filter(points => !polylineCollidesWithRects(points, rects));
  if(cleanCandidates.length){
    cleanCandidates.sort((a, b) => routeScore(a) - routeScore(b));
    return cleanCandidates[0];
  }

  return compactPolylinePoints([start, { x:Math.round((start.x + end.x) / 2), y:start.y }, { x:Math.round((start.x + end.x) / 2), y:end.y }, end]);
}
function makeEdgePath(start, end, edge = null, edgeIndex = 0, options = {}){
  return roundedOrthogonalPath(calculateEdgeWaypoints(start, end, edge, edgeIndex, options));
}
function drawTempEdge(clientX, clientY){
  clearTempEdge();
  const source = nodes.find(node => node.id === connectingSourceId);
  if(!source) return;
  const start = getPortPoint(source, "out", connectingSourceHandle);
  const end = screenToWorld(clientX, clientY);
  const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
  path.id = "tempEdge";
  path.setAttribute("class", "edge-temp");
  path.setAttribute("d", makeEdgePath(start, end, null, 0, { fast:true }));
  edgeLayer.appendChild(path);
}
function clearTempEdge(){
  const temporary = document.getElementById("tempEdge");
  if(temporary) temporary.remove();
}
function renderEdgeDefinitions(){
  const defs = document.createElementNS("http://www.w3.org/2000/svg", "defs");
  defs.innerHTML = `<marker id="edgeArrow" viewBox="0 0 10 10" refX="8.5" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
    <path d="M 0 0 L 10 5 L 0 10 z" class="edge-arrow-shape"></path>
  </marker>
  <marker id="edgeArrowSelected" viewBox="0 0 10 10" refX="8.5" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
    <path d="M 0 0 L 10 5 L 0 10 z" class="edge-arrow-shape selected"></path>
  </marker>`;
  edgeLayer.appendChild(defs);
}
function renderEdges(options = {}){
  edgeLayer.innerHTML = "";
  edgeLayer.setAttribute("overflow", "visible");
  renderEdgeDefinitions();
  const collapsedByNodeId = collapsedModuleMapByNodeId();
  const nodeById = new Map(nodes.map(node => [node.id, node]));
  const routingRects = options.fast ? null : nodes.map(node => getRouteNodeRect(node, 30));
  edges.forEach((edge, edgeIndex) => {
    const source = nodeById.get(edge.source);
    const target = nodeById.get(edge.target);
    if(!source || !target) return;

    const sourceModule = collapsedByNodeId.get(edge.source) || null;
    const targetModule = collapsedByNodeId.get(edge.target) || null;
    if(sourceModule && targetModule && sourceModule.id === targetModule.id) return;

    const rawStart = getPortPoint(source, "out", edge.sourceHandle || "out");
    const rawEnd = getPortPoint(target, "in", edge.targetHandle || "in");
    const start = sourceModule ? moduleEdgePortPoint(sourceModule, "out", rawEnd, rawStart.y) : rawStart;
    const end = targetModule ? moduleEdgePortPoint(targetModule, "in", rawStart, rawEnd.y) : rawEnd;
    if(!start || !end) return;

    const isModuleEdge = Boolean(sourceModule || targetModule);
    const pathData = makeEdgePath(start, end, edge, edgeIndex, { fast:Boolean(options.fast), routingRects });
    const hit = document.createElementNS("http://www.w3.org/2000/svg", "path");
    hit.setAttribute("d", pathData);
    hit.setAttribute("class", `edge-hit ${isModuleEdge ? "module-edge" : ""}`);
    hit.dataset.id = edge.id;
    const fromLabel = sourceModule ? `模块「${sourceModule.name || sourceModule.id}」` : `${edge.source}.${edge.sourceHandle || "out"}`;
    const toLabel = targetModule ? `模块「${targetModule.name || targetModule.id}」` : `${edge.target}.${edge.targetHandle || "in"}`;
    hit.setAttribute("aria-label", `${fromLabel} → ${toLabel}`);
    hit.addEventListener("mousedown", event => event.stopPropagation());
    hit.addEventListener("click", event => { event.stopPropagation(); selectEdge(edge.id); });
    hit.addEventListener("dblclick", event => { event.stopPropagation(); deleteEdge(edge.id); });
    hit.addEventListener("contextmenu", event => { event.preventDefault(); event.stopPropagation(); deleteEdge(edge.id); });
    const visible = document.createElementNS("http://www.w3.org/2000/svg", "path");
    visible.setAttribute("d", pathData);
    visible.setAttribute("class", `edge-visible ${isModuleEdge ? "module-edge" : ""} ${selectedEdgeId === edge.id ? "selected" : ""}`);
    visible.setAttribute("marker-end", selectedEdgeId === edge.id ? "url(#edgeArrowSelected)" : "url(#edgeArrow)");
    edgeLayer.append(hit, visible);
  });
}
function selectIncomingEdge(targetId, targetHandle = "in"){
  const edge = edges.find(item => item.target === targetId && (item.targetHandle || "in") === targetHandle);
  if(edge) selectEdge(edge.id);
}
function selectEdge(edgeId){
  selectedEdgeId = edgeId;
  selectedNodeId = null;
  connectingSourceId = null;
  connectingSourceHandle = "out";
  previewActionNodeId = null;
  colorPaletteNodeId = null;
  render();
  const edge = edges.find(item => item.id === edgeId);
  if(edge) setStatus(`已选择连线：${edge.source}.${edge.sourceHandle || "out"} → ${edge.target}.${edge.targetHandle || "in"}，按 Delete/Backspace 删除`);
}
function deleteEdge(edgeId){
  const edge = edges.find(item => item.id === edgeId);
  if(!edge) return;
  edges = edges.filter(item => item.id !== edgeId);
  if(selectedEdgeId === edgeId) selectedEdgeId = null;
  invalidateNodeAndDownstreamPreviews(edge.target);
  render();
  commitActiveWorkflowChange();
  toast("已删除连线", `${edge.source}.${edge.sourceHandle || "out"} → ${edge.target}.${edge.targetHandle || "in"}`, true);
}
function deleteSelectedEdge(){ if(selectedEdgeId) deleteEdge(selectedEdgeId); }

function renderParams(){
  if(selectedEdgeId && !selectedNodeId){
    const edge = edges.find(item => item.id === selectedEdgeId);
    if(edge){
      paramPanel.className = "param-card";
      paramPanel.innerHTML = `<h3>连线 · ${escapeHtml(edge.source)}.${escapeHtml(edge.sourceHandle || "out")} → ${escapeHtml(edge.target)}.${escapeHtml(edge.targetHandle || "in")}</h3><div class="hint">双击、右键或按 Delete 可以删除这条连线。</div><div class="row-actions"><button class="btn red" onclick="deleteSelectedEdge()">删除连线</button></div>`;
      return;
    }
  }
  const moduleInfo = workflowModules.find(item => item.id === selectedModuleId);
  if(moduleInfo && !selectedNodeId){
    const ids = moduleNodeIds(moduleInfo);
    paramPanel.className = "param-card";
    paramPanel.innerHTML = `<h3>模块 · ${escapeHtml(moduleInfo.name || moduleInfo.id)}</h3>
      <div class="hint">${escapeHtml(moduleInfo.description || "该模块用于组织复杂工作流，不改变后端执行语义。")}</div>
      <div class="module-param-summary" style="--module-accent:${safeColor(moduleInfo.color || "#526b75")};--module-opacity:${normalizeModuleOpacity(moduleInfo.opacity)}">
        <b>${ids.length}</b><span>节点</span><b>${Math.round(normalizeModuleOpacity(moduleInfo.opacity) * 100)}%</b><span>透明度</span>
      </div>
      <div class="row-actions">
        <button class="btn" onclick="toggleWorkflowModule('${escapeHtml(moduleInfo.id)}')">${moduleInfo.collapsed ? "展开模块" : "折叠模块"}</button>
        <button class="btn" onclick="openModuleEditor({mode:'edit', moduleId:'${escapeHtml(moduleInfo.id)}'})">编辑样式</button>
        <button class="btn red" onclick="deleteWorkflowModule('${escapeHtml(moduleInfo.id)}')">解除模块</button>
      </div>`;
    return;
  }
  const node = nodes.find(item => item.id === selectedNodeId);
  if(!node){
    paramPanel.className = "param-card hint";
    paramPanel.innerHTML = "请选择一个节点、连线或模块。左键框选画布区域可以创建功能模块。";
    return;
  }
  const meta = OPERATOR_META[node.type] || { label:node.type };
  const previewState = nodePreviews.has(node.id) ? "已生成节点效果预览" : "尚未生成节点效果预览";
  paramPanel.className = "param-card";
  if(node.type === "PythonSnippet" && typeof window.renderPythonSnippetParamPanel === "function"){
    paramPanel.innerHTML = window.renderPythonSnippetParamPanel(node, meta);
    return;
  }
  const inputInspector = renderNodeInputInspectorHtml(node, meta);
  paramPanel.innerHTML = `<h3>${escapeHtml(node.id)} · ${escapeHtml(meta.label)}</h3>
    <div class="hint">类型：${escapeHtml(node.type)}<br>${escapeHtml(meta.description || "")}<br>${previewState}<br><br>所有可调参数都在节点卡片内编辑；下方可查看该节点当前输入来源和端口/参数优先级。</div>
    ${inputInspector}
    <div class="row-actions"><button class="btn ghost" onclick="duplicateNode('${escapeHtml(node.id)}')">复制节点</button><button class="btn red" onclick="deleteNode('${escapeHtml(node.id)}')">删除节点</button></div>`;
}
