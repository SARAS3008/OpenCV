// 拆分自 app.bundle.legacy.js：第 1212-1579 行。
function toggleSelectedCollapse(){
  const node = nodes.find(item => item.id === selectedNodeId);
  if(!node) return;
  node.collapsed = !node.collapsed;
  render();
  commitActiveWorkflowChange();
}
// 兼容旧页面调用；现在这两个操作只控制左侧节点库分类，不再改变画布节点。
function collapseAllNodes(){ collapseAllOperatorGroups(); }
function expandAllNodes(){ expandAllOperatorGroups(); }
function duplicateNode(id){
  const source = nodes.find(item => item.id === id);
  if(!source) return;
  const newId = `n${nodeSeq++}`;
  nodes.push({
    id:newId,
    type:source.type,
    position:{ x:source.position.x + 42, y:source.position.y + 42 },
    params:JSON.parse(JSON.stringify(source.params || {})),
    collapsed:source.collapsed,
    color:source.color || DEFAULT_NODE_COLOR,
  });
  selectedNodeId = newId;
  selectedEdgeId = null;
  colorPaletteNodeId = null;
  render();
  commitActiveWorkflowChange();
}
function deleteNode(id){
  if(!nodes.some(node => node.id === id)) return;
  nodes = nodes.filter(node => node.id !== id);
  edges = edges.filter(edge => edge.source !== id && edge.target !== id);
  workflowModules = workflowModules.map(moduleInfo => ({ ...moduleInfo, node_ids:(moduleInfo.node_ids || []).filter(nodeId => nodeId !== id) })).filter(moduleInfo => (moduleInfo.node_ids || []).length);
  nodePreviews.delete(id);
  if(selectedNodeId === id) selectedNodeId = null;
  if(previewActionNodeId === id) previewActionNodeId = null;
  if(colorPaletteNodeId === id) colorPaletteNodeId = null;
  if(lightboxNodeId === id) closeImageLightbox();
  render();
  commitActiveWorkflowChange();
  toast("已删除节点", id, true);
}
function deleteSelectedNode(){ if(selectedNodeId) deleteNode(selectedNodeId); }

function buildWorkflow(){
  const nodeIds = new Set(nodes.map(node => node.id));
  return {
    version:"2.3",
    nodes:nodes.map(node => ({
      id:node.id,
      type:node.type,
      position:node.position,
      params:{ ...(node.params || {}) },
      collapsed:Boolean(node.collapsed),
      color:node.color || DEFAULT_NODE_COLOR,
    })),
    edges:edges.map(edge => ({ ...edge })),
    modules:(workflowModules || []).map(moduleInfo => ({
      id:moduleInfo.id,
      name:moduleInfo.name || "功能模块",
      node_ids:(moduleInfo.node_ids || []).filter(nodeId => nodeIds.has(nodeId)),
      description:moduleInfo.description || "",
      color:safeColor(moduleInfo.color || "#526b75"),
      opacity:normalizeModuleOpacity(moduleInfo.opacity),
      collapsed:Boolean(moduleInfo.collapsed),
    })).filter(moduleInfo => moduleInfo.node_ids.length),
  };
}

const RUN_LOG_LIMIT = 500;

function formatRunLogTimestamp(value){
  const date = value ? new Date(value) : new Date();
  const safeDate = Number.isNaN(date.getTime()) ? new Date() : date;
  const pad = number => String(number).padStart(2, "0");
  return `${safeDate.getFullYear()}-${pad(safeDate.getMonth() + 1)}-${pad(safeDate.getDate())} ${pad(safeDate.getHours())}:${pad(safeDate.getMinutes())}:${pad(safeDate.getSeconds())}`;
}

function clearRunLog(message = "等待运行工作流..."){
  if(!previewPanel) return;
  previewPanel.replaceChildren();
  if(message){
    const empty = document.createElement("div");
    empty.className = "run-log-empty";
    empty.textContent = message;
    previewPanel.appendChild(empty);
  }
}

function appendRunLog(level, message, details = "", timestamp = null, eventName = ""){
  if(!previewPanel) return;
  previewPanel.querySelector(".run-log-empty")?.remove();
  const normalizedLevel = ["success", "warning", "error", "debug"].includes(level) ? level : "info";
  const row = document.createElement("div");
  row.className = `run-log-entry ${normalizedLevel}`;
  if(eventName) row.dataset.event = eventName;

  const time = document.createElement("time");
  time.className = "run-log-time";
  time.dateTime = timestamp || new Date().toISOString();
  time.textContent = formatRunLogTimestamp(timestamp);

  const badge = document.createElement("span");
  badge.className = "run-log-level";
  badge.textContent = ({ success:"成功", warning:"警告", error:"错误", debug:"调试", info:"信息" })[normalizedLevel];

  const content = document.createElement("div");
  content.className = "run-log-content";
  const messageElement = document.createElement("div");
  messageElement.className = "run-log-message";
  messageElement.textContent = String(message || "运行事件");
  content.appendChild(messageElement);
  if(details){
    const detailElement = document.createElement("div");
    detailElement.className = "run-log-details";
    detailElement.textContent = String(details);
    content.appendChild(detailElement);
  }

  row.append(time, badge, content);
  previewPanel.appendChild(row);
  while(previewPanel.querySelectorAll(".run-log-entry").length > RUN_LOG_LIMIT){
    previewPanel.querySelector(".run-log-entry")?.remove();
  }
  const scroll = document.getElementById("previewScroll");
  if(scroll) scroll.scrollTop = scroll.scrollHeight;
}

function workflowLogDetails(event){
  if(event.node_id){
    const progress = event.node_total ? `${event.node_index || "-"}/${event.node_total}` : "";
    return [progress, event.node_type || "", event.duration_ms != null ? `${Number(event.duration_ms).toFixed(2)} ms` : ""].filter(Boolean).join(" · ");
  }
  if(event.source_name){
    return [`${event.index || "-"}/${event.total || "-"}`, event.source_name, event.duration_ms != null ? `${Number(event.duration_ms).toFixed(2)} ms` : ""].filter(Boolean).join(" · ");
  }
  if(event.output_dir || event.csv_path){
    return [event.output_dir ? `结果目录：${event.output_dir}` : "", event.csv_path ? `CSV：${event.csv_path}` : ""].filter(Boolean).join(" · ");
  }
  return "";
}

function handleWorkflowLogEvent(event){
  appendRunLog(event.level || "info", event.message || event.event || "运行事件", workflowLogDetails(event), event.timestamp, event.event || "");
}

function workflowExecutionSignatureForDebug(workflow = buildWorkflow()){
  return JSON.stringify({
    image_id:workflow.image_id || null,
    nodes:(workflow.nodes || []).map(node => ({ id:node.id, type:node.type, params:node.params || {} })),
    edges:(workflow.edges || []).map(edge => ({
      source:edge.source,
      target:edge.target,
      sourceHandle:edge.sourceHandle || "out",
      targetHandle:edge.targetHandle || "in",
    })),
  });
}

function resetLocalDebugState(options = {}){
  debugSessionId = null;
  debugWorkflowExecutionSignature = "";
  debugCurrentNodeId = null;
  debugNextNodeId = null;
  debugTargetNodeId = null;
  debugExecutedNodeIds.clear();
  debugRunBusy = false;
  updateRunModeUi();
  if(!options.preserveRender){
    renderNodes();
    updateMinimap();
  }
  if(!options.preserveLogs && previewPanel){
    appendRunLog("debug", "调试会话已重置");
  }
}

async function resetDebugSession(options = {}){
  const sessionId = debugSessionId;
  resetLocalDebugState({
    preserveLogs:Boolean(options.preserveLogs || options.silent),
    preserveRender:Boolean(options.preserveRender),
  });
  if(sessionId){
    try{ await VisionApi.resetDebugSession(sessionId); }
    catch(error){ if(!options.silent) console.warn("调试会话重置失败", error); }
  }
  if(!options.silent){
    setStatus("调试会话已结束；可重新选择运行模式。");
    toast("调试已重置", "已清除执行进度，节点结果预览仍保留", true);
  }
}

function invalidateDebugSessionIfWorkflowChanged(){
  if(!debugSessionId || debugRunBusy) return;
  const currentSignature = workflowExecutionSignatureForDebug();
  if(currentSignature === debugWorkflowExecutionSignature) return;
  const oldSessionId = debugSessionId;
  resetLocalDebugState({ preserveLogs:true });
  VisionApi.resetDebugSession(oldSessionId).catch(() => {});
  appendRunLog("warning", "工作流参数或连线已修改，原调试会话已失效", "移动节点和折叠节点不会触发重置；执行参数与连线变化会重新开始调试");
  setStatus("工作流已修改，请重新开始单步调试。");
}

function updateRunModeUi(){
  const select = document.getElementById("runModeSelect");
  const button = document.getElementById("runModeButton");
  const resetButton = document.getElementById("debugResetButton");
  const controls = document.querySelector(".run-mode-controls");
  if(!select || !button) return;
  const mode = select.value || "full";
  const labels = {
    full:"▶ 整体运行",
    step:debugSessionId ? "⏭ 继续单步" : "⏭ 单步运行",
    run_to_node:"⏯ 运行到节点",
  };
  button.textContent = labels[mode] || labels.full;
  button.disabled = debugRunBusy;
  select.disabled = debugRunBusy;
  if(resetButton){
    resetButton.hidden = !debugSessionId;
    resetButton.disabled = debugRunBusy;
  }
  controls?.classList.toggle("busy", debugRunBusy);
  if(mode === "run_to_node"){
    button.title = selectedNodeId ? `执行到当前选中的节点 ${selectedNodeId}` : "请先在画布中选择目标节点";
  }else if(mode === "step"){
    button.title = debugNextNodeId ? `下一步将执行 ${debugNextNodeId}` : "每次只执行一个新的节点";
  }else{
    button.title = "按当前方式运行整个工作流";
  }
}

function runSelectedMode(){
  const mode = document.getElementById("runModeSelect")?.value || "full";
  if(mode === "full") return runWorkflow();
  if(mode === "run_to_node") return executeDebugAction("run_to_node");
  return executeDebugAction("step");
}

function applyDebugResult(data){
  debugSessionId = data.debug_session_id || debugSessionId;
  debugWorkflowExecutionSignature = workflowExecutionSignatureForDebug();
  debugExecutedNodeIds.clear();
  (data.executed_order || []).forEach(nodeId => debugExecutedNodeIds.add(nodeId));
  debugCurrentNodeId = data.current_node_id || null;
  debugNextNodeId = data.next_node_id || null;
  debugTargetNodeId = data.target_node_id || null;
  if(debugCurrentNodeId){
    selectedNodeId = debugCurrentNodeId;
    selectedEdgeId = null;
  }
  renderPreviews(data.previews || []);
  updateRunModeUi();
}

async function executeDebugAction(action){
  if(debugRunBusy) return;
  const workflow = buildWorkflow();
  if(!workflow.nodes.length){
    toast("无法调试", "流程为空，请先添加节点");
    return;
  }
  const targetNodeId = action === "run_to_node" ? selectedNodeId : null;
  if(action === "run_to_node" && !targetNodeId){
    setStatus("请先在画布中选择要运行到的节点。");
    toast("请选择目标节点", "选中节点后再使用“运行到节点”模式");
    return;
  }
  const signature = workflowExecutionSignatureForDebug(workflow);
  if(debugSessionId && debugWorkflowExecutionSignature && signature !== debugWorkflowExecutionSignature){
    await resetDebugSession({ silent:true, preserveLogs:true, preserveRender:true });
  }

  debugRunBusy = true;
  updateRunModeUi();
  document.getElementById("taskCount").textContent = "1";
  if(previewCollapsed) togglePreviewPanel(false);
  if(!debugSessionId){
    clearRunLog("");
    appendRunLog("debug", "正在建立调试会话...", `${workflow.nodes.length} 个节点 · ${workflow.edges.length} 条连线`);
  }else{
    appendRunLog("debug", action === "step" ? "继续执行下一步" : `继续执行到节点 ${targetNodeId}`, debugNextNodeId ? `当前下一节点：${debugNextNodeId}` : "");
  }
  setStatus(action === "step" ? "单步执行中..." : `正在执行到节点 ${targetNodeId}...`);

  try{
    const data = await VisionApi.executeDebugStream({
      workflow,
      session_id:debugSessionId || null,
      action,
      target_node_id:targetNodeId,
    }, handleWorkflowLogEvent);
    applyDebugResult(data);

    if(data.completed){
      const skippedText = (data.skipped_nodes || []).length ? `；跳过未选分支：${data.skipped_nodes.join("、")}` : "";
      setStatus(`调试执行完成。执行顺序：${(data.executed_order || []).join(" → ")}${skippedText}`);
      toast("调试完成", `共执行 ${(data.executed_order || []).length} 个节点`, true);
    }else if(action === "run_to_node"){
      setStatus(`已执行到节点 ${targetNodeId}。下一步：${data.next_node_id || "无"}。运行模式已切换为单步。`);
      const select = document.getElementById("runModeSelect");
      if(select) select.value = "step";
      updateRunModeUi();
      toast("已暂停到指定节点", `${targetNodeId}；可继续单步执行`, true);
    }else{
      setStatus(`单步完成：${(data.newly_executed || []).join("、") || "无新节点"}。下一步：${data.next_node_id || "无"}`);
      toast("单步执行完成", data.current_node_id || "工作流已完成", true);
    }
  }catch(error){
    const message = error?.message || String(error);
    const payload = error?.payload || null;
    if(payload && Array.isArray(payload.previews)){
      if(payload.debug_session_id){
        debugSessionId = payload.debug_session_id;
        debugWorkflowExecutionSignature = workflowExecutionSignatureForDebug();
        debugExecutedNodeIds.clear();
        (payload.executed_order || []).forEach(nodeId => debugExecutedNodeIds.add(nodeId));
        debugCurrentNodeId = payload.current_node_id || payload.failed_node?.node_id || null;
        debugNextNodeId = payload.next_node_id || payload.failed_node?.node_id || null;
        if(debugCurrentNodeId){
          selectedNodeId = debugCurrentNodeId;
          selectedEdgeId = null;
        }
      }
      renderPreviews(payload.previews || []);
      renderExecutionFailureSummary(payload);
    }else{
      appendRunLog("error", `调试执行失败：${message}`);
    }
    if(payload?.restart_required || error?.httpStatus === 409){
      resetLocalDebugState({ preserveLogs:true });
      appendRunLog("warning", "调试会话需要重新开始", "服务可能已重启、会话已过期，或工作流执行参数发生变化");
    }
    setStatus(`调试失败：${message}`);
    toast("调试执行失败", message);
  }finally{
    debugRunBusy = false;
    document.getElementById("taskCount").textContent = "0";
    updateRunModeUi();
  }
}

async function runWorkflow(){
  if(debugRunBusy) return;
  const previousDebugSession = debugSessionId;
  if(previousDebugSession){
    resetLocalDebugState({ preserveLogs:true, preserveRender:true });
    VisionApi.resetDebugSession(previousDebugSession).catch(() => {});
  }
  const workflow = buildWorkflow();
  setStatus("运行中...");
  document.getElementById("taskCount").textContent = "1";
  if(previewCollapsed) togglePreviewPanel(false);
  clearRunLog("");
  appendRunLog("info", "正在建立实时运行通道...", `${workflow.nodes.length} 个节点 · ${workflow.edges.length} 条连线`);
  try{
    const data = await VisionApi.executeWorkflowStream(workflow, handleWorkflowLogEvent);
    renderPreviews(data.previews || [], data.batch || null);
    appendRunLog("success", "运行结果已同步到各节点下方", `共更新 ${(data.previews || []).length} 个节点结果`);
    if(data.mode === "batch" && data.batch){
      const batch = data.batch;
      setStatus(`批量运行完成：共 ${batch.total} 张，成功 ${batch.succeeded} 张，失败 ${batch.failed} 张。结果目录：${batch.output_dir}`);
      toast("批量处理完成", `成功 ${batch.succeeded} / ${batch.total}，失败 ${batch.failed}`, batch.failed === 0);
    }else{
      setStatus(`运行成功。执行顺序：${(data.order || []).join(" → ")}`);
      toast("运行成功", `已生成 ${(data.previews || []).length} 个节点结果`, true);
    }
  }catch(error){
    const message = error && error.message ? error.message : String(error);
    const payload = error?.payload || null;
    if(payload && Array.isArray(payload.previews)){
      renderPreviews(payload.previews || [], payload.batch || null);
      renderExecutionFailureSummary(payload);
      const failed = payload.failed_node;
      const executedText = (payload.executed_order || []).join(" → ") || "无";
      setStatus(`运行到节点 ${failed?.node_id || "未知"} 时失败。已完成：${executedText}。错误：${message}`);
      if(failed?.node_id){
        selectedNodeId = failed.node_id;
        selectedEdgeId = null;
        render();
      }
      toast("节点执行失败", `${failed?.node_id || "未知节点"}：${failed?.error || message}`);
    }else{
      setStatus(`运行失败：${message}`);
      appendRunLog("error", `运行失败：${message}`);
      toast("运行失败", message);
    }
  }finally{
    document.getElementById("taskCount").textContent = "0";
  }
}

function renderExecutionFailureSummary(payload){
  const failed = payload.failed_node || {};
  const executed = payload.executed_order || [];
  const pending = payload.pending_nodes || [];
  appendRunLog(
    "error",
    `工作流在节点 ${failed.node_id || "未知"} · ${failed.label || failed.type || "未知节点"} 中断`,
    `已完成：${executed.join(" → ") || "无"}；未执行：${pending.join("、") || "无"}`
  );
}

function togglePreviewPanel(force){
  previewCollapsed = typeof force === "boolean" ? force : !previewCollapsed;
  previewWrap.classList.toggle("collapsed", previewCollapsed);
  previewToggleText.textContent = previewCollapsed ? "展开" : "折叠";
  if(!suppressDocumentSync) persistActiveWorkflowView();
}

function renderPreviews(previews, batchSummary = null){
  nodePreviews.clear();
  previews.forEach(item => nodePreviews.set(item.node_id, item));
  previewActionNodeId = null;
  renderNodes();
  updateMinimap();
  if(!suppressDocumentSync) captureActiveWorkflowDocument(false);
}

function renderBatchSummary(batch){
  appendRunLog(
    Number(batch.failed || 0) > 0 ? "warning" : "success",
    `批量处理汇总：总计 ${Number(batch.total || 0)}，成功 ${Number(batch.succeeded || 0)}，失败 ${Number(batch.failed || 0)}`,
    [batch.output_dir ? `结果目录：${batch.output_dir}` : "", batch.csv_path ? `CSV：${batch.csv_path}` : ""].filter(Boolean).join(" · ")
  );
}

function downloadNodePreview(nodeId){
  const preview = nodePreviews.get(nodeId);
  if(!preview || !preview.image){
    toast("下载失败", "该节点还没有可下载的结果图");
    return;
  }
  const anchor = document.createElement("a");
  anchor.href = preview.image;
  anchor.download = `${safeFilename(nodeId)}_${safeFilename(preview.label || preview.type || "result")}.png`;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  toast("开始下载", anchor.download, true);
}

function openImageLightbox(nodeId){
  const preview = nodePreviews.get(nodeId);
  if(!preview || !preview.image){
    toast("无法放大", "该节点还没有结果图");
    return;
  }
  lightboxNodeId = nodeId;
  const lightbox = document.getElementById("imageLightbox");
  const image = document.getElementById("lightboxImage");
  document.getElementById("lightboxTitle").textContent = `${nodeId} · ${preview.label || preview.type || "节点结果"}`;
  document.getElementById("lightboxMeta").textContent = "原始分辨率 · 可滚动查看";
  image.src = preview.image;
  image.alt = `${preview.label || nodeId} 的原图`;
  document.getElementById("lightboxDownload").onclick = event => {
    event.stopPropagation();
    downloadNodePreview(nodeId);
  };
  document.getElementById("lightboxRestore").onclick = event => {
    event.stopPropagation();
    closeImageLightbox();
  };
  lightbox.classList.add("open");
  lightbox.setAttribute("aria-hidden", "false");
  document.body.classList.add("lightbox-open");
}
function closeImageLightbox(){
  const lightbox = document.getElementById("imageLightbox");
  lightbox.classList.remove("open");
  lightbox.setAttribute("aria-hidden", "true");
  document.getElementById("lightboxImage").removeAttribute("src");
  lightboxNodeId = null;
  document.body.classList.remove("lightbox-open");
}

async function exportAlgorithmScript(){
  if(!nodes.length){ toast("导出失败", "请先编排工作流"); return; }
  setStatus("正在生成独立算法脚本...");
  try{
    const result = await VisionApi.exportScript(buildWorkflow());
    const url = URL.createObjectURL(result.blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = result.filename || "vision_algorithm.py";
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    URL.revokeObjectURL(url);
    setStatus("独立算法脚本已导出");
    toast("脚本已导出", anchor.download, true);
  }catch(error){
    setStatus(`脚本导出失败：${error.message}`);
    toast("脚本导出失败", error.message);
  }
}

async function saveWorkflowLocal(){
  const documentInfo = getActiveWorkflowDocument();
  if(!documentInfo) return;
  captureActiveWorkflowDocument(false);
  try{
    const project = await VisionWorkspaceStore.saveServerDocument(documentInfo);
    documentInfo.projectId = project.project_id;
    documentInfo.savedSnapshot = workflowSignature(documentInfo.workflow);
    documentInfo.savedName = documentInfo.name;
    documentInfo.dirty = false;
    renderWorkflowTabs();
    persistWorkspace();
    toast("项目已保存", `${documentInfo.name} · 服务端项目库`, true);
    setStatus(`${documentInfo.name} 已保存到服务端项目库（Ctrl+S）`);
  }catch(error){
    documentInfo.savedSnapshot = workflowSignature(documentInfo.workflow);
    documentInfo.savedName = documentInfo.name;
    documentInfo.dirty = false;
    storageSet("vision_python_mvp_workflow_v3", JSON.stringify(documentInfo.workflow, null, 2));
    renderWorkflowTabs();
    persistWorkspace();
    toast("服务端保存失败，已本地兜底", error.message || String(error));
    setStatus(`${documentInfo.name} 已保存到本地缓存；服务端保存失败：${error.message || error}`);
  }
}

async function openProjectFromServer(){
  try{
    const data = await VisionApi.listProjects();
    const projects = data.projects || [];
    if(!projects.length){ toast("暂无项目", "服务端项目库为空"); return; }
    const menu = projects.map((item, index) => `${index + 1}. ${item.name}（${item.node_count || 0} 节点，${item.updated_at || ""}）`).join("\n");
    const answer = window.prompt(`输入要打开的项目序号：\n${menu}`, "1");
    if(answer === null) return;
    const index = Number(answer) - 1;
    if(!Number.isInteger(index) || index < 0 || index >= projects.length){ toast("打开失败", "项目序号无效"); return; }
    const documentInfo = await VisionWorkspaceStore.openServerProject(projects[index].project_id);
    captureActiveWorkflowDocument(true);
    const existingIndex = workflowDocuments.findIndex(item => item.projectId === documentInfo.projectId);
    if(existingIndex >= 0) workflowDocuments[existingIndex] = documentInfo;
    else workflowDocuments.push(documentInfo);
    activeWorkflowId = documentInfo.id;
    restoreWorkflowDocument(documentInfo);
    renderWorkflowTabs();
    persistWorkspace();
    toast("项目已打开", documentInfo.name, true);
  }catch(error){
    toast("打开项目失败", error.message || String(error));
  }
}

async function showModelManager(){
  try{
    const data = await VisionApi.listModels();
    const models = data.models || [];
    const cache = data.cache || {};
    const lines = models.length
      ? models.map((item, index) => `${index + 1}. ${item.filename} · ${Math.round((item.size || 0) / 1024 / 1024 * 10) / 10}MB · ${item.exists ? "文件存在" : "文件缺失"}`).join("\n")
      : "暂无已上传模型";
    window.alert(`模型管理\n已注册：${models.length} 个；缓存：${cache.cached_count || 0}/${cache.max_items || 0}\n\n${lines}`);
  }catch(error){
    toast("模型列表获取失败", error.message || String(error));
  }
}

function loadWorkflowLocal(){
  const documentInfo = getActiveWorkflowDocument();
  if(!documentInfo) return;
  let workflow = null;
  if(documentInfo.savedSnapshot){
    try{ workflow = JSON.parse(documentInfo.savedSnapshot); }catch(error){ console.warn(error); }
  }
  if(!workflow){
    const raw = storageGet("vision_python_mvp_workflow_v3") || storageGet("vision_python_mvp_workflow_v2");
    if(raw){
      try{ workflow = JSON.parse(raw); }catch(error){ toast("加载失败", error.message || String(error)); return; }
    }
  }
  if(!workflow){ toast("加载失败", "当前工作流还没有保存版本"); return; }
  suppressDocumentSync = true;
  try{ applyWorkflow(workflow, { silent:true }); }finally{ suppressDocumentSync = false; }
  documentInfo.workflow = buildWorkflow();
  documentInfo.savedSnapshot = workflowSignature(documentInfo.workflow);
  documentInfo.name = documentInfo.savedName || documentInfo.name;
  documentInfo.savedName = documentInfo.name;
  documentInfo.dirty = false;
  documentInfo.runtimePreviews = [];
  renderWorkflowTabs();
  persistWorkspace();
  toast("已恢复保存版本", documentInfo.name, true);
  setStatus(`${documentInfo.name} 已恢复到最近保存状态`);
}
function downloadWorkflowJson(){
  const documentInfo = getActiveWorkflowDocument();
  const blob = new Blob([JSON.stringify(buildWorkflow(), null, 2)], { type:"application/json" });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = `${safeFilename(documentInfo?.name || "vision_workflow")}.json`;
  anchor.click();
  URL.revokeObjectURL(url);
}
function resetView(){ pan = { x:-260, y:-120 }; zoom = .82; applyTransform(); persistActiveWorkflowView(); setStatus("已重置画布视图"); }

function applyWorkflow(workflow, options = {}){
  nodePreviews.clear();
  previewActionNodeId = null;
  colorPaletteNodeId = null;
  closeImageLightbox();
  nodes = (workflow.nodes || []).map(rawNode => {
    const normalized = normalizeNodeType(rawNode.type, rawNode.params || {});
    if(!OPERATOR_META[normalized.type]) return null;
    return {
      id:rawNode.id,
      type:normalized.type,
      position:rawNode.position || { x:100, y:100 },
      params:{ ...defaultParams(normalized.type), ...normalized.params },
      collapsed:Boolean(rawNode.collapsed),
      color:safeColor(rawNode.color || DEFAULT_NODE_COLOR),
    };
  }).filter(Boolean);
  edges = (workflow.edges || [])
    .filter(edge => nodes.some(node => node.id === edge.source) && nodes.some(node => node.id === edge.target))
    .map(edge => ({ ...edge, sourceHandle:edge.sourceHandle || "out", targetHandle:edge.targetHandle || "in" }));
  const nodeIds = new Set(nodes.map(node => node.id));
  workflowModules = (workflow.modules || []).map(rawModule => ({
    id:String(rawModule.id || `m${moduleSeq++}`),
    name:String(rawModule.name || "功能模块"),
    node_ids:(rawModule.node_ids || rawModule.nodeIds || []).filter(nodeId => nodeIds.has(nodeId)),
    description:String(rawModule.description || ""),
    color:safeColor(rawModule.color || "#526b75"),
    opacity:normalizeModuleOpacity(rawModule.opacity),
    collapsed:Boolean(rawModule.collapsed),
  })).filter(moduleInfo => moduleInfo.node_ids.length);
  const maxModuleSeq = workflowModules.reduce((maxValue, moduleInfo) => Math.max(maxValue, Number(String(moduleInfo.id).replace(/^m/, "")) || 0), 0);
  moduleSeq = maxModuleSeq + 1;
  connectingSourceId = null;
  connectingSourceHandle = "out";
  const maxSequence = nodes.reduce((maxValue, node) => Math.max(maxValue, Number(String(node.id).replace(/^n/, "")) || 0), 0);
  nodeSeq = maxSequence + 1;
  selectedNodeId = nodes[0]?.id || null;
  selectedEdgeId = null;
  selectedModuleId = null;
  clearRunLog("工作流已加载，运行后显示实时日志。");
  render();
  if(!options.silent) setStatus("工作流已加载；旧版 Gray/BGR2RGB 节点已自动迁移为颜色转换节点");
}

function createDemoWorkflow(){
  applyWorkflow(demoWorkflowDefinition(), { silent:true });
  pan = { x:-260, y:-120 };
  zoom = .82;
  applyTransform();
  commitActiveWorkflowChange();
  setStatus("示例流程已生成。请在读取图像节点内填写服务器图片路径，然后运行。");
  toast("示例流程已生成", "请先填写 ReadImage 的图片路径", true);
}

function clearWorkflow(){
  applyWorkflow(emptyWorkflow(), { silent:true });
  commitActiveWorkflowChange();
  setStatus("流程已清空");
}

function upstreamNodeIds(nodeId){
  const result = new Set();
  const stack = [nodeId];
  while(stack.length){
    const current = stack.pop();
    if(!current || result.has(current)) continue;
    result.add(current);
    edges.filter(edge => edge.target === current).forEach(edge => stack.push(edge.source));
  }
  return Array.from(result);
}

function defaultModuleNameForNodeIds(nodeIds){
  if(!nodeIds.length) return "功能模块";
  const first = nodes.find(node => node.id === nodeIds[0]);
  const label = first ? ((OPERATOR_META[first.type] || {}).label || first.type) : "功能模块";
  if(nodeIds.length === 1) return `${label}模块`;
  return `${label}等 ${nodeIds.length} 节点模块`;
}
function openModuleEditor(options = {}){
  const mode = options.mode === "edit" ? "edit" : "create";
  const moduleInfo = mode === "edit" ? workflowModules.find(item => item.id === options.moduleId) : null;
  const nodeIds = mode === "edit" ? moduleNodeIds(moduleInfo) : (options.nodeIds || []).filter(id => nodes.some(node => node.id === id));
  if(!nodeIds.length){
    toast("无法创建模块", "请先用鼠标框选至少一个节点");
    return;
  }
  moduleEditorState = {
    mode,
    moduleId:moduleInfo?.id || null,
    nodeIds:[...new Set(nodeIds)],
  };
  const modal = document.getElementById("moduleEditor");
  if(!modal) return;
  const nameInput = document.getElementById("moduleNameInput");
  const descInput = document.getElementById("moduleDescriptionInput");
  const colorInput = document.getElementById("moduleColorInput");
  const opacityInput = document.getElementById("moduleOpacityInput");
  const collapsedInput = document.getElementById("moduleCollapsedInput");
  document.getElementById("moduleEditorTitle").textContent = mode === "edit" ? "编辑功能模块" : "创建功能模块";
  document.getElementById("moduleEditorSummary").textContent = `${nodeIds.length} 个节点：${nodeIds.join("、")}`;
  nameInput.value = moduleInfo?.name || defaultModuleNameForNodeIds(nodeIds);
  descInput.value = moduleInfo?.description || "";
  colorInput.value = safeColor(moduleInfo?.color || "#526b75");
  opacityInput.value = normalizeModuleOpacity(moduleInfo?.opacity);
  collapsedInput.checked = Boolean(moduleInfo?.collapsed);
  document.getElementById("moduleEditorDeleteButton").style.display = mode === "edit" ? "inline-flex" : "none";
  document.getElementById("moduleEditorSubmitButton").textContent = mode === "edit" ? "保存模块" : "创建模块";
  renderModuleColorSwatches();
  updateModuleEditorPreview();
  modal.classList.add("open");
  modal.setAttribute("aria-hidden", "false");
  document.body.classList.add("module-editor-open");
  nameInput.focus();
  nameInput.select();
}
function closeModuleEditor(){
  const modal = document.getElementById("moduleEditor");
  if(modal){
    modal.classList.remove("open");
    modal.setAttribute("aria-hidden", "true");
  }
  document.body.classList.remove("module-editor-open");
  moduleEditorState = null;
}
function renderModuleColorSwatches(){
  const container = document.getElementById("moduleColorSwatches");
  if(!container) return;
  const current = safeColor(document.getElementById("moduleColorInput")?.value || "#526b75");
  container.innerHTML = MODULE_COLORS.map(color => `<button type="button" class="module-color-swatch ${color === current ? "active" : ""}" style="background:${color}" data-module-color="${color}" title="使用 ${color}"></button>`).join("");
  container.querySelectorAll("[data-module-color]").forEach(button => {
    button.onclick = () => {
      document.getElementById("moduleColorInput").value = button.dataset.moduleColor;
      renderModuleColorSwatches();
      updateModuleEditorPreview();
    };
  });
}
function updateModuleEditorPreview(){
  const name = document.getElementById("moduleNameInput")?.value || "功能模块";
  const color = safeColor(document.getElementById("moduleColorInput")?.value || "#526b75");
  const opacity = normalizeModuleOpacity(document.getElementById("moduleOpacityInput")?.value);
  const label = document.getElementById("moduleOpacityLabel");
  if(label) label.textContent = `${Math.round(opacity * 100)}%`;
  const card = document.getElementById("modulePreviewCard");
  if(card){
    card.style.setProperty("--module-accent", color);
    card.style.setProperty("--module-opacity", String(opacity));
    card.style.setProperty("--module-opacity-percent", `${Math.round(opacity * 100)}%`);
    card.querySelector(".module-preview-title").textContent = name;
    card.querySelector(".module-preview-subtitle").textContent = `${moduleEditorState?.nodeIds?.length || 0} 个节点 · 可折叠展开`;
  }
}
function submitModuleEditor(){
  if(!moduleEditorState) return;
  const name = (document.getElementById("moduleNameInput")?.value || "").trim() || "功能模块";
  const description = (document.getElementById("moduleDescriptionInput")?.value || "").trim();
  const color = safeColor(document.getElementById("moduleColorInput")?.value || "#526b75");
  const opacity = normalizeModuleOpacity(document.getElementById("moduleOpacityInput")?.value);
  const collapsed = Boolean(document.getElementById("moduleCollapsedInput")?.checked);
  const node_ids = [...new Set(moduleEditorState.nodeIds)].filter(id => nodes.some(node => node.id === id));
  if(!node_ids.length){
    toast("模块保存失败", "模块内没有有效节点");
    return;
  }
  if(moduleEditorState.mode === "edit"){
    const moduleInfo = workflowModules.find(item => item.id === moduleEditorState.moduleId);
    if(!moduleInfo) return;
    Object.assign(moduleInfo, { name, description, color, opacity, collapsed, node_ids });
    selectedModuleId = moduleInfo.id;
    toast("模块已更新", name, true);
  }else{
    const moduleId = `m${moduleSeq++}`;
    workflowModules.push({ id:moduleId, name, node_ids, description, color, opacity, collapsed });
    selectedModuleId = moduleId;
    selectedNodeId = null;
    selectedEdgeId = null;
    toast("模块已创建", `${name}：${node_ids.length} 个节点`, true);
  }
  closeModuleEditor();
  commitActiveWorkflowChange();
  render();
}
function deleteEditingModule(){
  if(!moduleEditorState?.moduleId) return;
  const moduleId = moduleEditorState.moduleId;
  closeModuleEditor();
  deleteWorkflowModule(moduleId);
}
function createWorkflowModule(nodeIds = null){
  const ids = Array.isArray(nodeIds) && nodeIds.length
    ? nodeIds
    : selectedNodeId ? upstreamNodeIds(selectedNodeId) : nodes.map(node => node.id);
  openModuleEditor({ mode:"create", nodeIds:ids });
}
function deleteWorkflowModule(moduleId){
  const moduleInfo = workflowModules.find(item => item.id === moduleId);
  if(!moduleInfo) return;
  if(!confirm(`解除模块「${moduleInfo.name || moduleId}」？节点不会被删除。`)) return;
  workflowModules = workflowModules.filter(item => item.id !== moduleId);
  if(selectedModuleId === moduleId) selectedModuleId = null;
  commitActiveWorkflowChange();
  render();
  toast("已解除模块", moduleInfo.name || moduleId, true);
}
function toggleWorkflowModule(moduleId){
  const moduleInfo = workflowModules.find(item => item.id === moduleId);
  if(!moduleInfo) return;
  moduleInfo.collapsed = !moduleInfo.collapsed;
  selectedModuleId = moduleId;
  selectedNodeId = null;
  selectedEdgeId = null;
  commitActiveWorkflowChange();
  render();
}
function expandAllWorkflowModules(){
  let changed = false;
  workflowModules.forEach(moduleInfo => {
    if(moduleInfo.collapsed){ moduleInfo.collapsed = false; changed = true; }
  });
  if(changed) commitActiveWorkflowChange();
  render();
}
function collapseAllWorkflowModules(){
  let changed = false;
  workflowModules.forEach(moduleInfo => {
    if(!moduleInfo.collapsed){ moduleInfo.collapsed = true; changed = true; }
  });
  if(changed) commitActiveWorkflowChange();
  render();
}
function toggleWorkflowExplorer(){
  setSidePanelMode(activeSidePanel === "structure" ? null : "structure");
}
function executionOrderForExplorer(){
  const order = (typeof topologicalNodeOrderForLayout === "function" ? topologicalNodeOrderForLayout() : null) || nodes.map(node => node.id);
  const known = new Set(order);
  nodes.map(node => node.id).filter(id => !known.has(id)).forEach(id => order.push(id));
  return order;
}
function primaryModuleForNode(nodeId){
  const candidates = (workflowModules || []).filter(moduleInfo => moduleNodeIds(moduleInfo).includes(nodeId));
  if(!candidates.length) return null;
  candidates.sort((a, b) => moduleNodeIds(a).length - moduleNodeIds(b).length || String(a.id).localeCompare(String(b.id)));
  return candidates[0];
}
function sameExplorerScope(sourceId, targetId){
  const sourceModule = primaryModuleForNode(sourceId);
  const targetModule = primaryModuleForNode(targetId);
  return (sourceModule?.id || null) === (targetModule?.id || null);
}
function isIfElseNode(nodeId){
  const node = nodes.find(item => item.id === nodeId);
  return node?.type === "LogicIfElse";
}
function buildIfElseBranchIndex(orderIndex){
  const branchIndex = new Map();
  const branchOwned = new Map();
  const branchHandles = ["true_value", "false_value"];
  nodes.filter(node => node.type === "LogicIfElse").forEach(ifNode => {
    const grouped = { true_value:[], false_value:[] };
    branchHandles.forEach(handle => {
      edges
        .filter(edge => edge.target === ifNode.id && (edge.targetHandle || "in") === handle)
        .map(edge => edge.source)
        .filter(sourceId => sourceId !== ifNode.id && sameExplorerScope(sourceId, ifNode.id))
        .sort((a, b) => (orderIndex.get(a) ?? 999999) - (orderIndex.get(b) ?? 999999))
        .forEach(sourceId => {
          grouped[handle].push(sourceId);
          if(!branchOwned.has(sourceId)) branchOwned.set(sourceId, { ifNodeId:ifNode.id, handle });
        });
    });
    if(grouped.true_value.length || grouped.false_value.length) branchIndex.set(ifNode.id, grouped);
  });
  return { branchIndex, branchOwned };
}
function workflowStructureGroups(){
  const order = executionOrderForExplorer();
  const orderIndex = new Map(order.map((id, index) => [id, index]));
  const nodeIds = new Set(nodes.map(node => node.id));
  const { branchIndex, branchOwned } = buildIfElseBranchIndex(orderIndex);
  const moduleMap = new Map();
  (workflowModules || []).forEach(moduleInfo => {
    const ids = moduleNodeIds(moduleInfo).filter(id => nodeIds.has(id));
    if(!ids.length) return;
    ids.sort((a, b) => (orderIndex.get(a) ?? 999999) - (orderIndex.get(b) ?? 999999));
    const visibleIds = ids.filter(id => {
      const owner = branchOwned.get(id);
      return !owner || !ids.includes(owner.ifNodeId);
    });
    const minOrder = Math.min(...ids.map(id => orderIndex.get(id) ?? 999999));
    moduleMap.set(moduleInfo.id, { type:"module", moduleInfo, ids, visibleIds, minOrder });
  });
  const items = [];
  const emittedModules = new Set();
  order.forEach(nodeId => {
    if(branchOwned.has(nodeId)) return;
    const moduleInfo = primaryModuleForNode(nodeId);
    if(moduleInfo && moduleMap.has(moduleInfo.id)){
      if(!emittedModules.has(moduleInfo.id)){
        emittedModules.add(moduleInfo.id);
        items.push(moduleMap.get(moduleInfo.id));
      }
    }else if(nodeIds.has(nodeId)){
      items.push({ type:"node", id:nodeId, minOrder:orderIndex.get(nodeId) ?? 999999 });
    }
  });
  return { items, order, orderIndex, branchIndex, branchOwned };
}
function renameActiveWorkflowFromExplorer(){
  const documentInfo = getActiveWorkflowDocument();
  if(!documentInfo) return;
  renameWorkflow(documentInfo.id);
  renderWorkflowExplorer();
}
function renderWorkflowExplorer(){
  const container = document.getElementById("workflowExplorer");
  if(!container) return;
  const documentInfo = getActiveWorkflowDocument();
  const workflowName = documentInfo?.name || "Vision Workflow";
  const { items, orderIndex, branchIndex } = workflowStructureGroups();
  const rootHtml = `<div class="workflow-tree-root">
    <div class="workflow-tree-root-head">
      <span class="tree-root-icon">▣</span>
      <button type="button" class="tree-root-title" title="点击重命名工作流" onclick="renameActiveWorkflowFromExplorer()">${escapeHtml(workflowName)}</button>
      <button type="button" class="tree-action" title="重命名工作流" onclick="renameActiveWorkflowFromExplorer()">✎</button>
    </div>
    <div class="workflow-tree-root-meta"><b>${nodes.length}</b> 节点 · <b>${workflowModules.length}</b> 模块 · <b>${edges.length}</b> 连线 · 普通连线仅排序，模块/If 才形成层级</div>
  </div>`;
  if(!nodes.length){
    container.innerHTML = `${rootHtml}<div class="workflow-explorer-empty">当前工作流为空。拖拽节点到画布，或导入一个流程。</div>`;
    return;
  }
  const renderNodeButton = (nodeId, options = {}) => {
    const node = nodes.find(item => item.id === nodeId);
    if(!node) return "";
    const meta = OPERATOR_META[node.type] || {};
    const selected = selectedNodeId === node.id;
    const preview = nodePreviews.get(node.id);
    const status = preview?.status === "error" ? "error" : preview?.status === "success" ? "success" : "idle";
    const orderNo = (orderIndex.get(node.id) ?? 0) + 1;
    const parents = edges.filter(edge => edge.target === node.id).map(edge => `${edge.source}.${edge.sourceHandle || "out"}`);
    const parentHint = parents.length ? `输入来自：${parents.join("、")}` : "入口节点";
    const roleClass = isIfElseNode(node.id) ? "if-node" : "";
    const extraClass = options.extraClass || "";
    return `<button type="button" class="workflow-tree-node ${roleClass} ${extraClass} ${selected ? "selected" : ""} ${status}" onclick="focusNodeInCanvas('${escapeHtml(node.id)}')" title="#${orderNo} ${escapeHtml(node.id)} · ${escapeHtml(parentHint)} · ${escapeHtml(meta.description || meta.label || node.type)}">
      <span class="tree-node-icon">${ICONS[meta.category || meta.kind] || "◇"}</span>
      <span class="tree-node-label"><em>#${orderNo}</em>${escapeHtml(meta.label || node.type)}</span>
      <small>${escapeHtml(node.id)}</small>
    </button>`;
  };
  const renderIfBranches = nodeId => {
    const branches = branchIndex.get(nodeId);
    if(!branches) return "";
    const renderBranch = (handle, title, icon) => {
      const ids = branches[handle] || [];
      if(!ids.length) return "";
      const body = ids.map(id => renderNodeWithLogicalChildren(id, { extraClass:"branch-child" })).join("");
      return `<div class="workflow-tree-branch ${handle === "true_value" ? "branch-true" : "branch-false"}">
        <div class="workflow-tree-branch-title"><span>${icon}</span><b>${title}</b><small>${handle}</small></div>
        <div class="workflow-tree-branch-children">${body}</div>
      </div>`;
    };
    return `<div class="workflow-tree-branches">${renderBranch("true_value", "If 分支", "✓")}${renderBranch("false_value", "Else 分支", "×")}</div>`;
  };
  const renderNodeWithLogicalChildren = (nodeId, options = {}) => {
    return `<div class="workflow-tree-node-wrap">${renderNodeButton(nodeId, options)}${renderIfBranches(nodeId)}</div>`;
  };
  const renderModuleNodeList = item => {
    const visibleIds = item.visibleIds || item.ids || [];
    return visibleIds.map(id => renderNodeWithLogicalChildren(id)).join("");
  };
  const itemHtml = items.map(item => {
    if(item.type === "node"){
      return `<div class="workflow-tree-standalone">${renderNodeWithLogicalChildren(item.id)}</div>`;
    }
    const moduleInfo = item.moduleInfo;
    const selected = selectedModuleId === moduleInfo.id;
    const color = safeColor(moduleInfo.color || "#526b75");
    const orderStart = Math.min(...item.ids.map(id => orderIndex.get(id) ?? 999999)) + 1;
    return `<div class="workflow-tree-module ${selected ? "selected" : ""}" style="--module-accent:${color}">
      <div class="workflow-tree-module-head">
        <button type="button" class="tree-toggle" title="折叠/展开模块" onclick="toggleWorkflowModule('${escapeHtml(moduleInfo.id)}')">${moduleInfo.collapsed ? "▸" : "▾"}</button>
        <button type="button" class="tree-module-title" onclick="focusModuleInCanvas('${escapeHtml(moduleInfo.id)}')" title="执行段 #${orderStart} 起 · ${escapeHtml(moduleInfo.description || moduleInfo.name || "功能模块")}">
          <span class="tree-folder-icon">▦</span><b><em>#${orderStart}</em>${escapeHtml(moduleInfo.name || "功能模块")}</b><small>${item.ids.length}</small>
        </button>
        <button type="button" class="tree-action" title="编辑模块" onclick="openModuleEditor({mode:'edit', moduleId:'${escapeHtml(moduleInfo.id)}'})">⚙</button>
      </div>
      <div class="workflow-tree-children ${moduleInfo.collapsed ? "hidden" : ""}">${renderModuleNodeList(item)}</div>
    </div>`;
  }).join("");
  container.innerHTML = `${rootHtml}${itemHtml}`;
}

function toast(title, text, ok){
  const element = document.getElementById("toast");
  document.getElementById("toastTitle").textContent = title;
  document.getElementById("toastText").textContent = text || "";
  element.className = `toast show${ok ? " ok" : ""}`;
  clearTimeout(window.__toastTimer);
  window.__toastTimer = setTimeout(() => element.className = "toast", 3200);
}
function setStatus(text){ statusEl.textContent = text; }
function escapeHtml(value){
  return String(value).replace(/[&<>"']/g, character => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" })[character]);
}
function safeFilename(value){ return String(value).replace(/[\\/:*?"<>|\s]+/g, "_").replace(/^_+|_+$/g, "") || "result"; }
function safeColor(value){ return /^#[0-9a-fA-F]{6}$/.test(String(value)) ? String(value) : DEFAULT_NODE_COLOR; }

