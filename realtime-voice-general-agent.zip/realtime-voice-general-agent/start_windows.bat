@echo off
chcp 65001 >nul
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo [错误] 未检测到 Node.js。请先安装 Node.js 20 或更高版本。
  pause
  exit /b 1
)

if not exist .env (
  copy .env.example .env >nul
  echo 已创建 .env，请用记事本填写 OPENAI_API_KEY 后重新运行。
  notepad .env
  pause
  exit /b 0
)

echo 正在启动通用实时语音 Agent...
start "" http://127.0.0.1:3000
node server.js
pause
