const elements = {
  startButton: document.querySelector("#startButton"),
  stopButton: document.querySelector("#stopButton"),
  muteButton: document.querySelector("#muteButton"),
  clearButton: document.querySelector("#clearButton"),
  copyButton: document.querySelector("#copyButton"),
  downloadButton: document.querySelector("#downloadButton"),
  resultMeta: document.querySelector("#resultMeta"),
  capabilityList: document.querySelector("#capabilityList"),
  connectionBadge: document.querySelector("#connectionBadge"),
  connectionText: document.querySelector("#connectionText"),
  agentState: document.querySelector("#agentState"),
  voiceOrb: document.querySelector("#voiceOrb"),
  messages: document.querySelector("#messages"),
  emptyConversation: document.querySelector("#emptyConversation"),
  textForm: document.querySelector("#textForm"),
  textInput: document.querySelector("#textInput"),
  sendButton: document.querySelector("#sendButton"),
  toolStatus: document.querySelector("#toolStatus"),
  resultContent: document.querySelector("#resultContent"),
  debugToggle: document.querySelector("#debugToggle"),
  eventLog: document.querySelector("#eventLog"),
  toast: document.querySelector("#toast")
};

let peerConnection = null;
let dataChannel = null;
let localStream = null;
let remoteAudio = null;
let muted = false;
let activeAssistantBubble = null;
let assistantBuffer = "";
let currentResultMarkdown = "";
let currentResultTitle = "任务结果";
let transcribeModel = "gpt-4o-mini-transcribe";
const executedCallIds = new Set();
const eventHistory = [];

const setConnection = (state, text) => {
  elements.connectionBadge.className = `status-badge ${state}`;
  elements.connectionText.textContent = text;
};

const setAgentState = (text, orbState = "idle") => {
  elements.agentState.textContent = text;
  elements.voiceOrb.className = `voice-orb ${orbState}`;
};

const setControls = (connected) => {
  elements.startButton.disabled = connected;
  elements.stopButton.disabled = !connected;
  elements.muteButton.disabled = !connected;
  elements.textInput.disabled = !connected;
  elements.sendButton.disabled = !connected;
};

const showToast = (message) => {
  elements.toast.textContent = message;
  elements.toast.classList.add("show");
  window.clearTimeout(showToast.timer);
  showToast.timer = window.setTimeout(() => elements.toast.classList.remove("show"), 3400);
};

const logEvent = (direction, event) => {
  const record = {
    time: new Date().toLocaleTimeString(),
    direction,
    type: event?.type || "unknown",
    event
  };
  eventHistory.unshift(record);
  if (eventHistory.length > 80) eventHistory.pop();
  elements.eventLog.textContent = eventHistory
    .map((item) => `[${item.time}] ${item.direction} ${item.type}\n${JSON.stringify(item.event, null, 2)}`)
    .join("\n\n");
};

const sendEvent = (event) => {
  if (!dataChannel || dataChannel.readyState !== "open") {
    throw new Error("实时数据通道尚未连接。");
  }
  const payload = { event_id: crypto.randomUUID(), ...event };
  dataChannel.send(JSON.stringify(payload));
  logEvent("→", payload);
};

const addMessage = (role, text, live = false) => {
  elements.emptyConversation?.remove();
  const wrapper = document.createElement("div");
  wrapper.className = `message ${role}${live ? " live" : ""}`;

  const roleLabel = document.createElement("span");
  roleLabel.className = "role";
  roleLabel.textContent = role === "user" ? "你" : "AI 助手";

  const bubble = document.createElement("div");
  bubble.className = "bubble";
  bubble.textContent = text;

  wrapper.append(roleLabel, bubble);
  elements.messages.appendChild(wrapper);
  elements.messages.scrollTop = elements.messages.scrollHeight;
  return { wrapper, bubble };
};

const updateAssistantTranscript = (delta) => {
  if (!delta) return;
  if (!activeAssistantBubble) {
    assistantBuffer = "";
    activeAssistantBubble = addMessage("assistant", "", true);
  }
  assistantBuffer += delta;
  activeAssistantBubble.bubble.textContent = assistantBuffer;
  elements.messages.scrollTop = elements.messages.scrollHeight;
};

const finalizeAssistantTranscript = (transcript = "") => {
  if (transcript && !assistantBuffer) updateAssistantTranscript(transcript);
  if (activeAssistantBubble) activeAssistantBubble.wrapper.classList.remove("live");
  activeAssistantBubble = null;
  assistantBuffer = "";
};

const escapeHtml = (value) =>
  value
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");

function markdownToHtml(markdown) {
  const lines = escapeHtml(markdown).split("\n");
  const html = [];
  let listType = null;

  const closeList = () => {
    if (listType) html.push(`</${listType}>`);
    listType = null;
  };

  for (const rawLine of lines) {
    const line = rawLine.trimEnd();

    if (/^# /.test(line)) {
      closeList();
      html.push(`<h1>${line.slice(2)}</h1>`);
    } else if (/^## /.test(line)) {
      closeList();
      html.push(`<h2>${line.slice(3)}</h2>`);
    } else if (/^---+$/.test(line)) {
      closeList();
      html.push("<hr>");
    } else if (/^- \[ \] /.test(line)) {
      if (listType !== "ul") {
        closeList();
        html.push("<ul>");
        listType = "ul";
      }
      html.push(`<li>☐ ${line.slice(6)}</li>`);
    } else if (/^- /.test(line)) {
      if (listType !== "ul") {
        closeList();
        html.push("<ul>");
        listType = "ul";
      }
      html.push(`<li>${line.slice(2)}</li>`);
    } else if (/^\d+\. /.test(line)) {
      if (listType !== "ol") {
        closeList();
        html.push("<ol>");
        listType = "ol";
      }
      html.push(`<li>${line.replace(/^\d+\. /, "")}</li>`);
    } else if (!line.trim()) {
      closeList();
    } else {
      closeList();
      const formatted = line.replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>");
      html.push(`<p>${formatted}</p>`);
    }
  }

  closeList();
  return html.join("\n");
}

const setToolStatus = (state, title, detail) => {
  const icon = state === "running" ? "↻" : state === "done" ? "✓" : state === "error" ? "!" : "⌁";
  elements.toolStatus.className = `tool-status ${state}`;
  elements.toolStatus.innerHTML = `
    <span class="tool-icon">${icon}</span>
    <div><strong>${escapeHtml(title)}</strong><span>${escapeHtml(detail)}</span></div>
  `;
};

async function executeFunctionCall(call) {
  const callId = call.call_id || call.callId || call.id;
  const name = call.name;
  if (!callId || !name || executedCallIds.has(callId)) return;
  executedCallIds.add(callId);

  let args = {};
  try {
    args = typeof call.arguments === "string" ? JSON.parse(call.arguments || "{}") : call.arguments || {};
  } catch {
    args = {};
  }

  setToolStatus("running", `正在执行 ${name}`, "模型已完成意图识别，正在调用后端工具。 ");
  setAgentState("正在执行任务…", "speaking");

  try {
    const response = await fetch("/api/tools/execute", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, arguments: args, callId })
    });
    const result = await response.json();
    if (!response.ok || !result.ok) throw new Error(result.error || "工具执行失败");

    currentResultMarkdown = result.markdown || JSON.stringify(result, null, 2);
    elements.resultContent.innerHTML = markdownToHtml(currentResultMarkdown);
    elements.resultContent.classList.remove("hidden");
    currentResultTitle = result.title || "任务结果";
    elements.copyButton.disabled = false;
    elements.downloadButton.disabled = false;
    if (result.data && Object.keys(result.data).length) {
      elements.resultMeta.textContent = Object.entries(result.data)
        .map(([key, value]) => `${key}: ${Array.isArray(value) ? value.join("、") : value}`)
        .join(" · ");
      elements.resultMeta.classList.remove("hidden");
    } else {
      elements.resultMeta.classList.add("hidden");
    }
    setToolStatus("done", result.title || "任务已完成", result.summary || "结果已生成。 ");

    sendEvent({
      type: "conversation.item.create",
      item: {
        type: "function_call_output",
        call_id: callId,
        output: JSON.stringify({
          ok: true,
          title: result.title,
          summary: result.summary,
          result_location: "页面右侧任务执行结果区域",
          data: result.model_output || result.data || null
        })
      }
    });

    sendEvent({
      type: "response.create",
      response: {
        instructions: "工具已经成功执行。用一句简短中文告诉用户任务已完成，结果显示在右侧，不要朗读全文。"
      }
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : "工具执行失败";
    setToolStatus("error", "工具执行失败", message);
    showToast(message);

    try {
      sendEvent({
        type: "conversation.item.create",
        item: {
          type: "function_call_output",
          call_id: callId,
          output: JSON.stringify({ ok: false, error: message })
        }
      });
      sendEvent({
        type: "response.create",
        response: { instructions: "工具执行失败。用中文简短说明失败，并建议用户重试。" }
      });
    } catch {
      // 会话可能已经关闭。
    }
  }
}

function findFunctionCalls(event) {
  const calls = [];

  if (event.type === "response.function_call_arguments.done") {
    calls.push({
      call_id: event.call_id,
      name: event.name,
      arguments: event.arguments
    });
  }

  if (event.type === "response.done" && Array.isArray(event.response?.output)) {
    for (const output of event.response.output) {
      if (output.type === "function_call") calls.push(output);
    }
  }

  return calls;
}

function handleServerEvent(event) {
  logEvent("←", event);

  switch (event.type) {
    case "session.created":
      break;

    case "input_audio_buffer.speech_started":
      setAgentState("正在听你说话…", "listening");
      break;

    case "input_audio_buffer.speech_stopped":
      setAgentState("正在理解…", "speaking");
      break;

    case "conversation.item.input_audio_transcription.completed":
      if (event.transcript?.trim()) addMessage("user", event.transcript.trim());
      break;

    case "response.audio_transcript.delta":
    case "response.output_audio_transcript.delta":
    case "response.text.delta":
    case "response.output_text.delta":
      updateAssistantTranscript(event.delta || "");
      setAgentState("AI 正在回答…", "speaking");
      break;

    case "response.audio_transcript.done":
    case "response.output_audio_transcript.done":
    case "response.text.done":
    case "response.output_text.done":
      finalizeAssistantTranscript(event.transcript || event.text || "");
      break;

    case "response.done":
      finalizeAssistantTranscript();
      setAgentState("随时可以继续说话", "idle");
      break;

    case "error":
      console.error("Realtime error:", event);
      showToast(event.error?.message || "实时会话出现错误。");
      break;
  }

  for (const call of findFunctionCalls(event)) executeFunctionCall(call);
}

async function startSession() {
  setConnection("connecting", "连接中");
  setAgentState("正在申请麦克风权限…", "idle");
  elements.startButton.disabled = true;

  try {
    const healthResponse = await fetch("/api/health");
    const health = await healthResponse.json();
    if (Array.isArray(health.tools)) {
      elements.capabilityList.innerHTML = health.tools
        .map((tool) => `<span class="capability-chip" title="${escapeHtml(tool.examples || "")}">${escapeHtml(tool.label)}</span>`)
        .join("");
    }
    if (!health.configured) throw new Error("服务端未配置 OPENAI_API_KEY。请先填写 .env。 ");
    transcribeModel = health.transcribeModel || transcribeModel;

    localStream = await navigator.mediaDevices.getUserMedia({
      audio: {
        echoCancellation: true,
        noiseSuppression: true,
        autoGainControl: true,
        channelCount: 1
      }
    });

    peerConnection = new RTCPeerConnection();
    remoteAudio = document.createElement("audio");
    remoteAudio.autoplay = true;
    remoteAudio.playsInline = true;

    peerConnection.ontrack = (event) => {
      remoteAudio.srcObject = event.streams[0];
      remoteAudio.play().catch(() => showToast("请点击页面一次以允许播放 AI 语音。"));
    };

    peerConnection.onconnectionstatechange = () => {
      if (["failed", "disconnected"].includes(peerConnection?.connectionState)) {
        showToast("WebRTC 连接已中断。 ");
        stopSession();
      }
    };

    for (const track of localStream.getTracks()) peerConnection.addTrack(track, localStream);

    dataChannel = peerConnection.createDataChannel("oai-events");
    dataChannel.addEventListener("message", (message) => {
      try {
        handleServerEvent(JSON.parse(message.data));
      } catch (error) {
        console.error("Invalid realtime event:", error, message.data);
      }
    });

    dataChannel.addEventListener("open", () => {
      setConnection("online", "实时连接已建立");
      setAgentState("随时可以开始说话", "idle");
      setControls(true);
      sendEvent({
        type: "response.create",
        response: {
          instructions: "用一句简短中文问候用户，并告诉用户可以直接说出任何想完成的项目或内容任务。"
        }
      });
    });

    const offer = await peerConnection.createOffer();
    await peerConnection.setLocalDescription(offer);

    const sdpResponse = await fetch("/session", {
      method: "POST",
      headers: { "Content-Type": "application/sdp" },
      body: offer.sdp
    });

    const answerSdp = await sdpResponse.text();
    if (!sdpResponse.ok) throw new Error(answerSdp || "创建实时会话失败。 ");

    await peerConnection.setRemoteDescription({ type: "answer", sdp: answerSdp });
  } catch (error) {
    const message = error instanceof Error ? error.message : "启动失败";
    setConnection("error", "连接失败");
    setAgentState("连接失败，请检查配置后重试", "idle");
    showToast(message);
    cleanupSession();
  }
}

function cleanupSession() {
  if (dataChannel) dataChannel.close();
  dataChannel = null;

  if (localStream) {
    localStream.getTracks().forEach((track) => track.stop());
    localStream = null;
  }

  if (peerConnection) peerConnection.close();
  peerConnection = null;

  if (remoteAudio) {
    remoteAudio.pause();
    remoteAudio.srcObject = null;
    remoteAudio = null;
  }

  muted = false;
  elements.muteButton.textContent = "麦克风静音";
  activeAssistantBubble = null;
  assistantBuffer = "";
  executedCallIds.clear();
  setControls(false);
  elements.startButton.disabled = false;
}

function stopSession() {
  cleanupSession();
  setConnection("offline", "未连接");
  setAgentState("会话已结束，可以重新开始", "idle");
}

function toggleMute() {
  if (!localStream) return;
  muted = !muted;
  localStream.getAudioTracks().forEach((track) => (track.enabled = !muted));
  elements.muteButton.textContent = muted ? "取消静音" : "麦克风静音";
  setAgentState(muted ? "麦克风已静音" : "随时可以继续说话", "idle");
}

function sendTextMessage(text) {
  addMessage("user", text);
  sendEvent({
    type: "conversation.item.create",
    item: {
      type: "message",
      role: "user",
      content: [{ type: "input_text", text }]
    }
  });
  sendEvent({ type: "response.create" });
}

elements.startButton.addEventListener("click", startSession);
elements.stopButton.addEventListener("click", stopSession);
elements.muteButton.addEventListener("click", toggleMute);

elements.textForm.addEventListener("submit", (event) => {
  event.preventDefault();
  const text = elements.textInput.value.trim();
  if (!text) return;
  try {
    sendTextMessage(text);
    elements.textInput.value = "";
  } catch (error) {
    showToast(error instanceof Error ? error.message : "发送失败");
  }
});

elements.clearButton.addEventListener("click", () => {
  elements.messages.innerHTML = `
    <div class="empty-state" id="emptyConversation">
      <strong>对话已清空</strong><span>新的语音或文字内容会显示在这里。</span>
    </div>`;
  elements.emptyConversation = document.querySelector("#emptyConversation");
});

elements.downloadButton.addEventListener("click", () => {
  if (!currentResultMarkdown) return;
  const blob = new Blob([currentResultMarkdown], { type: "text/markdown;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `${currentResultTitle.replace(/[\/:*?"<>|]/g, "-") || "任务结果"}.md`;
  link.click();
  URL.revokeObjectURL(url);
});

elements.copyButton.addEventListener("click", async () => {
  if (!currentResultMarkdown) return;
  try {
    await navigator.clipboard.writeText(currentResultMarkdown);
    showToast("任务结果已复制。 ");
  } catch {
    showToast("复制失败，请手动选择文本。 ");
  }
});

elements.debugToggle.addEventListener("click", () => {
  elements.eventLog.classList.toggle("hidden");
  elements.debugToggle.textContent = elements.eventLog.classList.contains("hidden")
    ? "查看事件日志"
    : "隐藏事件日志";
});

async function loadCapabilities() {
  try {
    const response = await fetch("/api/tools");
    const data = await response.json();
    if (Array.isArray(data.tools)) {
      elements.capabilityList.innerHTML = data.tools
        .map((tool) => `<span class="capability-chip" title="${escapeHtml(tool.examples || "")}">${escapeHtml(tool.label)}</span>`)
        .join("");
    }
  } catch {
    elements.capabilityList.innerHTML = '<span class="capability-chip">工具列表加载失败</span>';
  }
}

loadCapabilities();
window.addEventListener("beforeunload", cleanupSession);
