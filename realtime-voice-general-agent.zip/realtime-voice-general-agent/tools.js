import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { fileURLToPath } from "node:url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DATA_DIR = path.join(__dirname, "data");
const OUTPUT_DIR = path.join(__dirname, "outputs");
const PROJECTS_FILE = path.join(DATA_DIR, "projects.json");
const NOTES_FILE = path.join(DATA_DIR, "notes.json");

for (const directory of [DATA_DIR, OUTPUT_DIR]) {
  fs.mkdirSync(directory, { recursive: true });
}

const cleanText = (value, fallback = "", maxLength = 30000) => {
  if (typeof value !== "string") return fallback;
  const text = value.trim();
  return (text || fallback).slice(0, maxLength);
};

const cleanList = (value, maxItems = 50) => {
  if (!Array.isArray(value)) return [];
  return value
    .map((item) => cleanText(item, "", 1000))
    .filter(Boolean)
    .slice(0, maxItems);
};

const readJsonArray = (file) => {
  try {
    const parsed = JSON.parse(fs.readFileSync(file, "utf8"));
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
};

const writeJsonArray = (file, value) => {
  fs.writeFileSync(file, `${JSON.stringify(value, null, 2)}\n`, "utf8");
};

const slugify = (value) =>
  cleanText(value, "artifact", 80)
    .toLowerCase()
    .replace(/[^\p{L}\p{N}]+/gu, "-")
    .replace(/^-+|-+$/g, "") || "artifact";

const timestampForFile = () => new Date().toISOString().replace(/[:.]/g, "-");

const saveMarkdown = (title, markdown) => {
  const fileName = `${timestampForFile()}-${slugify(title)}.md`;
  fs.writeFileSync(path.join(OUTPUT_DIR, fileName), `${markdown.trim()}\n`, "utf8");
  return fileName;
};

const listSection = (title, items, emptyText = "暂无") => {
  const body = items.length ? items.map((item, index) => `${index + 1}. ${item}`).join("\n") : emptyText;
  return `## ${title}\n\n${body}`;
};

const checkboxSection = (title, items, emptyText = "暂无") => {
  const body = items.length ? items.map((item) => `- [ ] ${item}`).join("\n") : emptyText;
  return `## ${title}\n\n${body}`;
};

export const TOOL_DEFINITIONS = [
  {
    type: "function",
    name: "create_artifact",
    description:
      "创建并保存任意文本型成果。当用户要方案、报告、需求文档、旅游攻略、会议纪要、总结、邮件、文案、清单、教程或其他可用 Markdown 表达的内容时调用。markdown_content 必须是已经完成、可以直接交付的正文，而不是写作建议。",
    parameters: {
      type: "object",
      strict: true,
      additionalProperties: false,
      properties: {
        title: { type: "string", description: "成果标题。" },
        artifact_type: {
          type: "string",
          enum: ["方案", "报告", "需求文档", "会议纪要", "旅游攻略", "邮件", "文案", "清单", "教程", "总结", "其他"],
          description: "成果类型。"
        },
        summary: { type: "string", description: "一句话说明已经完成了什么。" },
        markdown_content: { type: "string", description: "完整、可直接交付的 Markdown 正文。" }
      },
      required: ["title", "artifact_type", "summary", "markdown_content"]
    }
  },
  {
    type: "function",
    name: "create_project_workspace",
    description:
      "创建一个本地项目工作区并保存项目目标、交付物、里程碑、任务、风险和备注。适用于软件项目、活动、学习计划、旅行筹备、内容制作等任何项目。",
    parameters: {
      type: "object",
      strict: true,
      additionalProperties: false,
      properties: {
        project_name: { type: "string", description: "项目名称。" },
        objective: { type: "string", description: "项目目标和完成后的结果。" },
        deadline: { type: "string", description: "截止时间；没有时写‘待确认’。" },
        deliverables: { type: "array", items: { type: "string" }, description: "主要交付物。" },
        milestones: { type: "array", items: { type: "string" }, description: "按顺序排列的里程碑。" },
        tasks: { type: "array", items: { type: "string" }, description: "可以立即执行的任务。" },
        risks: { type: "array", items: { type: "string" }, description: "风险、依赖或待确认事项。" },
        notes: { type: "string", description: "补充说明；没有时传空字符串。" }
      },
      required: ["project_name", "objective", "deadline", "deliverables", "milestones", "tasks", "risks", "notes"]
    }
  },
  {
    type: "function",
    name: "update_project_workspace",
    description:
      "更新已经创建的项目：记录进展、完成任务、增加新任务、风险和下一步。project_reference 可以是项目 ID 或项目名称。",
    parameters: {
      type: "object",
      strict: true,
      additionalProperties: false,
      properties: {
        project_reference: { type: "string", description: "项目 ID 或项目名称。" },
        progress_note: { type: "string", description: "本次进展说明。" },
        completed_tasks: { type: "array", items: { type: "string" }, description: "已完成任务的 ID 或名称。" },
        new_tasks: { type: "array", items: { type: "string" }, description: "新增任务。" },
        new_risks: { type: "array", items: { type: "string" }, description: "新增风险或依赖。" },
        next_actions: { type: "array", items: { type: "string" }, description: "接下来要做的事情。" }
      },
      required: ["project_reference", "progress_note", "completed_tasks", "new_tasks", "new_risks", "next_actions"]
    }
  },
  {
    type: "function",
    name: "list_projects",
    description: "查询本地已经创建的项目。当用户问有哪些项目、某个项目是否存在或想查看项目概览时调用。",
    parameters: {
      type: "object",
      strict: true,
      additionalProperties: false,
      properties: {
        keyword: { type: "string", description: "项目名称关键词；查看全部时传空字符串。" },
        limit: { type: "integer", minimum: 1, maximum: 20, description: "最多返回多少个项目。" }
      },
      required: ["keyword", "limit"]
    }
  },
  {
    type: "function",
    name: "save_note",
    description: "保存用户明确要求记住、记录或归档的普通笔记、灵感、决定和会议结论。",
    parameters: {
      type: "object",
      strict: true,
      additionalProperties: false,
      properties: {
        title: { type: "string", description: "笔记标题。" },
        content: { type: "string", description: "完整笔记内容。" },
        tags: { type: "array", items: { type: "string" }, description: "标签。" }
      },
      required: ["title", "content", "tags"]
    }
  }
];

export const TOOL_CATALOG = [
  { name: "create_artifact", label: "生成任意文档", examples: "方案、报告、攻略、需求、邮件、纪要、文案" },
  { name: "create_project_workspace", label: "创建项目工作区", examples: "目标、里程碑、任务、风险、交付物" },
  { name: "update_project_workspace", label: "更新项目进展", examples: "完成任务、新增任务、下一步、风险" },
  { name: "list_projects", label: "查询项目", examples: "查看本地项目和状态" },
  { name: "save_note", label: "保存笔记", examples: "灵感、决定、会议结论" }
];

function createArtifact(args) {
  const title = cleanText(args.title, "未命名成果", 160);
  const artifactType = cleanText(args.artifact_type, "其他", 40);
  const summary = cleanText(args.summary, `已生成${artifactType}。`, 500);
  const markdown = cleanText(args.markdown_content, `# ${title}\n\n内容待补充。`, 100000);
  const fileName = saveMarkdown(title, markdown);

  return {
    title,
    kind: "artifact",
    summary,
    markdown,
    data: { artifact_type: artifactType, saved_file: fileName },
    model_output: { title, artifact_type: artifactType, saved_file: fileName, summary }
  };
}

function createProjectWorkspace(args) {
  const projects = readJsonArray(PROJECTS_FILE);
  const now = new Date().toISOString();
  const project = {
    id: `prj_${crypto.randomUUID().slice(0, 8)}`,
    name: cleanText(args.project_name, "未命名项目", 160),
    objective: cleanText(args.objective, "待确认", 3000),
    deadline: cleanText(args.deadline, "待确认", 200),
    deliverables: cleanList(args.deliverables),
    milestones: cleanList(args.milestones),
    tasks: cleanList(args.tasks).map((title, index) => ({
      id: `task_${index + 1}`,
      title,
      status: "todo"
    })),
    risks: cleanList(args.risks),
    notes: cleanText(args.notes, "", 5000),
    updates: [],
    created_at: now,
    updated_at: now
  };

  projects.push(project);
  writeJsonArray(PROJECTS_FILE, projects);

  const markdown = [
    `# 项目：${project.name}`,
    `**项目 ID：** ${project.id}`,
    `**截止时间：** ${project.deadline}`,
    `## 项目目标\n\n${project.objective}`,
    listSection("交付物", project.deliverables, "待确认"),
    listSection("里程碑", project.milestones, "待确认"),
    checkboxSection("任务清单", project.tasks.map((task) => `${task.id} · ${task.title}`), "待补充"),
    listSection("风险与依赖", project.risks, "暂无已知风险。"),
    project.notes ? `## 备注\n\n${project.notes}` : ""
  ].filter(Boolean).join("\n\n");

  const fileName = saveMarkdown(project.name, markdown);
  return {
    title: `项目：${project.name}`,
    kind: "project",
    summary: `已创建项目工作区，包含 ${project.tasks.length} 个任务和 ${project.milestones.length} 个里程碑。`,
    markdown,
    data: { project_id: project.id, saved_file: fileName, project_name: project.name },
    model_output: { project_id: project.id, project_name: project.name, task_count: project.tasks.length, saved_file: fileName }
  };
}

function findProject(projects, reference) {
  const value = cleanText(reference, "", 200).toLowerCase();
  if (!value) return null;
  return projects.find((project) => project.id.toLowerCase() === value)
    || projects.find((project) => project.name.toLowerCase() === value)
    || projects.find((project) => project.name.toLowerCase().includes(value));
}

function updateProjectWorkspace(args) {
  const projects = readJsonArray(PROJECTS_FILE);
  const project = findProject(projects, args.project_reference);
  if (!project) throw new Error(`找不到项目：${cleanText(args.project_reference, "未提供")}`);

  const completed = cleanList(args.completed_tasks);
  const newTasks = cleanList(args.new_tasks);
  const newRisks = cleanList(args.new_risks);
  const nextActions = cleanList(args.next_actions);
  const progressNote = cleanText(args.progress_note, "本次未补充进展说明。", 5000);

  const completedMatches = [];
  for (const reference of completed) {
    const lower = reference.toLowerCase();
    const task = project.tasks.find((item) => item.id.toLowerCase() === lower)
      || project.tasks.find((item) => item.title.toLowerCase().includes(lower));
    if (task) {
      task.status = "done";
      completedMatches.push(task.title);
    }
  }

  const nextIndex = project.tasks.length + 1;
  newTasks.forEach((title, index) => {
    project.tasks.push({ id: `task_${nextIndex + index}`, title, status: "todo" });
  });
  project.risks.push(...newRisks);
  project.updates.push({
    at: new Date().toISOString(),
    progress_note: progressNote,
    completed_tasks: completedMatches,
    new_tasks: newTasks,
    new_risks: newRisks,
    next_actions: nextActions
  });
  project.updated_at = new Date().toISOString();
  writeJsonArray(PROJECTS_FILE, projects);

  const pendingTasks = project.tasks.filter((task) => task.status !== "done");
  const doneTasks = project.tasks.filter((task) => task.status === "done");
  const markdown = [
    `# 项目更新：${project.name}`,
    `**项目 ID：** ${project.id}`,
    `## 本次进展\n\n${progressNote}`,
    listSection("本次完成", completedMatches, "未匹配到需要完成的任务。"),
    listSection("新增任务", newTasks, "无"),
    listSection("下一步", nextActions, "待确认"),
    listSection("新增风险", newRisks, "无"),
    `## 当前状态\n\n已完成 ${doneTasks.length} 项，待完成 ${pendingTasks.length} 项。`,
    checkboxSection("待完成任务", pendingTasks.map((task) => `${task.id} · ${task.title}`), "所有任务已完成。")
  ].join("\n\n");

  const fileName = saveMarkdown(`${project.name}-项目更新`, markdown);
  return {
    title: `项目更新：${project.name}`,
    kind: "project_update",
    summary: `项目已更新：完成 ${completedMatches.length} 项，新增 ${newTasks.length} 项，当前还有 ${pendingTasks.length} 项待完成。`,
    markdown,
    data: { project_id: project.id, saved_file: fileName, pending_tasks: pendingTasks.length },
    model_output: { project_id: project.id, completed_count: completedMatches.length, added_count: newTasks.length, pending_count: pendingTasks.length }
  };
}

function listProjects(args) {
  const keyword = cleanText(args.keyword, "", 200).toLowerCase();
  const limit = Math.min(20, Math.max(1, Number.isInteger(args.limit) ? args.limit : 10));
  const projects = readJsonArray(PROJECTS_FILE)
    .filter((project) => !keyword || project.name.toLowerCase().includes(keyword) || project.id.toLowerCase().includes(keyword))
    .sort((a, b) => String(b.updated_at).localeCompare(String(a.updated_at)))
    .slice(0, limit);

  const markdown = projects.length
    ? [
        "# 本地项目列表",
        ...projects.map((project) => {
          const done = project.tasks.filter((task) => task.status === "done").length;
          return `## ${project.name}\n\n- 项目 ID：${project.id}\n- 截止时间：${project.deadline}\n- 任务进度：${done}/${project.tasks.length}\n- 目标：${project.objective}`;
        })
      ].join("\n\n")
    : "# 本地项目列表\n\n没有找到匹配的项目。";

  return {
    title: "本地项目列表",
    kind: "project_list",
    summary: projects.length ? `找到 ${projects.length} 个项目。` : "没有找到匹配的项目。",
    markdown,
    data: { projects: projects.map((project) => ({ id: project.id, name: project.name, deadline: project.deadline })) },
    model_output: { projects: projects.map((project) => ({ id: project.id, name: project.name, deadline: project.deadline })) }
  };
}

function saveNote(args) {
  const notes = readJsonArray(NOTES_FILE);
  const note = {
    id: `note_${crypto.randomUUID().slice(0, 8)}`,
    title: cleanText(args.title, "未命名笔记", 160),
    content: cleanText(args.content, "", 30000),
    tags: cleanList(args.tags, 20),
    created_at: new Date().toISOString()
  };
  notes.push(note);
  writeJsonArray(NOTES_FILE, notes);

  const markdown = [
    `# ${note.title}`,
    note.tags.length ? `**标签：** ${note.tags.join("、")}` : "",
    note.content || "暂无内容。"
  ].filter(Boolean).join("\n\n");
  const fileName = saveMarkdown(note.title, markdown);

  return {
    title: note.title,
    kind: "note",
    summary: `笔记已保存，共 ${note.content.length} 个字符。`,
    markdown,
    data: { note_id: note.id, saved_file: fileName },
    model_output: { note_id: note.id, title: note.title, saved_file: fileName }
  };
}

export function executeTool(name, args = {}) {
  let result;
  switch (name) {
    case "create_artifact":
      result = createArtifact(args);
      break;
    case "create_project_workspace":
      result = createProjectWorkspace(args);
      break;
    case "update_project_workspace":
      result = updateProjectWorkspace(args);
      break;
    case "list_projects":
      result = listProjects(args);
      break;
    case "save_note":
      result = saveNote(args);
      break;
    default:
      throw new Error(`不支持的工具：${name}`);
  }

  return {
    ok: true,
    tool: name,
    generated_at: new Date().toISOString(),
    ...result
  };
}
