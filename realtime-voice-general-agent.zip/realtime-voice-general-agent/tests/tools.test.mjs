import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { executeTool, TOOL_DEFINITIONS } from "../tools.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const root = path.join(__dirname, "..");

assert.equal(TOOL_DEFINITIONS.length, 5);

const artifact = executeTool("create_artifact", {
  title: "杭州三日游攻略",
  artifact_type: "旅游攻略",
  summary: "已生成杭州三日游攻略。",
  markdown_content: "# 杭州三日游攻略\n\n## 第一天\n\n游览西湖。"
});
assert.equal(artifact.ok, true);
assert.match(artifact.markdown, /西湖/);
assert.ok(fs.existsSync(path.join(root, "outputs", artifact.data.saved_file)));

const project = executeTool("create_project_workspace", {
  project_name: "官网改版",
  objective: "上线新版企业官网",
  deadline: "2026-09-01",
  deliverables: ["新版页面", "上线检查清单"],
  milestones: ["需求确认", "开发测试", "上线"],
  tasks: ["确认页面范围", "完成首页原型"],
  risks: ["素材可能延期"],
  notes: "先做移动端适配。"
});
assert.match(project.data.project_id, /^prj_/);
assert.match(project.markdown, /官网改版/);

const update = executeTool("update_project_workspace", {
  project_reference: project.data.project_id,
  progress_note: "首页原型已确认。",
  completed_tasks: ["完成首页原型"],
  new_tasks: ["开发首页"],
  new_risks: [],
  next_actions: ["本周完成首页开发"]
});
assert.match(update.summary, /完成 1 项/);

const listed = executeTool("list_projects", { keyword: "官网", limit: 5 });
assert.match(listed.markdown, /官网改版/);

const note = executeTool("save_note", {
  title: "会议决定",
  content: "周五发布测试版本。",
  tags: ["项目", "决定"]
});
assert.match(note.markdown, /周五发布/);

console.log("✓ 通用工具测试全部通过");
