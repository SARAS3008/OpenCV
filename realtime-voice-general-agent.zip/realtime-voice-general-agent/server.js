import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { executeTool, TOOL_CATALOG, TOOL_DEFINITIONS } from "./tools.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const PUBLIC_DIR = path.join(__dirname, "public");

function loadEnvFile() {
  const envPath = path.join(__dirname, ".env");
  if (!fs.existsSync(envPath)) return;
  for (const rawLine of fs.readFileSync(envPath, "utf8").split(/\r?\n/)) {
    const line = rawLine.trim();
    if (!line || line.startsWith("#")) continue;
    const index = line.indexOf("=");
    if (index < 1) continue;
    const key = line.slice(0, index).trim();
    let value = line.slice(index + 1).trim();
    if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) {
      value = value.slice(1, -1);
    }
    if (!(key in process.env)) process.env[key] = value;
  }
}

loadEnvFile();

const port = Number(process.env.PORT || 3000);
const apiKey = process.env.OPENAI_API_KEY?.trim();
const realtimeModel = process.env.OPENAI_REALTIME_MODEL?.trim() || "gpt-realtime-2.1";
const voice = process.env.OPENAI_VOICE?.trim() || "marin";
const transcribeModel = process.env.OPENAI_TRANSCRIBE_MODEL?.trim() || "gpt-live-transcribe";
const safetyIdentifier = process.env.OPENAI_SAFETY_IDENTIFIER?.trim();

const instructions = `
# 角色与目标
你是一个中文实时语音通用项目助手。你的目标是通过自然对话理解用户真正想完成的事情，并在能力范围内直接产出结果或调用工具执行。

# 对话风格
- 默认使用简体中文。
- 语音回复自然、简短，通常一到三句话。
- 用户可以随时打断你；被打断后立即听取新需求。
- 工具执行前可以用一句话说明正在做什么，工具完成后只说明结果已经显示在右侧，不要朗读全文。

# 工具决策
- 用户要生成方案、报告、需求文档、攻略、会议纪要、总结、邮件、文案、清单、教程等文本成果：调用 create_artifact，并在 markdown_content 中给出完整可交付正文。
- 用户想启动、规划或拆解任何项目：调用 create_project_workspace。
- 用户汇报已有项目的进展、完成项、新任务或风险：调用 update_project_workspace。
- 用户想查看本地已有项目：调用 list_projects。
- 用户明确要求记录、保存或归档信息：调用 save_note。
- 普通知识问答、讨论和澄清可以直接回答，不必为了展示工具而强行调用工具。

# 信息收集
- 能从上下文合理获取的信息直接使用。
- 只有缺少会显著影响结果的关键信息时才追问，一次最多问一个核心问题。
- 不要编造姓名、日期、预算、指标、业务数据或已经发生的动作；缺失信息写“待确认”。

# 能力边界
- 当前本地工具可以生成并保存文档、创建和更新本地项目、查询项目、保存笔记。
- 当前没有联网搜索、发送邮件、修改日历、预订、支付、操作 GitHub 或企业系统的真实连接。用户要求这些外部动作时，明确说明尚未接入对应工具；可以先生成草稿、计划或待执行清单，但不要声称已经完成外部动作。
`.trim();

function buildTranscriptionConfig() {
  if (transcribeModel === "gpt-live-transcribe") {
    return { model: transcribeModel, languages: ["zh-cn"], delay: "low" };
  }
  return { model: transcribeModel, language: "zh" };
}

function buildSessionConfig() {
  const session = {
    type: "realtime",
    model: realtimeModel,
    instructions,
    audio: {
      input: { transcription: buildTranscriptionConfig() },
      output: { voice }
    },
    tools: TOOL_DEFINITIONS,
    tool_choice: "auto"
  };
  if (realtimeModel.startsWith("gpt-realtime-2")) {
    session.reasoning = { effort: "low" };
  }
  return session;
}

const contentTypes = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".ico": "image/x-icon"
};

function sendJson(res, status, value) {
  res.writeHead(status, { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" });
  res.end(JSON.stringify(value));
}

function sendText(res, status, value, contentType = "text/plain; charset=utf-8") {
  res.writeHead(status, { "Content-Type": contentType, "Cache-Control": "no-store" });
  res.end(value);
}

async function readBody(req, maxBytes = 2 * 1024 * 1024) {
  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > maxBytes) throw new Error("请求内容过大。");
    chunks.push(chunk);
  }
  return Buffer.concat(chunks).toString("utf8");
}

function servePublic(reqPath, res) {
  const requested = reqPath === "/" ? "/index.html" : reqPath;
  const safeRelative = path.normalize(requested).replace(/^(\.\.(\/|\\|$))+/, "").replace(/^[/\\]+/, "");
  let filePath = path.join(PUBLIC_DIR, safeRelative);
  if (!filePath.startsWith(PUBLIC_DIR)) {
    sendText(res, 403, "Forbidden");
    return;
  }
  if (!fs.existsSync(filePath) || fs.statSync(filePath).isDirectory()) {
    filePath = path.join(PUBLIC_DIR, "index.html");
  }
  const type = contentTypes[path.extname(filePath).toLowerCase()] || "application/octet-stream";
  res.writeHead(200, { "Content-Type": type, "Cache-Control": "no-cache" });
  fs.createReadStream(filePath).pipe(res);
}

async function handleRequest(req, res) {
  const url = new URL(req.url || "/", `http://${req.headers.host || "127.0.0.1"}`);

  if (req.method === "GET" && url.pathname === "/api/health") {
    sendJson(res, 200, {
      ok: true,
      configured: Boolean(apiKey),
      model: realtimeModel,
      voice,
      transcribeModel,
      tools: TOOL_CATALOG
    });
    return;
  }

  if (req.method === "GET" && url.pathname === "/api/tools") {
    sendJson(res, 200, { ok: true, tools: TOOL_CATALOG });
    return;
  }

  if (req.method === "POST" && url.pathname === "/session") {
    if (!apiKey) {
      sendText(res, 500, "未配置 OPENAI_API_KEY。请复制 .env.example 为 .env 并填写 Key。");
      return;
    }
    const sdp = await readBody(req);
    if (!sdp.includes("v=0")) {
      sendText(res, 400, "无效的 WebRTC SDP。");
      return;
    }

    const form = new FormData();
    form.set("sdp", sdp);
    form.set("session", JSON.stringify(buildSessionConfig()));
    const headers = { Authorization: `Bearer ${apiKey}` };
    if (safetyIdentifier) headers["OpenAI-Safety-Identifier"] = safetyIdentifier;

    const response = await fetch("https://api.openai.com/v1/realtime/calls", {
      method: "POST",
      headers,
      body: form
    });
    const responseText = await response.text();
    if (!response.ok) {
      console.error("Realtime session error:", response.status, responseText);
      sendText(res, response.status, responseText);
      return;
    }
    sendText(res, 200, responseText, "application/sdp");
    return;
  }

  if (req.method === "POST" && url.pathname === "/api/tools/execute") {
    const rawBody = await readBody(req);
    let body;
    try {
      body = JSON.parse(rawBody || "{}");
    } catch {
      sendJson(res, 400, { ok: false, error: "请求 JSON 格式无效。" });
      return;
    }
    const { name, arguments: toolArguments } = body;
    if (typeof name !== "string" || !name.trim()) {
      sendJson(res, 400, { ok: false, error: "缺少工具名称。" });
      return;
    }
    const args = toolArguments && typeof toolArguments === "object" && !Array.isArray(toolArguments)
      ? toolArguments
      : {};
    try {
      sendJson(res, 200, executeTool(name, args));
    } catch (error) {
      console.error("Tool execution error:", error);
      sendJson(res, 400, { ok: false, error: error instanceof Error ? error.message : "工具执行失败。" });
    }
    return;
  }

  if (req.method === "GET" || req.method === "HEAD") {
    servePublic(url.pathname, res);
    return;
  }

  sendText(res, 404, "Not found");
}

const server = http.createServer((req, res) => {
  handleRequest(req, res).catch((error) => {
    console.error("Request error:", error);
    if (!res.headersSent) sendJson(res, 500, { ok: false, error: error instanceof Error ? error.message : "服务端错误。" });
    else res.end();
  });
});

server.listen(port, "127.0.0.1", () => {
  console.log(`\n通用实时语音 Agent 已启动：http://127.0.0.1:${port}`);
  console.log(`模型：${realtimeModel}，声音：${voice}，转写：${transcribeModel}`);
  console.log(`已注册工具：${TOOL_CATALOG.map((tool) => tool.name).join(", ")}`);
  if (!apiKey) console.warn("警告：未配置 OPENAI_API_KEY，页面可打开但无法建立实时会话。\n");
});
