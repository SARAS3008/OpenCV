# 通用实时语音 Agent Demo

这是一个可直接运行的 **实时双向语音交互 + 大模型工具调用 + 本地项目工作区** 示例。项目只使用 Node.js 内置模块，不需要安装第三方 npm 包。

它不再绑定“周报”场景。用户可以通过自然语音提出不同项目或内容任务，模型会判断是直接回答、生成成果、创建项目、更新项目、查询项目，还是保存笔记。

## 可以演示什么

- “帮我做一份杭州三日游攻略，预算两千元。”
- “创建一个企业官网改版项目，目标是九月上线。”
- “官网项目首页原型已经完成，新增一个首页开发任务。”
- “帮我写一份智能客服产品方案。”
- “把刚才讨论的三个决定保存成会议笔记。”
- “查看我目前有哪些项目。”

## 当前已注册工具

| 工具 | 作用 |
|---|---|
| `create_artifact` | 生成并保存任意 Markdown 成果：方案、报告、攻略、需求、纪要、邮件、文案等 |
| `create_project_workspace` | 创建任意类型项目，保存目标、交付物、里程碑、任务和风险 |
| `update_project_workspace` | 更新已有项目的进展、完成项、新任务和风险 |
| `list_projects` | 查询本地项目 |
| `save_note` | 保存笔记、灵感、决定和会议结论 |

生成的 Markdown 文件保存在 `outputs/`，项目和笔记数据保存在 `data/`。

## 重要边界

“大模型可以处理任何项目”不等于它天然可以操作任何外部系统。它只能真正执行已经注册的工具：

```text
用户语音 → 模型理解意图 → 选择已注册工具 → 后端执行 → 返回结果
```

例如要真正发送邮件、修改日历、搜索实时网页、操作 GitHub、查询公司数据库，需要继续接入对应 API、MCP Server 或自定义函数工具。本 Demo 在没有这些连接时不会假装已经完成外部动作，而是生成草稿或执行清单。

## 技术架构

```text
浏览器麦克风
    │ WebRTC 连续音频
    ▼
OpenAI Realtime 模型
    │ Function Calling
    ▼
浏览器 DataChannel
    │ POST /api/tools/execute
    ▼
Node.js 工具注册表
    ├─ 生成 Markdown 文件
    ├─ 创建/更新本地项目 JSON
    ├─ 查询项目
    └─ 保存笔记
```

## 环境要求

- Node.js 20 或更高版本（项目没有第三方 npm 依赖）
- Chrome 或 Edge
- 可访问 Realtime 模型的 OpenAI API Key
- 麦克风

## Windows 快速启动

1. 解压项目。
2. 双击 `start_windows.bat`。
3. 第一次运行会创建 `.env` 并打开记事本。
4. 填写：

```env
OPENAI_API_KEY=你的_API_Key
OPENAI_REALTIME_MODEL=gpt-realtime-2.1
OPENAI_TRANSCRIBE_MODEL=gpt-live-transcribe
OPENAI_VOICE=marin
PORT=3000
```

5. 保存后再次双击 `start_windows.bat`。
6. 打开 `http://127.0.0.1:3000`。

## 命令行启动

```bash
cp .env.example .env
# 编辑 .env
npm start
```

运行测试：

```bash
npm test
```

## 如何增加新能力

在 `tools.js` 中完成三步：

1. 在 `TOOL_DEFINITIONS` 增加函数的 JSON Schema。
2. 编写真实处理函数，例如调用企业 API、数据库或自动化服务。
3. 在 `executeTool()` 注册工具名称和处理函数。

然后在 `server.js` 的系统指令中明确：什么时候调用、需要哪些信息、什么情况下必须确认。

建议把工具分成三类：

- **读取类**：搜索知识库、查询订单、读取项目状态。
- **生成类**：文档、图片、代码、报告。
- **写入类**：发送邮件、创建日程、提交工单。写入类在正式项目中应加入权限、确认和审计。

## 主要文件

- `server.js`：创建 Realtime WebRTC 会话，保管 API Key，提供工具执行接口。
- `tools.js`：工具定义、工具注册和本地执行逻辑。
- `public/app.js`：WebRTC、实时事件、Function Calling、结果回传。
- `public/index.html`：通用 Agent 页面。
- `data/`：本地项目与笔记数据。
- `outputs/`：生成的 Markdown 成果。

## 安全与生产化

当前是单机 Demo。正式部署还应加入用户登录、权限隔离、输入校验、写操作确认、审计日志、速率限制、敏感数据保护和数据库持久化。不要把 `.env` 上传到 GitHub。
