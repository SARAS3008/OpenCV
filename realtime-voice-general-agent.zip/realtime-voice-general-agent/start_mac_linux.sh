#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"

if ! command -v node >/dev/null 2>&1; then
  echo "未检测到 Node.js，请先安装 Node.js 20 或更高版本。"
  exit 1
fi

if [ ! -f .env ]; then
  cp .env.example .env
  echo "已创建 .env。请填写 OPENAI_API_KEY 后再次运行。"
  exit 0
fi

node server.js
