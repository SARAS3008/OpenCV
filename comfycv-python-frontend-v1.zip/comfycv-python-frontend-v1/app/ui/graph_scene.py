from __future__ import annotations

from typing import Callable

from PySide6.QtCore import QPointF, Qt
from PySide6.QtGui import QKeyEvent
from PySide6.QtWidgets import QGraphicsItem, QGraphicsScene

from app.core.models import NodeDefinition, WorkflowEdge, WorkflowNode
from app.ui.graph_items import EdgeItem, NodeItem, PortItem
from app.ui.i18n import Locale


def default_params(definition: NodeDefinition) -> dict:
    return {key: spec.default for key, spec in definition.params.items()}


class GraphScene(QGraphicsScene):
    def __init__(self, locale: Locale = "zh") -> None:
        super().__init__()
        self.locale = locale
        self.node_items: dict[str, NodeItem] = {}
        self.edge_items: list[EdgeItem] = []
        self._node_counter = 1
        self._drag_source_port: PortItem | None = None
        self._temp_edge: EdgeItem | None = None
        self.on_selection_changed_callback: Callable[[], None] | None = None
        self.on_graph_changed_callback: Callable[[], None] | None = None
        self.selectionChanged.connect(self._emit_selection_changed)
        self.setSceneRect(-2000, -2000, 4000, 4000)

    def add_node_from_definition(self, definition: NodeDefinition, pos: QPointF | None = None, params: dict | None = None, node_id: str | None = None) -> NodeItem:
        if node_id is None:
            node_id = f"{definition.type}_{self._node_counter}"
            self._node_counter += 1
        node = NodeItem(node_id=node_id, definition=definition, params=params or default_params(definition), locale=self.locale)
        node.setPos(pos or QPointF(0, 0))
        self.addItem(node)
        self.node_items[node_id] = node
        self._emit_graph_changed()
        return node

    def add_edge_between(self, source_port: PortItem, target_port: PortItem) -> EdgeItem | None:
        if source_port.port_role != "output" or target_port.port_role != "input":
            return None
        if source_port.node_item.node_id == target_port.node_item.node_id:
            return None

        # One input port keeps one connection. New connection replaces old one.
        for edge in list(self.edge_items):
            if edge.target_port is target_port:
                self.remove_edge(edge)

        edge = EdgeItem(source_port, target_port)
        self.edge_items.append(edge)
        self.addItem(edge)
        self._emit_graph_changed()
        return edge

    def remove_edge(self, edge: EdgeItem) -> None:
        if edge in self.edge_items:
            self.edge_items.remove(edge)
        self.removeItem(edge)
        self._emit_graph_changed()

    def remove_node(self, node: NodeItem) -> None:
        for edge in list(self.edge_items):
            if edge.source_port and edge.source_port.node_item is node:
                self.remove_edge(edge)
            elif edge.target_port and edge.target_port.node_item is node:
                self.remove_edge(edge)
        self.node_items.pop(node.node_id, None)
        self.removeItem(node)
        self._emit_graph_changed()

    def delete_selected(self) -> None:
        selected = list(self.selectedItems())
        for item in selected:
            if isinstance(item, EdgeItem):
                self.remove_edge(item)
        for item in selected:
            if isinstance(item, NodeItem):
                self.remove_node(item)
        self._emit_selection_changed()

    def clear_workflow(self) -> None:
        self.clear()
        self.node_items.clear()
        self.edge_items.clear()
        self._drag_source_port = None
        self._temp_edge = None
        self._node_counter = 1
        self._emit_graph_changed()

    def set_locale(self, locale: Locale) -> None:
        self.locale = locale
        for node in self.node_items.values():
            node.set_locale(locale)

    def workflow_nodes(self) -> list[WorkflowNode]:
        return [WorkflowNode(id=node.node_id, type=node.definition.type, params=dict(node.params)) for node in self.node_items.values()]

    def workflow_edges(self) -> list[WorkflowEdge]:
        output: list[WorkflowEdge] = []
        for edge in self.edge_items:
            if edge.source_port and edge.target_port:
                output.append(
                    WorkflowEdge(
                        from_node=edge.source_port.node_item.node_id,
                        from_output=edge.source_port.port_name,
                        to_node=edge.target_port.node_item.node_id,
                        to_input=edge.target_port.port_name,
                    )
                )
        return output

    def selected_node(self) -> NodeItem | None:
        for item in self.selectedItems():
            if isinstance(item, NodeItem):
                return item
        return None

    def update_edges_for_node(self, node_id: str) -> None:
        for edge in self.edge_items:
            if (edge.source_port and edge.source_port.node_item.node_id == node_id) or (edge.target_port and edge.target_port.node_item.node_id == node_id):
                edge.update_path()

    def show_all_ports(self, visible: bool) -> None:
        for node in self.node_items.values():
            node.set_ports_visible(visible or node.isSelected())

    def apply_run_previews(self, result) -> None:  # noqa: ANN001
        for node_id, node in self.node_items.items():
            run_result = result.node_results.get(node_id) if result else None
            if not run_result:
                node.set_preview(None, None, None)
                continue
            preview = next((p for p in run_result.previews if p.preview_data_url), None)
            node.set_preview(preview.preview_data_url if preview else None, run_result.elapsed_ms, run_result.error)

    def _port_at(self, pos: QPointF) -> PortItem | None:
        for item in self.items(pos):
            if isinstance(item, PortItem):
                return item
        return None

    def mousePressEvent(self, event) -> None:  # noqa: ANN001
        port = self._port_at(event.scenePos())
        if port and event.button() == Qt.LeftButton and port.port_role == "output":
            self._drag_source_port = port
            self.show_all_ports(True)
            self._temp_edge = EdgeItem(port, None, temp_end=event.scenePos())
            self.addItem(self._temp_edge)
            event.accept()
            return
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event) -> None:  # noqa: ANN001
        if self._temp_edge:
            self._temp_edge.temp_end = event.scenePos()
            self._temp_edge.update_path()
            event.accept()
            return
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event) -> None:  # noqa: ANN001
        if self._temp_edge:
            target = self._port_at(event.scenePos())
            if self._drag_source_port and target and target.port_role == "input":
                self.add_edge_between(self._drag_source_port, target)
            self.removeItem(self._temp_edge)
            self._temp_edge = None
            self._drag_source_port = None
            self.show_all_ports(False)
            event.accept()
            return
        super().mouseReleaseEvent(event)

    def keyPressEvent(self, event: QKeyEvent) -> None:
        if event.key() in (Qt.Key_Delete, Qt.Key_Backspace):
            self.delete_selected()
            event.accept()
            return
        super().keyPressEvent(event)

    def _emit_selection_changed(self) -> None:
        if self.on_selection_changed_callback:
            self.on_selection_changed_callback()

    def _emit_graph_changed(self) -> None:
        if self.on_graph_changed_callback:
            self.on_graph_changed_callback()
