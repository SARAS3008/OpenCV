from __future__ import annotations

from collections import defaultdict
from typing import Callable

from PySide6.QtCore import Qt
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDoubleSpinBox,
    QFormLayout,
    QFrame,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QScrollArea,
    QSpinBox,
    QTreeWidget,
    QTreeWidgetItem,
    QVBoxLayout,
    QWidget,
)

from app.core.models import NodeDefinition, WorkflowRunResult
from app.ui.graph_items import NodeItem
from app.ui.i18n import Locale, category_label, node_label, param_label, tr
from app.ui.image_utils import pixmap_from_data_url


CATEGORY_ORDER = ["IO", "Basic", "Filter", "Edge", "Threshold", "Morphology", "Contours", "AI / YOLO"]


class OperatorLibrary(QWidget):
    def __init__(self, on_add_node: Callable[[NodeDefinition], None], locale: Locale = "zh") -> None:
        super().__init__()
        self.on_add_node = on_add_node
        self.locale = locale
        self.definitions: list[NodeDefinition] = []
        self.search = QLineEdit()
        self.tree = QTreeWidget()
        self.tree.setHeaderHidden(True)
        self.tree.itemDoubleClicked.connect(self._on_double_click)
        self.search.textChanged.connect(lambda _: self.refresh())

        layout = QVBoxLayout(self)
        self.title = QLabel(tr(self.locale, "operators"))
        self.title.setObjectName("panelTitle")
        layout.addWidget(self.title)
        self.search.setPlaceholderText(tr(self.locale, "search"))
        layout.addWidget(self.search)
        layout.addWidget(self.tree, 1)

    def set_definitions(self, definitions: list[NodeDefinition]) -> None:
        self.definitions = definitions
        self.refresh()

    def set_locale(self, locale: Locale) -> None:
        self.locale = locale
        self.title.setText(tr(locale, "operators"))
        self.search.setPlaceholderText(tr(locale, "search"))
        self.refresh()

    def refresh(self) -> None:
        expanded = set()
        for i in range(self.tree.topLevelItemCount()):
            item = self.tree.topLevelItem(i)
            if item.isExpanded():
                expanded.add(item.data(0, Qt.UserRole))

        self.tree.clear()
        query = self.search.text().strip().lower()
        groups: dict[str, list[NodeDefinition]] = defaultdict(list)
        for d in self.definitions:
            haystack = f"{d.type} {d.title} {d.category} {d.description}".lower()
            if query and query not in haystack:
                continue
            groups[d.category].append(d)

        categories = sorted(groups.keys(), key=lambda x: CATEGORY_ORDER.index(x) if x in CATEGORY_ORDER else 99)
        for category in categories:
            root = QTreeWidgetItem([category_label(self.locale, category)])
            root.setData(0, Qt.UserRole, category)
            root.setFlags(root.flags() & ~Qt.ItemIsSelectable)
            self.tree.addTopLevelItem(root)
            for d in groups[category]:
                child = QTreeWidgetItem([node_label(self.locale, d.type, d.title)])
                child.setData(0, Qt.UserRole, d.type)
                child.setToolTip(0, d.description)
                root.addChild(child)
            root.setExpanded(category in expanded or not expanded)

    def _on_double_click(self, item: QTreeWidgetItem, column: int) -> None:
        node_type = item.data(0, Qt.UserRole)
        definition = next((d for d in self.definitions if d.type == node_type), None)
        if definition:
            self.on_add_node(definition)


class ParamsPanel(QWidget):
    def __init__(self, on_params_changed: Callable[[], None], on_delete_node: Callable[[], None], locale: Locale = "zh") -> None:
        super().__init__()
        self.locale = locale
        self.node: NodeItem | None = None
        self.on_params_changed = on_params_changed
        self.on_delete_node = on_delete_node

        outer = QVBoxLayout(self)
        header = QHBoxLayout()
        self.title = QLabel(tr(locale, "params"))
        self.title.setObjectName("panelTitle")
        self.delete_btn = QPushButton("×")
        self.delete_btn.setFixedWidth(32)
        self.delete_btn.clicked.connect(self.on_delete_node)
        header.addWidget(self.title)
        header.addStretch(1)
        header.addWidget(self.delete_btn)
        outer.addLayout(header)

        self.content = QWidget()
        self.form = QFormLayout(self.content)
        self.form.setLabelAlignment(Qt.AlignLeft)
        outer.addWidget(self.content)
        outer.addStretch(1)
        self.set_node(None)

    def set_locale(self, locale: Locale) -> None:
        self.locale = locale
        self.title.setText(tr(locale, "params"))
        self.set_node(self.node)

    def clear_form(self) -> None:
        while self.form.count():
            item = self.form.takeAt(0)
            widget = item.widget()
            if widget:
                widget.deleteLater()
            layout = item.layout()
            if layout:
                while layout.count():
                    child = layout.takeAt(0)
                    if child.widget():
                        child.widget().deleteLater()

    def set_node(self, node: NodeItem | None) -> None:
        self.node = node
        self.clear_form()
        self.delete_btn.setEnabled(node is not None)
        if node is None:
            self.form.addRow(QLabel(tr(self.locale, "no_node")))
            return

        title = QLabel(node_label(self.locale, node.definition.type, node.definition.title))
        title.setObjectName("nodeParamTitle")
        self.form.addRow(title)

        for key, spec in node.definition.params.items():
            value = node.params.get(key, spec.default)
            label = param_label(self.locale, key, spec.label)
            widget: QWidget
            if spec.type == "int":
                spin = QSpinBox()
                spin.setMinimum(int(spec.min if spec.min is not None else -2147483648))
                spin.setMaximum(int(spec.max if spec.max is not None else 2147483647))
                spin.setSingleStep(int(spec.step if spec.step is not None else 1))
                spin.setValue(int(value or 0))
                spin.valueChanged.connect(lambda v, k=key: self._set_param(k, v))
                widget = spin
            elif spec.type == "float":
                spin = QDoubleSpinBox()
                spin.setDecimals(4)
                spin.setMinimum(float(spec.min if spec.min is not None else -1e12))
                spin.setMaximum(float(spec.max if spec.max is not None else 1e12))
                spin.setSingleStep(float(spec.step if spec.step is not None else 0.1))
                spin.setValue(float(value or 0.0))
                spin.valueChanged.connect(lambda v, k=key: self._set_param(k, v))
                widget = spin
            elif spec.type == "bool":
                box = QCheckBox()
                box.setChecked(bool(value))
                box.stateChanged.connect(lambda state, k=key: self._set_param(k, state == Qt.Checked.value))
                widget = box
            elif spec.type == "select":
                combo = QComboBox()
                for opt in spec.options or []:
                    combo.addItem(str(opt), opt)
                index = combo.findData(value)
                if index >= 0:
                    combo.setCurrentIndex(index)
                combo.currentIndexChanged.connect(lambda idx, c=combo, k=key: self._set_param(k, c.itemData(idx)))
                widget = combo
            else:
                line = QLineEdit(str(value or ""))
                line.textChanged.connect(lambda text, k=key: self._set_param(k, text))
                widget = line
            self.form.addRow(label, widget)

    def _set_param(self, key: str, value) -> None:  # noqa: ANN001
        if self.node is None:
            return
        self.node.params[key] = value
        self.on_params_changed()


class PreviewPanel(QWidget):
    def __init__(self, locale: Locale = "zh") -> None:
        super().__init__()
        self.locale = locale
        self.node: NodeItem | None = None
        self.result: WorkflowRunResult | None = None

        outer = QVBoxLayout(self)
        self.title = QLabel(tr(locale, "preview"))
        self.title.setObjectName("panelTitle")
        outer.addWidget(self.title)
        self.info = QLabel(tr(locale, "no_preview"))
        self.info.setWordWrap(True)
        outer.addWidget(self.info)

        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.body = QWidget()
        self.body_layout = QVBoxLayout(self.body)
        self.scroll.setWidget(self.body)
        outer.addWidget(self.scroll, 1)

    def set_locale(self, locale: Locale) -> None:
        self.locale = locale
        self.title.setText(tr(locale, "preview"))
        self.refresh()

    def set_context(self, node: NodeItem | None, result: WorkflowRunResult | None) -> None:
        self.node = node
        self.result = result
        self.refresh()

    def _clear(self) -> None:
        while self.body_layout.count():
            item = self.body_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

    def refresh(self) -> None:
        self._clear()
        if not self.node or not self.result:
            self.info.setText(tr(self.locale, "no_preview"))
            return
        run = self.result.node_results.get(self.node.node_id)
        if not run:
            self.info.setText(tr(self.locale, "no_preview"))
            return
        if not run.ok:
            self.info.setText(f"Error: {run.error}")
            return
        self.info.setText(f"{self.node.node_id} · {run.elapsed_ms:.1f} ms")
        for preview in run.previews:
            card = QFrame()
            card.setObjectName("previewCard")
            card_layout = QVBoxLayout(card)
            card_layout.addWidget(QLabel(f"{preview.output_name} · {preview.type} · {preview.summary}"))
            pixmap = pixmap_from_data_url(preview.preview_data_url)
            if pixmap:
                label = QLabel()
                label.setAlignment(Qt.AlignCenter)
                label.setPixmap(pixmap.scaled(520, 360, Qt.KeepAspectRatio, Qt.SmoothTransformation))
                card_layout.addWidget(label)
            self.body_layout.addWidget(card)
        self.body_layout.addStretch(1)
