from __future__ import annotations

from dataclasses import dataclass

from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import QColor, QFont, QPainter, QPainterPath, QPen
from PySide6.QtWidgets import QGraphicsEllipseItem, QGraphicsItem, QGraphicsPathItem, QStyleOptionGraphicsItem, QWidget

from app.core.models import NodeDefinition
from app.ui.i18n import Locale, category_label, node_label
from app.ui.image_utils import pixmap_from_data_url


NODE_W = 210
NODE_HEADER_H = 44
NODE_PORT_H = 24
NODE_THUMB_H = 86
NODE_PAD = 12
PORT_RADIUS = 7


@dataclass
class PortRef:
    node_id: str
    port_name: str
    port_role: str  # input | output


class PortItem(QGraphicsEllipseItem):
    def __init__(self, node_item: "NodeItem", port_name: str, port_role: str, port_type: str) -> None:
        super().__init__(-PORT_RADIUS, -PORT_RADIUS, PORT_RADIUS * 2, PORT_RADIUS * 2, node_item)
        self.node_item = node_item
        self.port_name = port_name
        self.port_role = port_role
        self.port_type = port_type
        self.setZValue(20)
        self.setAcceptHoverEvents(True)
        self.setAcceptedMouseButtons(Qt.LeftButton)
        self.setBrush(QColor("#8b5cf6"))
        self.setPen(QPen(QColor("#ffffff"), 2))
        self.setVisible(False)

    @property
    def ref(self) -> PortRef:
        return PortRef(self.node_item.node_id, self.port_name, self.port_role)

    def scene_center(self) -> QPointF:
        return self.mapToScene(QPointF(0, 0))

    def hoverEnterEvent(self, event) -> None:  # noqa: ANN001
        self.setBrush(QColor("#c084fc"))
        super().hoverEnterEvent(event)

    def hoverLeaveEvent(self, event) -> None:  # noqa: ANN001
        self.setBrush(QColor("#8b5cf6"))
        super().hoverLeaveEvent(event)


class EdgeItem(QGraphicsPathItem):
    def __init__(self, source_port: PortItem | None, target_port: PortItem | None, temp_end: QPointF | None = None) -> None:
        super().__init__()
        self.source_port = source_port
        self.target_port = target_port
        self.temp_end = temp_end
        self.setZValue(-1)
        self.setFlag(QGraphicsItem.ItemIsSelectable, True)
        self.setPen(QPen(QColor("#7c3aed"), 3))
        self.update_path()

    def update_path(self) -> None:
        if not self.source_port:
            return
        start = self.source_port.scene_center()
        end = self.target_port.scene_center() if self.target_port else (self.temp_end or start)
        dx = max(70.0, abs(end.x() - start.x()) * 0.5)
        path = QPainterPath(start)
        path.cubicTo(QPointF(start.x() + dx, start.y()), QPointF(end.x() - dx, end.y()), end)
        self.setPath(path)

    def paint(self, painter: QPainter, option: QStyleOptionGraphicsItem, widget: QWidget | None = None) -> None:
        color = QColor("#a78bfa") if self.isSelected() else QColor("#7c3aed")
        painter.setRenderHint(QPainter.Antialiasing)
        painter.setPen(QPen(color, 4 if self.isSelected() else 3, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))
        painter.drawPath(self.path())


class NodeItem(QGraphicsItem):
    def __init__(self, node_id: str, definition: NodeDefinition, params: dict, locale: Locale = "zh") -> None:
        super().__init__()
        self.node_id = node_id
        self.definition = definition
        self.params = params
        self.locale = locale
        self.elapsed_ms: float | None = None
        self.error: str | None = None
        self.preview_data_url: str | None = None
        self._pixmap = None
        self.input_ports: dict[str, PortItem] = {}
        self.output_ports: dict[str, PortItem] = {}
        self._hovered = False

        self.height = max(
            NODE_HEADER_H + NODE_PAD * 2 + max(len(definition.inputs), len(definition.outputs), 1) * NODE_PORT_H,
            NODE_HEADER_H + NODE_THUMB_H + NODE_PAD * 3,
        )
        self.setAcceptHoverEvents(True)
        self.setFlag(QGraphicsItem.ItemIsMovable, True)
        self.setFlag(QGraphicsItem.ItemIsSelectable, True)
        self.setFlag(QGraphicsItem.ItemSendsGeometryChanges, True)

        self._create_ports()

    def _create_ports(self) -> None:
        for i, port in enumerate(self.definition.inputs):
            p = PortItem(self, port.name, "input", port.type)
            y = NODE_HEADER_H + NODE_PAD + i * NODE_PORT_H + NODE_PORT_H / 2
            p.setPos(0, y)
            self.input_ports[port.name] = p
        for i, port in enumerate(self.definition.outputs):
            p = PortItem(self, port.name, "output", port.type)
            y = NODE_HEADER_H + NODE_PAD + i * NODE_PORT_H + NODE_PORT_H / 2
            p.setPos(NODE_W, y)
            self.output_ports[port.name] = p

    def boundingRect(self) -> QRectF:
        return QRectF(0, 0, NODE_W, self.height)

    def paint(self, painter: QPainter, option: QStyleOptionGraphicsItem, widget: QWidget | None = None) -> None:
        painter.setRenderHint(QPainter.Antialiasing)
        rect = self.boundingRect()
        bg = QColor("#1f2937") if not self.isSelected() else QColor("#312e81")
        border = QColor("#4f46e5") if self.isSelected() else QColor("#374151")
        if self.error:
            border = QColor("#ef4444")
        painter.setPen(QPen(border, 2))
        painter.setBrush(bg)
        painter.drawRoundedRect(rect, 14, 14)

        painter.setPen(Qt.NoPen)
        painter.setBrush(QColor("#111827"))
        painter.drawRoundedRect(QRectF(0, 0, NODE_W, NODE_HEADER_H), 14, 14)
        painter.drawRect(QRectF(0, NODE_HEADER_H - 16, NODE_W, 16))

        painter.setPen(QColor("#f9fafb"))
        title_font = QFont()
        title_font.setPointSize(10)
        title_font.setBold(True)
        painter.setFont(title_font)
        painter.drawText(QRectF(NODE_PAD, 6, NODE_W - NODE_PAD * 2, 19), Qt.AlignLeft | Qt.AlignVCenter, node_label(self.locale, self.definition.type, self.definition.title))

        painter.setPen(QColor("#a5b4fc"))
        meta_font = QFont()
        meta_font.setPointSize(8)
        painter.setFont(meta_font)
        meta = category_label(self.locale, self.definition.category)
        if self.elapsed_ms is not None:
            meta += f" · {self.elapsed_ms:.1f} ms"
        painter.drawText(QRectF(NODE_PAD, 25, NODE_W - NODE_PAD * 2, 16), Qt.AlignLeft | Qt.AlignVCenter, meta)

        label_font = QFont()
        label_font.setPointSize(8)
        painter.setFont(label_font)
        painter.setPen(QColor("#d1d5db"))
        for i, port in enumerate(self.definition.inputs):
            y = NODE_HEADER_H + NODE_PAD + i * NODE_PORT_H
            painter.drawText(QRectF(NODE_PAD, y, NODE_W / 2 - NODE_PAD, NODE_PORT_H), Qt.AlignLeft | Qt.AlignVCenter, f"◂ {port.label or port.name}")
        for i, port in enumerate(self.definition.outputs):
            y = NODE_HEADER_H + NODE_PAD + i * NODE_PORT_H
            painter.drawText(QRectF(NODE_W / 2, y, NODE_W / 2 - NODE_PAD, NODE_PORT_H), Qt.AlignRight | Qt.AlignVCenter, f"{port.label or port.name} ▸")

        if self._pixmap:
            target = QRectF(NODE_PAD, self.height - NODE_THUMB_H - NODE_PAD, NODE_W - NODE_PAD * 2, NODE_THUMB_H)
            painter.setPen(QPen(QColor("#374151"), 1))
            painter.setBrush(QColor("#0f172a"))
            painter.drawRoundedRect(target, 8, 8)
            scaled = self._pixmap.scaled(int(target.width()), int(target.height()), Qt.KeepAspectRatio, Qt.SmoothTransformation)
            x = target.x() + (target.width() - scaled.width()) / 2
            y = target.y() + (target.height() - scaled.height()) / 2
            painter.drawPixmap(int(x), int(y), scaled)

        if self.error:
            painter.setPen(QColor("#fecaca"))
            painter.drawText(QRectF(NODE_PAD, self.height - 20, NODE_W - NODE_PAD * 2, 16), Qt.AlignLeft | Qt.AlignVCenter, self.error[:32])

    def hoverEnterEvent(self, event) -> None:  # noqa: ANN001
        self._hovered = True
        self.set_ports_visible(True)
        super().hoverEnterEvent(event)

    def hoverLeaveEvent(self, event) -> None:  # noqa: ANN001
        self._hovered = False
        self.set_ports_visible(self.isSelected())
        super().hoverLeaveEvent(event)

    def itemChange(self, change: QGraphicsItem.GraphicsItemChange, value):  # noqa: ANN001
        if change == QGraphicsItem.ItemPositionHasChanged:
            scene = self.scene()
            if scene and hasattr(scene, "update_edges_for_node"):
                scene.update_edges_for_node(self.node_id)
        if change == QGraphicsItem.ItemSelectedHasChanged:
            self.set_ports_visible(bool(value) or self._hovered)
        return super().itemChange(change, value)

    def set_ports_visible(self, visible: bool) -> None:
        for port in list(self.input_ports.values()) + list(self.output_ports.values()):
            port.setVisible(visible)

    def set_preview(self, data_url: str | None, elapsed_ms: float | None = None, error: str | None = None) -> None:
        self.preview_data_url = data_url
        self.elapsed_ms = elapsed_ms
        self.error = error
        self._pixmap = pixmap_from_data_url(data_url)
        self.update()

    def set_locale(self, locale: Locale) -> None:
        self.locale = locale
        self.update()
