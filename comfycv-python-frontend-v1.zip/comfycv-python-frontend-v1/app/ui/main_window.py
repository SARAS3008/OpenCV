from __future__ import annotations

import sys
from pathlib import Path

from PySide6.QtCore import QPointF, Qt
from PySide6.QtGui import QAction, QPainter
from PySide6.QtWidgets import (
    QApplication,
    QFileDialog,
    QFrame,
    QGraphicsView,
    QHBoxLayout,
    QLabel,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QSplitter,
    QStatusBar,
    QVBoxLayout,
    QWidget,
)

from app.core.executor import WorkflowExecutor
from app.core.models import WorkflowRunResult
from app.nodes.registry import registry
from app.ui.graph_items import NodeItem
from app.ui.graph_scene import GraphScene
from app.ui.i18n import Locale, tr
from app.ui.panels import OperatorLibrary, ParamsPanel, PreviewPanel


class GraphView(QGraphicsView):
    def __init__(self, scene: GraphScene) -> None:
        super().__init__(scene)
        self.setRenderHint(QPainter.Antialiasing)
        self.setRenderHint(QPainter.SmoothPixmapTransform)
        self.setDragMode(QGraphicsView.RubberBandDrag)
        self.setViewportUpdateMode(QGraphicsView.FullViewportUpdate)
        self.setTransformationAnchor(QGraphicsView.AnchorUnderMouse)
        self.setBackgroundBrush(Qt.transparent)

    def wheelEvent(self, event) -> None:  # noqa: ANN001
        factor = 1.15 if event.angleDelta().y() > 0 else 1 / 1.15
        self.scale(factor, factor)


class MainWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.locale: Locale = "zh"
        self.definitions = registry.definitions()
        self.executor = WorkflowExecutor()
        self.last_result: WorkflowRunResult | None = None
        self.left_collapsed = False

        self.scene = GraphScene(locale=self.locale)
        self.scene.on_selection_changed_callback = self.refresh_selection_panels
        self.scene.on_graph_changed_callback = self.clear_run_result
        self.view = GraphView(self.scene)

        self.library = OperatorLibrary(self.add_node_to_canvas, locale=self.locale)
        self.library.set_definitions(self.definitions)
        self.params_panel = ParamsPanel(self.mark_dirty, self.delete_selected, locale=self.locale)
        self.preview_panel = PreviewPanel(locale=self.locale)

        self._build_ui()
        self._build_actions()
        self.apply_locale()
        self.load_demo_workflow()

    def _build_ui(self) -> None:
        self.setWindowTitle("ComfyCV Python")
        self.resize(1440, 900)

        root = QWidget()
        root_layout = QVBoxLayout(root)
        root_layout.setContentsMargins(10, 10, 10, 10)
        root_layout.setSpacing(10)

        self.toolbar = QFrame()
        self.toolbar.setObjectName("topbar")
        tool_layout = QHBoxLayout(self.toolbar)
        self.title_label = QLabel("ComfyCV Python")
        self.title_label.setObjectName("appTitle")
        self.new_btn = QPushButton()
        self.demo_btn = QPushButton()
        self.open_btn = QPushButton()
        self.run_btn = QPushButton()
        self.delete_btn = QPushButton()
        self.lang_btn = QPushButton()
        self.collapse_btn = QPushButton("⇤")
        self.help_label = QLabel()
        self.help_label.setObjectName("helpLabel")
        self.help_label.setWordWrap(False)

        for b in [self.new_btn, self.demo_btn, self.open_btn, self.run_btn, self.delete_btn, self.lang_btn, self.collapse_btn]:
            b.setCursor(Qt.PointingHandCursor)

        tool_layout.addWidget(self.title_label)
        tool_layout.addSpacing(16)
        tool_layout.addWidget(self.new_btn)
        tool_layout.addWidget(self.demo_btn)
        tool_layout.addWidget(self.open_btn)
        tool_layout.addWidget(self.run_btn)
        tool_layout.addWidget(self.delete_btn)
        tool_layout.addStretch(1)
        tool_layout.addWidget(self.help_label)
        tool_layout.addStretch(1)
        tool_layout.addWidget(self.lang_btn)
        root_layout.addWidget(self.toolbar)

        self.splitter = QSplitter(Qt.Horizontal)
        self.left_frame = QFrame()
        self.left_frame.setObjectName("panel")
        left_layout = QVBoxLayout(self.left_frame)
        left_layout.setContentsMargins(10, 10, 10, 10)
        left_layout.addWidget(self.collapse_btn)
        self.collapsed_label = QLabel()
        self.collapsed_label.setObjectName("collapsedLabel")
        self.collapsed_label.setAlignment(Qt.AlignCenter)
        self.collapsed_label.hide()
        left_layout.addWidget(self.collapsed_label, 1)
        left_layout.addWidget(self.library, 10)

        self.canvas_frame = QFrame()
        self.canvas_frame.setObjectName("canvasFrame")
        canvas_layout = QVBoxLayout(self.canvas_frame)
        canvas_layout.setContentsMargins(0, 0, 0, 0)
        canvas_layout.addWidget(self.view)

        self.right_frame = QFrame()
        self.right_frame.setObjectName("panel")
        right_layout = QVBoxLayout(self.right_frame)
        right_layout.setContentsMargins(10, 10, 10, 10)
        right_layout.addWidget(self.params_panel, 1)
        right_layout.addWidget(self.preview_panel, 2)

        self.splitter.addWidget(self.left_frame)
        self.splitter.addWidget(self.canvas_frame)
        self.splitter.addWidget(self.right_frame)
        self.splitter.setSizes([280, 840, 340])
        root_layout.addWidget(self.splitter, 1)

        self.setCentralWidget(root)
        self.setStatusBar(QStatusBar())
        self.statusBar().showMessage(tr(self.locale, "status_ready"))

    def _build_actions(self) -> None:
        self.new_btn.clicked.connect(self.new_workflow)
        self.demo_btn.clicked.connect(self.load_demo_workflow)
        self.open_btn.clicked.connect(self.open_image)
        self.run_btn.clicked.connect(self.run_workflow)
        self.delete_btn.clicked.connect(self.delete_selected)
        self.lang_btn.clicked.connect(self.toggle_language)
        self.collapse_btn.clicked.connect(self.toggle_left_panel)

        delete_action = QAction("Delete", self)
        delete_action.setShortcut("Delete")
        delete_action.triggered.connect(self.delete_selected)
        self.addAction(delete_action)

        backspace_action = QAction("Backspace", self)
        backspace_action.setShortcut("Backspace")
        backspace_action.triggered.connect(self.delete_selected)
        self.addAction(backspace_action)

    def apply_locale(self) -> None:
        self.new_btn.setText(tr(self.locale, "new"))
        self.demo_btn.setText(tr(self.locale, "demo"))
        self.open_btn.setText(tr(self.locale, "open_image"))
        self.run_btn.setText(tr(self.locale, "run"))
        self.delete_btn.setText(tr(self.locale, "delete"))
        self.lang_btn.setText(tr(self.locale, "language"))
        self.help_label.setText(tr(self.locale, "help"))
        self.collapsed_label.setText(tr(self.locale, "collapsed"))
        self.library.set_locale(self.locale)
        self.params_panel.set_locale(self.locale)
        self.preview_panel.set_locale(self.locale)
        self.scene.set_locale(self.locale)

    def toggle_language(self) -> None:
        self.locale = "en" if self.locale == "zh" else "zh"
        self.apply_locale()

    def toggle_left_panel(self) -> None:
        self.left_collapsed = not self.left_collapsed
        if self.left_collapsed:
            self.library.hide()
            self.collapsed_label.show()
            self.left_frame.setMaximumWidth(56)
            self.collapse_btn.setText("⇥")
        else:
            self.left_frame.setMaximumWidth(16777215)
            self.library.show()
            self.collapsed_label.hide()
            self.collapse_btn.setText("⇤")
            self.splitter.setSizes([280, 840, 340])

    def definition_by_type(self, node_type: str):  # noqa: ANN201
        for d in self.definitions:
            if d.type == node_type:
                return d
        raise KeyError(node_type)

    def canvas_center(self) -> QPointF:
        viewport_center = self.view.viewport().rect().center()
        return self.view.mapToScene(viewport_center)

    def add_node_to_canvas(self, definition) -> NodeItem:  # noqa: ANN001
        pos = self.canvas_center()
        node = self.scene.add_node_from_definition(definition, pos)
        node.setSelected(True)
        return node

    def new_workflow(self) -> None:
        self.scene.clear_workflow()
        self.last_result = None
        self.refresh_selection_panels()
        self.statusBar().showMessage(tr(self.locale, "status_ready"))

    def load_demo_workflow(self) -> None:
        self.scene.clear_workflow()
        defs = {d.type: d for d in self.definitions}
        x, y = -420, -120
        n1 = self.scene.add_node_from_definition(defs["ImageInput"], QPointF(x, y))
        n2 = self.scene.add_node_from_definition(defs["CvtColor"], QPointF(x + 260, y))
        n3 = self.scene.add_node_from_definition(defs["GaussianBlur"], QPointF(x + 520, y))
        n4 = self.scene.add_node_from_definition(defs["Canny"], QPointF(x + 780, y))
        n5 = self.scene.add_node_from_definition(defs["Preview"], QPointF(x + 1040, y))
        self.scene.add_edge_between(n1.output_ports["image"], n2.input_ports["image"])
        self.scene.add_edge_between(n2.output_ports["image"], n3.input_ports["image"])
        self.scene.add_edge_between(n3.output_ports["image"], n4.input_ports["image"])
        self.scene.add_edge_between(n4.output_ports["edges"], n5.input_ports["image"])
        self.view.fitInView(self.scene.itemsBoundingRect().adjusted(-100, -100, 100, 100), Qt.KeepAspectRatio)
        n1.setSelected(True)
        self.last_result = None
        self.refresh_selection_panels()

    def open_image(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self,
            tr(self.locale, "open_image"),
            str(Path.home()),
            "Images (*.png *.jpg *.jpeg *.bmp *.tif *.tiff *.webp);;All Files (*)",
        )
        if not path:
            return

        input_nodes = [n for n in self.scene.node_items.values() if n.definition.type == "ImageInput"]
        selected = self.scene.selected_node()
        target = selected if selected and selected.definition.type == "ImageInput" else (input_nodes[0] if input_nodes else None)
        if target is None:
            target = self.scene.add_node_from_definition(self.definition_by_type("ImageInput"), self.canvas_center())
        target.params["path"] = path
        target.setSelected(True)
        self.mark_dirty()
        self.refresh_selection_panels()
        self.statusBar().showMessage(f"Image: {path}")

    def run_workflow(self) -> None:
        nodes = self.scene.workflow_nodes()
        edges = self.scene.workflow_edges()
        if not nodes:
            QMessageBox.information(self, "ComfyCV", "Workflow is empty.")
            return
        self.statusBar().showMessage("Running...")
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            result = self.executor.run(nodes, edges)
        finally:
            QApplication.restoreOverrideCursor()
        self.last_result = result
        self.scene.apply_run_previews(result)
        self.refresh_selection_panels()
        if result.ok:
            self.statusBar().showMessage(tr(self.locale, "workflow_ok"))
        else:
            self.statusBar().showMessage(f"{tr(self.locale, 'workflow_failed')}: {result.error}")
            QMessageBox.warning(self, tr(self.locale, "workflow_failed"), result.error or "Unknown error")

    def delete_selected(self) -> None:
        self.scene.delete_selected()
        self.refresh_selection_panels()

    def mark_dirty(self) -> None:
        self.last_result = None
        self.scene.apply_run_previews(None)
        self.refresh_selection_panels()

    def clear_run_result(self) -> None:
        self.last_result = None
        self.scene.apply_run_previews(None)
        self.refresh_selection_panels()

    def refresh_selection_panels(self) -> None:
        node = self.scene.selected_node()
        self.params_panel.set_node(node)
        self.preview_panel.set_context(node, self.last_result)


def load_stylesheet() -> str:
    path = Path(__file__).with_name("styles.qss")
    return path.read_text(encoding="utf-8") if path.exists() else ""


def main() -> None:
    app = QApplication(sys.argv)
    app.setApplicationName("ComfyCV Python")
    app.setStyleSheet(load_stylesheet())
    window = MainWindow()
    window.show()
    sys.exit(app.exec())
