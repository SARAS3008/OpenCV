from __future__ import annotations

import base64
from typing import Optional

from PySide6.QtGui import QPixmap


def pixmap_from_data_url(data_url: str | None) -> QPixmap | None:
    if not data_url:
        return None
    try:
        _, b64 = data_url.split(",", 1)
        raw = base64.b64decode(b64)
        pixmap = QPixmap()
        if pixmap.loadFromData(raw, "PNG"):
            return pixmap
    except Exception:
        return None
    return None
