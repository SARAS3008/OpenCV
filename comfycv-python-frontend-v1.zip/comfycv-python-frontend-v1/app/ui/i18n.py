from __future__ import annotations

from typing import Literal

Locale = Literal["zh", "en"]

TEXT = {
    "zh": {
        "app_title": "ComfyCV Python",
        "new": "新建空白",
        "demo": "加载示例",
        "open_image": "打开图片",
        "run": "运行工作流",
        "delete": "删除选中",
        "language": "English",
        "operators": "算子库",
        "search": "搜索算子...",
        "params": "参数",
        "preview": "预览",
        "selected": "当前选中",
        "no_node": "请选择一个节点",
        "no_preview": "暂无预览。运行工作流后，点击节点查看结果。",
        "help": "拖动右侧输出端口到左侧输入端口来连接节点。选中节点或连线后按 Delete 删除。",
        "status_ready": "就绪",
        "workflow_ok": "工作流执行完成",
        "workflow_failed": "工作流执行失败",
        "collapsed": "算子",
    },
    "en": {
        "app_title": "ComfyCV Python",
        "new": "New",
        "demo": "Demo",
        "open_image": "Open Image",
        "run": "Run Workflow",
        "delete": "Delete Selected",
        "language": "中文",
        "operators": "Operators",
        "search": "Search nodes...",
        "params": "Parameters",
        "preview": "Preview",
        "selected": "Selected",
        "no_node": "Select a node",
        "no_preview": "No preview yet. Run workflow, then select a node.",
        "help": "Drag a right output port to a left input port to connect nodes. Select nodes or edges and press Delete to remove.",
        "status_ready": "Ready",
        "workflow_ok": "Workflow finished",
        "workflow_failed": "Workflow failed",
        "collapsed": "Nodes",
    },
}

CATEGORY_ZH = {
    "IO": "输入输出",
    "Basic": "基础处理",
    "Filter": "滤波",
    "Edge": "边缘检测",
    "Threshold": "阈值分割",
    "Morphology": "形态学",
    "Contours": "轮廓分析",
    "AI / YOLO": "AI / YOLO",
}

NODE_ZH = {
    "ImageInput": "图像输入",
    "Preview": "预览",
    "CvtColor": "颜色转换",
    "Resize": "缩放",
    "GaussianBlur": "高斯模糊",
    "MedianBlur": "中值滤波",
    "Canny": "Canny 边缘",
    "Threshold": "阈值分割",
    "AdaptiveThreshold": "自适应阈值",
    "Erode": "腐蚀",
    "Dilate": "膨胀",
    "MorphologyEx": "形态学操作",
    "FindContours": "查找轮廓",
    "FilterContours": "过滤轮廓",
    "DrawContours": "绘制轮廓",
    "YOLODetect": "YOLO 检测",
}

PARAM_ZH = {
    "path": "图像路径",
    "code": "转换方式",
    "ksize": "核大小",
    "sigmaX": "Sigma X",
    "threshold1": "阈值 1",
    "threshold2": "阈值 2",
    "apertureSize": "孔径大小",
    "L2gradient": "L2 梯度",
    "thresh": "阈值",
    "maxval": "最大值",
    "maxValue": "最大值",
    "type": "类型",
    "method": "方法",
    "thresholdType": "阈值类型",
    "blockSize": "块大小",
    "C": "C 常量",
    "scale": "缩放比例",
    "interpolation": "插值方式",
    "shape": "结构元素形状",
    "iterations": "迭代次数",
    "op": "操作",
    "mode": "检索模式",
    "min_area": "最小面积",
    "max_area": "最大面积",
    "thickness": "线宽",
    "draw_rect": "绘制外接矩形",
    "model_path": "模型路径",
    "conf": "置信度",
    "iou": "IoU",
    "imgsz": "输入尺寸",
}


def tr(locale: Locale, key: str) -> str:
    return TEXT[locale].get(key, key)


def category_label(locale: Locale, name: str) -> str:
    if locale == "zh":
        return CATEGORY_ZH.get(name, name)
    return name


def node_label(locale: Locale, node_type: str, fallback: str) -> str:
    if locale == "zh":
        return NODE_ZH.get(node_type, fallback)
    return fallback


def param_label(locale: Locale, key: str, fallback: str | None = None) -> str:
    if locale == "zh":
        return PARAM_ZH.get(key, fallback or key)
    return fallback or key
