# ComfyCV Python Frontend v1

这是一个**纯 Python 前端**版本的 ComfyCV starter。它不使用 JS、不使用 React、不使用 Vite、不需要 npm。

当前结构是：

```text
comfycv-python-frontend-v1/
├─ run.py                  # 启动入口
├─ requirements.txt         # Python 依赖
└─ app/
   ├─ core/                 # 工作流执行引擎、数据模型、预览编码
   ├─ nodes/                # OpenCV / YOLO 算子节点
   └─ ui/                   # PySide6 桌面前端
```

## 运行方式

```bash
cd comfycv-python-frontend-v1
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python run.py
```

## 使用方式

1. 点击 `打开图片`，选择本地图像。
2. 如果画布里有 `Image Input`，会把图像路径填到该节点；如果没有，会自动创建一个。
3. 左侧算子库按类别折叠，双击某个算子可添加节点。
4. 鼠标移到节点上，会显示输入/输出连接点。
5. 从节点右侧输出端口拖到另一个节点左侧输入端口，即可连接。
6. 点击 `运行工作流`。
7. 点击任意节点，右侧会显示该节点的处理结果预览。
8. 选中节点或连线后，按 `Delete`/`Backspace` 或点击 `删除选中` 可删除。

## 如何新增一个 OpenCV 节点

在 `app/nodes/` 新增一个 Python 文件，例如：

```python
import cv2

from app.core.models import ParamSpec, PortSpec
from app.nodes.base import CvNode, RunContext, ensure_odd


class BoxBlur(CvNode):
    type = "BoxBlur"
    title = "Box Blur"
    category = "Filter"
    description = "Simple box blur."

    inputs = [PortSpec(name="image", type="Image", label="Image")]
    outputs = [PortSpec(name="image", type="Image", label="Image")]
    params = {
        "ksize": ParamSpec(type="int", default=3, min=1, max=99, step=2, label="Kernel size"),
    }

    def run(self, ctx: RunContext, image, ksize=3, **_):
        k = ensure_odd(int(ksize))
        return {"image": cv2.blur(image, (k, k))}
```

然后在 `app/nodes/registry.py` 中导入并注册：

```python
from app.nodes.my_filter import BoxBlur

registry.register(BoxBlur)
```

重启程序后，左侧算子库会自动出现新节点。

## YOLO 扩展

当前已预留：

```text
app/nodes/yolo.py
```

`YOLODetect` 默认不强制安装 `ultralytics`。当你填写 `model_path` 并安装：

```bash
pip install ultralytics
```

它会尝试调用 Ultralytics YOLO。如果后续你想换成 ONNXRuntime、OpenVINO 或 TensorRT，建议新增：

```text
app/nodes/ai/
├─ yolo_onnxruntime.py
├─ yolo_openvino.py
├─ yolo_tensorrt.py
└─ draw_detections.py
```

## 主要文件说明

### `app/core/models.py`

定义节点、端口、参数、连线、运行结果等数据结构。

### `app/core/executor.py`

DAG 工作流执行引擎。负责拓扑排序、按节点顺序执行、把上游输出传给下游输入、收集每个节点结果。

### `app/core/preview.py`

把 OpenCV/NumPy 图像转换成 PNG base64 预览数据，供 PySide6 UI 显示。

### `app/nodes/base.py`

所有算子的基类 `CvNode`，以及 `RunContext`、`ensure_odd()` 等工具。

### `app/nodes/*.py`

具体算法节点。以后主要扩展这里。

### `app/nodes/registry.py`

节点注册中心。新增节点后要在这里注册。

### `app/ui/main_window.py`

桌面应用主窗口。负责工具栏、画布、左侧算子库、右侧参数/预览面板。

### `app/ui/graph_scene.py`

节点图场景。负责添加节点、删除节点、创建连线、删除连线、把画布转换成 workflow 数据。

### `app/ui/graph_items.py`

节点、端口、连线的绘制逻辑。鼠标移到节点上显示端口的逻辑也在这里。

### `app/ui/panels.py`

左侧算子库、右侧参数面板、右侧预览面板。

### `app/ui/i18n.py`

中英文切换文案。

### `app/ui/styles.qss`

PySide6 QSS 样式表，用来美化界面。
