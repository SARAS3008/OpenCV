/**
 * 前后端通信层。
 * 页面组件只调用 VisionApi，不直接关心 fetch、HTTP 状态码和错误格式。
 */
(() => {
  const API_BASE = "/api";

  async function request(path, options = {}) {
    const response = await fetch(`${API_BASE}${path}`, options);
    let data;
    try {
      data = await response.json();
    } catch (_error) {
      throw new Error(`服务返回了无法解析的响应（HTTP ${response.status}）`);
    }

    if (!response.ok || data.success === false) {
      const error = new Error(data.error || data.detail || `请求失败（HTTP ${response.status}）`);
      error.payload = data;
      error.httpStatus = response.status;
      throw error;
    }
    return data;
  }


  async function getMe() {
    return request("/users/me");
  }

  async function listWorkspaces() {
    return request("/workspaces");
  }

  async function listProjectVersions(projectId) {
    return request(`/projects/${encodeURIComponent(projectId)}/versions`);
  }

  async function diffProject(projectId, fromVersion, toVersion) {
    const params = new URLSearchParams();
    if (fromVersion) params.set("from_version", fromVersion);
    if (toVersion) params.set("to_version", toVersion);
    const query = params.toString();
    return request(`/projects/${encodeURIComponent(projectId)}/diff${query ? `?${query}` : ""}`);
  }

  async function rollbackProject(projectId, versionId) {
    return request(`/projects/${encodeURIComponent(projectId)}/rollback/${encodeURIComponent(versionId)}`, { method:"POST" });
  }

  async function releaseProjectVersion(projectId, versionId) {
    return request(`/projects/${encodeURIComponent(projectId)}/release/${encodeURIComponent(versionId)}`, { method:"POST" });
  }

  async function listDatasets() {
    return request("/datasets");
  }

  async function createDataset(payload) {
    return request("/datasets", { method:"POST", headers:{ "Content-Type":"application/json" }, body:JSON.stringify(payload) });
  }

  async function runRegression(payload) {
    return request("/regression-tests/run", { method:"POST", headers:{ "Content-Type":"application/json" }, body:JSON.stringify(payload) });
  }

  async function submitWorkflowJob(payload) {
    return request("/jobs/run", { method:"POST", headers:{ "Content-Type":"application/json" }, body:JSON.stringify(payload) });
  }

  async function listRuns() {
    return request("/runs");
  }

  async function listJobs() {
    return request("/jobs");
  }

  async function getJob(jobId) {
    return request(`/jobs/${encodeURIComponent(jobId)}`);
  }

  async function listModelAssets() {
    return request("/models/assets");
  }

  async function updateModelMetadata(modelId, metadata) {
    return request(`/models/${encodeURIComponent(modelId)}`, { method:"PATCH", headers:{ "Content-Type":"application/json" }, body:JSON.stringify(metadata) });
  }

  async function getOperators() {
    return request("/operators");
  }

  async function executeWorkflow(workflow) {
    return request("/run", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(workflow),
    });
  }


  async function listProjects() {
    return request("/projects");
  }

  async function getProject(projectId) {
    return request(`/projects/${encodeURIComponent(projectId)}`);
  }

  async function saveProject(project) {
    return request("/projects", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(project),
    });
  }

  async function deleteProject(projectId) {
    return request(`/projects/${encodeURIComponent(projectId)}`, { method: "DELETE" });
  }

  async function listModels() {
    return request("/models");
  }

  async function clearModelCache() {
    return request("/models/cache/clear", { method: "POST" });
  }

  async function uploadModel(file) {
    const form = new FormData();
    form.append("file", file);
    return request("/upload-model", {
      method: "POST",
      body: form,
    });
  }

  async function exportScript(workflow) {
    const response = await fetch(`${API_BASE}/export-script`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(workflow),
    });

    if (!response.ok) {
      let message = `导出失败（HTTP ${response.status}）`;
      try {
        const data = await response.json();
        message = data.error || data.detail || message;
      } catch (_error) {
        // 保留默认错误信息。
      }
      throw new Error(message);
    }

    const disposition = response.headers.get("Content-Disposition") || "";
    const match = disposition.match(/filename="?([^";]+)"?/i);
    return {
      blob: await response.blob(),
      filename: match ? match[1] : "vision_algorithm.py",
    };
  }

  window.VisionApi = Object.freeze({
    getMe,
    listWorkspaces,
    listProjectVersions,
    diffProject,
    rollbackProject,
    releaseProjectVersion,
    listDatasets,
    createDataset,
    runRegression,
    submitWorkflowJob,
    listRuns,
    listJobs,
    getJob,
    listModelAssets,
    updateModelMetadata,
    getOperators,
    executeWorkflow,
    listProjects,
    getProject,
    saveProject,
    deleteProject,
    listModels,
    clearModelCache,
    uploadModel,
    exportScript,
  });
})();
