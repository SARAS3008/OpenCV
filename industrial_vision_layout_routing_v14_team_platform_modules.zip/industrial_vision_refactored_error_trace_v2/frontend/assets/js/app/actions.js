// 拆分自 app.bundle.legacy.js：第 1212-1579 行。
function toggleSelectedCollapse(){
  const node = nodes.find(item => item.id === selectedNodeId);
  if(!node) return;
  node.collapsed = !node.collapsed;
  render();
  commitActiveWorkflowChange();
}
// 兼容旧页面调用；现在这两个操作只控制左侧节点库分类，不再改变画布节点。
function collapseAllNodes(){ collapseAllOperatorGroups(); }
function expandAllNodes(){ expandAllOperatorGroups(); }
function duplicateNode(id){
  const source = nodes.find(item => item.id === id);
  if(!source) return;
  const newId = `n${nodeSeq++}`;
  nodes.push({
    id:newId,
    type:source.type,
    position:{ x:source.position.x + 42, y:source.position.y + 42 },
    params:JSON.parse(JSON.stringify(source.params || {})),
    collapsed:source.collapsed,
    color:source.color || DEFAULT_NODE_COLOR,
  });
  selectedNodeId = newId;
  selectedEdgeId = null;
  colorPaletteNodeId = null;
  render();
  commitActiveWorkflowChange();
}
function deleteNode(id){
  if(!nodes.some(node => node.id === id)) return;
  nodes = nodes.filter(node => node.id !== id);
  edges = edges.filter(edge => edge.source !== id && edge.target !== id);
  workflowModules = workflowModules.map(moduleInfo => ({ ...moduleInfo, node_ids:(moduleInfo.node_ids || []).filter(nodeId => nodeId !== id) })).filter(moduleInfo => (moduleInfo.node_ids || []).length);
  nodePreviews.delete(id);
  if(selectedNodeId === id) selectedNodeId = null;
  if(previewActionNodeId === id) previewActionNodeId = null;
  if(colorPaletteNodeId === id) colorPaletteNodeId = null;
  if(lightboxNodeId === id) closeImageLightbox();
  render();
  commitActiveWorkflowChange();
  toast("已删除节点", id, true);
}
function deleteSelectedNode(){ if(selectedNodeId) deleteNode(selectedNodeId); }

function buildWorkflow(){
  const nodeIds = new Set(nodes.map(node => node.id));
  return {
    version:"2.2",
    nodes:nodes.map(node => ({
      id:node.id,
      type:node.type,
      position:node.position,
      params:{ ...(node.params || {}) },
      collapsed:Boolean(node.collapsed),
      color:node.color || DEFAULT_NODE_COLOR,
    })),
    edges:edges.map(edge => ({ ...edge })),
    modules:(workflowModules || []).map(moduleInfo => ({
      id:moduleInfo.id,
      name:moduleInfo.name || "功能模块",
      node_ids:(moduleInfo.node_ids || []).filter(nodeId => nodeIds.has(nodeId)),
      description:moduleInfo.description || "",
      color:safeColor(moduleInfo.color || "#526b75"),
      collapsed:Boolean(moduleInfo.collapsed),
    })).filter(moduleInfo => moduleInfo.node_ids.length),
  };
}

async function runWorkflow(){
  const workflow = buildWorkflow();
  setStatus("运行中...");
  document.getElementById("taskCount").textContent = "1";
  if(previewCollapsed) togglePreviewPanel(false);
  previewPanel.innerHTML = '<div class="empty-preview">正在运行 OpenCV 流程...</div>';
  try{
    const data = await VisionApi.executeWorkflow(workflow);
    renderPreviews(data.previews || [], data.batch || null);
    if(data.mode === "batch" && data.batch){
      const batch = data.batch;
      setStatus(`批量运行完成：共 ${batch.total} 张，成功 ${batch.succeeded} 张，失败 ${batch.failed} 张。结果目录：${batch.output_dir}`);
      toast("批量处理完成", `成功 ${batch.succeeded} / ${batch.total}，失败 ${batch.failed}`, batch.failed === 0);
    }else{
      setStatus(`运行成功。执行顺序：${(data.order || []).join(" → ")}`);
      toast("运行成功", `已生成 ${(data.previews || []).length} 个节点结果`, true);
    }
  }catch(error){
    const message = error && error.message ? error.message : String(error);
    const payload = error?.payload || null;
    if(payload && Array.isArray(payload.previews)){
      renderPreviews(payload.previews || [], payload.batch || null);
      renderExecutionFailureSummary(payload);
      const failed = payload.failed_node;
      const executedText = (payload.executed_order || []).join(" → ") || "无";
      setStatus(`运行到节点 ${failed?.node_id || "未知"} 时失败。已完成：${executedText}。错误：${message}`);
      if(failed?.node_id){
        selectedNodeId = failed.node_id;
        selectedEdgeId = null;
        render();
      }
      toast("节点执行失败", `${failed?.node_id || "未知节点"}：${failed?.error || message}`);
    }else{
      setStatus(`运行失败：${message}`);
      previewPanel.innerHTML = `<div class="empty-preview">运行失败：${escapeHtml(message)}</div>`;
      toast("运行失败", message);
    }
  }finally{
    document.getElementById("taskCount").textContent = "0";
  }
}

function renderExecutionFailureSummary(payload){
  const failed = payload.failed_node || {};
  const card = document.createElement("div");
  card.className = "execution-error-summary";
  const executed = payload.executed_order || [];
  const pending = payload.pending_nodes || [];
  card.innerHTML = `<div class="execution-error-summary-title"><span>工作流执行中断</span><span class="tag">ERROR</span></div>
    <div class="execution-error-node"><strong>失败节点：</strong>${escapeHtml(failed.node_id || "未知")} · ${escapeHtml(failed.label || failed.type || "未知节点")}</div>
    <div class="execution-error-message">${escapeHtml(failed.error || payload.error || "未知错误")}</div>
    <div class="execution-error-progress"><strong>已完成：</strong>${escapeHtml(executed.join(" → ") || "无")}</div>
    <div class="execution-error-progress"><strong>未执行：</strong>${escapeHtml(pending.join("、") || "无")}</div>`;
  previewPanel.prepend(card);
}

function togglePreviewPanel(force){
  previewCollapsed = typeof force === "boolean" ? force : !previewCollapsed;
  previewWrap.classList.toggle("collapsed", previewCollapsed);
  previewToggleText.textContent = previewCollapsed ? "展开" : "折叠";
  if(!suppressDocumentSync) persistActiveWorkflowView();
}

function renderPreviews(previews, batchSummary = null){
  nodePreviews.clear();
  previews.forEach(item => nodePreviews.set(item.node_id, item));
  previewActionNodeId = null;
  renderNodes();
  updateMinimap();

  previewPanel.innerHTML = "";
  if(batchSummary) renderBatchSummary(batchSummary);
  if(!previews.length){
    if(!batchSummary) previewPanel.innerHTML = '<div class="empty-preview">没有生成预览结果</div>';
    return;
  }
  previews.forEach((item, index) => {
    const card = document.createElement("div");
    if(item.status === "error" || item.result_type === "error"){
      card.className = "preview-card error-preview-card";
      const title = `${index + 1}. ${item.node_id} · ${item.label}`;
      card.innerHTML = `<div class="preview-meta"><b title="${escapeHtml(title)}">${escapeHtml(title)}</b><span class="tag">ERROR</span></div>${renderNodeErrorHtml(item)}`;
      previewPanel.appendChild(card);
      return;
    }
    const hasImage = Boolean(item.image);
    const hasMetrics = previewMetricEntries(item).length > 0;
    const previewKind = hasImage && hasMetrics ? "combined" : hasMetrics ? "metrics" : "image";
    card.className = `preview-card ${previewKind}-preview-card`;
    const title = `${index + 1}. ${item.node_id} · ${item.label}`;
    const content = `${hasImage ? `<img src="${item.image}" alt="${escapeHtml(title)}" title="点击查看原图" />` : ""}${hasMetrics ? renderMetricResultHtml(item, true) : ""}`;
    const itemMeta = OPERATOR_META[item.type] || {};
    const tagLabel = previewKind === "combined"
      ? (itemMeta.kind === "logic" ? "图像 + 逻辑" : "图像 + 数值")
      : previewKind === "metrics"
        ? (itemMeta.kind === "logic" ? "逻辑" : "数值")
        : escapeHtml(item.type || "");
    card.innerHTML = `<div class="preview-meta"><b title="${escapeHtml(title)}">${escapeHtml(title)}</b><span class="tag">${tagLabel}</span></div>${content}`;
    const image = card.querySelector("img");
    if(image) image.addEventListener("click", () => openImageLightbox(item.node_id));
    previewPanel.appendChild(card);
  });
  if(!suppressDocumentSync) captureActiveWorkflowDocument(false);
}

function renderBatchSummary(batch){
  const card = document.createElement("div");
  card.className = "batch-summary";
  const failedRows = (batch.rows || []).filter(row => row.status === "error").slice(0, 5);
  const csvLine = batch.csv_path
    ? `<div class="batch-summary-path"><strong>CSV：</strong>${escapeHtml(batch.csv_path)}</div>`
    : "";
  const errors = failedRows.length
    ? `<div class="batch-summary-errors"><strong>前 ${failedRows.length} 个失败：</strong><br>${failedRows.map(row => `${escapeHtml(row.source_name || row.source_path)}：${escapeHtml(row.error || "未知错误")}`).join("<br>")}</div>`
    : "";
  card.innerHTML = `<div class="batch-summary-title"><span>批量处理汇总</span><span class="tag">BATCH</span></div>
    <div class="batch-summary-grid">
      <div class="batch-summary-stat"><b>${Number(batch.total || 0)}</b><span>总图片</span></div>
      <div class="batch-summary-stat"><b>${Number(batch.succeeded || 0)}</b><span>成功</span></div>
      <div class="batch-summary-stat"><b>${Number(batch.failed || 0)}</b><span>失败</span></div>
    </div>
    <div class="batch-summary-path"><strong>结果目录：</strong>${escapeHtml(batch.output_dir || "")}</div>
    ${csvLine}${errors}`;
  previewPanel.appendChild(card);
}

function downloadNodePreview(nodeId){
  const preview = nodePreviews.get(nodeId);
  if(!preview || !preview.image){
    toast("下载失败", "该节点还没有可下载的结果图");
    return;
  }
  const anchor = document.createElement("a");
  anchor.href = preview.image;
  anchor.download = `${safeFilename(nodeId)}_${safeFilename(preview.label || preview.type || "result")}.png`;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  toast("开始下载", anchor.download, true);
}

function openImageLightbox(nodeId){
  const preview = nodePreviews.get(nodeId);
  if(!preview || !preview.image){
    toast("无法放大", "该节点还没有结果图");
    return;
  }
  lightboxNodeId = nodeId;
  const lightbox = document.getElementById("imageLightbox");
  const image = document.getElementById("lightboxImage");
  document.getElementById("lightboxTitle").textContent = `${nodeId} · ${preview.label || preview.type || "节点结果"}`;
  document.getElementById("lightboxMeta").textContent = "原始分辨率 · 可滚动查看";
  image.src = preview.image;
  image.alt = `${preview.label || nodeId} 的原图`;
  document.getElementById("lightboxDownload").onclick = event => {
    event.stopPropagation();
    downloadNodePreview(nodeId);
  };
  document.getElementById("lightboxRestore").onclick = event => {
    event.stopPropagation();
    closeImageLightbox();
  };
  lightbox.classList.add("open");
  lightbox.setAttribute("aria-hidden", "false");
  document.body.classList.add("lightbox-open");
}
function closeImageLightbox(){
  const lightbox = document.getElementById("imageLightbox");
  lightbox.classList.remove("open");
  lightbox.setAttribute("aria-hidden", "true");
  document.getElementById("lightboxImage").removeAttribute("src");
  lightboxNodeId = null;
  document.body.classList.remove("lightbox-open");
}

async function exportAlgorithmScript(){
  if(!nodes.length){ toast("导出失败", "请先编排工作流"); return; }
  setStatus("正在生成独立算法脚本...");
  try{
    const result = await VisionApi.exportScript(buildWorkflow());
    const url = URL.createObjectURL(result.blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = result.filename || "vision_algorithm.py";
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    URL.revokeObjectURL(url);
    setStatus("独立算法脚本已导出");
    toast("脚本已导出", anchor.download, true);
  }catch(error){
    setStatus(`脚本导出失败：${error.message}`);
    toast("脚本导出失败", error.message);
  }
}

async function saveWorkflowLocal(){
  const documentInfo = getActiveWorkflowDocument();
  if(!documentInfo) return;
  captureActiveWorkflowDocument(false);
  try{
    const project = await VisionWorkspaceStore.saveServerDocument(documentInfo);
    documentInfo.projectId = project.project_id;
    documentInfo.savedSnapshot = workflowSignature(documentInfo.workflow);
    documentInfo.savedName = documentInfo.name;
    documentInfo.dirty = false;
    renderWorkflowTabs();
    persistWorkspace();
    toast("项目已保存", `${documentInfo.name} · 服务端项目库`, true);
    setStatus(`${documentInfo.name} 已保存到服务端项目库（Ctrl+S）`);
  }catch(error){
    documentInfo.savedSnapshot = workflowSignature(documentInfo.workflow);
    documentInfo.savedName = documentInfo.name;
    documentInfo.dirty = false;
    storageSet("vision_python_mvp_workflow_v3", JSON.stringify(documentInfo.workflow, null, 2));
    renderWorkflowTabs();
    persistWorkspace();
    toast("服务端保存失败，已本地兜底", error.message || String(error));
    setStatus(`${documentInfo.name} 已保存到本地缓存；服务端保存失败：${error.message || error}`);
  }
}

async function openProjectFromServer(){
  try{
    const data = await VisionApi.listProjects();
    const projects = data.projects || [];
    if(!projects.length){ toast("暂无项目", "服务端项目库为空"); return; }
    const menu = projects.map((item, index) => `${index + 1}. ${item.name}（${item.node_count || 0} 节点，${item.updated_at || ""}）`).join("\n");
    const answer = window.prompt(`输入要打开的项目序号：\n${menu}`, "1");
    if(answer === null) return;
    const index = Number(answer) - 1;
    if(!Number.isInteger(index) || index < 0 || index >= projects.length){ toast("打开失败", "项目序号无效"); return; }
    const documentInfo = await VisionWorkspaceStore.openServerProject(projects[index].project_id);
    captureActiveWorkflowDocument(true);
    const existingIndex = workflowDocuments.findIndex(item => item.projectId === documentInfo.projectId);
    if(existingIndex >= 0) workflowDocuments[existingIndex] = documentInfo;
    else workflowDocuments.push(documentInfo);
    activeWorkflowId = documentInfo.id;
    restoreWorkflowDocument(documentInfo);
    renderWorkflowTabs();
    persistWorkspace();
    toast("项目已打开", documentInfo.name, true);
  }catch(error){
    toast("打开项目失败", error.message || String(error));
  }
}

async function showModelManager(){
  try{
    const data = await VisionApi.listModels();
    const models = data.models || [];
    const cache = data.cache || {};
    const lines = models.length
      ? models.map((item, index) => `${index + 1}. ${item.filename} · ${Math.round((item.size || 0) / 1024 / 1024 * 10) / 10}MB · ${item.exists ? "文件存在" : "文件缺失"}`).join("\n")
      : "暂无已上传模型";
    window.alert(`模型管理\n已注册：${models.length} 个；缓存：${cache.cached_count || 0}/${cache.max_items || 0}\n\n${lines}`);
  }catch(error){
    toast("模型列表获取失败", error.message || String(error));
  }
}

function loadWorkflowLocal(){
  const documentInfo = getActiveWorkflowDocument();
  if(!documentInfo) return;
  let workflow = null;
  if(documentInfo.savedSnapshot){
    try{ workflow = JSON.parse(documentInfo.savedSnapshot); }catch(error){ console.warn(error); }
  }
  if(!workflow){
    const raw = storageGet("vision_python_mvp_workflow_v3") || storageGet("vision_python_mvp_workflow_v2");
    if(raw){
      try{ workflow = JSON.parse(raw); }catch(error){ toast("加载失败", error.message || String(error)); return; }
    }
  }
  if(!workflow){ toast("加载失败", "当前工作流还没有保存版本"); return; }
  suppressDocumentSync = true;
  try{ applyWorkflow(workflow, { silent:true }); }finally{ suppressDocumentSync = false; }
  documentInfo.workflow = buildWorkflow();
  documentInfo.savedSnapshot = workflowSignature(documentInfo.workflow);
  documentInfo.name = documentInfo.savedName || documentInfo.name;
  documentInfo.savedName = documentInfo.name;
  documentInfo.dirty = false;
  documentInfo.runtimePreviews = [];
  renderWorkflowTabs();
  persistWorkspace();
  toast("已恢复保存版本", documentInfo.name, true);
  setStatus(`${documentInfo.name} 已恢复到最近保存状态`);
}
function downloadWorkflowJson(){
  const documentInfo = getActiveWorkflowDocument();
  const blob = new Blob([JSON.stringify(buildWorkflow(), null, 2)], { type:"application/json" });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = `${safeFilename(documentInfo?.name || "vision_workflow")}.json`;
  anchor.click();
  URL.revokeObjectURL(url);
}
function resetView(){ pan = { x:-260, y:-120 }; zoom = .82; applyTransform(); persistActiveWorkflowView(); setStatus("已重置画布视图"); }

function applyWorkflow(workflow, options = {}){
  nodePreviews.clear();
  previewActionNodeId = null;
  colorPaletteNodeId = null;
  closeImageLightbox();
  nodes = (workflow.nodes || []).map(rawNode => {
    const normalized = normalizeNodeType(rawNode.type, rawNode.params || {});
    if(!OPERATOR_META[normalized.type]) return null;
    return {
      id:rawNode.id,
      type:normalized.type,
      position:rawNode.position || { x:100, y:100 },
      params:{ ...defaultParams(normalized.type), ...normalized.params },
      collapsed:Boolean(rawNode.collapsed),
      color:safeColor(rawNode.color || DEFAULT_NODE_COLOR),
    };
  }).filter(Boolean);
  edges = (workflow.edges || [])
    .filter(edge => nodes.some(node => node.id === edge.source) && nodes.some(node => node.id === edge.target))
    .map(edge => ({ ...edge, sourceHandle:edge.sourceHandle || "out", targetHandle:edge.targetHandle || "in" }));
  const nodeIds = new Set(nodes.map(node => node.id));
  workflowModules = (workflow.modules || []).map(rawModule => ({
    id:String(rawModule.id || `m${moduleSeq++}`),
    name:String(rawModule.name || "功能模块"),
    node_ids:(rawModule.node_ids || rawModule.nodeIds || []).filter(nodeId => nodeIds.has(nodeId)),
    description:String(rawModule.description || ""),
    color:safeColor(rawModule.color || "#526b75"),
    collapsed:Boolean(rawModule.collapsed),
  })).filter(moduleInfo => moduleInfo.node_ids.length);
  const maxModuleSeq = workflowModules.reduce((maxValue, moduleInfo) => Math.max(maxValue, Number(String(moduleInfo.id).replace(/^m/, "")) || 0), 0);
  moduleSeq = maxModuleSeq + 1;
  connectingSourceId = null;
  connectingSourceHandle = "out";
  const maxSequence = nodes.reduce((maxValue, node) => Math.max(maxValue, Number(String(node.id).replace(/^n/, "")) || 0), 0);
  nodeSeq = maxSequence + 1;
  selectedNodeId = nodes[0]?.id || null;
  selectedEdgeId = null;
  previewPanel.innerHTML = '<div class="empty-preview">运行后显示每步处理结果</div>';
  render();
  if(!options.silent) setStatus("工作流已加载；旧版 Gray/BGR2RGB 节点已自动迁移为颜色转换节点");
}

function createDemoWorkflow(){
  applyWorkflow(demoWorkflowDefinition(), { silent:true });
  pan = { x:-260, y:-120 };
  zoom = .82;
  applyTransform();
  commitActiveWorkflowChange();
  setStatus("示例流程已生成。请在读取图像节点内填写服务器图片路径，然后运行。");
  toast("示例流程已生成", "请先填写 ReadImage 的图片路径", true);
}

function clearWorkflow(){
  applyWorkflow(emptyWorkflow(), { silent:true });
  commitActiveWorkflowChange();
  setStatus("流程已清空");
}

function upstreamNodeIds(nodeId){
  const result = new Set();
  const stack = [nodeId];
  while(stack.length){
    const current = stack.pop();
    if(!current || result.has(current)) continue;
    result.add(current);
    edges.filter(edge => edge.target === current).forEach(edge => stack.push(edge.source));
  }
  return Array.from(result);
}
function createWorkflowModule(){
  if(!nodes.length){ toast("无法创建模块", "当前工作流还没有节点"); return; }
  const defaultIds = selectedNodeId ? upstreamNodeIds(selectedNodeId) : nodes.map(node => node.id);
  const rawIds = prompt("请输入要聚合的节点ID，使用逗号分隔；留空则使用当前节点及其上游节点", defaultIds.join(","));
  if(rawIds === null) return;
  const idSet = new Set(rawIds.trim() ? rawIds.split(/[,，\s]+/).filter(Boolean) : defaultIds);
  const validIds = nodes.map(node => node.id).filter(id => idSet.has(id));
  if(!validIds.length){ toast("无法创建模块", "没有匹配到有效节点ID"); return; }
  const name = prompt("请为这个功能模块命名", selectedNodeId ? "功能模块" : "完整流程模块");
  if(name === null) return;
  const moduleId = `m${moduleSeq++}`;
  workflowModules.push({ id:moduleId, name:name.trim() || "功能模块", node_ids:validIds, description:"", color:"#526b75", collapsed:false });
  render();
  commitActiveWorkflowChange();
  toast("模块已创建", `${name || "功能模块"}：${validIds.join("、")}`, true);
}
function renameWorkflowModule(moduleId){
  const moduleInfo = workflowModules.find(item => item.id === moduleId);
  if(!moduleInfo) return;
  const name = prompt("修改模块名称", moduleInfo.name || "功能模块");
  if(name === null) return;
  moduleInfo.name = name.trim() || moduleInfo.name || "功能模块";
  commitActiveWorkflowChange();
  render();
}
function deleteWorkflowModule(moduleId){
  const moduleInfo = workflowModules.find(item => item.id === moduleId);
  if(!moduleInfo) return;
  if(!confirm(`解除模块「${moduleInfo.name || moduleId}」？节点不会被删除。`)) return;
  workflowModules = workflowModules.filter(item => item.id !== moduleId);
  commitActiveWorkflowChange();
  render();
  toast("已解除模块", moduleInfo.name || moduleId, true);
}
function toggleWorkflowModule(moduleId){
  const moduleInfo = workflowModules.find(item => item.id === moduleId);
  if(!moduleInfo) return;
  moduleInfo.collapsed = !moduleInfo.collapsed;
  commitActiveWorkflowChange();
  render();
}

function toast(title, text, ok){
  const element = document.getElementById("toast");
  document.getElementById("toastTitle").textContent = title;
  document.getElementById("toastText").textContent = text || "";
  element.className = `toast show${ok ? " ok" : ""}`;
  clearTimeout(window.__toastTimer);
  window.__toastTimer = setTimeout(() => element.className = "toast", 3200);
}
function setStatus(text){ statusEl.textContent = text; }
function escapeHtml(value){
  return String(value).replace(/[&<>"']/g, character => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" })[character]);
}
function safeFilename(value){ return String(value).replace(/[\\/:*?"<>|\s]+/g, "_").replace(/^_+|_+$/g, "") || "result"; }
function safeColor(value){ return /^#[0-9a-fA-F]{6}$/.test(String(value)) ? String(value) : DEFAULT_NODE_COLOR; }

