// 拆分自 app.bundle.legacy.js：第 1687-1733 行。

document.addEventListener("keydown", event => {
  if((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "s"){
    event.preventDefault();
    saveWorkflowLocal();
    return;
  }
  if(event.key === "Escape"){
    if(lightboxNodeId){ closeImageLightbox(); return; }
    connectingSourceId = null;
    connectingSourceHandle = "out";
    clearTempEdge();
    previewActionNodeId = null;
    colorPaletteNodeId = null;
    renderNodes();
    setStatus("已取消当前操作");
  }
  if((event.key === "Delete" || event.key === "Backspace") && selectedEdgeId && !event.target.matches("input,textarea,select")){
    event.preventDefault();
    deleteSelectedEdge();
  }
});
window.addEventListener("resize", updateMinimap);
document.querySelector(".minimap").addEventListener("click", navigateFromMinimap);
document.getElementById("nodeLibraryToggle").addEventListener("click", toggleNodeLibrary);
document.getElementById("newWorkflowButton").addEventListener("click", newWorkflow);
document.getElementById("exportScriptButton").addEventListener("click", exportAlgorithmScript);
document.getElementById("workflowInput").addEventListener("change", async event => {
  const file = event.target.files[0];
  if(!file) return;
  try{
    applyWorkflow(JSON.parse(await file.text()), { silent:true });
    const documentInfo = getActiveWorkflowDocument();
    if(documentInfo){
      documentInfo.name = file.name.replace(/\.json$/i, "") || documentInfo.name;
    }
    commitActiveWorkflowChange();
    toast("JSON 流程已导入", file.name, true);
    setStatus(`已导入到当前工作流：${documentInfo?.name || file.name}`);
  }catch(error){
    toast("导入失败", error.message || String(error));
  }finally{
    event.target.value = "";
  }
});
setNodeLibraryVisible(true);
initOperators();
