// 拆分自 app.bundle.legacy.js：第 1580-1686 行。
function currentViewportWorldRect(){
  const rect = viewport.getBoundingClientRect();
  return {
    x:-pan.x / zoom,
    y:-pan.y / zoom,
    width:rect.width / zoom,
    height:rect.height / zoom,
  };
}

function renderedNodeHeight(node){
  const element = Array.from(nodeLayer.children).find(item => item.dataset.id === node.id);
  return element ? element.getBoundingClientRect().height / zoom : nodeHeight(node);
}

function computeMinimapTransform(){
  const minimap = document.querySelector(".minimap");
  const header = minimap.querySelector(".minimap-head");
  const viewRect = currentViewportWorldRect();
  const rectangles = [viewRect, ...nodes.map(node => ({
    x:node.position.x,
    y:node.position.y,
    width:NODE_WIDTH,
    height:renderedNodeHeight(node),
  }))];

  let minX = Math.min(...rectangles.map(rect => rect.x));
  let minY = Math.min(...rectangles.map(rect => rect.y));
  let maxX = Math.max(...rectangles.map(rect => rect.x + rect.width));
  let maxY = Math.max(...rectangles.map(rect => rect.y + rect.height));
  const worldWidth = Math.max(1, maxX - minX);
  const worldHeight = Math.max(1, maxY - minY);
  const worldPadding = Math.max(100, Math.min(420, Math.max(worldWidth, worldHeight) * .08));
  minX -= worldPadding;
  minY -= worldPadding;
  maxX += worldPadding;
  maxY += worldPadding;

  const headerHeight = header.offsetHeight || 22;
  const pixelPadding = 8;
  const availableWidth = Math.max(1, minimap.clientWidth - pixelPadding * 2);
  const availableHeight = Math.max(1, minimap.clientHeight - headerHeight - pixelPadding * 2);
  const boundsWidth = Math.max(1, maxX - minX);
  const boundsHeight = Math.max(1, maxY - minY);
  const scale = Math.min(availableWidth / boundsWidth, availableHeight / boundsHeight);
  const drawnWidth = boundsWidth * scale;
  const drawnHeight = boundsHeight * scale;
  const offsetX = pixelPadding + (availableWidth - drawnWidth) / 2 - minX * scale;
  const offsetY = headerHeight + pixelPadding + (availableHeight - drawnHeight) / 2 - minY * scale;

  return { minX, minY, maxX, maxY, scale, offsetX, offsetY, headerHeight };
}

function minimapWorldToScreen(x, y){
  if(!minimapTransform) return { x:0, y:0 };
  return {
    x:x * minimapTransform.scale + minimapTransform.offsetX,
    y:y * minimapTransform.scale + minimapTransform.offsetY,
  };
}

function updateMinimap(){
  const mini = document.getElementById("miniNodes");
  const view = document.getElementById("miniView");
  mini.innerHTML = "";
  minimapTransform = computeMinimapTransform();

  nodes.forEach(node => {
    const marker = document.createElement("div");
    const point = minimapWorldToScreen(node.position.x, node.position.y);
    marker.className = "mini-node";
    marker.dataset.nodeId = node.id;
    marker.style.left = `${point.x}px`;
    marker.style.top = `${point.y}px`;
    marker.style.width = `${Math.max(4, NODE_WIDTH * minimapTransform.scale)}px`;
    marker.style.height = `${Math.max(4, renderedNodeHeight(node) * minimapTransform.scale)}px`;
    marker.style.background = safeColor(node.color || DEFAULT_NODE_COLOR);
    marker.title = `${node.id} · ${(OPERATOR_META[node.type] || {}).label || node.type}`;
    mini.appendChild(marker);
  });

  const viewportWorld = currentViewportWorldRect();
  const viewPoint = minimapWorldToScreen(viewportWorld.x, viewportWorld.y);
  view.style.left = `${viewPoint.x}px`;
  view.style.top = `${viewPoint.y}px`;
  view.style.width = `${Math.max(2, viewportWorld.width * minimapTransform.scale)}px`;
  view.style.height = `${Math.max(2, viewportWorld.height * minimapTransform.scale)}px`;
}

function navigateFromMinimap(event){
  if(!minimapTransform) return;
  const minimap = document.querySelector(".minimap");
  const rect = minimap.getBoundingClientRect();
  const localX = event.clientX - rect.left;
  const localY = event.clientY - rect.top;
  if(localY <= minimapTransform.headerHeight) return;

  const worldX = (localX - minimapTransform.offsetX) / minimapTransform.scale;
  const worldY = (localY - minimapTransform.offsetY) / minimapTransform.scale;
  const viewportRect = viewport.getBoundingClientRect();
  pan.x = viewportRect.width / 2 - worldX * zoom;
  pan.y = viewportRect.height / 2 - worldY * zoom;
  applyTransform();
  persistActiveWorkflowView();
  setStatus(`已通过导航视图定位到画布坐标：${Math.round(worldX)}, ${Math.round(worldY)}`);
}

