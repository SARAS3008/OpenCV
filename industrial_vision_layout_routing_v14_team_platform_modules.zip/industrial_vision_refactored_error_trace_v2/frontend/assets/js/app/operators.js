// 拆分自 app.bundle.legacy.js：第 352-496 行。
function renderOperatorPanel(){
  renderCategoryOperatorPanel({
    category:"图像",
    panelId:"operatorPanel",
    searchId:"opSearch",
    collapsedGroups:collapsedOperatorGroups,
  });
  renderCategoryOperatorPanel({
    category:"逻辑",
    panelId:"logicOperatorPanel",
    searchId:"logicSearch",
    collapsedGroups:collapsedLogicOperatorGroups,
  });
}

function renderCategoryOperatorPanel({ category, panelId, searchId, collapsedGroups }){
  const panel = document.getElementById(panelId);
  if(!panel) return;
  panel.innerHTML = "";
  const search = document.getElementById(searchId);
  const query = (search?.value || "").trim().toLowerCase();
  const groups = OPERATOR_CATALOG[category] || [];
  groups.forEach(groupInfo => {
    const matched = groupInfo.items.filter(type => {
      const meta = OPERATOR_META[type] || {};
      if(meta.hidden) return false;
      const haystack = `${type} ${meta.label || ""} ${meta.description || ""} ${groupInfo.group}`.toLowerCase();
      return !query || haystack.includes(query);
    });
    if(!matched.length) return;

    const groupKey = `${category}:${groupInfo.group}`;
    const group = document.createElement("div");
    group.className = `op-group${collapsedGroups.has(groupKey) ? " closed" : ""}`;
    const title = document.createElement("div");
    title.className = "group-title";
    title.setAttribute("role", "button");
    title.setAttribute("tabindex", "0");
    title.setAttribute("aria-expanded", String(!collapsedGroups.has(groupKey)));
    title.innerHTML = `<span class="chev">▾</span>${escapeHtml(groupInfo.group)}<span style="color:#707b8d;font-weight:700">${matched.length}</span>`;
    const toggleGroup = () => {
      if(collapsedGroups.has(groupKey)) collapsedGroups.delete(groupKey);
      else collapsedGroups.add(groupKey);
      group.classList.toggle("closed", collapsedGroups.has(groupKey));
      title.setAttribute("aria-expanded", String(!collapsedGroups.has(groupKey)));
    };
    title.onclick = toggleGroup;
    title.onkeydown = event => {
      if(event.key === "Enter" || event.key === " "){
        event.preventDefault();
        toggleGroup();
      }
    };

    const ops = document.createElement("div");
    ops.className = "ops";
    matched.forEach(type => {
      const meta = OPERATOR_META[type];
      const op = document.createElement("div");
      op.className = `op ${category === "逻辑" ? "logic-op" : ""}`;
      op.draggable = true;
      op.dataset.type = type;
      op.innerHTML = `<div class="op-icon" style="background:${kindColor(meta.kind)}">${ICONS[meta.kind] || "□"}</div><div><div class="op-name">${escapeHtml(meta.label)}</div><div class="op-desc">${escapeHtml(meta.description || type)}</div></div><div class="op-type">${escapeHtml(type)}</div>`;
      op.ondragstart = event => event.dataTransfer.setData("operator/type", type);
      op.ondblclick = () => addNodeAtViewportCenter(type);
      ops.appendChild(op);
    });
    group.append(title, ops);
    panel.appendChild(group);
  });
}

function kindColor(kind){
  return { io:"#6c7177", color:"#555987", filter:"#406c88", segment:"#80604a", morph:"#47705f", geo:"#72547f", measure:"#7a4c59", ai:"#3f6e9f", custom:"#576b7a", logic:"#6b5c91" }[kind] || "#555a61";
}

function setNodeLibraryVisible(visible){
  nodeLibraryVisible = Boolean(visible);
  const main = document.querySelector(".main");
  const library = document.getElementById("nodeLibrary");
  const toggle = document.getElementById("nodeLibraryToggle");
  main.classList.toggle("nodes-panel-hidden", !nodeLibraryVisible);
  library.setAttribute("aria-hidden", String(!nodeLibraryVisible));
  toggle.classList.toggle("active", nodeLibraryVisible);
  toggle.setAttribute("aria-expanded", String(nodeLibraryVisible));
  toggle.title = nodeLibraryVisible ? "隐藏节点库" : "显示节点库";
  window.requestAnimationFrame(updateMinimap);
  if(!suppressDocumentSync) persistActiveWorkflowView();
}
function toggleNodeLibrary(){ setNodeLibraryVisible(!nodeLibraryVisible); }

function collapseAllOperatorGroups(){
  (OPERATOR_CATALOG["图像"] || []).forEach(groupInfo => collapsedOperatorGroups.add(`图像:${groupInfo.group}`));
  renderOperatorPanel();
  setStatus("已按类别折叠图像节点库");
}
function expandAllOperatorGroups(){
  collapsedOperatorGroups.clear();
  renderOperatorPanel();
  setStatus("已展开图像节点库中的全部类别");
}
function collapseAllLogicOperatorGroups(){
  (OPERATOR_CATALOG["逻辑"] || []).forEach(groupInfo => collapsedLogicOperatorGroups.add(`逻辑:${groupInfo.group}`));
  renderOperatorPanel();
  setStatus("已按类别折叠逻辑节点库");
}
function expandAllLogicOperatorGroups(){
  collapsedLogicOperatorGroups.clear();
  renderOperatorPanel();
  setStatus("已展开逻辑节点库中的全部类别");
}

function defaultParams(type){
  return JSON.parse(JSON.stringify((OPERATOR_META[type] && OPERATOR_META[type].params) || {}));
}

function normalizeNodeType(type, params = {}){
  if(type === "Gray") return { type:"ColorConvert", params:{ ...params, mode:"GRAY" } };
  if(type === "BGR2RGB") return { type:"ColorConvert", params:{ ...params, mode:"RGB" } };
  return { type, params };
}

function addNode(type, x, y, options = {}){
  const normalized = normalizeNodeType(type, defaultParams(type));
  if(!OPERATOR_META[normalized.type]){
    toast("不能添加节点", `${type} 尚未实现`);
    return;
  }
  const id = `n${nodeSeq++}`;
  const node = {
    id,
    type:normalized.type,
    position:{ x:Math.round(x), y:Math.round(y) },
    params:Object.keys(normalized.params).length ? normalized.params : defaultParams(normalized.type),
    collapsed:false,
    color:DEFAULT_NODE_COLOR,
  };
  nodes.push(node);
  selectedNodeId = id;
  selectedEdgeId = null;
  colorPaletteNodeId = null;

  if(options.centerOnPoint){
    render();
    const element = Array.from(nodeLayer.querySelectorAll(".node")).find(candidate => candidate.dataset.id === id);
    const measuredWidth = element?.offsetWidth || NODE_WIDTH;
    const measuredHeight = element?.offsetHeight || (typeof nodeHeight === "function" ? nodeHeight(node) : 220);
    node.position = {
      x:Math.round(options.centerOnPoint.x - measuredWidth / 2),
      y:Math.round(options.centerOnPoint.y - measuredHeight / 2),
    };
  }

  render();
  commitActiveWorkflowChange();
  setStatus(`已添加节点：${id} · ${OPERATOR_META[normalized.type].label}`);
}

function addNodeAtViewportCenter(type){
  const center = typeof getViewportCenterWorldPoint === "function"
    ? getViewportCenterWorldPoint()
    : { x:460 + nodes.length * 28, y:240 + nodes.length * 22 };
  addNode(type, center.x, center.y, { centerOnPoint:center });
}

