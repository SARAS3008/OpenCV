from __future__ import annotations

# 兼容旧导入路径；实际实现已拆分到 backend.algorithms.yolo.*。
from backend.algorithms.yolo import *  # noqa: F401,F403
