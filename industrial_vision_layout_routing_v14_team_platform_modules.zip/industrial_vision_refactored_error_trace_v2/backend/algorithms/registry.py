from __future__ import annotations

from backend.algorithms.image_ops import (
    op_adaptive_threshold,
    op_batch_read_images,
    op_bgr_to_rgb,
    op_bilateral_filter,
    op_canny,
    op_clahe,
    op_color_convert,
    op_dilate,
    op_display,
    op_equalize_hist,
    op_erode,
    op_find_contours,
    op_flip,
    op_gaussian_blur,
    op_gray,
    op_invert,
    op_laplacian,
    op_mean_blur,
    op_median_blur,
    op_morph_close,
    op_morph_gradient,
    op_morph_open,
    op_normalize,
    op_otsu_threshold,
    op_orb_feature_match,
    op_read_image,
    op_resize,
    op_rotate90,
    op_save_batch_results,
    op_sharpen,
    op_sobel,
    op_threshold,
)
from backend.algorithms.logic_ops import (
    op_logic_boolean,
    op_logic_compare,
    op_logic_constant,
    op_logic_for_loop,
    op_logic_if_else,
    op_logic_not,
    op_logic_while_loop,
)
from backend.algorithms.metadata import OPERATOR_CATALOG as _BASE_OPERATOR_CATALOG, OPERATOR_META as _BASE_OPERATOR_META
from backend.algorithms.operator_registry import OperatorDefinition, OperatorRegistry
from backend.algorithms.python_snippet_ops import op_python_snippet
from backend.algorithms.plugin_loader import PluginLoadError, load_custom_operators
from backend.algorithms.types import Operator
from backend.algorithms.yolo_ops import (
    op_roi_pair_edge_distance,
    op_yolo_infer,
    op_yolo_select_top_detections,
)

_BUILTIN_OPERATORS: dict[str, Operator] = {
    "ReadImage": op_read_image,
    "BatchReadImages": op_batch_read_images,
    "SaveBatchResults": op_save_batch_results,
    "Display": op_display,
    "Gray": op_gray,
    "BGR2RGB": op_bgr_to_rgb,
    "ColorConvert": op_color_convert,
    "Invert": op_invert,
    "Normalize": op_normalize,
    "EqualizeHist": op_equalize_hist,
    "CLAHE": op_clahe,
    "MeanBlur": op_mean_blur,
    "GaussianBlur": op_gaussian_blur,
    "MedianBlur": op_median_blur,
    "BilateralFilter": op_bilateral_filter,
    "Sharpen": op_sharpen,
    "Threshold": op_threshold,
    "OtsuThreshold": op_otsu_threshold,
    "AdaptiveThreshold": op_adaptive_threshold,
    "Canny": op_canny,
    "Sobel": op_sobel,
    "Laplacian": op_laplacian,
    "Erode": op_erode,
    "Dilate": op_dilate,
    "MorphOpen": op_morph_open,
    "MorphClose": op_morph_close,
    "MorphGradient": op_morph_gradient,
    "Resize": op_resize,
    "Flip": op_flip,
    "Rotate90": op_rotate90,
    "FindContours": op_find_contours,
    "ORBFeatureMatch": op_orb_feature_match,
    "YoloInfer": op_yolo_infer,
    "YoloSelectTopDetections": op_yolo_select_top_detections,
    "RoiPairEdgeDistance": op_roi_pair_edge_distance,
    "LogicConstant": op_logic_constant,
    "LogicCompare": op_logic_compare,
    "LogicBoolean": op_logic_boolean,
    "LogicNot": op_logic_not,
    "LogicIfElse": op_logic_if_else,
    "LogicForLoop": op_logic_for_loop,
    "LogicWhileLoop": op_logic_while_loop,
    "PythonSnippet": op_python_snippet,
}

OPERATOR_REGISTRY = OperatorRegistry()
OPERATOR_REGISTRY.register_many(_BUILTIN_OPERATORS, _BASE_OPERATOR_META, _BASE_OPERATOR_CATALOG)

FAILED_CUSTOM_PLUGINS: list[dict[str, str]] = []
custom_definitions, plugin_errors = load_custom_operators()
FAILED_CUSTOM_PLUGINS.extend(error.as_dict() for error in plugin_errors)

for definition in custom_definitions:
    try:
        OPERATOR_REGISTRY.register(
            OperatorDefinition(
                type_name=definition.type_name,
                operator=definition.operator,
                metadata=definition.metadata,
                category=definition.category,
                group=definition.group,
                script_compiler=definition.script_compiler,
                builtin=False,
            )
        )
    except ValueError as exc:
        FAILED_CUSTOM_PLUGINS.append(
            PluginLoadError(
                module=definition.type_name,
                error=f"自定义算子注册失败：{exc}",
                cause_type=type(exc).__name__,
            ).as_dict()
        )

# 同步回 metadata 模块级字典，兼容仍直接从 backend.algorithms.metadata 导入的旧代码。
_BASE_OPERATOR_META.clear()
_BASE_OPERATOR_META.update(OPERATOR_REGISTRY.metadata)
_BASE_OPERATOR_CATALOG.clear()
_BASE_OPERATOR_CATALOG.update(OPERATOR_REGISTRY.catalog)

# 兼容旧导入，同时现在都来自统一注册表。
OPERATORS = OPERATOR_REGISTRY.operators
OPERATOR_META = OPERATOR_REGISTRY.metadata
OPERATOR_CATALOG = OPERATOR_REGISTRY.catalog
CUSTOM_SCRIPT_COMPILERS = OPERATOR_REGISTRY.script_compilers
OPERATOR_DEFINITIONS = OPERATOR_REGISTRY.definitions

__all__ = [
    "OPERATOR_REGISTRY",
    "OPERATOR_DEFINITIONS",
    "OPERATORS",
    "OPERATOR_META",
    "OPERATOR_CATALOG",
    "CUSTOM_SCRIPT_COMPILERS",
    "FAILED_CUSTOM_PLUGINS",
]
