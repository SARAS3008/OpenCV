from __future__ import annotations

from typing import Any

import cv2
import numpy as np

from backend.algorithms.helpers import to_float, to_int
from backend.algorithms.types import ExecutionContext, OperatorInputs, OperatorParams, OperatorResult
from backend.algorithms.yolo.common import _int_or_none, _parse_class_indices, _yes

def _detection_confidence(item: Any) -> float:
    if not isinstance(item, dict):
        return 0.0
    try:
        return float(item.get("confidence") or 0.0)
    except (TypeError, ValueError):
        return 0.0


def _detection_class_id(item: Any) -> int:
    if not isinstance(item, dict):
        return -1
    value = item.get("class_id")
    try:
        return int(value)
    except (TypeError, ValueError):
        return -1


def _box_xyxy(item: dict[str, Any]) -> tuple[float, float, float, float] | None:
    coords = item.get("box_xyxy") or item.get("bbox") or item.get("xyxy")
    if not isinstance(coords, (list, tuple)) or len(coords) < 4:
        return None
    try:
        x1, y1, x2, y2 = [float(coords[index]) for index in range(4)]
    except (TypeError, ValueError):
        return None
    if x2 <= x1 or y2 <= y1:
        return None
    return x1, y1, x2, y2


def _box_area(item: dict[str, Any]) -> float:
    box = _box_xyxy(item)
    if box is None:
        return 0.0
    x1, y1, x2, y2 = box
    return max(0.0, x2 - x1) * max(0.0, y2 - y1)


def _box_center(item: dict[str, Any]) -> tuple[float, float] | None:
    box = _box_xyxy(item)
    if box is None:
        return None
    x1, y1, x2, y2 = box
    return ((x1 + x2) / 2.0, (y1 + y2) / 2.0)


def _normalize_sort_by(value: Any) -> str:
    mode = str(value or "CONFIDENCE_DESC").strip().upper()
    aliases = {
        "CONF": "CONFIDENCE_DESC",
        "CONFIDENCE": "CONFIDENCE_DESC",
        "SCORE": "CONFIDENCE_DESC",
        "CLASS_ID": "CLASS_ID_DESC",
        "ID": "CLASS_ID_DESC",
        "AREA": "AREA_DESC",
        "LEFT": "LEFT_TO_RIGHT",
        "X": "LEFT_TO_RIGHT",
        "TOP": "TOP_TO_BOTTOM",
        "Y": "TOP_TO_BOTTOM",
    }
    mode = aliases.get(mode, mode)
    allowed = {"CONFIDENCE_DESC", "CLASS_ID_DESC", "AREA_DESC", "LEFT_TO_RIGHT", "TOP_TO_BOTTOM"}
    if mode not in allowed:
        allowed_text = "、".join(sorted(allowed))
        raise ValueError(f"不支持的检测结果排序方式：{value}，可选值：{allowed_text}")
    return mode


def _image_shape_from_inputs(image: Any, detections: list[dict[str, Any]]) -> tuple[int, int] | None:
    if isinstance(image, np.ndarray):
        height, width = image.shape[:2]
        return int(height), int(width)
    for item in detections:
        shape = item.get("image_shape") or item.get("image_shape_hw") or item.get("orig_shape")
        if isinstance(shape, (list, tuple)) and len(shape) >= 2:
            try:
                height, width = int(shape[0]), int(shape[1])
                if height > 0 and width > 0:
                    return height, width
            except (TypeError, ValueError):
                continue
    max_x = 0.0
    max_y = 0.0
    for item in detections:
        box = _box_xyxy(item)
        if box is None:
            continue
        _, _, x2, y2 = box
        max_x = max(max_x, x2)
        max_y = max(max_y, y2)
    if max_x > 0 and max_y > 0:
        return max(1, int(np.ceil(max_y))), max(1, int(np.ceil(max_x)))
    return None


def _polygon_points(item: dict[str, Any]) -> list[list[float]]:
    points = item.get("mask_polygon") or item.get("polygon") or item.get("segmentation")
    if not isinstance(points, list):
        return []
    if points and all(isinstance(v, (int, float)) for v in points):
        # 兼容 [x1, y1, x2, y2, ...] 扁平格式。
        return [[float(points[i]), float(points[i + 1])] for i in range(0, len(points) - 1, 2)]
    normalized: list[list[float]] = []
    for point in points:
        if isinstance(point, (list, tuple)) and len(point) >= 2:
            try:
                normalized.append([float(point[0]), float(point[1])])
            except (TypeError, ValueError):
                continue
    return normalized



def _clamp_box(box: tuple[float, float, float, float], width: int, height: int, padding: int = 0) -> tuple[int, int, int, int]:
    x1, y1, x2, y2 = box
    x1_i = max(0, min(width - 1, int(round(x1)) - padding))
    y1_i = max(0, min(height - 1, int(round(y1)) - padding))
    x2_i = max(1, min(width, int(round(x2)) + padding))
    y2_i = max(1, min(height, int(round(y2)) + padding))
    if x2_i <= x1_i:
        x2_i = min(width, x1_i + 1)
    if y2_i <= y1_i:
        y2_i = min(height, y1_i + 1)
    return x1_i, y1_i, x2_i, y2_i

def _target_mask(item: dict[str, Any], height: int, width: int) -> np.ndarray:
    mask = np.zeros((height, width), dtype=np.uint8)
    polygon = _polygon_points(item)
    if len(polygon) >= 3:
        pts = np.asarray(polygon, dtype=np.float32)
        pts[:, 0] = np.clip(pts[:, 0], 0, max(0, width - 1))
        pts[:, 1] = np.clip(pts[:, 1], 0, max(0, height - 1))
        cv2.fillPoly(mask, [np.round(pts).astype(np.int32)], 255)
        return mask
    box = _box_xyxy(item)
    if box is None:
        return mask
    x1, y1, x2, y2 = _clamp_box(box, width, height, 0)
    mask[y1:y2, x1:x2] = 255
    return mask


def _select_per_class_best(
    detections: list[dict[str, Any]],
    class_indices: list[int],
    min_confidence: float,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    selected: list[dict[str, Any]] = []
    missing: list[dict[str, Any]] = []
    for rank, class_id in enumerate(class_indices, start=1):
        same_class = [
            item
            for item in detections
            if _detection_class_id(item) == class_id and _box_xyxy(item) is not None
        ]
        best_any = max(same_class, key=lambda item: (_detection_confidence(item), _box_area(item)), default=None)
        qualified = [item for item in same_class if _detection_confidence(item) >= min_confidence]
        best = max(qualified, key=lambda item: (_detection_confidence(item), _box_area(item)), default=None)
        if best is None:
            missing.append(
                {
                    "class_id": class_id,
                    "found": False,
                    "best_confidence": round(_detection_confidence(best_any), 6) if best_any is not None else None,
                    "reason": "below_threshold" if best_any is not None else "not_detected",
                }
            )
            continue
        item = dict(best)
        center = _box_center(item)
        if center is not None:
            item["center"] = [round(center[0], 3), round(center[1], 3)]
        item["selected_rank"] = rank
        item["target_id"] = item.get("track_id") if item.get("track_id") is not None else item.get("class_id")
        item["found"] = True
        selected.append(item)
    return selected, missing


def op_yolo_select_top_detections(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    """从 YOLO 检测结果中筛选目标。

    支持两种模式：
    1. MIXED_TOP_K：旧行为，在所有检测中混合排序后取 Top-K。
    2. PER_CLASS_BEST：按指定类别 index 分别筛选，每个 index 只取该类置信度最高且
       大于等于阈值的一个目标；任一 index 未命中时可报错，也可在 missing_indices 中返回。
    """

    raw = inputs.get("detections")
    if not isinstance(raw, list):
        raise ValueError("检测筛选节点需要连接 YOLO 的 detections 输出")

    min_confidence = max(0.0, min(1.0, to_float(params.get("min_confidence", 0.35), 0.35)))
    top_k = max(1, to_int(params.get("top_k", 2), 2))
    sort_by = _normalize_sort_by(params.get("sort_by", "CONFIDENCE_DESC"))
    require_exact_count = _yes(params.get("require_exact_count"), True)
    class_indices = _parse_class_indices(params.get("class_indices"))
    selection_mode = str(params.get("selection_mode", "AUTO") or "AUTO").strip().upper()
    if selection_mode not in {"AUTO", "MIXED_TOP_K", "PER_CLASS_BEST"}:
        raise ValueError("selection_mode 只能是 AUTO、MIXED_TOP_K 或 PER_CLASS_BEST")
    if selection_mode == "AUTO":
        selection_mode = "PER_CLASS_BEST" if class_indices else "MIXED_TOP_K"

    detections = [dict(item) for item in raw if isinstance(item, dict)]
    valid_detections = [item for item in detections if _box_xyxy(item) is not None]
    missing_indices: list[dict[str, Any]] = []

    if selection_mode == "PER_CLASS_BEST":
        if not class_indices:
            class_indices = sorted({_detection_class_id(item) for item in valid_detections if _detection_class_id(item) >= 0})[:top_k]
        selected, missing_indices = _select_per_class_best(valid_detections, class_indices, min_confidence)
        expected_count = len(class_indices)
        if top_k != expected_count:
            # 在按类别分别筛选模式下，“保留数量”与类别 index 数量语义一致；自动修正并记录。
            top_k = expected_count or top_k
        if require_exact_count and missing_indices:
            details = ", ".join(
                f"index={item['class_id']}({item['reason']}, best={item['best_confidence']})"
                for item in missing_indices
            )
            raise ValueError(f"按类别分别筛选未找到全部目标：{details}；阈值为 {min_confidence}")
    else:
        filtered = [item for item in valid_detections if _detection_confidence(item) >= min_confidence]
        if sort_by == "CLASS_ID_DESC":
            filtered.sort(key=lambda item: (_detection_class_id(item), _detection_confidence(item)), reverse=True)
        elif sort_by == "AREA_DESC":
            filtered.sort(key=lambda item: (_box_area(item), _detection_confidence(item)), reverse=True)
        elif sort_by == "LEFT_TO_RIGHT":
            filtered.sort(key=lambda item: (_box_center(item) or (10**12, 10**12))[0])
        elif sort_by == "TOP_TO_BOTTOM":
            filtered.sort(key=lambda item: (_box_center(item) or (10**12, 10**12))[1])
        else:
            filtered.sort(key=lambda item: (_detection_confidence(item), _box_area(item)), reverse=True)
        selected = filtered[:top_k]
        expected_count = top_k
        if require_exact_count and len(selected) < top_k:
            raise ValueError(f"筛选后只有 {len(selected)} 个目标，少于要求的 {top_k} 个；请降低置信度阈值或更换测试图片")
        for index, item in enumerate(selected, start=1):
            center = _box_center(item)
            if center is not None:
                item["center"] = [round(center[0], 3), round(center[1], 3)]
            item["selected_rank"] = index
            item["target_id"] = item.get("track_id") if item.get("track_id") is not None else item.get("class_id")
            item["found"] = True

    centers = [item.get("center") for item in selected if isinstance(item.get("center"), list)]

    if selection_mode == "PER_CLASS_BEST":
        selected_by_rank = {
            int(item.get("selected_rank")): item
            for item in selected
            if isinstance(item.get("selected_rank"), int)
        }
        mask_items: list[dict[str, Any] | None] = [
            selected_by_rank.get(rank) for rank in range(1, expected_count + 1)
        ]
    else:
        mask_items = list(selected[:expected_count])

    shape = _image_shape_from_inputs(inputs.get("image"), detections)
    combined_mask: np.ndarray | None = None
    masks: list[np.ndarray] = []
    if shape is not None:
        height, width = shape
        combined_mask = np.zeros((height, width), dtype=np.uint8)
        for item in mask_items:
            if isinstance(item, dict):
                mask = _target_mask(item, height, width)
            else:
                # 按类别分别筛选且某个 index 未命中时，仍输出同序号空白 Mask，
                # 这样下游连接 maskN 的节点不会因为端口缺失而失败。
                mask = np.zeros((height, width), dtype=np.uint8)
            masks.append(mask)
            combined_mask = cv2.bitwise_or(combined_mask, mask)

    metrics = {
        "input_count": len(raw),
        "valid_count": len(valid_detections),
        "selected_count": len(selected),
        "expected_count": expected_count,
        "min_confidence": min_confidence,
        "top_k": top_k,
        "selection_mode": selection_mode,
        "class_indices": class_indices,
        "missing_indices": missing_indices,
        "sort_by": sort_by,
        "mask_output_count": len(mask_items),
        "mask_ports": [f"mask{index}" for index in range(1, len(mask_items) + 1)],
        "selected": [
            {
                "rank": item.get("selected_rank"),
                "target_id": item.get("target_id"),
                "class_id": item.get("class_id"),
                "class_name": item.get("class_name"),
                "confidence": item.get("confidence"),
                "center": item.get("center"),
                "box_xyxy": item.get("box_xyxy"),
                "found": item.get("found", True),
            }
            for item in selected
        ],
    }

    result: dict[str, Any] = {
        "selected": selected,
        "count": len(selected),
        "expected_count": expected_count,
        "missing_indices": missing_indices,
        "first": selected[0] if selected else None,
        "second": selected[1] if len(selected) > 1 else None,
        "centers": centers,
        "metrics": metrics,
        "data": {"yolo_selected": metrics},
    }
    if combined_mask is not None:
        result["mask"] = combined_mask
        result["mask_color_space"] = "GRAY"
        result["out"] = combined_mask
        result["out_color_space"] = "GRAY"
    for index, mask in enumerate(masks, start=1):
        result[f"mask{index}"] = mask
        result[f"mask{index}_color_space"] = "GRAY"
    return result


