from __future__ import annotations

from typing import Any

import cv2
import numpy as np

from backend.algorithms.helpers import ensure_bgr
from backend.algorithms.yolo.common import _float_or_none, _int_or_none, _name_for, _to_list

def _limit_points(points: Any, max_points: int) -> Any:
    if not isinstance(points, list) or max_points <= 0 or len(points) <= max_points:
        return points
    return points[:max_points]


def _extract_boxes(result: Any, names: Any, max_geometry_points: int) -> list[dict[str, Any]]:
    boxes = getattr(result, "boxes", None)
    if boxes is None:
        return []

    xyxy = _to_list(getattr(boxes, "xyxy", None)) or []
    cls_values = _to_list(getattr(boxes, "cls", None)) or []
    conf_values = _to_list(getattr(boxes, "conf", None)) or []
    ids = _to_list(getattr(boxes, "id", None)) or []

    detections: list[dict[str, Any]] = []
    for index, coords in enumerate(xyxy):
        class_id = _int_or_none(cls_values[index] if index < len(cls_values) else None)
        confidence = _float_or_none(conf_values[index] if index < len(conf_values) else None)
        detection: dict[str, Any] = {
            "index": index,
            "class_id": class_id,
            "class_name": _name_for(names, class_id),
            "confidence": confidence,
            "box_xyxy": _limit_points(coords, max_geometry_points),
        }
        if index < len(ids):
            detection["track_id"] = _int_or_none(ids[index])
        detections.append(detection)
    return detections


def _attach_masks(result: Any, detections: list[dict[str, Any]], max_geometry_points: int) -> int:
    masks = getattr(result, "masks", None)
    if masks is None:
        return 0
    polygons = getattr(masks, "xy", None)
    if polygons is None:
        polygons = getattr(masks, "xyn", None)
    if polygons is None:
        return 0

    count = 0
    for index, polygon in enumerate(polygons):
        points = _to_list(polygon) or []
        if index < len(detections):
            detections[index]["mask_polygon"] = _limit_points(points, max_geometry_points)
        count += 1
    return count


def _attach_keypoints(result: Any, detections: list[dict[str, Any]], max_geometry_points: int) -> int:
    keypoints = getattr(result, "keypoints", None)
    if keypoints is None:
        return 0
    xy = _to_list(getattr(keypoints, "xy", None)) or []
    conf = _to_list(getattr(keypoints, "conf", None)) or []
    count = 0
    for index, points in enumerate(xy):
        item = {
            "xy": _limit_points(points, max_geometry_points),
        }
        if index < len(conf):
            item["confidence"] = _limit_points(conf[index], max_geometry_points)
        if index < len(detections):
            detections[index]["keypoints"] = item
        else:
            detections.append({"index": index, "keypoints": item})
        count += len(points) if isinstance(points, list) else 0
    return count


def _extract_obb(result: Any, names: Any, max_geometry_points: int) -> list[dict[str, Any]]:
    obb = getattr(result, "obb", None)
    if obb is None:
        return []

    polygons = _to_list(getattr(obb, "xyxyxyxy", None)) or []
    xywhr = _to_list(getattr(obb, "xywhr", None)) or []
    cls_values = _to_list(getattr(obb, "cls", None)) or []
    conf_values = _to_list(getattr(obb, "conf", None)) or []

    detections: list[dict[str, Any]] = []
    total = max(len(polygons), len(xywhr), len(cls_values), len(conf_values))
    for index in range(total):
        class_id = _int_or_none(cls_values[index] if index < len(cls_values) else None)
        detection: dict[str, Any] = {
            "index": index,
            "class_id": class_id,
            "class_name": _name_for(names, class_id),
            "confidence": _float_or_none(conf_values[index] if index < len(conf_values) else None),
        }
        if index < len(polygons):
            detection["obb_polygon"] = _limit_points(polygons[index], max_geometry_points)
        if index < len(xywhr):
            detection["obb_xywhr"] = _limit_points(xywhr[index], max_geometry_points)
        detections.append(detection)
    return detections


def _extract_classification(result: Any, names: Any) -> dict[str, Any]:
    probs = getattr(result, "probs", None)
    if probs is None:
        return {"top5": [], "top_class": "", "top_confidence": 0.0, "probabilities": []}

    data = _to_list(getattr(probs, "data", None)) or []
    if data:
        pairs = sorted(enumerate(data), key=lambda item: float(item[1]), reverse=True)[:5]
        top5 = [
            {
                "class_id": int(class_id),
                "class_name": _name_for(names, int(class_id)),
                "confidence": round(float(confidence), 6),
            }
            for class_id, confidence in pairs
        ]
    else:
        top_ids = _to_list(getattr(probs, "top5", None)) or []
        top_conf = _to_list(getattr(probs, "top5conf", None)) or []
        top5 = [
            {
                "class_id": int(class_id),
                "class_name": _name_for(names, int(class_id)),
                "confidence": round(float(top_conf[index]), 6) if index < len(top_conf) else None,
            }
            for index, class_id in enumerate(top_ids)
        ]

    if not top5:
        top1 = _int_or_none(getattr(probs, "top1", None))
        top1conf = _float_or_none(getattr(probs, "top1conf", None)) or 0.0
        if top1 is not None:
            top5 = [{"class_id": top1, "class_name": _name_for(names, top1), "confidence": top1conf}]

    top = top5[0] if top5 else {}
    return {
        "top5": top5,
        "top_class": str(top.get("class_name") or ""),
        "top_confidence": float(top.get("confidence") or 0.0),
        "probabilities": data,
    }


def _extract_result_payload(result: Any, task: str, include_geometry: bool, max_results: int, max_geometry_points: int) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    names = getattr(result, "names", None)
    if names is None:
        names = getattr(getattr(result, "model", None), "names", {})

    resolved_task = task
    detections: list[dict[str, Any]] = []
    extra: dict[str, Any] = {}

    classification = _extract_classification(result, names)
    if classification["top5"] and task in {"auto", "classify"}:
        resolved_task = "classify"
        extra["classification"] = classification
    else:
        if task == "obb" or getattr(result, "obb", None) is not None:
            resolved_task = "obb"
            detections = _extract_obb(result, names, max_geometry_points)
        else:
            detections = _extract_boxes(result, names, max_geometry_points)
            if task == "segment" or getattr(result, "masks", None) is not None:
                resolved_task = "segment"
                extra["mask_count"] = _attach_masks(result, detections, max_geometry_points) if include_geometry else 0
            if task == "pose" or getattr(result, "keypoints", None) is not None:
                resolved_task = "pose"
                extra["keypoint_count"] = _attach_keypoints(result, detections, max_geometry_points) if include_geometry else 0
            if resolved_task == "auto":
                resolved_task = "detect"

    if not include_geometry:
        for detection in detections:
            for key in ["box_xyxy", "mask_polygon", "keypoints", "obb_polygon", "obb_xywhr"]:
                detection.pop(key, None)

    image_shape = getattr(result, "orig_shape", None)
    if image_shape is None:
        orig_img = getattr(result, "orig_img", None)
        if isinstance(orig_img, np.ndarray):
            image_shape = orig_img.shape[:2]
    if image_shape is not None:
        try:
            h, w = list(image_shape)[:2]
            shape_hw = [int(h), int(w)]
            for detection in detections:
                detection.setdefault("image_shape", shape_hw)
        except Exception:
            pass

    if max_results > 0:
        detections = detections[:max_results]
    return detections, {**extra, "resolved_task": resolved_task}


def _make_annotated_image(result: Any, fallback: np.ndarray) -> np.ndarray:
    try:
        annotated = result.plot()
        if isinstance(annotated, np.ndarray):
            if annotated.ndim == 2:
                return cv2.cvtColor(annotated, cv2.COLOR_GRAY2BGR)
            return ensure_bgr(annotated)
    except Exception:
        pass
    return fallback.copy()


