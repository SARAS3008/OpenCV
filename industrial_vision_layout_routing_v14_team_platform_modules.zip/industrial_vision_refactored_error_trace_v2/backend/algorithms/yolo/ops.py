from __future__ import annotations

from collections import Counter
from typing import Any

import numpy as np

from backend.algorithms.helpers import to_float, to_int
from backend.algorithms.types import ExecutionContext, OperatorInputs, OperatorParams, OperatorResult
from backend.algorithms.yolo.common import (
    _image_for_yolo,
    _normalize_task,
    _parse_class_filter,
    _parse_class_indices,
    _passes_class_filter,
    _passes_class_indices,
    _yes,
)
from backend.algorithms.yolo.model_manager import load_yolo_model as _load_yolo_model, resolve_model_ref as _resolve_model_ref
from backend.algorithms.yolo.result_parser import _extract_result_payload, _make_annotated_image

def op_yolo_infer(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    """使用 Ultralytics YOLO 模型执行检测、分割、分类、姿态或 OBB 推理。"""

    image = inputs["in"]
    model_ref, model_name, model_location = _resolve_model_ref(params.get("model_path"), context)
    task = _normalize_task(params.get("task", "auto"))
    model = _load_yolo_model(model_ref, task, context)

    model_input = _image_for_yolo(image, inputs.get("in_color_space", "BGR"))
    conf = max(0.0, min(1.0, to_float(params.get("confidence", 0.25), 0.25)))
    iou = max(0.0, min(1.0, to_float(params.get("iou", 0.45), 0.45)))
    imgsz = max(1, to_int(params.get("imgsz", 640), 640))
    max_det = max(1, to_int(params.get("max_det", 300), 300))
    max_results = max(0, to_int(params.get("max_results", max_det), max_det))
    max_geometry_points = max(0, to_int(params.get("max_geometry_points", 500), 500))
    include_geometry = _yes(params.get("include_geometry"), True)
    output_mode = str(params.get("output_mode", "ANNOTATED") or "ANNOTATED").strip().upper()
    device = str(params.get("device", "") or "").strip()
    class_indices = _parse_class_indices(params.get("class_indices"))

    predict_args: dict[str, Any] = {
        "source": model_input,
        "conf": conf,
        "iou": iou,
        "imgsz": imgsz,
        "max_det": max_det,
        "verbose": False,
        "save": False,
    }
    if device:
        predict_args["device"] = device
    if class_indices and task in {"detect", "segment", "pose", "obb"}:
        # 在 Ultralytics 推理阶段先筛选类别，减少后处理负担；
        # 后面仍会再次过滤，兼容不支持 classes 参数的导出/后端模型。
        predict_args["classes"] = class_indices
    if task != "auto":
        predict_args["task"] = task

    results = model.predict(**predict_args)
    if not results:
        raise ValueError("YOLO 未返回推理结果")
    result = results[0]

    detections, extra = _extract_result_payload(result, task, include_geometry, max_results, max_geometry_points)
    if class_indices:
        class_index_set = set(class_indices)
        detections = [item for item in detections if _passes_class_indices(item, class_index_set)]
    class_filter = _parse_class_filter(params.get("class_filter"))
    if class_filter:
        detections = [item for item in detections if _passes_class_filter(item, class_filter)]

    classification = extra.get("classification") or {}
    if classification:
        top_class = classification.get("top_class", "")
        top_confidence = float(classification.get("top_confidence") or 0.0)
        count = 1 if top_class else 0
        per_class_counts: dict[str, int] = {str(top_class): 1} if top_class else {}
    else:
        top = max(detections, key=lambda item: float(item.get("confidence") or 0.0), default={})
        top_class = str(top.get("class_name") or "")
        top_confidence = float(top.get("confidence") or 0.0)
        count = len(detections)
        per_class_counts = dict(Counter(str(item.get("class_name") or item.get("class_id") or "unknown") for item in detections))

    speed = getattr(result, "speed", {}) or {}
    metrics: dict[str, Any] = {
        "task": extra.get("resolved_task", task),
        "model": model_name,
        "result_count": count,
        "top_class": top_class,
        "top_confidence": round(top_confidence, 6),
        "per_class_counts": per_class_counts,
        "class_indices": class_indices,
    }
    if isinstance(speed, dict):
        metrics["speed_ms"] = {str(key): round(float(value), 4) for key, value in speed.items() if isinstance(value, (int, float))}
    if "mask_count" in extra:
        metrics["mask_count"] = extra["mask_count"]
    if "keypoint_count" in extra:
        metrics["keypoint_count"] = extra["keypoint_count"]

    if output_mode == "ORIGINAL":
        output_image = model_input.copy()
    else:
        output_image = _make_annotated_image(result, model_input)

    data: dict[str, Any] = {
        "yolo": {
            "task": metrics["task"],
            "model_path": model_location,
            "result_count": count,
            "top_class": top_class,
            "top_confidence": round(top_confidence, 6),
            "per_class_counts": per_class_counts,
            "class_indices": class_indices,
            "class_filter": sorted(class_filter),
            "detections": detections,
        }
    }
    if classification:
        data["yolo"]["classification"] = classification

    return {
        "out": output_image,
        "out_color_space": "BGR",
        "detections": detections,
        "count": count,
        "top_class": top_class,
        "top_confidence": round(top_confidence, 6),
        "task": metrics["task"],
        "metrics": metrics,
        "data": data,
    }


