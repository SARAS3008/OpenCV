from __future__ import annotations

from typing import Any

import cv2
import numpy as np

from backend.algorithms.helpers import ensure_bgr, to_int
from backend.algorithms.types import ExecutionContext, OperatorInputs, OperatorParams, OperatorResult
from backend.algorithms.yolo.common import _image_for_yolo
from backend.algorithms.yolo.selection import _box_xyxy

def _clamp_box(box: tuple[float, float, float, float], width: int, height: int, padding: int = 0) -> tuple[int, int, int, int]:
    x1, y1, x2, y2 = box
    x1_i = max(0, min(width - 1, int(round(x1)) - padding))
    y1_i = max(0, min(height - 1, int(round(y1)) - padding))
    x2_i = max(1, min(width, int(round(x2)) + padding))
    y2_i = max(1, min(height, int(round(y2)) + padding))
    if x2_i <= x1_i:
        x2_i = min(width, x1_i + 1)
    if y2_i <= y1_i:
        y2_i = min(height, y1_i + 1)
    return x1_i, y1_i, x2_i, y2_i


def _edge_roi(image: np.ndarray, box: tuple[int, int, int, int], threshold1: int, threshold2: int, aperture_size: int) -> np.ndarray:
    x1, y1, x2, y2 = box
    roi = image[y1:y2, x1:x2]
    if roi.size == 0:
        return np.zeros((1, 1), dtype=np.uint8)
    gray = cv2.cvtColor(ensure_bgr(roi), cv2.COLOR_BGR2GRAY) if roi.ndim == 3 else roi
    return cv2.Canny(gray, threshold1, threshold2, apertureSize=aperture_size)


def _make_pair_canvas(
    image: np.ndarray,
    detections: list[dict[str, Any]],
    boxes: list[tuple[int, int, int, int]],
    centers: list[tuple[float, float]],
    distance: float,
    edge_images: list[np.ndarray],
) -> np.ndarray:
    base = ensure_bgr(image).copy()
    # 标出两个目标区域、中心点和中心连线。
    for index, (item, box, center) in enumerate(zip(detections, boxes, centers), start=1):
        x1, y1, x2, y2 = box
        cx, cy = int(round(center[0])), int(round(center[1]))
        cv2.rectangle(base, (x1, y1), (x2, y2), (0, 220, 255), 2)
        cv2.circle(base, (cx, cy), 5, (0, 80, 255), -1)
        label = f"#{index} id={item.get('target_id', item.get('class_id'))} conf={float(item.get('confidence') or 0):.2f}"
        cv2.putText(base, label, (x1, max(18, y1 - 8)), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 220, 255), 2, cv2.LINE_AA)
    if len(centers) >= 2:
        p1 = tuple(int(round(v)) for v in centers[0])
        p2 = tuple(int(round(v)) for v in centers[1])
        cv2.line(base, p1, p2, (0, 80, 255), 2)
        mid = (int(round((p1[0] + p2[0]) / 2)), int(round((p1[1] + p2[1]) / 2)))
        cv2.putText(base, f"distance={distance:.2f}px", (max(8, mid[0] - 70), max(24, mid[1] - 8)), cv2.FONT_HERSHEY_SIMPLEX, 0.65, (0, 80, 255), 2, cv2.LINE_AA)

    # 右侧拼接两个 ROI 的边缘检测结果，方便在一个预览里看完整流程。
    if not edge_images:
        return base
    target_width = max(180, min(320, base.shape[1] // 3))
    panels = []
    for index, edge in enumerate(edge_images, start=1):
        edge_bgr = cv2.cvtColor(edge, cv2.COLOR_GRAY2BGR)
        scale = target_width / max(1, edge_bgr.shape[1])
        new_h = max(1, int(round(edge_bgr.shape[0] * scale)))
        resized = cv2.resize(edge_bgr, (target_width, new_h), interpolation=cv2.INTER_NEAREST)
        title = np.zeros((28, target_width, 3), dtype=np.uint8)
        cv2.putText(title, f"ROI {index} Canny", (8, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.58, (255, 255, 255), 1, cv2.LINE_AA)
        panels.append(np.vstack([title, resized]))
    panel = np.vstack(panels)
    if panel.shape[0] < base.shape[0]:
        pad = np.zeros((base.shape[0] - panel.shape[0], panel.shape[1], 3), dtype=np.uint8)
        panel = np.vstack([panel, pad])
    elif panel.shape[0] > base.shape[0]:
        pad = np.zeros((panel.shape[0] - base.shape[0], base.shape[1], 3), dtype=np.uint8)
        base = np.vstack([base, pad])
    return np.hstack([base, panel])


def op_roi_pair_edge_distance(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    """对两个检测区域分别做 Canny 边缘检测，并计算两个区域中心点距离。"""

    image = inputs.get("image")
    detections = inputs.get("detections")
    if not isinstance(image, np.ndarray):
        raise ValueError("ROI边缘距离节点需要连接原图 image 输入")
    if not isinstance(detections, list):
        raise ValueError("ROI边缘距离节点需要连接筛选后的 detections 输入")
    if len(detections) < 2:
        raise ValueError("ROI边缘距离节点至少需要 2 个检测目标")

    pair = [dict(item) for item in detections[:2] if isinstance(item, dict)]
    if len(pair) < 2:
        raise ValueError("前两个检测目标格式无效")

    padding = max(0, to_int(params.get("padding", 0), 0))
    threshold1 = max(0, to_int(params.get("threshold1", 50), 50))
    threshold2 = max(0, to_int(params.get("threshold2", 150), 150))
    aperture_size = to_int(params.get("aperture_size", 3), 3)
    if aperture_size not in {3, 5, 7}:
        aperture_size = 3

    bgr = _image_for_yolo(image, inputs.get("image_color_space", inputs.get("in_color_space", "BGR")))
    height, width = bgr.shape[:2]
    boxes: list[tuple[int, int, int, int]] = []
    centers: list[tuple[float, float]] = []
    edge_images: list[np.ndarray] = []

    for item in pair:
        box_float = _box_xyxy(item)
        if box_float is None:
            raise ValueError("检测目标缺少有效 box_xyxy，YOLO 节点需要打开 include_geometry")
        box = _clamp_box(box_float, width, height, padding)
        boxes.append(box)
        x1, y1, x2, y2 = box
        center = ((x1 + x2) / 2.0, (y1 + y2) / 2.0)
        centers.append(center)
        item["center"] = [round(center[0], 3), round(center[1], 3)]
        item["target_id"] = item.get("track_id") if item.get("track_id") is not None else item.get("class_id")
        edge_images.append(_edge_roi(bgr, box, threshold1, threshold2, aperture_size))

    distance = float(np.hypot(centers[0][0] - centers[1][0], centers[0][1] - centers[1][1]))
    canvas = _make_pair_canvas(bgr, pair, boxes, centers, distance, edge_images)

    metrics = {
        "distance_px": round(distance, 6),
        "center1": [round(centers[0][0], 3), round(centers[0][1], 3)],
        "center2": [round(centers[1][0], 3), round(centers[1][1], 3)],
        "target1": {
            "target_id": pair[0].get("target_id"),
            "class_id": pair[0].get("class_id"),
            "class_name": pair[0].get("class_name"),
            "confidence": pair[0].get("confidence"),
            "box_xyxy": list(boxes[0]),
            "edge_pixel_count": int(np.count_nonzero(edge_images[0])),
        },
        "target2": {
            "target_id": pair[1].get("target_id"),
            "class_id": pair[1].get("class_id"),
            "class_name": pair[1].get("class_name"),
            "confidence": pair[1].get("confidence"),
            "box_xyxy": list(boxes[1]),
            "edge_pixel_count": int(np.count_nonzero(edge_images[1])),
        },
    }

    return {
        "out": canvas,
        "out_color_space": "BGR",
        "edge1": edge_images[0],
        "edge1_color_space": "GRAY",
        "edge2": edge_images[1],
        "edge2_color_space": "GRAY",
        "distance": round(distance, 6),
        "center1": metrics["center1"],
        "center2": metrics["center2"],
        "metrics": metrics,
        "data": {"roi_pair_edge_distance": metrics},
    }
