from fastapi import APIRouter

from backend.api.routes import datasets, export_script, jobs, models, operators, projects, regression, runs, team, upload, workflow

api_router = APIRouter()
api_router.include_router(team.router, tags=["team"])
api_router.include_router(operators.router, tags=["operators"])
api_router.include_router(upload.router, tags=["upload"])
api_router.include_router(models.router, tags=["models"])
api_router.include_router(projects.router, tags=["projects"])
api_router.include_router(datasets.router, tags=["datasets"])
api_router.include_router(runs.router, tags=["runs"])
api_router.include_router(jobs.router, tags=["jobs"])
api_router.include_router(regression.router, tags=["regression"])
api_router.include_router(workflow.router, tags=["workflow"])
api_router.include_router(export_script.router, tags=["export"])
