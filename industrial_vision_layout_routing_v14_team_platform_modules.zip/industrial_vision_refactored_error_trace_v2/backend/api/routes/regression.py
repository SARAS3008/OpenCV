from __future__ import annotations

import copy
import time
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Request

from backend.api.dependencies import (
    get_dataset_store,
    get_image_store,
    get_job_queue,
    get_model_manager,
    get_project_store,
    get_run_history_store,
    get_user_id,
)
from backend.algorithms.yolo.model_manager import YoloModelManager
from backend.models.workflow import WorkflowRequest
from backend.services.dataset_store import DatasetStore
from backend.services.image_store import ImageStore
from backend.services.job_queue import JobQueue
from backend.services.project_store import ProjectStore
from backend.services.run_history_store import RunHistoryStore
from backend.services.workflow_engine import run_workflow

router = APIRouter(prefix="/regression-tests")


def _workflow_for_sample(base_workflow: dict[str, Any], sample: dict[str, Any]) -> WorkflowRequest:
    payload = copy.deepcopy(base_workflow)
    image_path = sample.get("image_path") or ""
    if image_path:
        for node in payload.get("nodes") or []:
            if node.get("type") == "ReadImage":
                node.setdefault("params", {})["image_path"] = image_path
                break
    return WorkflowRequest.model_validate(payload)


def _evaluate_expectation(result: dict[str, Any], expected: dict[str, Any]) -> tuple[bool, dict[str, Any]]:
    checks: dict[str, Any] = {}
    passed = True
    if "success" in expected:
        actual = bool(result.get("success", True))
        target = bool(expected.get("success"))
        checks["success"] = {"expected": target, "actual": actual, "passed": actual == target}
        passed = passed and actual == target
    metrics = expected.get("metrics") if isinstance(expected.get("metrics"), dict) else {}
    if metrics:
        previews = result.get("previews") or []
        merged: dict[str, Any] = {}
        for preview in previews:
            if isinstance(preview, dict) and isinstance(preview.get("metrics"), dict):
                merged.update(preview["metrics"])
        metric_checks = {}
        for key, target in metrics.items():
            actual = merged.get(key)
            ok = actual == target
            metric_checks[key] = {"expected": target, "actual": actual, "passed": ok}
            passed = passed and ok
        checks["metrics"] = metric_checks
    return passed, checks


def _run_regression(
    *,
    owner_id: str,
    project_id: str,
    dataset_id: str,
    project_store: ProjectStore,
    dataset_store: DatasetStore,
    history_store: RunHistoryStore,
    image_store: ImageStore,
    model_manager: YoloModelManager,
    version_id: str | None = None,
    progress=None,
) -> dict[str, Any]:
    project = project_store.get_project(project_id, owner_id)
    if version_id:
        workflow = project_store.get_version(project_id, version_id, owner_id).get("workflow") or {}
    else:
        workflow = project.get("workflow") or {}
        version_id = project.get("latest_version_id")
    dataset = dataset_store.get_dataset(owner_id=owner_id, dataset_id=dataset_id)
    samples = dataset.get("samples") or []
    total = len(samples)
    rows = []
    started = time.perf_counter()
    passed_count = 0
    failed_count = 0
    error_count = 0
    for index, sample in enumerate(samples):
        if progress:
            progress(index, max(1, total), f"回归测试 {index + 1}/{total}")
        sample_started = time.perf_counter()
        try:
            result = run_workflow(_workflow_for_sample(workflow, sample), image_store, user_id=owner_id, model_manager=model_manager)
            ok, checks = _evaluate_expectation(result, sample.get("expected") or {"success": True})
            status = "passed" if ok else "failed"
            if ok:
                passed_count += 1
            else:
                failed_count += 1
            rows.append({
                "sample_id": sample.get("sample_id"),
                "image_path": sample.get("image_path"),
                "label": sample.get("label"),
                "status": status,
                "checks": checks,
                "duration_ms": round((time.perf_counter() - sample_started) * 1000, 2),
                "summary": {"preview_count": len(result.get("previews") or []), "order": result.get("order") or []},
            })
        except Exception as exc:  # noqa: BLE001 - 单样本失败继续跑完整数据集
            error_count += 1
            rows.append({
                "sample_id": sample.get("sample_id"),
                "image_path": sample.get("image_path"),
                "label": sample.get("label"),
                "status": "error",
                "error": f"{type(exc).__name__}: {exc}",
                "duration_ms": round((time.perf_counter() - sample_started) * 1000, 2),
            })
    if progress:
        progress(total, max(1, total), "回归测试完成")
    duration_ms = round((time.perf_counter() - started) * 1000, 2)
    report = {
        "success": error_count == 0,
        "project_id": project_id,
        "version_id": version_id,
        "dataset_id": dataset_id,
        "total": total,
        "passed": passed_count,
        "failed": failed_count,
        "errors": error_count,
        "pass_rate": round(passed_count / total, 6) if total else 0,
        "duration_ms": duration_ms,
        "samples": rows,
    }
    history_store.record_run(
        owner_id=owner_id,
        workflow=workflow,
        result={"success": report["success"], "mode": "regression", "report": report},
        project_id=project_id,
        version_id=version_id,
        dataset_id=dataset_id,
        kind="regression",
        status="success" if error_count == 0 else "failed",
        metrics={"pass_rate": report["pass_rate"], "passed": passed_count, "failed": failed_count, "errors": error_count},
    )
    return report


@router.post("/run")
async def run_regression_test(
    request: Request,
    project_store: ProjectStore = Depends(get_project_store),
    dataset_store: DatasetStore = Depends(get_dataset_store),
    history_store: RunHistoryStore = Depends(get_run_history_store),
    image_store: ImageStore = Depends(get_image_store),
    model_manager: YoloModelManager = Depends(get_model_manager),
    user_id: str = Depends(get_user_id),
) -> dict[str, Any]:
    payload = await request.json()
    try:
        report = _run_regression(
            owner_id=user_id,
            project_id=payload.get("project_id"),
            version_id=payload.get("version_id"),
            dataset_id=payload.get("dataset_id"),
            project_store=project_store,
            dataset_store=dataset_store,
            history_store=history_store,
            image_store=image_store,
            model_manager=model_manager,
        )
        return {"success": True, "report": report}
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.post("/jobs")
async def submit_regression_job(
    request: Request,
    queue: JobQueue = Depends(get_job_queue),
    project_store: ProjectStore = Depends(get_project_store),
    dataset_store: DatasetStore = Depends(get_dataset_store),
    history_store: RunHistoryStore = Depends(get_run_history_store),
    image_store: ImageStore = Depends(get_image_store),
    model_manager: YoloModelManager = Depends(get_model_manager),
    user_id: str = Depends(get_user_id),
) -> dict[str, Any]:
    payload = await request.json()
    project_id = payload.get("project_id")
    version_id = payload.get("version_id")
    dataset_id = payload.get("dataset_id")

    def task(progress):
        return _run_regression(
            owner_id=user_id,
            project_id=project_id,
            version_id=version_id,
            dataset_id=dataset_id,
            project_store=project_store,
            dataset_store=dataset_store,
            history_store=history_store,
            image_store=image_store,
            model_manager=model_manager,
            progress=progress,
        )

    return {"success": True, "job": queue.submit(owner_id=user_id, kind="regression", fn=task)}
