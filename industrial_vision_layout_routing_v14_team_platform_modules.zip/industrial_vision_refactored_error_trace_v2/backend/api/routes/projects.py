from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Request

from backend.api.dependencies import get_project_store, get_user_id
from backend.models.workflow import WorkflowRequest
from backend.services.project_store import ProjectStore

router = APIRouter(prefix="/projects")


@router.get("")
def list_projects(
    project_store: ProjectStore = Depends(get_project_store),
    user_id: str = Depends(get_user_id),
) -> dict[str, Any]:
    return {"success": True, "projects": project_store.list_projects(user_id)}


@router.post("")
async def save_project(
    request: Request,
    project_store: ProjectStore = Depends(get_project_store),
    user_id: str = Depends(get_user_id),
) -> dict[str, Any]:
    payload = await request.json()
    try:
        workflow = WorkflowRequest.model_validate(payload.get("workflow") or {})
        project = project_store.save_project(
            workflow=workflow,
            owner_id=user_id,
            project_id=payload.get("project_id"),
            name=payload.get("name"),
            description=payload.get("description") or "",
            change_note=payload.get("change_note") or "保存工作流",
            workspace_id=payload.get("workspace_id"),
            create_version=payload.get("create_version", True) is not False,
        )
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return {"success": True, "project": project}


@router.get("/{project_id}")
def get_project(
    project_id: str,
    project_store: ProjectStore = Depends(get_project_store),
    user_id: str = Depends(get_user_id),
) -> dict[str, Any]:
    try:
        return {"success": True, "project": project_store.get_project(project_id, user_id)}
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.delete("/{project_id}")
def delete_project(
    project_id: str,
    project_store: ProjectStore = Depends(get_project_store),
    user_id: str = Depends(get_user_id),
) -> dict[str, Any]:
    try:
        return {"success": True, "project": project_store.delete_project(project_id, user_id)}
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.get("/{project_id}/versions")
def list_project_versions(
    project_id: str,
    project_store: ProjectStore = Depends(get_project_store),
    user_id: str = Depends(get_user_id),
) -> dict[str, Any]:
    try:
        return {"success": True, "versions": project_store.list_versions(project_id, user_id)}
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.get("/{project_id}/versions/{version_id}")
def get_project_version(
    project_id: str,
    version_id: str,
    project_store: ProjectStore = Depends(get_project_store),
    user_id: str = Depends(get_user_id),
) -> dict[str, Any]:
    try:
        return {"success": True, "version": project_store.get_version(project_id, version_id, user_id)}
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.get("/{project_id}/diff")
def diff_project_versions(
    project_id: str,
    from_version: str | None = None,
    to_version: str | None = None,
    project_store: ProjectStore = Depends(get_project_store),
    user_id: str = Depends(get_user_id),
) -> dict[str, Any]:
    try:
        return {"success": True, **project_store.diff_versions(project_id, user_id, from_version=from_version, to_version=to_version)}
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.post("/{project_id}/rollback/{version_id}")
def rollback_project(
    project_id: str,
    version_id: str,
    project_store: ProjectStore = Depends(get_project_store),
    user_id: str = Depends(get_user_id),
) -> dict[str, Any]:
    try:
        return {"success": True, "project": project_store.rollback_project(project_id, version_id, user_id)}
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.post("/{project_id}/release/{version_id}")
def release_project_version(
    project_id: str,
    version_id: str,
    project_store: ProjectStore = Depends(get_project_store),
    user_id: str = Depends(get_user_id),
) -> dict[str, Any]:
    try:
        return {"success": True, "project": project_store.release_version(project_id, version_id, user_id)}
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
