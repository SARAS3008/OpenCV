from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, Request

from backend.api.dependencies import get_user_id, get_workspace_store
from backend.services.team_store import WorkspaceStore

router = APIRouter()


@router.get("/users/me")
def get_me(
    store: WorkspaceStore = Depends(get_workspace_store),
    user_id: str = Depends(get_user_id),
) -> dict[str, Any]:
    return {"success": True, "user": store.me(user_id)}


@router.get("/workspaces")
def list_workspaces(
    store: WorkspaceStore = Depends(get_workspace_store),
    user_id: str = Depends(get_user_id),
) -> dict[str, Any]:
    return {"success": True, "workspaces": store.list_workspaces(user_id)}


@router.post("/workspaces")
async def create_workspace(
    request: Request,
    store: WorkspaceStore = Depends(get_workspace_store),
    user_id: str = Depends(get_user_id),
) -> dict[str, Any]:
    payload = await request.json()
    workspace = store.create_workspace(
        owner_id=user_id,
        name=payload.get("name") or "新工作区",
        members=payload.get("members") or [],
    )
    return {"success": True, "workspace": workspace}
