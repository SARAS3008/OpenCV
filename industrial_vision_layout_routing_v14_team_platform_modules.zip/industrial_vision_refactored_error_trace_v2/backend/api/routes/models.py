from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Request

from backend.api.dependencies import get_model_manager, get_user_id
from backend.algorithms.yolo.model_manager import YoloModelManager

router = APIRouter(prefix="/models")


@router.get("")
def list_models(
    manager: YoloModelManager = Depends(get_model_manager),
    user_id: str = Depends(get_user_id),
) -> dict[str, Any]:
    return {"success": True, "models": manager.list_models(owner_id=user_id), "cache": manager.stats()}


@router.get("/assets")
def list_model_assets(
    manager: YoloModelManager = Depends(get_model_manager),
    user_id: str = Depends(get_user_id),
) -> dict[str, Any]:
    return {"success": True, "assets": manager.list_model_assets(owner_id=user_id), "cache": manager.stats()}


@router.patch("/{model_id}")
async def update_model_metadata(
    model_id: str,
    request: Request,
    manager: YoloModelManager = Depends(get_model_manager),
    user_id: str = Depends(get_user_id),
) -> dict[str, Any]:
    payload = await request.json()
    try:
        return {"success": True, "model": manager.update_model_metadata(model_id, owner_id=user_id, metadata=payload)}
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.delete("/{model_id}")
def delete_model(
    model_id: str,
    manager: YoloModelManager = Depends(get_model_manager),
    user_id: str = Depends(get_user_id),
) -> dict[str, Any]:
    try:
        return {"success": True, "model": manager.delete_model(model_id, owner_id=user_id)}
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.post("/cache/clear")
def clear_model_cache(
    manager: YoloModelManager = Depends(get_model_manager),
    user_id: str = Depends(get_user_id),
) -> dict[str, Any]:
    manager.clear_cache(owner_id=user_id)
    return {"success": True, "cache": manager.stats()}
