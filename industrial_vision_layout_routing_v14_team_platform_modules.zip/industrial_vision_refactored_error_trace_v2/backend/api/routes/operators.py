from fastapi import APIRouter

from backend.algorithms.registry import FAILED_CUSTOM_PLUGINS, OPERATOR_CATALOG, OPERATOR_META

router = APIRouter()


@router.get("/operators")
def list_operators() -> dict:
    return {"operators": OPERATOR_META, "catalog": OPERATOR_CATALOG, "plugin_errors": FAILED_CUSTOM_PLUGINS}
