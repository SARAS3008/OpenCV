from __future__ import annotations

from fastapi import Request

from backend.algorithms.yolo.model_manager import YoloModelManager, safe_user_id
from backend.services.image_store import ImageStore
from backend.services.project_store import ProjectStore
from backend.services.team_store import WorkspaceStore
from backend.services.dataset_store import DatasetStore
from backend.services.run_history_store import RunHistoryStore
from backend.services.job_queue import JobQueue


def get_user_id(request: Request) -> str:
    # 轻量多用户隔离：真实部署可在这里接入认证系统。
    return safe_user_id(request.headers.get("X-User-Id") or request.headers.get("X-User-Email") or "default")


def get_image_store(request: Request) -> ImageStore:
    return request.app.state.image_store


def get_model_manager(request: Request) -> YoloModelManager:
    return request.app.state.model_manager


def get_project_store(request: Request) -> ProjectStore:
    return request.app.state.project_store


def get_workspace_store(request: Request) -> WorkspaceStore:
    return request.app.state.workspace_store

def get_dataset_store(request: Request) -> DatasetStore:
    return request.app.state.dataset_store

def get_run_history_store(request: Request) -> RunHistoryStore:
    return request.app.state.run_history_store

def get_job_queue(request: Request) -> JobQueue:
    return request.app.state.job_queue
