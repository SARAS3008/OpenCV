from __future__ import annotations

import json
import re
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from backend.algorithms.yolo.model_manager import safe_user_id
from backend.config import PROJECTS_DIR
from backend.models.workflow import WorkflowRequest
from backend.services.workflow_diff import diff_workflows

_SAFE_NAME_RE = re.compile(r"[^0-9A-Za-z._\-\u4e00-\u9fff ]+")


def _now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _safe_name(value: str | None, fallback: str = "Vision Workflow") -> str:
    name = _SAFE_NAME_RE.sub("_", str(value or fallback).strip())
    return name[:120] or fallback


@dataclass(frozen=True)
class ProjectSummary:
    project_id: str
    name: str
    owner_id: str
    created_at: str
    updated_at: str
    description: str = ""


class ProjectStore:
    """基于文件系统的项目保存服务。

    每个用户一个目录，项目 JSON 独立保存，便于后续替换成数据库。
    """

    def __init__(self, root_dir: Path = PROJECTS_DIR) -> None:
        self.root_dir = root_dir.resolve()
        self.root_dir.mkdir(parents=True, exist_ok=True)

    def _user_dir(self, owner_id: str) -> Path:
        directory = self.root_dir / safe_user_id(owner_id)
        directory.mkdir(parents=True, exist_ok=True)
        return directory

    def _project_path(self, project_id: str, owner_id: str) -> Path:
        safe_id = safe_user_id(project_id)
        path = (self._user_dir(owner_id) / f"{safe_id}.json").resolve()
        if path.parent != self._user_dir(owner_id).resolve():
            raise ValueError("项目 ID 无效")
        return path

    def _versions_dir(self, project_id: str, owner_id: str) -> Path:
        directory = (self._user_dir(owner_id) / "_versions" / safe_user_id(project_id)).resolve()
        base = (self._user_dir(owner_id) / "_versions").resolve()
        directory.mkdir(parents=True, exist_ok=True)
        if directory.parent != base:
            raise ValueError("项目 ID 无效")
        return directory

    def _version_path(self, project_id: str, owner_id: str, version_id: str) -> Path:
        safe_version = safe_user_id(version_id)
        path = (self._versions_dir(project_id, owner_id) / f"{safe_version}.json").resolve()
        if path.parent != self._versions_dir(project_id, owner_id).resolve():
            raise ValueError("版本 ID 无效")
        return path

    def _next_version_id(self, project_id: str, owner_id: str) -> str:
        existing = [path.stem for path in self._versions_dir(project_id, owner_id).glob("v*.json")]
        numbers = []
        for item in existing:
            try:
                numbers.append(int(item.lstrip("v")))
            except ValueError:
                continue
        return f"v{(max(numbers) if numbers else 0) + 1:06d}"

    def list_projects(self, owner_id: str = "default") -> list[dict[str, Any]]:
        projects: list[dict[str, Any]] = []
        for path in sorted(self._user_dir(owner_id).glob("*.json"), key=lambda item: item.stat().st_mtime, reverse=True):
            try:
                payload = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                continue
            projects.append({
                "project_id": payload.get("project_id") or path.stem,
                "name": payload.get("name") or path.stem,
                "owner_id": payload.get("owner_id") or safe_user_id(owner_id),
                "description": payload.get("description") or "",
                "created_at": payload.get("created_at") or "",
                "updated_at": payload.get("updated_at") or "",
                "latest_version_id": payload.get("latest_version_id") or "",
                "released_version_id": payload.get("released_version_id") or "",
                "node_count": len((payload.get("workflow") or {}).get("nodes") or []),
                "edge_count": len((payload.get("workflow") or {}).get("edges") or []),
                "module_count": len((payload.get("workflow") or {}).get("modules") or []),
            })
        return projects

    def get_project(self, project_id: str, owner_id: str = "default") -> dict[str, Any]:
        path = self._project_path(project_id, owner_id)
        if not path.is_file():
            raise ValueError("项目不存在")
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise ValueError(f"项目文件读取失败：{exc}") from exc

    def save_project(
        self,
        *,
        workflow: WorkflowRequest | dict[str, Any],
        owner_id: str = "default",
        project_id: str | None = None,
        name: str | None = None,
        description: str = "",
        change_note: str = "",
        create_version: bool = True,
        workspace_id: str | None = None,
    ) -> dict[str, Any]:
        active_owner = safe_user_id(owner_id)
        workflow_model = workflow if isinstance(workflow, WorkflowRequest) else WorkflowRequest.model_validate(workflow)
        workflow_payload = workflow_model.model_dump()
        now = _now_iso()
        resolved_id = safe_user_id(project_id) if project_id else uuid.uuid4().hex
        path = self._project_path(resolved_id, active_owner)

        created_at = now
        existing: dict[str, Any] = {}
        previous_workflow: dict[str, Any] | None = None
        if path.is_file():
            try:
                existing = json.loads(path.read_text(encoding="utf-8"))
                created_at = str(existing.get("created_at") or now)
                previous_workflow = existing.get("workflow") or None
            except (OSError, json.JSONDecodeError):
                existing = {}

        version_id = existing.get("latest_version_id") or ""
        if create_version:
            version_id = self._next_version_id(resolved_id, active_owner)

        payload = {
            "version": 2,
            "project_id": resolved_id,
            "name": _safe_name(name or existing.get("name"), "Vision Workflow"),
            "description": str(description if description is not None else existing.get("description") or "")[:1000],
            "owner_id": active_owner,
            "workspace_id": workspace_id or existing.get("workspace_id") or f"ws_{active_owner}",
            "created_at": created_at,
            "updated_at": now,
            "latest_version_id": version_id,
            "released_version_id": existing.get("released_version_id") or "",
            "workflow": workflow_payload,
        }
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(path)

        if create_version:
            version_payload = {
                "schema_version": 1,
                "project_id": resolved_id,
                "version_id": version_id,
                "name": payload["name"],
                "description": payload["description"],
                "owner_id": active_owner,
                "workspace_id": payload["workspace_id"],
                "created_at": now,
                "created_by": active_owner,
                "change_note": str(change_note or "保存工作流")[:1000],
                "workflow": workflow_payload,
                "diff_from_previous": diff_workflows(previous_workflow, workflow_payload),
                "status": "draft",
            }
            self._version_path(resolved_id, active_owner, version_id).write_text(
                json.dumps(version_payload, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
        return payload

    def list_versions(self, project_id: str, owner_id: str = "default") -> list[dict[str, Any]]:
        self.get_project(project_id, owner_id)
        versions = []
        for path in sorted(self._versions_dir(project_id, owner_id).glob("*.json"), key=lambda item: item.name, reverse=True):
            try:
                payload = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                continue
            workflow = payload.get("workflow") or {}
            versions.append({
                "project_id": payload.get("project_id") or project_id,
                "version_id": payload.get("version_id") or path.stem,
                "created_at": payload.get("created_at") or "",
                "created_by": payload.get("created_by") or payload.get("owner_id") or "",
                "change_note": payload.get("change_note") or "",
                "status": payload.get("status") or "draft",
                "node_count": len(workflow.get("nodes") or []),
                "edge_count": len(workflow.get("edges") or []),
                "module_count": len(workflow.get("modules") or []),
            })
        return versions

    def get_version(self, project_id: str, version_id: str, owner_id: str = "default") -> dict[str, Any]:
        self.get_project(project_id, owner_id)
        path = self._version_path(project_id, owner_id, version_id)
        if not path.is_file():
            raise ValueError("项目版本不存在")
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise ValueError(f"版本文件读取失败：{exc}") from exc

    def diff_versions(
        self,
        project_id: str,
        owner_id: str = "default",
        *,
        from_version: str | None = None,
        to_version: str | None = None,
    ) -> dict[str, Any]:
        project = self.get_project(project_id, owner_id)
        if from_version:
            before = self.get_version(project_id, from_version, owner_id).get("workflow") or {}
        else:
            versions = self.list_versions(project_id, owner_id)
            before = self.get_version(project_id, versions[1]["version_id"], owner_id).get("workflow") if len(versions) > 1 else {}
        after = self.get_version(project_id, to_version, owner_id).get("workflow") if to_version else project.get("workflow") or {}
        return {
            "project_id": project_id,
            "from_version": from_version,
            "to_version": to_version or project.get("latest_version_id"),
            "diff": diff_workflows(before, after),
        }

    def rollback_project(self, project_id: str, version_id: str, owner_id: str = "default", *, change_note: str = "版本回滚") -> dict[str, Any]:
        project = self.get_project(project_id, owner_id)
        version = self.get_version(project_id, version_id, owner_id)
        return self.save_project(
            workflow=version.get("workflow") or {},
            owner_id=owner_id,
            project_id=project_id,
            name=project.get("name") or version.get("name"),
            description=project.get("description") or version.get("description") or "",
            change_note=f"{change_note}: {version_id}",
            create_version=True,
            workspace_id=project.get("workspace_id"),
        )

    def release_version(self, project_id: str, version_id: str, owner_id: str = "default") -> dict[str, Any]:
        project = self.get_project(project_id, owner_id)
        version = self.get_version(project_id, version_id, owner_id)
        path = self._project_path(project_id, owner_id)
        project["released_version_id"] = version_id
        project["released_at"] = _now_iso()
        project["updated_at"] = project["released_at"]
        path.write_text(json.dumps(project, ensure_ascii=False, indent=2), encoding="utf-8")
        version["status"] = "released"
        self._version_path(project_id, owner_id, version_id).write_text(json.dumps(version, ensure_ascii=False, indent=2), encoding="utf-8")
        return project

    def delete_project(self, project_id: str, owner_id: str = "default") -> dict[str, Any]:
        payload = self.get_project(project_id, owner_id)
        path = self._project_path(project_id, owner_id)
        path.unlink(missing_ok=True)
        return payload
