from __future__ import annotations

import json
import time
import uuid
from pathlib import Path
from typing import Any

from backend.algorithms.yolo.model_manager import safe_user_id
from backend.config import RUN_HISTORY_DIR


def _now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


class RunHistoryStore:
    """保存运行历史、回归报告和结果摘要。"""

    def __init__(self, root_dir: Path = RUN_HISTORY_DIR) -> None:
        self.root_dir = root_dir.resolve()
        self.root_dir.mkdir(parents=True, exist_ok=True)

    def _user_dir(self, owner_id: str) -> Path:
        path = self.root_dir / safe_user_id(owner_id)
        path.mkdir(parents=True, exist_ok=True)
        return path

    def record_run(
        self,
        *,
        owner_id: str,
        workflow: dict[str, Any] | None = None,
        result: dict[str, Any] | None = None,
        project_id: str | None = None,
        version_id: str | None = None,
        dataset_id: str | None = None,
        kind: str = "workflow",
        status: str | None = None,
        error: str | None = None,
        metrics: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        now = _now_iso()
        run_id = uuid.uuid4().hex
        result = result or {}
        payload = {
            "version": 1,
            "run_id": run_id,
            "kind": kind,
            "owner_id": safe_user_id(owner_id),
            "project_id": project_id,
            "version_id": version_id,
            "dataset_id": dataset_id,
            "created_at": now,
            "status": status or ("success" if result.get("success", True) else "failed"),
            "error": error or result.get("error"),
            "workflow": workflow or {},
            "summary": self._summarize_result(result),
            "metrics": metrics or {},
            "result": self._compact_result(result),
        }
        path = self._user_dir(owner_id) / f"{run_id}.json"
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(path)
        return payload

    def list_runs(self, *, owner_id: str, project_id: str | None = None, limit: int = 50) -> list[dict[str, Any]]:
        rows: list[dict[str, Any]] = []
        for path in sorted(self._user_dir(owner_id).glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True):
            try:
                payload = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                continue
            if project_id and payload.get("project_id") != project_id:
                continue
            rows.append({
                "run_id": payload.get("run_id") or path.stem,
                "kind": payload.get("kind") or "workflow",
                "project_id": payload.get("project_id"),
                "version_id": payload.get("version_id"),
                "dataset_id": payload.get("dataset_id"),
                "created_at": payload.get("created_at") or "",
                "status": payload.get("status") or "unknown",
                "summary": payload.get("summary") or {},
                "metrics": payload.get("metrics") or {},
                "error": payload.get("error"),
            })
            if len(rows) >= limit:
                break
        return rows

    def get_run(self, *, owner_id: str, run_id: str) -> dict[str, Any]:
        path = self._user_dir(owner_id) / f"{safe_user_id(run_id)}.json"
        if not path.is_file():
            raise ValueError("运行记录不存在")
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise ValueError(f"运行记录读取失败：{exc}") from exc

    def _summarize_result(self, result: dict[str, Any]) -> dict[str, Any]:
        previews = result.get("previews") or []
        batch = result.get("batch") or None
        return {
            "mode": result.get("mode") or ("batch" if batch else "single"),
            "preview_count": len(previews) if isinstance(previews, list) else 0,
            "order": result.get("order") or result.get("executed_order") or [],
            "batch": batch,
        }

    def _compact_result(self, result: dict[str, Any]) -> dict[str, Any]:
        compact = dict(result)
        previews = compact.get("previews")
        if isinstance(previews, list):
            compact["previews"] = [
                {k: v for k, v in item.items() if k not in {"image", "thumbnail", "full_image"}}
                for item in previews
                if isinstance(item, dict)
            ]
        return compact
