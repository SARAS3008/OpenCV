from __future__ import annotations

import json
import time
import uuid
from pathlib import Path
from typing import Any

from backend.algorithms.yolo.model_manager import safe_user_id
from backend.config import WORKSPACES_DIR


def _now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


class WorkspaceStore:
    """轻量团队/工作区服务。

    这里暂时使用文件系统实现，目的是让平台先具备团队协作数据模型：
    用户、工作区、成员角色。真实部署时可以替换为 OAuth/LDAP + 数据库。
    """

    def __init__(self, root_dir: Path = WORKSPACES_DIR) -> None:
        self.root_dir = root_dir.resolve()
        self.root_dir.mkdir(parents=True, exist_ok=True)

    def _path(self, workspace_id: str) -> Path:
        safe_id = safe_user_id(workspace_id)
        return self.root_dir / f"{safe_id}.json"

    def _default_workspace(self, owner_id: str) -> dict[str, Any]:
        active_user = safe_user_id(owner_id)
        workspace_id = f"ws_{active_user}"
        now = _now_iso()
        return {
            "version": 1,
            "workspace_id": workspace_id,
            "name": "默认工作区",
            "owner_id": active_user,
            "created_at": now,
            "updated_at": now,
            "members": [{"user_id": active_user, "role": "Owner", "joined_at": now}],
        }

    def ensure_personal_workspace(self, owner_id: str) -> dict[str, Any]:
        active_user = safe_user_id(owner_id)
        workspace_id = f"ws_{active_user}"
        path = self._path(workspace_id)
        if path.is_file():
            try:
                return json.loads(path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                pass
        payload = self._default_workspace(active_user)
        self._write(path, payload)
        return payload

    def me(self, user_id: str) -> dict[str, Any]:
        active_user = safe_user_id(user_id)
        workspace = self.ensure_personal_workspace(active_user)
        return {
            "user_id": active_user,
            "display_name": active_user,
            "roles": {workspace["workspace_id"]: "Owner"},
            "default_workspace_id": workspace["workspace_id"],
        }

    def list_workspaces(self, user_id: str) -> list[dict[str, Any]]:
        active_user = safe_user_id(user_id)
        self.ensure_personal_workspace(active_user)
        result: list[dict[str, Any]] = []
        for path in sorted(self.root_dir.glob("*.json")):
            try:
                item = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                continue
            members = item.get("members") or []
            if item.get("owner_id") == active_user or any(member.get("user_id") == active_user for member in members):
                result.append({
                    "workspace_id": item.get("workspace_id") or path.stem,
                    "name": item.get("name") or path.stem,
                    "owner_id": item.get("owner_id") or "default",
                    "created_at": item.get("created_at") or "",
                    "updated_at": item.get("updated_at") or "",
                    "member_count": len(members),
                    "role": next((m.get("role") for m in members if m.get("user_id") == active_user), "Owner"),
                })
        return result

    def create_workspace(self, *, owner_id: str, name: str, members: list[dict[str, Any]] | None = None) -> dict[str, Any]:
        active_user = safe_user_id(owner_id)
        now = _now_iso()
        workspace_id = f"ws_{uuid.uuid4().hex}"
        normalized_members = [{"user_id": active_user, "role": "Owner", "joined_at": now}]
        for member in members or []:
            member_user = safe_user_id(member.get("user_id") or member.get("email"))
            if member_user == active_user:
                continue
            normalized_members.append({"user_id": member_user, "role": str(member.get("role") or "Developer"), "joined_at": now})
        payload = {
            "version": 1,
            "workspace_id": workspace_id,
            "name": str(name or "新工作区")[:120],
            "owner_id": active_user,
            "created_at": now,
            "updated_at": now,
            "members": normalized_members,
        }
        self._write(self._path(workspace_id), payload)
        return payload

    def _write(self, path: Path, payload: dict[str, Any]) -> None:
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(path)
