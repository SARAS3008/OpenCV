# v13 架构优化说明

本版本围绕可维护性、长时间运行稳定性和项目化管理做了增量重构，保持旧 API 和旧导入路径兼容。

## 1. YOLO 算子拆分

原 `backend/algorithms/yolo_ops.py` 已缩减为兼容导出入口，实际实现拆分为：

- `backend/algorithms/yolo/common.py`：通用参数、类型转换、类别过滤、图像颜色空间处理。
- `backend/algorithms/yolo/model_manager.py`：模型路径解析、上传记录、LRU/TTL 缓存、多用户隔离。
- `backend/algorithms/yolo/result_parser.py`：检测框、分割、多边形、姿态、OBB、分类结果解析。
- `backend/algorithms/yolo/selection.py`：Top-K、按类别筛选、动态 Mask 输出。
- `backend/algorithms/yolo/roi_distance.py`：ROI 边缘距离测量。
- `backend/algorithms/yolo/ops.py`：`YoloInfer` 算子入口。

旧代码仍可继续使用：

```python
from backend.algorithms import yolo_ops
from backend.algorithms.yolo_ops import op_yolo_infer
```

## 2. 统一算子注册表

新增：

- `backend/algorithms/operator_registry.py`
- `OperatorDefinition`
- `OperatorRegistry`

现在算子运行函数、元数据、目录分组和脚本导出编译器会统一注册到 `OPERATOR_REGISTRY`。旧变量仍然保留：

- `OPERATORS`
- `OPERATOR_META`
- `OPERATOR_CATALOG`
- `CUSTOM_SCRIPT_COMPILERS`

自定义插件仍通过 `OPERATOR_DEFINITION` 加载，但现在也会进入统一注册表。

## 3. 模型管理与缓存策略

新增服务：`YoloModelManager`。

能力包括：

- 多模型缓存，不再每次加载新模型时清空旧模型。
- LRU 淘汰，默认最多缓存 `MODEL_CACHE_MAX_ITEMS = 4` 个模型。
- TTL 过期，默认 `MODEL_CACHE_TTL_SECONDS = 1800`。
- 基于 `X-User-Id` / `X-User-Email` 的轻量多用户隔离。
- 上传模型元数据保存到 `models/uploads/models.json`。

新增 API：

- `GET /api/models`：查看当前用户模型列表和缓存状态。
- `DELETE /api/models/{model_id}`：删除当前用户模型。
- `POST /api/models/cache/clear`：清理当前用户缓存。
- `POST /api/upload-model`：返回兼容的 `model_path`，同时新增 `model_id` 和 `owner_id`。

## 4. 服务端项目管理

新增服务：`ProjectStore`。

项目以 JSON 保存到：

```text
projects/<user_id>/<project_id>.json
```

新增 API：

- `GET /api/projects`：列出当前用户项目。
- `POST /api/projects`：保存或更新项目。
- `GET /api/projects/{project_id}`：读取项目。
- `DELETE /api/projects/{project_id}`：删除项目。

前端 `Ctrl+S` 现在优先保存到服务端项目库；服务端不可用时，自动回落到本地缓存。

## 5. 前端状态模块化

新增：

- `frontend/assets/js/app/state_store.js`

该模块负责：

- 工作区签名与深拷贝。
- 本地兜底缓存。
- 服务端项目列表、打开、保存。
- 工作流文档对象创建。

原页面的全局状态变量仍保留，避免一次性大改破坏画布交互；但持久化与项目管理已经从 `state.js` 中抽离出来，后续可以继续把节点、连线、选择态迁移到同一模块。

## 6. 回归测试

新增 `tests/test_project_and_model_management.py`，覆盖：

- 项目保存、列表、读取、删除。
- 项目多用户隔离。
- YOLO 模型缓存按用户隔离、复用和 LRU 淘汰。
- YOLO 算子使用执行上下文里的模型管理器。

当前测试结果：

```text
54 passed
```
