# 本轮优化说明

## 1. 前端 app.js 拆分

维护源文件已从单个 `frontend/assets/js/app.js` 拆分为：

- `frontend/assets/js/app/state.js`：全局状态、工作流文档、初始化。
- `frontend/assets/js/app/operators.js`：节点库、分类、节点新增。
- `frontend/assets/js/app/canvas.js`：画布、节点、端口、连线、参数面板。
- `frontend/assets/js/app/actions.js`：节点操作、运行预览、导入导出、Lightbox。
- `frontend/assets/js/app/minimap.js`：导航视图坐标映射与点击定位。
- `frontend/assets/js/app/bootstrap.js`：事件绑定和启动入口。

`frontend/assets/js/app.bundle.legacy.js` 保留原始单文件版本，便于回滚和对照；`app.js` 只保留入口说明与旧版静态检查兼容标记。

## 2. 自定义插件隔离加载

`backend/algorithms/plugin_loader.py` 改为逐插件 try/except。单个插件导入失败、结构无效或类型冲突时，不再阻止 FastAPI 应用启动。

`GET /api/operators` 现在额外返回：

```json
{
  "plugin_errors": [
    {"module": "backend.custom_operators.xxx", "error": "...", "cause_type": "ValueError"}
  ]
}
```

前端初始化时如果发现插件错误，会显示提示，并引导查看 `/api/operators` 的 `plugin_errors` 字段。

## 3. AST 脚本导出支持多输出端口

`backend/services/script_exporter.py` 的变量映射已从按节点映射升级为按 `(node_id, output_handle)` 映射。自定义 `script_compiler` 支持新多输出协议：

```python
return [], {
    "out": {"expression": "image.copy()", "kind": "image", "color_space": "BGR"},
    "score": {"expression": "float(score)", "kind": "value"},
}
```

旧三元组协议 `([statements], expression, color_space)` 继续兼容。`MeanBrightness` 已迁移到新协议，`mean_brightness` 和 `brightness_std` 连接到逻辑节点时，导出的脚本会传递数值端口，而不是误传图像变量。

## 4. If/Else 分支按需执行

后端执行器从“全量拓扑执行”升级为“终点按需执行 + If/Else 动态分支选择”。

- 普通节点仍按拓扑依赖顺序执行。
- `LogicIfElse` 会先计算 `condition`。
- 条件为真时只执行 `true_value` 依赖分支；条件为假时只执行 `false_value` 依赖分支。
- 未被选择且没有其他终点依赖的分支不会执行，也不会产生预览。

`LogicForLoop` 和 `LogicWhileLoop` 仍保持安全数值迭代节点，不扩展为任意子流程容器；真正的循环子图仍需要引入子图作用域和控制令牌。


## 2026-07-01 · 前端交互优化：双击新增节点居中

- 节点库中双击算子时，不再使用固定的 `460 + nodes.length * 28 / 240 + nodes.length * 22` 坐标。
- 新增 `getViewportCenterWorldPoint()`，将当前画布视口中心从屏幕坐标换算为世界坐标。
- 新增 `addNodeAtViewportCenter(type)`，双击新增节点会按实际 DOM 尺寸回算左上角，使节点本体居中出现在当前视图中。
- 拖拽新增节点的行为保持不变，仍按鼠标释放位置创建。

## 2026-07-01 · 新增 YOLO 推理算子接口

- 新增 `backend/algorithms/yolo_ops.py`，通过 Ultralytics `YOLO` 接口加载模型并执行推理。
- 新增内置算子 `YoloInfer`，位于图像节点库的 `AI推理` 分组。
- 支持任务：`auto`、`detect`、`segment`、`classify`、`pose`、`obb`。
- 新增 `/api/upload-model`，前端可直接在节点参数中选择本地模型文件并上传，返回可写入 `model_path` 的项目相对路径。
- `YoloInfer` 输出：
  - `out`：标注图或原图；
  - `detections`：检测/分割/姿态/OBB 的结构化列表；
  - `count`：结果数量；
  - `top_class` / `top_confidence`：最高类别和置信度；
  - `task`：最终识别/使用的任务类型；
  - `metrics` / `data.yolo`：用于前端预览和批量 CSV 汇总。
- 前端 `param_schema.type = "file"` 已支持文件参数控件；当前用于模型文件上传。
- 新依赖：`ultralytics>=8.3,<9.0`。如果运行环境未安装，节点执行时会返回明确错误提示。

## v7 YOLO Top2 ROI 边缘距离示例

- `YoloInfer.model_path` 现在支持直接填写 `yolov8n.pt` 这类 Ultralytics 预训练模型短名称；本地不存在时交给 Ultralytics 首次运行自动下载。
- 新增 `YoloSelectTopDetections`：从 YOLO `detections` 中按置信度阈值、排序方式和 Top-K 规则筛选目标。默认 `min_confidence=0.35`、`top_k=2`、`sort_by=CONFIDENCE_DESC`。
- 新增 `RoiPairEdgeDistance`：接收原图和两个检测目标，分别裁剪 ROI 做 Canny 边缘检测，并计算两个 ROI 中心点距离。
- 新增示例工作流：`examples/yolo_top2_roi_edge_distance_workflow.json`。
- 新增测试图像：`examples/images/bus.jpg`。
- 新增模型下载脚本：`scripts/download_yolov8n.py`。

## v8 YOLO 类别 Index 过滤

- `YoloInfer` 新增参数 `class_indices`，用于按模型类别 index 白名单过滤推理结果，例如 `0,1,8`。
- 对 `detect`、`segment`、`pose`、`obb` 任务，`class_indices` 会优先作为 Ultralytics `classes` 参数传入推理阶段，减少无关类别的后处理结果。
- 后处理阶段仍会再次按 `class_id` 过滤 `detections`，兼容部分模型/后端不支持 `classes` 参数或返回未过滤结果的情况。
- `YoloInfer.detections`、`count`、`top_class`、`top_confidence`、`metrics`、`data.yolo` 均基于过滤后的结果计算，因此后续节点只会接收到指定类别 index 的目标。
- 保留旧参数 `class_filter`，用于按类别名或类别 ID 做二次过滤；精确按 index 过滤时建议优先使用 `class_indices`。
- 新增示例工作流：`examples/yolo_class_indices_top2_roi_distance_workflow.json`，默认只保留 `0,1,8` 三类，再取置信度最高的 2 个目标做 ROI 边缘检测和中心距离计算。

## v9 YOLO 目标筛选：按类别分别选择与二值 Mask 输出

- `YoloSelectTopDetections` 新增 `selection_mode`：
  - `AUTO`：填写 `class_indices` 时自动使用按类别分别筛选；未填写时保持原混合 Top-K 行为。
  - `PER_CLASS_BEST`：对 `class_indices` 中的每个类别 index 单独筛选，只取该类别内置信度最高且大于等于 `min_confidence` 的一个目标。
  - `MIXED_TOP_K`：兼容旧行为，在所有目标中混合排序后取 Top-K。
- `YoloSelectTopDetections.class_indices` 用于声明后续真正需要的类别，例如 `0,1,8`。按类别模式下，`top_k` 应等于 index 总数；实际执行会以 index 数量作为期望数量。
- 当某个 index 未检测到或最高置信度低于阈值时：
  - `require_exact_count=YES`：节点报错，并指出缺失 index、原因和当前最佳置信度；
  - `require_exact_count=NO`：流程继续，缺失项写入 `missing_indices`。
- 新增可选输入 `image`。连接原图后，筛选节点会输出二值 Mask：
  - `mask`：所有已选目标的合并 Mask；
  - `mask1` / `mask2` / ...：单个目标区域 Mask；
  - Mask 为单通道 `uint8` 图像，目标区域为 255，背景为 0。
- 如果上游检测结果包含分割多边形，则 Mask 使用多边形填充；否则使用检测框区域填充，适用于普通目标检测模型。
- 新增示例工作流：`examples/yolo_per_class_mask_roi_distance_workflow.json`。

## v10 YOLO 目标筛选：Mask 输出端口按参数自动适配

- `YoloSelectTopDetections` 的单目标 Mask 端口改为动态输出端口。
- 当填写 `class_indices` 时，前端按 index 数量自动生成 `mask1`、`mask2` ...；例如 `class_indices=0,1` 显示 `mask1`、`mask2`，`class_indices=0,1,8` 会继续显示 `mask3`。
- 未填写 `class_indices` 时，按 `top_k` 自动生成对应数量的单目标 Mask 端口。
- 后端不再限制只输出前 4 个 Mask，会根据期望目标数量返回 `maskN`。
- 在按类别分别筛选且 `require_exact_count=NO` 时，如果某个类别未命中，仍会按原顺序输出对应编号的空白二值 Mask，避免下游已连接的 `maskN` 端口因缺失而报错。
- 当前动态端口上限为 20 个，避免节点过高或误填过大数值导致前端不可用。
- 新增示例工作流：`examples/yolo_dynamic_mask_outputs_workflow.json`，展示 `class_indices=0,1,8` 时自动生成 `mask1`、`mask2`、`mask3` 并分别连接到显示节点。

## v11 前端交互优化：自动美化排线与节点布局

- 画布工具栏新增“美化排线”按钮。
- 点击后会在不改变节点类型、参数、连线关系和执行语义的前提下，按 DAG 拓扑运行层级自动重排节点。
- 布局规则：
  - 入度为 0 的节点放在左侧起始层；
  - 下游节点按依赖关系逐层向右排列；
  - 同一层节点根据当前画布顺序和上下游重心排序，减少连线交叉；
  - 根据节点实际 DOM 尺寸计算纵向间距，避免节点重叠。
- 连线路径由原来的单纯贝塞尔曲线升级为带圆角的正交折线路径；自动布局后，大多数连线会走在层级之间的空白通道中，减少穿过节点区域的情况。
- 自动布局完成后，会把新布局整体平移到当前视图中心，用户不用重新寻找工作流。
- 如果当前工作流存在环，前端不会强行重排，而是提示先删除循环依赖。

## v12 前端交互优化：连线避障与负坐标可见性修复

- 修复节点被拖到画布上方或自动布局后出现负坐标时，SVG 连线被裁剪导致“连线实际存在但画布看不见”的问题：`world`、`edge-layer`、`node-layer` 均允许可视溢出，`renderEdges` 也会显式设置 SVG `overflow=visible`。
- 连线渲染从简单中点折线升级为避障正交路由：渲染时会把非起止节点作为障碍矩形，优先选择不穿过节点区域的垂直通道或上下总线通道。
- 美化后的复杂工作流不再依赖“线藏在节点下面”的视觉效果；路径会尽量走节点之间或节点外侧，减少盲区。
- 连线增加圆角、端点箭头和更宽的命中区域，查看方向和点击选择更清晰。
- 输出端口位置改为使用节点实际测量宽度，避免多端口/动态端口节点在不同样式下连线起点偏移。
