from __future__ import annotations

import sys
import types
from pathlib import Path

import cv2
import numpy as np
from fastapi.testclient import TestClient

from backend.algorithms import yolo_ops
from backend.algorithms.types import ExecutionContext
from backend.main import app
from backend.models.workflow import WorkflowRequest
from backend.services.image_store import ImageStore
from backend.services.workflow_engine import run_workflow


class FakeBoxes:
    xyxy = np.array([[3.0, 4.0, 16.0, 18.0]], dtype=float)
    cls = np.array([0], dtype=float)
    conf = np.array([0.91], dtype=float)
    id = None


class FakeResult:
    names = {0: "defect"}
    boxes = FakeBoxes()
    masks = None
    keypoints = None
    obb = None
    probs = None
    speed = {"preprocess": 1.2, "inference": 3.4, "postprocess": 0.5}

    def __init__(self, image: np.ndarray) -> None:
        self._image = image

    def plot(self) -> np.ndarray:
        canvas = self._image.copy()
        cv2.rectangle(canvas, (3, 4), (16, 18), (0, 255, 0), 1)
        return canvas


class FakeYOLO:
    def __init__(self, model_path: str, task: str | None = None) -> None:
        self.model_path = model_path
        self.task = task

    def predict(self, **kwargs):
        assert kwargs["task"] == "detect"
        assert kwargs["source"].shape == (24, 32, 3)
        return [FakeResult(kwargs["source"])]


def _install_fake_ultralytics(monkeypatch) -> None:
    fake_module = types.SimpleNamespace(YOLO=FakeYOLO)
    monkeypatch.setitem(sys.modules, "ultralytics", fake_module)
    yolo_ops._MODEL_CACHE.clear()


def _make_store(tmp_path: Path) -> ImageStore:
    return ImageStore(tmp_path / "uploads", {".png", ".jpg", ".jpeg"}, path_base=tmp_path)


def test_yolo_operator_metadata_and_upload_endpoint(tmp_path: Path) -> None:
    client = TestClient(app)

    operators = client.get("/api/operators")
    assert operators.status_code == 200
    payload = operators.json()
    assert "YoloInfer" in payload["operators"]
    assert any(group["group"] == "AI推理" and "YoloInfer" in group["items"] for group in payload["catalog"]["图像"])
    assert payload["operators"]["YoloInfer"]["param_schema"]["model_path"]["type"] == "file"
    assert "class_indices" in payload["operators"]["YoloInfer"]["param_schema"]
    assert "0,1,8" in payload["operators"]["YoloInfer"]["param_schema"]["class_indices"]["placeholder"]

    response = client.post("/api/upload-model", files={"file": ("best.pt", b"fake model bytes", "application/octet-stream")})
    assert response.status_code == 200
    data = response.json()
    assert data["success"] is True
    assert data["model_path"].startswith("models/uploads/")
    assert data["model_path"].endswith("best.pt")


def test_yolo_detect_workflow_outputs_metrics_and_structured_data(tmp_path: Path, monkeypatch) -> None:
    _install_fake_ultralytics(monkeypatch)
    store = _make_store(tmp_path)

    model_path = tmp_path / "best.pt"
    model_path.write_bytes(b"fake model")

    image = np.full((24, 32, 3), 80, dtype=np.uint8)
    ok, encoded = cv2.imencode(".png", image)
    assert ok
    stored = store.save("part.png", encoded.tobytes())

    workflow = WorkflowRequest.model_validate(
        {
            "image_id": stored.image_id,
            "nodes": [
                {"id": "n1", "type": "ReadImage"},
                {
                    "id": "n2",
                    "type": "YoloInfer",
                    "params": {
                        "model_path": str(model_path),
                        "task": "detect",
                        "confidence": 0.2,
                        "iou": 0.5,
                        "imgsz": 640,
                        "max_det": 10,
                    },
                },
            ],
            "edges": [{"source": "n1", "target": "n2"}],
        }
    )

    result = run_workflow(workflow, store)
    preview = next(item for item in result["previews"] if item["node_id"] == "n2")

    assert preview["result_type"] == "image"
    assert preview["image"].startswith("data:image/png;base64,")
    assert preview["metrics"]["task"] == "detect"
    assert preview["metrics"]["result_count"] == 1
    assert preview["metrics"]["top_class"] == "defect"
    assert preview["metrics"]["top_confidence"] == 0.91
    assert preview["data"]["yolo"]["detections"][0]["box_xyxy"] == [3.0, 4.0, 16.0, 18.0]


def test_frontend_wires_model_file_upload_control() -> None:
    client = TestClient(app)
    api_js = client.get("/assets/js/api.js").text
    canvas_js = client.get("/assets/js/app/canvas.js").text
    app_js = client.get("/assets/js/app.js").text
    css = client.get("/assets/css/styles.css").text

    assert "function uploadModel(file)" in api_js
    assert 'request("/upload-model"' in api_js
    assert 'schema.type === "file"' in canvas_js
    assert "VisionApi.uploadModel(file)" in canvas_js
    assert "node-file-button" in canvas_js
    assert "YoloInfer" in app_js
    assert ".node-file-param" in css


def test_yolo_class_indices_are_passed_to_predict_and_filter_outputs(tmp_path: Path, monkeypatch) -> None:
    class MultiBoxes:
        xyxy = np.array([[0.0, 0.0, 10.0, 10.0], [10.0, 0.0, 20.0, 10.0], [0.0, 10.0, 10.0, 20.0]], dtype=float)
        cls = np.array([0, 1, 8], dtype=float)
        conf = np.array([0.40, 0.80, 0.90], dtype=float)
        id = None

    class MultiResult:
        names = {0: "person", 1: "bicycle", 8: "boat"}
        boxes = MultiBoxes()
        masks = None
        keypoints = None
        obb = None
        probs = None
        speed = {}

        def __init__(self, image: np.ndarray) -> None:
            self._image = image

        def plot(self) -> np.ndarray:
            return self._image.copy()

    class MultiYOLO:
        last_kwargs: dict[str, object] = {}

        def __init__(self, model_path: str, task: str | None = None) -> None:
            self.model_path = model_path
            self.task = task

        def predict(self, **kwargs):
            MultiYOLO.last_kwargs = kwargs
            return [MultiResult(kwargs["source"])]

    monkeypatch.setitem(sys.modules, "ultralytics", types.SimpleNamespace(YOLO=MultiYOLO))
    yolo_ops._MODEL_CACHE.clear()

    store = _make_store(tmp_path)
    model_path = tmp_path / "best.pt"
    model_path.write_bytes(b"fake model")
    image = np.full((24, 32, 3), 80, dtype=np.uint8)

    result = yolo_ops.op_yolo_infer(
        {"in": image, "in_color_space": "BGR"},
        {"model_path": str(model_path), "task": "detect", "class_indices": "0, 8", "confidence": 0.35},
        ExecutionContext(image_id=None, image_store=store),
    )

    assert MultiYOLO.last_kwargs["classes"] == [0, 8]
    assert [item["class_id"] for item in result["detections"]] == [0, 8]
    assert result["count"] == 2
    assert result["top_class"] == "boat"
    assert result["metrics"]["class_indices"] == [0, 8]
    assert result["data"]["yolo"]["class_indices"] == [0, 8]


def test_yolo_class_indices_reject_invalid_values() -> None:
    try:
        yolo_ops._parse_class_indices("0,abc,8")
    except ValueError as exc:
        assert "类别 index" in str(exc)
    else:
        raise AssertionError("invalid class index should raise ValueError")
