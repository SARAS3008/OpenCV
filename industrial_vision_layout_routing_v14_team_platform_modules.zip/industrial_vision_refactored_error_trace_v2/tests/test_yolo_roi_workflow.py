from __future__ import annotations

from pathlib import Path

import numpy as np

from backend.algorithms.metadata import OPERATOR_CATALOG, OPERATOR_META
from backend.algorithms.yolo_ops import _resolve_model_ref, op_roi_pair_edge_distance, op_yolo_select_top_detections
from backend.algorithms.types import ExecutionContext
from backend.services.image_store import ImageStore


def _context(tmp_path: Path) -> ExecutionContext:
    store = ImageStore(tmp_path / "uploads", {".png", ".jpg", ".jpeg"}, path_base=tmp_path)
    return ExecutionContext(image_id=None, image_store=store)


def test_yolov8n_alias_can_be_used_without_local_file(tmp_path: Path) -> None:
    model_ref, model_name, model_location = _resolve_model_ref("yolov8n.pt", _context(tmp_path))
    assert model_ref == "yolov8n.pt"
    assert model_name == "yolov8n.pt"
    assert model_location == "yolov8n.pt"


def test_yolo_selection_filters_top_two_by_confidence(tmp_path: Path) -> None:
    detections = [
        {"index": 0, "class_id": 1, "class_name": "a", "confidence": 0.36, "box_xyxy": [0, 0, 10, 10]},
        {"index": 1, "class_id": 2, "class_name": "b", "confidence": 0.91, "box_xyxy": [20, 0, 40, 20]},
        {"index": 2, "class_id": 3, "class_name": "c", "confidence": 0.12, "box_xyxy": [50, 0, 60, 10]},
        {"index": 3, "class_id": 4, "class_name": "d", "confidence": 0.62, "box_xyxy": [0, 30, 20, 50]},
    ]

    result = op_yolo_select_top_detections(
        {"detections": detections},
        {"min_confidence": 0.35, "top_k": 2, "sort_by": "CONFIDENCE_DESC", "require_exact_count": "YES"},
        _context(tmp_path),
    )

    assert result["count"] == 2
    assert [item["class_id"] for item in result["selected"]] == [2, 4]
    assert result["selected"][0]["center"] == [30.0, 10.0]
    assert result["metrics"]["selected_count"] == 2


def test_roi_pair_edge_distance_outputs_canvas_and_distance(tmp_path: Path) -> None:
    image = np.zeros((80, 100, 3), dtype=np.uint8)
    image[10:30, 10:30] = 255
    image[40:70, 60:90] = 180
    detections = [
        {"class_id": 1, "class_name": "target-a", "confidence": 0.88, "box_xyxy": [10, 10, 30, 30]},
        {"class_id": 2, "class_name": "target-b", "confidence": 0.77, "box_xyxy": [60, 40, 90, 70]},
    ]

    result = op_roi_pair_edge_distance(
        {"image": image, "image_color_space": "BGR", "detections": detections},
        {"threshold1": 50, "threshold2": 150, "aperture_size": 3, "padding": 2},
        _context(tmp_path),
    )

    assert result["out"].ndim == 3
    assert result["edge1"].ndim == 2
    assert result["edge2"].ndim == 2
    assert result["distance"] == 65.192024
    assert result["center1"] == [20.0, 20.0]
    assert result["center2"] == [75.0, 55.0]
    assert result["metrics"]["target1"]["edge_pixel_count"] > 0
    assert result["metrics"]["target2"]["edge_pixel_count"] > 0


def test_yolo_roi_nodes_are_in_operator_catalog() -> None:
    assert "YoloSelectTopDetections" in OPERATOR_META
    assert "RoiPairEdgeDistance" in OPERATOR_META
    ai_group = next(group for group in OPERATOR_CATALOG["图像"] if group["group"] == "AI推理")
    assert "YoloSelectTopDetections" in ai_group["items"]
    assert "RoiPairEdgeDistance" in ai_group["items"]


def test_yolo_selection_per_class_best_and_binary_masks(tmp_path: Path) -> None:
    image = np.zeros((40, 60, 3), dtype=np.uint8)
    detections = [
        {"index": 0, "class_id": 0, "class_name": "a", "confidence": 0.92, "box_xyxy": [2, 3, 12, 13], "image_shape": [40, 60]},
        {"index": 1, "class_id": 0, "class_name": "a", "confidence": 0.88, "box_xyxy": [20, 3, 30, 13], "image_shape": [40, 60]},
        {"index": 2, "class_id": 8, "class_name": "b", "confidence": 0.86, "box_xyxy": [30, 20, 50, 35], "image_shape": [40, 60]},
        {"index": 3, "class_id": 1, "class_name": "c", "confidence": 0.99, "box_xyxy": [0, 0, 5, 5], "image_shape": [40, 60]},
    ]

    result = op_yolo_select_top_detections(
        {"detections": detections, "image": image},
        {
            "selection_mode": "PER_CLASS_BEST",
            "class_indices": "0,8",
            "min_confidence": 0.85,
            "top_k": 2,
            "require_exact_count": "YES",
        },
        _context(tmp_path),
    )

    assert result["count"] == 2
    assert result["expected_count"] == 2
    assert result["missing_indices"] == []
    assert [item["class_id"] for item in result["selected"]] == [0, 8]
    assert result["selected"][0]["confidence"] == 0.92
    assert result["selected"][1]["confidence"] == 0.86
    assert result["mask"].shape == (40, 60)
    assert result["mask1"].dtype == np.uint8
    assert result["mask1_color_space"] == "GRAY"
    assert np.count_nonzero(result["mask1"]) == 100
    assert np.count_nonzero(result["mask2"]) == 300
    assert np.count_nonzero(result["mask"]) == 400


def test_yolo_selection_per_class_reports_missing_when_not_strict(tmp_path: Path) -> None:
    detections = [
        {"index": 0, "class_id": 0, "class_name": "a", "confidence": 0.84, "box_xyxy": [0, 0, 10, 10], "image_shape": [20, 20]},
        {"index": 1, "class_id": 8, "class_name": "b", "confidence": 0.91, "box_xyxy": [10, 10, 20, 20], "image_shape": [20, 20]},
    ]

    result = op_yolo_select_top_detections(
        {"detections": detections},
        {
            "selection_mode": "PER_CLASS_BEST",
            "class_indices": "0,8",
            "min_confidence": 0.85,
            "top_k": 2,
            "require_exact_count": "NO",
        },
        _context(tmp_path),
    )

    assert result["count"] == 1
    assert result["expected_count"] == 2
    assert result["missing_indices"] == [{"class_id": 0, "found": False, "best_confidence": 0.84, "reason": "below_threshold"}]
    assert [item["class_id"] for item in result["selected"]] == [8]
    assert result["mask"].shape == (20, 20)


def test_yolo_selection_per_class_missing_raises_when_strict(tmp_path: Path) -> None:
    detections = [
        {"index": 0, "class_id": 0, "class_name": "a", "confidence": 0.84, "box_xyxy": [0, 0, 10, 10], "image_shape": [20, 20]},
    ]

    try:
        op_yolo_select_top_detections(
            {"detections": detections},
            {
                "selection_mode": "PER_CLASS_BEST",
                "class_indices": "0,8",
                "min_confidence": 0.85,
                "top_k": 2,
                "require_exact_count": "YES",
            },
            _context(tmp_path),
        )
    except ValueError as exc:
        assert "未找到全部目标" in str(exc)
        assert "index=0" in str(exc)
        assert "index=8" in str(exc)
    else:
        raise AssertionError("strict per-class selection should fail on missing targets")


def test_yolo_selection_outputs_dynamic_mask_ports_for_expected_targets(tmp_path: Path) -> None:
    image = np.zeros((50, 80, 3), dtype=np.uint8)
    detections = []
    for class_id in range(5):
        x1 = class_id * 10
        detections.append(
            {
                "index": class_id,
                "class_id": class_id,
                "class_name": f"c{class_id}",
                "confidence": 0.9,
                "box_xyxy": [x1, 0, x1 + 5, 5],
                "image_shape": [50, 80],
            }
        )

    result = op_yolo_select_top_detections(
        {"detections": detections, "image": image},
        {
            "selection_mode": "PER_CLASS_BEST",
            "class_indices": "0,1,2,3,4",
            "min_confidence": 0.85,
            "top_k": 5,
            "require_exact_count": "YES",
        },
        _context(tmp_path),
    )

    assert result["count"] == 5
    assert result["metrics"]["mask_output_count"] == 5
    assert result["metrics"]["mask_ports"] == ["mask1", "mask2", "mask3", "mask4", "mask5"]
    assert "mask5" in result
    assert result["mask5_color_space"] == "GRAY"
    assert np.count_nonzero(result["mask5"]) == 25


def test_yolo_selection_missing_target_keeps_blank_mask_slot(tmp_path: Path) -> None:
    image = np.zeros((20, 30, 3), dtype=np.uint8)
    detections = [
        {"index": 0, "class_id": 0, "class_name": "a", "confidence": 0.8, "box_xyxy": [0, 0, 10, 10], "image_shape": [20, 30]},
        {"index": 1, "class_id": 8, "class_name": "b", "confidence": 0.91, "box_xyxy": [10, 0, 20, 10], "image_shape": [20, 30]},
        {"index": 2, "class_id": 1, "class_name": "c", "confidence": 0.92, "box_xyxy": [20, 0, 30, 10], "image_shape": [20, 30]},
    ]

    result = op_yolo_select_top_detections(
        {"detections": detections, "image": image},
        {
            "selection_mode": "PER_CLASS_BEST",
            "class_indices": "0,8,1",
            "min_confidence": 0.85,
            "top_k": 3,
            "require_exact_count": "NO",
        },
        _context(tmp_path),
    )

    assert result["count"] == 2
    assert result["expected_count"] == 3
    assert result["metrics"]["mask_ports"] == ["mask1", "mask2", "mask3"]
    assert np.count_nonzero(result["mask1"]) == 0
    assert np.count_nonzero(result["mask2"]) == 100
    assert np.count_nonzero(result["mask3"]) == 100
