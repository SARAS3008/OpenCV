from __future__ import annotations

import sys
import types
from pathlib import Path

import numpy as np
from fastapi.testclient import TestClient

from backend.algorithms.yolo.model_manager import YoloModelManager
from backend.algorithms.types import ExecutionContext
from backend.algorithms.yolo_ops import op_yolo_infer
from backend.main import app
from backend.services.image_store import ImageStore
from backend.services.project_store import ProjectStore


client = TestClient(app)


def test_project_api_saves_lists_loads_and_deletes_workflow() -> None:
    workflow = {
        "version": "2.1",
        "nodes": [{"id": "n1", "type": "ReadImage", "params": {"image_path": ""}}],
        "edges": [],
    }
    headers = {"X-User-Id": "pytest-user"}

    saved = client.post("/api/projects", json={"name": "检测项目A", "workflow": workflow}, headers=headers)
    assert saved.status_code == 200
    project = saved.json()["project"]
    assert project["project_id"]
    assert project["owner_id"] == "pytest-user"

    listed = client.get("/api/projects", headers=headers).json()["projects"]
    assert any(item["project_id"] == project["project_id"] and item["node_count"] == 1 for item in listed)

    loaded = client.get(f"/api/projects/{project['project_id']}", headers=headers)
    assert loaded.status_code == 200
    assert loaded.json()["project"]["workflow"]["nodes"][0]["type"] == "ReadImage"

    deleted = client.delete(f"/api/projects/{project['project_id']}", headers=headers)
    assert deleted.status_code == 200


def test_project_store_separates_users(tmp_path: Path) -> None:
    store = ProjectStore(tmp_path / "projects")
    workflow = {"nodes": [], "edges": []}
    project = store.save_project(workflow=workflow, owner_id="alice", name="Alice Project")
    assert store.list_projects("alice")[0]["project_id"] == project["project_id"]
    assert store.list_projects("bob") == []


def test_yolo_model_manager_caches_per_user_and_evicts_lru(tmp_path: Path, monkeypatch) -> None:
    class FakeYOLO:
        instances = 0

        def __init__(self, model_path: str, task: str | None = None) -> None:
            FakeYOLO.instances += 1
            self.model_path = model_path
            self.task = task

        def predict(self, **kwargs):  # pragma: no cover - not needed for cache assertion
            return []

    monkeypatch.setitem(sys.modules, "ultralytics", types.SimpleNamespace(YOLO=FakeYOLO))
    manager = YoloModelManager(tmp_path / "models", tmp_path / "models" / "models.json", max_items=2, ttl_seconds=0, path_base=tmp_path)
    model_a = tmp_path / "a.pt"
    model_b = tmp_path / "b.pt"
    model_c = tmp_path / "c.pt"
    for path in (model_a, model_b, model_c):
        path.write_bytes(b"fake")

    first = manager.load_model(model_a, "detect", user_id="alice")
    second = manager.load_model(model_a, "detect", user_id="alice")
    assert first is second
    assert FakeYOLO.instances == 1

    other_user = manager.load_model(model_a, "detect", user_id="bob")
    assert other_user is not first
    assert FakeYOLO.instances == 2

    manager.load_model(model_b, "detect", user_id="alice")
    manager.load_model(model_c, "detect", user_id="alice")
    stats = manager.stats()
    assert stats["cached_count"] <= 2


def test_yolo_operator_uses_context_model_manager(tmp_path: Path, monkeypatch) -> None:
    class EmptyResult:
        names = {}
        boxes = None
        masks = None
        keypoints = None
        obb = None
        probs = None
        speed = {}

        def __init__(self, image):
            self.image = image

        def plot(self):
            return self.image

    class FakeYOLO:
        def __init__(self, model_path: str, task: str | None = None) -> None:
            self.model_path = model_path
            self.task = task

        def predict(self, **kwargs):
            return [EmptyResult(kwargs["source"])]

    monkeypatch.setitem(sys.modules, "ultralytics", types.SimpleNamespace(YOLO=FakeYOLO))
    manager = YoloModelManager(tmp_path / "models", tmp_path / "models" / "models.json", max_items=4, ttl_seconds=0, path_base=tmp_path)
    store = ImageStore(tmp_path / "uploads", {".png", ".jpg"}, path_base=tmp_path)
    model_path = tmp_path / "best.pt"
    model_path.write_bytes(b"fake")
    image = np.zeros((12, 16, 3), dtype=np.uint8)

    result = op_yolo_infer(
        {"in": image, "in_color_space": "BGR"},
        {"model_path": str(model_path), "task": "detect"},
        ExecutionContext(image_id=None, image_store=store, user_id="operator-user", model_manager=manager),
    )

    assert result["metrics"]["result_count"] == 0
    assert manager.stats()["cached_count"] == 1
    assert manager.stats()["cached_models"][0]["user_id"] == "operator-user"
