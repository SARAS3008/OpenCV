# 工业视觉流程编辑器（分层重构版）

本项目由原来的单文件 `app.py` 重构而来，前端、通信层、FastAPI 路由、工作流调度和 OpenCV 算法已经分开维护。

## 启动

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS / Linux: source .venv/bin/activate
pip install -r requirements.txt
python run.py
```

浏览器打开 `http://127.0.0.1:8000`。

## 目录结构

```text
industrial_vision_refactored/
├── backend/
│   ├── api/                 # FastAPI 路由与依赖
│   ├── algorithms/          # OpenCV 算子、元数据、注册表
│   ├── models/              # Pydantic 请求模型
│   ├── services/            # 工作流执行、图片路径、算法脚本编译
│   ├── config.py
│   └── main.py
├── frontend/
│   ├── index.html
│   └── assets/
│       ├── css/styles.css
│       └── js/
│           ├── api.js       # 前后端通信层
│           └── app.js       # 页面和画布交互
├── tests/
├── uploads/                 # 仅用于兼容旧版上传 API
├── requirements.txt
└── run.py
```

## 导出纯算法脚本

完成编排后，点击左侧的 **“导出脚本”**，页面会下载：

```text
vision_algorithm.py
```

工作流只在服务端生成代码时用于确定执行顺序。导出的文件不会包含：

- 节点和连线数据；
- `WORKFLOW` JSON；
- 算子注册表；
- 拓扑排序；
- 工作流解释器；
- FastAPI 或本项目模块引用。

导出结果会被编译为普通的顺序 OpenCV 代码，例如：

```python
image = read_image(input_path)
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
blurred = cv2.GaussianBlur(gray, (5, 5), 0)
result = cv2.Canny(blurred, 50, 150)
save_image(output_path, result)
```

实际文件会提供一个可复用的算法函数：

```python
def run_algorithm(input_image):
    ...
    return result
```

在新的环境中只需：

```bash
pip install opencv-python numpy
python vision_algorithm.py --input input.png --output result.png
```

也可以把 `vision_algorithm.py` 当作普通模块导入，直接调用 `run_algorithm()`。

脚本生成器位于：

```text
backend/services/script_exporter.py
```

它使用 Python AST 创建算法函数和命令行入口，并在返回脚本前再次调用 `compile()` 做语法校验。

## ReadImage 图片路径

新版前端不再提供全局图片上传按钮。创建或选中“读取图像”节点后，在右侧“参数 / 状态”区域填写 `image_path`。

```text
绝对路径示例：D:\images\part.png
相对路径示例：samples/part.png
```

相对路径以项目根目录为基准。路径指向的是**运行 FastAPI 后端的计算机**上的文件，而不是浏览器所在客户端的文件。浏览器出于安全限制无法提供客户端文件的真实绝对路径。

`POST /api/upload` 和旧工作流的 `image_id` 仍保留后端兼容，但新版页面不会使用它们。部署到公网前，应根据业务需要限制允许读取的目录。

## 统一颜色转换算子

节点库不再分别显示“灰度化”和“BGR 转 RGB”，统一使用 `ColorConvert`：

```json
{"mode": "GRAY"}
```

或：

```json
{"mode": "RGB"}
```

右侧参数面板会把 `mode` 显示为下拉选项。导入旧工作流时，前端会自动迁移：

- `Gray` → `ColorConvert(mode=GRAY)`
- `BGR2RGB` → `ColorConvert(mode=RGB)`

后端仍保留两个旧类型的隐藏兼容入口，但它们不会出现在节点目录中。

## 各层职责

- `frontend/assets/js/app.js`：页面状态、节点绘制、参数编辑、脚本下载和旧流程迁移。
- `frontend/assets/js/api.js`：封装算子查询、流程运行和脚本导出请求。
- `backend/api/routes/`：HTTP 输入输出。
- `backend/services/workflow_engine.py`：拓扑排序、节点调度、颜色空间传递和预览组装。
- `backend/services/script_exporter.py`：将编排结果编译成不含工作流运行时的独立算法代码。
- `backend/algorithms/image_ops.py`：OpenCV 算法实现。
- `backend/algorithms/registry.py`：算子注册。
- `backend/algorithms/metadata.py`：节点名称、目录、默认参数及参数控件描述。
- `backend/services/image_store.py`：服务器图片路径解析、Unicode 路径读取和旧上传兼容。

## API

- `GET /api/operators`
- `POST /api/run`
- `POST /api/export-script`
- `POST /api/upload`：仅保留旧版兼容

## 新增算子

1. 在 `backend/algorithms/image_ops.py` 编写函数。
2. 在 `backend/algorithms/registry.py` 注册。
3. 在 `backend/algorithms/metadata.py` 添加元数据和参数界面描述。
4. 在 `backend/services/script_exporter.py` 添加对应的 AST 编译规则。
5. 在 `tests/` 中补充执行和导出测试。
