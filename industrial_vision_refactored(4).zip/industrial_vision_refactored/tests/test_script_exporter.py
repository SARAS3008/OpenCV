from pathlib import Path
import subprocess
import sys

import cv2
import numpy as np
from fastapi.testclient import TestClient

from backend.main import app
from backend.models.workflow import WorkflowRequest
from backend.services.script_exporter import generate_algorithm_script


client = TestClient(app)


def sample_workflow() -> WorkflowRequest:
    return WorkflowRequest.model_validate(
        {
            "nodes": [
                {"id": "n1", "type": "ReadImage", "params": {"image_path": "missing-default.png"}},
                {"id": "n2", "type": "ColorConvert", "params": {"mode": "GRAY"}},
                {"id": "n3", "type": "GaussianBlur", "params": {"ksize": 5, "sigma": 0}},
                {"id": "n4", "type": "Canny", "params": {"threshold1": 20, "threshold2": 80}},
                {"id": "n5", "type": "Display", "params": {}},
            ],
            "edges": [
                {"source": "n1", "target": "n2"},
                {"source": "n2", "target": "n3"},
                {"source": "n3", "target": "n4"},
                {"source": "n4", "target": "n5"},
            ],
        }
    )


def test_generated_script_is_flat_algorithm_code() -> None:
    source = generate_algorithm_script(sample_workflow())
    compile(source, "vision_algorithm.py", "exec")

    assert "from backend" not in source
    assert "WORKFLOW =" not in source
    assert "OPERATORS =" not in source
    assert "topological_sort" not in source
    assert "run_workflow" not in source
    assert '"nodes"' not in source
    assert '"edges"' not in source
    assert "def run_algorithm(input_image):" in source
    assert "cv2.cvtColor" in source
    assert "cv2.GaussianBlur" in source
    assert "cv2.Canny" in source
    assert "def op_canny" not in source
    assert "pip install opencv-python numpy" in source


def test_generated_algorithm_runs_in_separate_directory(tmp_path: Path) -> None:
    script_path = tmp_path / "vision_algorithm.py"
    script_path.write_text(generate_algorithm_script(sample_workflow()), encoding="utf-8")

    image = np.zeros((64, 96, 3), dtype=np.uint8)
    cv2.rectangle(image, (20, 15), (75, 50), (255, 255, 255), -1)
    input_path = tmp_path / "input.png"
    output_path = tmp_path / "result.png"
    assert cv2.imwrite(str(input_path), image)

    result = subprocess.run(
        [
            sys.executable,
            str(script_path),
            "--input",
            str(input_path),
            "--output",
            str(output_path),
        ],
        cwd=tmp_path,
        capture_output=True,
        text=True,
        timeout=30,
        check=False,
        env={"PATH": str(Path(sys.executable).parent)},
    )

    assert result.returncode == 0, result.stderr
    assert output_path.is_file()
    output = cv2.imread(str(output_path), cv2.IMREAD_UNCHANGED)
    assert output is not None
    assert output.ndim == 2
    assert "已保存" in result.stdout


def test_export_script_api_returns_algorithm_attachment() -> None:
    response = client.post("/api/export-script", json=sample_workflow().model_dump())
    assert response.status_code == 200
    assert response.headers["content-type"].startswith("text/x-python")
    assert "vision_algorithm.py" in response.headers["content-disposition"]
    assert "def run_algorithm" in response.text
    assert "WORKFLOW =" not in response.text


def test_frontend_exposes_export_script_button_and_api() -> None:
    html = client.get("/").text
    app_js = client.get("/assets/js/app.js").text
    api_js = client.get("/assets/js/api.js").text

    assert 'id="exportScriptButton"' in html
    assert "导出脚本" in html
    assert "纯 OpenCV 算法程序" in html
    assert "function exportAlgorithmScript()" in app_js
    assert "vision_algorithm.py" in app_js
    assert "exportScriptButton" in app_js
    assert 'request("/export-script"' not in api_js  # blob 响应使用专用 fetch
    assert "async function exportScript(workflow)" in api_js
    assert "vision_algorithm.py" in api_js
