import base64
from pathlib import Path

import cv2
import numpy as np

from backend.models.workflow import WorkflowRequest
from backend.services.image_store import ImageStore
from backend.services.workflow_engine import run_workflow, topological_sort


def make_store(tmp_path: Path) -> ImageStore:
    return ImageStore(
        upload_dir=tmp_path / "uploads",
        allowed_extensions={".png", ".jpg", ".jpeg"},
        path_base=tmp_path,
    )


def write_sample(path: Path) -> None:
    image = np.zeros((40, 60, 3), dtype=np.uint8)
    image[:, :] = (0, 0, 255)  # OpenCV BGR 中的红色
    assert cv2.imwrite(str(path), image)


def decode_preview(data_url: str) -> np.ndarray:
    encoded = data_url.split(",", 1)[1]
    buffer = np.frombuffer(base64.b64decode(encoded), dtype=np.uint8)
    decoded = cv2.imdecode(buffer, cv2.IMREAD_UNCHANGED)
    assert decoded is not None
    return decoded


def test_path_based_demo_workflow_executes(tmp_path: Path) -> None:
    store = make_store(tmp_path)
    write_sample(tmp_path / "sample.png")

    workflow = WorkflowRequest.model_validate(
        {
            "nodes": [
                {"id": "n1", "type": "ReadImage", "params": {"image_path": "sample.png"}},
                {"id": "n2", "type": "ColorConvert", "params": {"mode": "GRAY"}},
                {"id": "n3", "type": "Canny", "params": {"threshold1": 50, "threshold2": 150}},
            ],
            "edges": [
                {"source": "n1", "target": "n2"},
                {"source": "n2", "target": "n3"},
            ],
        }
    )

    result = run_workflow(workflow, store)
    assert result["success"] is True
    assert result["order"] == ["n1", "n2", "n3"]
    assert len(result["previews"]) == 3
    assert decode_preview(result["previews"][1]["image"]).ndim == 2


def test_color_convert_rgb_preview_keeps_correct_channel_order(tmp_path: Path) -> None:
    store = make_store(tmp_path)
    write_sample(tmp_path / "red.png")
    workflow = WorkflowRequest.model_validate(
        {
            "nodes": [
                {"id": "n1", "type": "ReadImage", "params": {"image_path": str(tmp_path / "red.png")}},
                {"id": "n2", "type": "ColorConvert", "params": {"mode": "RGB"}},
                {"id": "n3", "type": "Display"},
            ],
            "edges": [
                {"source": "n1", "target": "n2"},
                {"source": "n2", "target": "n3"},
            ],
        }
    )

    result = run_workflow(workflow, store)
    preview = decode_preview(result["previews"][2]["image"])
    assert tuple(int(value) for value in preview[0, 0]) == (0, 0, 255)


def test_legacy_uploaded_image_id_still_executes(tmp_path: Path) -> None:
    store = make_store(tmp_path)
    ok, encoded = cv2.imencode(".png", np.full((20, 30, 3), 128, dtype=np.uint8))
    assert ok
    stored = store.save("legacy.png", encoded.tobytes())

    workflow = WorkflowRequest.model_validate(
        {
            "image_id": stored.image_id,
            "nodes": [
                {"id": "n1", "type": "ReadImage"},
                {"id": "n2", "type": "Gray"},
            ],
            "edges": [{"source": "n1", "target": "n2"}],
        }
    )
    result = run_workflow(workflow, store)
    assert result["success"] is True
    assert len(result["previews"]) == 2


def test_missing_read_image_path_is_rejected(tmp_path: Path) -> None:
    store = make_store(tmp_path)
    workflow = WorkflowRequest.model_validate(
        {"nodes": [{"id": "n1", "type": "ReadImage", "params": {"image_path": "missing.png"}}]}
    )
    try:
        run_workflow(workflow, store)
    except ValueError as exc:
        assert "图片路径不存在" in str(exc)
    else:
        raise AssertionError("应当拒绝不存在的图片路径")


def test_cycle_is_rejected() -> None:
    workflow = WorkflowRequest.model_validate(
        {
            "nodes": [
                {"id": "n1", "type": "ColorConvert"},
                {"id": "n2", "type": "Canny"},
            ],
            "edges": [
                {"source": "n1", "target": "n2"},
                {"source": "n2", "target": "n1"},
            ],
        }
    )
    try:
        topological_sort(workflow.nodes, workflow.edges)
    except ValueError as exc:
        assert "存在环" in str(exc)
    else:
        raise AssertionError("应当拒绝环形流程")
