from fastapi.testclient import TestClient

from backend.main import app


client = TestClient(app)


def test_node_library_and_path_parameter_ui() -> None:
    response = client.get("/")
    assert response.status_code == 200

    html = response.text
    assert 'id="nodeLibraryToggle"' in html
    assert 'aria-controls="nodeLibrary"' in html
    assert 'id="nodeLibrary"' in html
    assert 'id="imageInput"' not in html
    assert 'id="imageUploadText"' not in html

    node_library = html.split('<aside id="nodeLibrary"', 1)[1].split("</aside>", 1)[0]
    assert 'id="operatorPanel"' in node_library
    assert "upload-box" not in node_library
    assert "category-tabs" not in node_library


def test_frontend_assets_use_node_parameters_instead_of_upload() -> None:
    js = client.get("/assets/js/app.js")
    api_js = client.get("/assets/js/api.js")
    css = client.get("/assets/css/styles.css")

    assert js.status_code == 200
    assert api_js.status_code == 200
    assert css.status_code == 200
    assert "function toggleNodeLibrary()" in js.text
    assert "nodes-panel-hidden" in js.text
    assert "param_schema" in js.text
    assert "migrateWorkflowNode" in js.text
    assert "type:'ColorConvert'" in js.text
    assert "imageInput" not in js.text
    assert "uploadImage" not in api_js.text
    assert ".main.nodes-panel-hidden" in css.text
    assert ".param-row select" in css.text


def test_operator_catalog_exposes_one_color_convert_operator() -> None:
    response = client.get("/api/operators")
    assert response.status_code == 200
    data = response.json()

    color_group = next(
        group for group in data["catalog"]["图像"] if group["group"] == "颜色与增强"
    )
    assert "ColorConvert" in color_group["items"]
    assert "Gray" not in color_group["items"]
    assert "BGR2RGB" not in color_group["items"]

    read_meta = data["operators"]["ReadImage"]
    assert read_meta["params"] == {"image_path": ""}
    assert read_meta["param_schema"]["image_path"]["type"] == "text"

    convert_meta = data["operators"]["ColorConvert"]
    assert convert_meta["params"] == {"mode": "GRAY"}
    assert [item["value"] for item in convert_meta["param_schema"]["mode"]["options"]] == [
        "GRAY",
        "RGB",
    ]
