from __future__ import annotations

import base64
from collections import defaultdict, deque
from typing import Any

import cv2
import numpy as np

from backend.algorithms.registry import OPERATORS, OPERATOR_META
from backend.algorithms.types import ExecutionContext
from backend.models.workflow import WorkflowEdge, WorkflowNode, WorkflowRequest
from backend.services.image_store import ImageStore


def image_to_data_url(image: np.ndarray, color_space: str = "BGR") -> str:
    if image is None:
        return ""
    if image.dtype != np.uint8:
        image = np.clip(image, 0, 255).astype(np.uint8)
    encode_image = image
    if image.ndim == 3 and str(color_space).upper() == "RGB":
        encode_image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
    ok, buffer = cv2.imencode(".png", encode_image)
    if not ok:
        raise ValueError("图像编码失败")
    encoded = base64.b64encode(buffer).decode("utf-8")
    return f"data:image/png;base64,{encoded}"


def topological_sort(nodes: list[WorkflowNode], edges: list[WorkflowEdge]) -> list[str]:
    node_ids = [node.id for node in nodes]
    if len(node_ids) != len(set(node_ids)):
        raise ValueError("节点 ID 不能重复")

    node_set = set(node_ids)
    indegree = {node_id: 0 for node_id in node_ids}
    graph: dict[str, list[str]] = {node_id: [] for node_id in node_ids}

    for edge in edges:
        if edge.source not in node_set or edge.target not in node_set:
            raise ValueError("存在无效连线：source 或 target 节点不存在")
        graph[edge.source].append(edge.target)
        indegree[edge.target] += 1

    queue = deque(node_id for node_id in node_ids if indegree[node_id] == 0)
    order: list[str] = []
    while queue:
        node_id = queue.popleft()
        order.append(node_id)
        for target_id in graph[node_id]:
            indegree[target_id] -= 1
            if indegree[target_id] == 0:
                queue.append(target_id)

    if len(order) != len(node_ids):
        raise ValueError("流程中存在环，请检查节点连线")
    return order


def run_workflow(workflow: WorkflowRequest, image_store: ImageStore) -> dict[str, Any]:
    if not workflow.nodes:
        raise ValueError("流程为空，请先添加节点")

    order = topological_sort(workflow.nodes, workflow.edges)
    nodes = {node.id: node for node in workflow.nodes}
    incoming: dict[str, list[WorkflowEdge]] = defaultdict(list)
    for edge in workflow.edges:
        incoming[edge.target].append(edge)

    context = ExecutionContext(image_id=workflow.image_id, image_store=image_store)
    outputs: dict[str, dict[str, Any]] = {}
    previews: list[dict[str, Any]] = []

    for node_id in order:
        node = nodes[node_id]
        operator = OPERATORS.get(node.type)
        metadata = OPERATOR_META.get(node.type, {})
        if operator is None:
            raise ValueError(f"未知算子或尚未实现：{node.type}")

        inputs: dict[str, Any] = {}
        for edge in incoming[node_id]:
            if edge.source not in outputs:
                raise ValueError(f"节点 {node_id} 的上游 {edge.source} 尚未执行")
            source_output = outputs[edge.source]
            if edge.sourceHandle not in source_output:
                raise ValueError(
                    f"节点 {edge.source} 不存在输出端口：{edge.sourceHandle}"
                )
            inputs[edge.targetHandle] = source_output[edge.sourceHandle]
            source_color_key = f"{edge.sourceHandle}_color_space"
            if source_color_key in source_output:
                inputs[f"{edge.targetHandle}_color_space"] = source_output[source_color_key]

        if metadata.get("has_input", True) and "in" not in inputs:
            raise ValueError(f"节点 {node_id}（{node.type}）缺少输入连线")

        result = operator(inputs, node.params, context)
        out_image = result.get("out")
        if isinstance(out_image, np.ndarray) and "out_color_space" not in result:
            if out_image.ndim == 2:
                result["out_color_space"] = "GRAY"
            else:
                result["out_color_space"] = inputs.get("in_color_space", "BGR")
        outputs[node_id] = result
        previews.append(
            {
                "node_id": node_id,
                "type": node.type,
                "label": metadata.get("label", node.type),
                "image": image_to_data_url(result.get("out"), result.get("out_color_space", "BGR")),
            }
        )

    return {"success": True, "previews": previews, "order": order}
