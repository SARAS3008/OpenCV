from __future__ import annotations

import ast
import re
from collections import defaultdict
from copy import deepcopy
from dataclasses import dataclass
from typing import Any

from backend.models.workflow import WorkflowRequest
from backend.services.workflow_engine import topological_sort

SUPPORTED_OPERATORS = {
    "Display",
    "ColorConvert",
    "Gray",
    "BGR2RGB",
    "Invert",
    "Normalize",
    "EqualizeHist",
    "CLAHE",
    "MeanBlur",
    "GaussianBlur",
    "MedianBlur",
    "BilateralFilter",
    "Sharpen",
    "Threshold",
    "OtsuThreshold",
    "AdaptiveThreshold",
    "Canny",
    "Sobel",
    "Laplacian",
    "Erode",
    "Dilate",
    "MorphOpen",
    "MorphClose",
    "MorphGradient",
    "Resize",
    "Flip",
    "Rotate90",
    "FindContours",
}

_STEP_NAMES = {
    "ReadImage": "input",
    "Display": "result",
    "ColorConvert": "color",
    "Invert": "invert",
    "Normalize": "normalize",
    "EqualizeHist": "equalized",
    "CLAHE": "clahe",
    "MeanBlur": "mean_blur",
    "GaussianBlur": "gaussian_blur",
    "MedianBlur": "median_blur",
    "BilateralFilter": "bilateral",
    "Sharpen": "sharpen",
    "Threshold": "threshold",
    "OtsuThreshold": "otsu",
    "AdaptiveThreshold": "adaptive_threshold",
    "Canny": "canny",
    "Sobel": "sobel",
    "Laplacian": "laplacian",
    "Erode": "erode",
    "Dilate": "dilate",
    "MorphOpen": "morph_open",
    "MorphClose": "morph_close",
    "MorphGradient": "morph_gradient",
    "Resize": "resize",
    "Flip": "flip",
    "Rotate90": "rotate",
    "FindContours": "contours",
}

_BASE_SOURCE = r'''
import argparse
from pathlib import Path

import cv2
import numpy as np


def read_image(path_value):
    """读取图片，兼容包含中文的 Windows 路径。"""
    if not path_value:
        raise ValueError("请通过命令行参数指定输入图片")
    path = Path(path_value).expanduser()
    if not path.is_absolute():
        path = (Path(__file__).resolve().parent / path).resolve()
    if not path.is_file():
        raise FileNotFoundError(f"输入图片不存在：{path}")
    encoded = np.fromfile(str(path), dtype=np.uint8)
    image = cv2.imdecode(encoded, cv2.IMREAD_COLOR)
    if image is None:
        raise ValueError(f"OpenCV 无法读取图片：{path}")
    return image


def ensure_bgr(image, color_space="BGR"):
    if image is None:
        raise ValueError("输入图像为空")
    if image.ndim == 2:
        return cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
    if str(color_space).upper() == "RGB":
        return cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
    return image


def save_image(path_value, image, color_space="BGR"):
    """保存算法结果，RGB 图像会先转换为 OpenCV 使用的 BGR 顺序。"""
    path = Path(path_value).expanduser()
    if not path.is_absolute():
        path = (Path.cwd() / path).resolve()
    if not path.suffix:
        path = path.with_suffix(".png")
    if path.suffix.lower() not in {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff", ".webp"}:
        path = path.with_suffix(".png")
    path.parent.mkdir(parents=True, exist_ok=True)
    output = ensure_bgr(image, color_space) if image.ndim == 3 else image
    ok, encoded = cv2.imencode(path.suffix, output)
    if not ok:
        raise ValueError(f"图像编码失败：{path}")
    encoded.tofile(str(path))
    return path
'''


@dataclass(frozen=True)
class InputSpec:
    node_id: str
    argument_name: str
    cli_option: str
    default_path: str


@dataclass
class CompileState:
    statements: list[ast.stmt]
    variable_by_node: dict[str, str]
    color_by_node: dict[str, str]


def _to_int(value: Any, default: int) -> int:
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return default


def _to_float(value: Any, default: float) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _ensure_odd(value: Any, default: int = 3, minimum: int = 1) -> int:
    number = max(minimum, _to_int(value, default))
    return number + 1 if number % 2 == 0 else number


def _normalize_node_type(node_type: str, params: dict[str, Any]) -> tuple[str, dict[str, Any]]:
    normalized = deepcopy(params)
    if node_type == "Gray":
        normalized["mode"] = "GRAY"
        return "ColorConvert", normalized
    if node_type == "BGR2RGB":
        normalized["mode"] = "RGB"
        return "ColorConvert", normalized
    return node_type, normalized


def _expr(source: str) -> ast.expr:
    return ast.parse(source, mode="eval").body


def _statements(source: str) -> list[ast.stmt]:
    return ast.parse(source).body


def _assign(name: str, expression: ast.expr) -> ast.Assign:
    return ast.Assign(targets=[ast.Name(id=name, ctx=ast.Store())], value=expression)


def _semantic_variable(index: int, node_type: str, params: dict[str, Any]) -> str:
    suffix = _STEP_NAMES.get(node_type, re.sub(r"\W+", "_", node_type).lower())
    if node_type == "ColorConvert":
        suffix = "gray" if str(params.get("mode", "GRAY")).upper() == "GRAY" else "rgb"
    return f"step_{index:02d}_{suffix}"


def _gray_expression(source_var: str, color_space: str) -> ast.expr:
    if color_space == "GRAY":
        return ast.Name(id=source_var, ctx=ast.Load())
    conversion = "cv2.COLOR_RGB2GRAY" if color_space == "RGB" else "cv2.COLOR_BGR2GRAY"
    return _expr(f"cv2.cvtColor({source_var}, {conversion})")


def _bgr_expression(source_var: str, color_space: str) -> ast.expr:
    if color_space == "BGR":
        return ast.Name(id=source_var, ctx=ast.Load())
    if color_space == "GRAY":
        return _expr(f"cv2.cvtColor({source_var}, cv2.COLOR_GRAY2BGR)")
    return _expr(f"cv2.cvtColor({source_var}, cv2.COLOR_RGB2BGR)")


def _compile_operator(
    *,
    index: int,
    node_type: str,
    params: dict[str, Any],
    source_var: str,
    source_color: str,
    output_var: str,
) -> tuple[list[ast.stmt], str]:
    if node_type == "Display":
        return [_assign(output_var, ast.Name(id=source_var, ctx=ast.Load()))], source_color

    if node_type == "ColorConvert":
        mode = str(params.get("mode", "GRAY")).strip().upper()
        if mode == "GRAY":
            return [_assign(output_var, _gray_expression(source_var, source_color))], "GRAY"
        if mode == "RGB":
            if source_color == "RGB":
                expression = _expr(f"{source_var}.copy()")
            elif source_color == "GRAY":
                expression = _expr(f"cv2.cvtColor({source_var}, cv2.COLOR_GRAY2RGB)")
            else:
                expression = _expr(f"cv2.cvtColor({source_var}, cv2.COLOR_BGR2RGB)")
            return [_assign(output_var, expression)], "RGB"
        raise ValueError(f"颜色转换仅支持 GRAY 或 RGB，收到：{mode}")

    if node_type == "Invert":
        return [_assign(output_var, _expr(f"cv2.bitwise_not({source_var})"))], source_color

    if node_type == "Normalize":
        expression = _expr(
            f"cv2.normalize({source_var}, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)"
        )
        return [_assign(output_var, expression)], source_color

    if node_type == "EqualizeHist":
        return [_assign(output_var, _expr(f"cv2.equalizeHist({ast.unparse(_gray_expression(source_var, source_color))})"))], "GRAY"

    if node_type == "CLAHE":
        clip_limit = _to_float(params.get("clip_limit", 2.0), 2.0)
        tile_grid = max(1, _to_int(params.get("tile_grid", 8), 8))
        clahe_var = f"clahe_{index:02d}"
        gray_source = ast.unparse(_gray_expression(source_var, source_color))
        code = (
            f"{clahe_var} = cv2.createCLAHE(clipLimit={clip_limit!r}, "
            f"tileGridSize=({tile_grid}, {tile_grid}))\n"
            f"{output_var} = {clahe_var}.apply({gray_source})"
        )
        return _statements(code), "GRAY"

    if node_type in {"MeanBlur", "GaussianBlur", "MedianBlur"}:
        default = 5
        ksize = _ensure_odd(params.get("ksize", default), default)
        if node_type == "MeanBlur":
            expression = _expr(f"cv2.blur({source_var}, ({ksize}, {ksize}))")
        elif node_type == "GaussianBlur":
            sigma = _to_float(params.get("sigma", 0), 0.0)
            expression = _expr(
                f"cv2.GaussianBlur({source_var}, ({ksize}, {ksize}), {sigma!r})"
            )
        else:
            expression = _expr(f"cv2.medianBlur({source_var}, {ksize})")
        return [_assign(output_var, expression)], source_color

    if node_type == "BilateralFilter":
        diameter = _to_int(params.get("d", 7), 7)
        sigma_color = _to_float(params.get("sigma_color", 75), 75.0)
        sigma_space = _to_float(params.get("sigma_space", 75), 75.0)
        expression = _expr(
            f"cv2.bilateralFilter({source_var}, {diameter}, {sigma_color!r}, {sigma_space!r})"
        )
        return [_assign(output_var, expression)], source_color

    if node_type == "Sharpen":
        amount = _to_float(params.get("amount", 1.0), 1.0)
        kernel_var = f"sharpen_kernel_{index:02d}"
        code = (
            f"{kernel_var} = np.array([[0, -1, 0], [-1, {4 + amount!r}, -1], "
            f"[0, -1, 0]], dtype=np.float32)\n"
            f"{output_var} = cv2.filter2D({source_var}, -1, {kernel_var})"
        )
        return _statements(code), source_color

    if node_type in {"Threshold", "OtsuThreshold", "AdaptiveThreshold", "Canny", "Sobel", "Laplacian"}:
        gray_source = ast.unparse(_gray_expression(source_var, source_color))
        if node_type == "Threshold":
            threshold = _to_int(params.get("threshold", 127), 127)
            max_value = _to_int(params.get("max_value", 255), 255)
            code = f"_, {output_var} = cv2.threshold({gray_source}, {threshold}, {max_value}, cv2.THRESH_BINARY)"
        elif node_type == "OtsuThreshold":
            code = f"_, {output_var} = cv2.threshold({gray_source}, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)"
        elif node_type == "AdaptiveThreshold":
            block_size = _ensure_odd(params.get("block_size", 11), 11, 3)
            c_value = _to_int(params.get("c", 2), 2)
            code = (
                f"{output_var} = cv2.adaptiveThreshold({gray_source}, 255, "
                f"cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, {block_size}, {c_value})"
            )
        elif node_type == "Canny":
            threshold1 = _to_int(params.get("threshold1", 50), 50)
            threshold2 = _to_int(params.get("threshold2", 150), 150)
            code = f"{output_var} = cv2.Canny({gray_source}, {threshold1}, {threshold2})"
        elif node_type == "Sobel":
            dx = _to_int(params.get("dx", 1), 1)
            dy = _to_int(params.get("dy", 0), 0)
            ksize = _ensure_odd(params.get("ksize", 3), 3, 1)
            gradient_var = f"sobel_gradient_{index:02d}"
            code = (
                f"{gradient_var} = cv2.Sobel({gray_source}, cv2.CV_16S, {dx}, {dy}, ksize={ksize})\n"
                f"{output_var} = cv2.convertScaleAbs({gradient_var})"
            )
        else:
            ksize = _ensure_odd(params.get("ksize", 3), 3, 1)
            laplacian_var = f"laplacian_raw_{index:02d}"
            code = (
                f"{laplacian_var} = cv2.Laplacian({gray_source}, cv2.CV_16S, ksize={ksize})\n"
                f"{output_var} = cv2.convertScaleAbs({laplacian_var})"
            )
        return _statements(code), "GRAY"

    if node_type in {"Erode", "Dilate", "MorphOpen", "MorphClose", "MorphGradient"}:
        ksize = _ensure_odd(params.get("ksize", 3), 3, 1)
        kernel_var = f"morph_kernel_{index:02d}"
        lines = [f"{kernel_var} = np.ones(({ksize}, {ksize}), dtype=np.uint8)"]
        if node_type == "Erode":
            iterations = max(1, _to_int(params.get("iterations", 1), 1))
            lines.append(
                f"{output_var} = cv2.erode({source_var}, {kernel_var}, iterations={iterations})"
            )
        elif node_type == "Dilate":
            iterations = max(1, _to_int(params.get("iterations", 1), 1))
            lines.append(
                f"{output_var} = cv2.dilate({source_var}, {kernel_var}, iterations={iterations})"
            )
        else:
            operation = {
                "MorphOpen": "cv2.MORPH_OPEN",
                "MorphClose": "cv2.MORPH_CLOSE",
                "MorphGradient": "cv2.MORPH_GRADIENT",
            }[node_type]
            lines.append(
                f"{output_var} = cv2.morphologyEx({source_var}, {operation}, {kernel_var})"
            )
        return _statements("\n".join(lines)), source_color

    if node_type == "Resize":
        scale = max(_to_float(params.get("scale_percent", 50), 50.0), 1.0)
        expression = _expr(
            f"cv2.resize({source_var}, "
            f"(max(1, int({source_var}.shape[1] * {scale!r} / 100.0)), "
            f"max(1, int({source_var}.shape[0] * {scale!r} / 100.0))), "
            f"interpolation=cv2.INTER_AREA)"
        )
        return [_assign(output_var, expression)], source_color

    if node_type == "Flip":
        flip_code = _to_int(params.get("flip_code", 1), 1)
        if flip_code not in {-1, 0, 1}:
            flip_code = 1
        return [_assign(output_var, _expr(f"cv2.flip({source_var}, {flip_code})"))], source_color

    if node_type == "Rotate90":
        direction = _to_int(params.get("direction", 0), 0)
        rotate_code = {
            1: "cv2.ROTATE_90_COUNTERCLOCKWISE",
            2: "cv2.ROTATE_180",
        }.get(direction, "cv2.ROTATE_90_CLOCKWISE")
        return [_assign(output_var, _expr(f"cv2.rotate({source_var}, {rotate_code})"))], source_color

    if node_type == "FindContours":
        threshold = _to_int(params.get("threshold", 127), 127)
        min_area = _to_float(params.get("min_area", 20), 20.0)
        gray_var = f"contour_gray_{index:02d}"
        binary_var = f"contour_binary_{index:02d}"
        contours_var = f"contours_{index:02d}"
        count_var = f"contour_count_{index:02d}"
        gray_source = ast.unparse(_gray_expression(source_var, source_color))
        bgr_source = ast.unparse(_bgr_expression(source_var, source_color))
        code = f'''{gray_var} = {gray_source}
_, {binary_var} = cv2.threshold({gray_var}, {threshold}, 255, cv2.THRESH_BINARY)
{contours_var}, _ = cv2.findContours({binary_var}, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
{output_var} = {bgr_source}.copy()
{count_var} = 0
for contour in {contours_var}:
    if cv2.contourArea(contour) < {min_area!r}:
        continue
    cv2.drawContours({output_var}, [contour], -1, (0, 255, 0), 2)
    x, y, width, height = cv2.boundingRect(contour)
    cv2.rectangle({output_var}, (x, y), (x + width, y + height), (0, 180, 255), 1)
    {count_var} += 1
cv2.putText({output_var}, f"contours: {{{count_var}}}", (12, 28), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 220, 255), 2)'''
        return _statements(code), "BGR"

    raise ValueError(f"算子暂不支持导出为算法脚本：{node_type}")


def _validate_and_prepare(workflow: WorkflowRequest) -> tuple[
    list[str],
    dict[str, tuple[str, dict[str, Any]]],
    dict[str, list[str]],
    list[str],
]:
    if not workflow.nodes:
        raise ValueError("流程为空，无法导出算法脚本")

    order = topological_sort(workflow.nodes, workflow.edges)
    raw_nodes = {node.id: node for node in workflow.nodes}
    incoming: dict[str, list[str]] = defaultdict(list)
    outgoing: dict[str, list[str]] = defaultdict(list)
    for edge in workflow.edges:
        incoming[edge.target].append(edge.source)
        outgoing[edge.source].append(edge.target)

    normalized: dict[str, tuple[str, dict[str, Any]]] = {}
    read_nodes: list[str] = []
    for node_id in order:
        node = raw_nodes[node_id]
        node_type, params = _normalize_node_type(node.type, node.params)
        if node_type == "ReadImage":
            if incoming[node_id]:
                raise ValueError(f"读取图像节点不能有输入：{node_id}")
            read_nodes.append(node_id)
        else:
            if node_type not in SUPPORTED_OPERATORS:
                raise ValueError(f"算子暂不支持导出为算法脚本：{node_type}")
            if len(incoming[node_id]) != 1:
                raise ValueError(
                    f"当前算法脚本只支持单输入图像算子：{node_id}（收到 {len(incoming[node_id])} 个输入）"
                )
        normalized[node_id] = (node_type, params)

    if not read_nodes:
        raise ValueError("流程中至少需要一个读取图像节点")

    sink_nodes = [node_id for node_id in order if not outgoing[node_id]]
    if not sink_nodes:
        raise ValueError("流程没有可输出的终点")
    return order, normalized, incoming, sink_nodes


def _build_algorithm_function(
    order: list[str],
    normalized: dict[str, tuple[str, dict[str, Any]]],
    incoming: dict[str, list[str]],
    read_nodes: list[str],
    sink_nodes: list[str],
) -> tuple[ast.FunctionDef, dict[str, str], dict[str, str]]:
    if len(read_nodes) == 1:
        input_arguments = {read_nodes[0]: "input_image"}
    else:
        input_arguments = {
            node_id: f"input_image_{index}"
            for index, node_id in enumerate(read_nodes, start=1)
        }

    state = CompileState(statements=[], variable_by_node={}, color_by_node={})
    for index, node_id in enumerate(order, start=1):
        node_type, params = normalized[node_id]
        output_var = _semantic_variable(index, node_type, params)
        if node_type == "ReadImage":
            state.statements.append(
                _assign(output_var, ast.Name(id=input_arguments[node_id], ctx=ast.Load()))
            )
            state.variable_by_node[node_id] = output_var
            state.color_by_node[node_id] = "BGR"
            continue

        source_id = incoming[node_id][0]
        source_var = state.variable_by_node[source_id]
        source_color = state.color_by_node[source_id]
        statements, output_color = _compile_operator(
            index=index,
            node_type=node_type,
            params=params,
            source_var=source_var,
            source_color=source_color,
            output_var=output_var,
        )
        state.statements.extend(statements)
        state.variable_by_node[node_id] = output_var
        state.color_by_node[node_id] = output_color

    if len(sink_nodes) == 1:
        return_value: ast.expr = ast.Name(
            id=state.variable_by_node[sink_nodes[0]], ctx=ast.Load()
        )
    else:
        return_value = ast.Tuple(
            elts=[
                ast.Name(id=state.variable_by_node[node_id], ctx=ast.Load())
                for node_id in sink_nodes
            ],
            ctx=ast.Load(),
        )

    arguments = [
        ast.arg(arg=input_arguments[node_id])
        for node_id in read_nodes
    ]
    function = ast.FunctionDef(
        name="run_algorithm",
        args=ast.arguments(
            posonlyargs=[],
            args=arguments,
            kwonlyargs=[],
            kw_defaults=[],
            defaults=[],
            vararg=None,
            kwarg=None,
        ),
        body=[
            ast.Expr(
                value=ast.Constant(
                    value="执行导出的图像算法。参数是已解码的 OpenCV 图像，返回最终处理结果。"
                )
            ),
            *state.statements,
            ast.Return(value=return_value),
        ],
        decorator_list=[],
    )
    return function, state.variable_by_node, state.color_by_node


def _input_specs(
    read_nodes: list[str], normalized: dict[str, tuple[str, dict[str, Any]]]
) -> list[InputSpec]:
    specs: list[InputSpec] = []
    for index, node_id in enumerate(read_nodes, start=1):
        default_path = str(normalized[node_id][1].get("image_path") or "").strip()
        if len(read_nodes) == 1:
            argument_name = "input"
            cli_option = "--input"
        else:
            argument_name = f"input_{index}"
            cli_option = f"--input-{index}"
        specs.append(
            InputSpec(
                node_id=node_id,
                argument_name=argument_name,
                cli_option=cli_option,
                default_path=default_path,
            )
        )
    return specs


def _build_main_function(
    input_specs: list[InputSpec],
    sink_nodes: list[str],
    normalized: dict[str, tuple[str, dict[str, Any]]],
    color_by_node: dict[str, str],
) -> ast.FunctionDef:
    body: list[ast.stmt] = _statements(
        'parser = argparse.ArgumentParser(description="独立 OpenCV 图像算法脚本")'
    )

    for spec in input_specs:
        keywords: list[ast.keyword] = [
            ast.keyword(arg="help", value=ast.Constant(value="输入图片路径"))
        ]
        if spec.default_path:
            keywords.append(
                ast.keyword(arg="default", value=ast.Constant(value=spec.default_path))
            )
        else:
            keywords.append(ast.keyword(arg="required", value=ast.Constant(value=True)))
        body.append(
            ast.Expr(
                value=ast.Call(
                    func=ast.Attribute(
                        value=ast.Name(id="parser", ctx=ast.Load()),
                        attr="add_argument",
                        ctx=ast.Load(),
                    ),
                    args=[ast.Constant(value=spec.cli_option)],
                    keywords=keywords,
                )
            )
        )

    output_help = "输出图片路径" if len(sink_nodes) == 1 else "多个结果的输出目录"
    output_default = "result.png" if len(sink_nodes) == 1 else "algorithm_outputs"
    body.append(
        ast.Expr(
            value=ast.Call(
                func=ast.Attribute(
                    value=ast.Name(id="parser", ctx=ast.Load()),
                    attr="add_argument",
                    ctx=ast.Load(),
                ),
                args=[ast.Constant(value="--output")],
                keywords=[
                    ast.keyword(arg="default", value=ast.Constant(value=output_default)),
                    ast.keyword(arg="help", value=ast.Constant(value=output_help)),
                ],
            )
        )
    )
    body.extend(_statements("args = parser.parse_args()"))

    loaded_names: list[str] = []
    for index, spec in enumerate(input_specs, start=1):
        image_name = "input_image" if len(input_specs) == 1 else f"input_image_{index}"
        loaded_names.append(image_name)
        body.append(
            _assign(
                image_name,
                ast.Call(
                    func=ast.Name(id="read_image", ctx=ast.Load()),
                    args=[
                        ast.Attribute(
                            value=ast.Name(id="args", ctx=ast.Load()),
                            attr=spec.argument_name,
                            ctx=ast.Load(),
                        )
                    ],
                    keywords=[],
                ),
            )
        )

    algorithm_call = ast.Call(
        func=ast.Name(id="run_algorithm", ctx=ast.Load()),
        args=[ast.Name(id=name, ctx=ast.Load()) for name in loaded_names],
        keywords=[],
    )

    if len(sink_nodes) == 1:
        body.append(_assign("result", algorithm_call))
        body.append(
            _assign(
                "saved_path",
                ast.Call(
                    func=ast.Name(id="save_image", ctx=ast.Load()),
                    args=[
                        ast.Attribute(
                            value=ast.Name(id="args", ctx=ast.Load()),
                            attr="output",
                            ctx=ast.Load(),
                        ),
                        ast.Name(id="result", ctx=ast.Load()),
                        ast.Constant(value=color_by_node[sink_nodes[0]]),
                    ],
                    keywords=[],
                ),
            )
        )
        body.extend(_statements('print(f"已保存：{saved_path}")'))
    else:
        result_names = [f"result_{index}" for index in range(1, len(sink_nodes) + 1)]
        body.append(
            ast.Assign(
                targets=[
                    ast.Tuple(
                        elts=[ast.Name(id=name, ctx=ast.Store()) for name in result_names],
                        ctx=ast.Store(),
                    )
                ],
                value=algorithm_call,
            )
        )
        body.extend(
            _statements(
                "output_dir = Path(args.output).expanduser().resolve()\n"
                "output_dir.mkdir(parents=True, exist_ok=True)"
            )
        )
        for index, (node_id, result_name) in enumerate(
            zip(sink_nodes, result_names, strict=True), start=1
        ):
            node_type = normalized[node_id][0]
            filename = f"result_{index}_{_STEP_NAMES.get(node_type, node_type.lower())}.png"
            saved_name = f"saved_path_{index}"
            body.append(
                _assign(
                    saved_name,
                    ast.Call(
                        func=ast.Name(id="save_image", ctx=ast.Load()),
                        args=[
                            ast.BinOp(
                                left=ast.Name(id="output_dir", ctx=ast.Load()),
                                op=ast.Div(),
                                right=ast.Constant(value=filename),
                            ),
                            ast.Name(id=result_name, ctx=ast.Load()),
                            ast.Constant(value=color_by_node[node_id]),
                        ],
                        keywords=[],
                    ),
                )
            )
            body.extend(_statements(f'print(f"已保存：{{{saved_name}}}")'))

    return ast.FunctionDef(
        name="main",
        args=ast.arguments(
            posonlyargs=[],
            args=[],
            kwonlyargs=[],
            kw_defaults=[],
            defaults=[],
            vararg=None,
            kwarg=None,
        ),
        body=body,
        decorator_list=[],
    )


def generate_algorithm_script(workflow: WorkflowRequest) -> str:
    order, normalized, incoming, sink_nodes = _validate_and_prepare(workflow)
    read_nodes = [node_id for node_id in order if normalized[node_id][0] == "ReadImage"]
    algorithm_function, _, color_by_node = _build_algorithm_function(
        order, normalized, incoming, read_nodes, sink_nodes
    )
    main_function = _build_main_function(
        _input_specs(read_nodes, normalized), sink_nodes, normalized, color_by_node
    )

    base_module = ast.parse(_BASE_SOURCE)
    docstring = ast.Expr(
        value=ast.Constant(
            value=(
                "由工业视觉编排器生成的独立 OpenCV 算法脚本。\n\n"
                "脚本中不包含工作流、节点、连线、拓扑排序或项目运行时。\n"
                "安装依赖：pip install opencv-python numpy\n"
                "运行示例：python vision_algorithm.py --input input.png --output result.png"
            )
        )
    )
    main_guard = ast.If(
        test=ast.Compare(
            left=ast.Name(id="__name__", ctx=ast.Load()),
            ops=[ast.Eq()],
            comparators=[ast.Constant(value="__main__")],
        ),
        body=[
            ast.Expr(
                value=ast.Call(
                    func=ast.Name(id="main", ctx=ast.Load()), args=[], keywords=[]
                )
            )
        ],
        orelse=[],
    )
    module = ast.Module(
        body=[docstring, *base_module.body, algorithm_function, main_function, main_guard],
        type_ignores=[],
    )
    ast.fix_missing_locations(module)
    source = ast.unparse(module)
    source = "#!/usr/bin/env python3\n# -*- coding: utf-8 -*-\n" + source + "\n"
    compile(source, "vision_algorithm.py", "exec")

    forbidden_markers = (
        "WORKFLOW =",
        "OPERATORS =",
        "topological_sort",
        "run_workflow",
        '"nodes"',
        '"edges"',
        "from backend",
    )
    found = [marker for marker in forbidden_markers if marker in source]
    if found:
        raise RuntimeError(f"生成的算法脚本仍包含工作流运行时代码：{', '.join(found)}")
    return source


# 保留旧函数名，避免已有接口调用立即失效；其行为已经改为导出纯算法脚本。
def generate_standalone_script(workflow: WorkflowRequest) -> str:
    return generate_algorithm_script(workflow)
