from fastapi import APIRouter, Depends
from fastapi.responses import JSONResponse

from backend.api.dependencies import get_image_store
from backend.models.workflow import WorkflowRequest
from backend.services.image_store import ImageStore
from backend.services.workflow_engine import run_workflow

router = APIRouter()


@router.post("/run")
def execute_workflow(
    workflow: WorkflowRequest,
    image_store: ImageStore = Depends(get_image_store),
):
    try:
        return run_workflow(workflow, image_store)
    except (ValueError, KeyError, TypeError) as exc:
        return JSONResponse(
            status_code=400,
            content={"success": False, "error": str(exc)},
        )
