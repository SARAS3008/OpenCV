from typing import Any, Dict

import cv2
import numpy as np

def to_int(value: Any, default: int) -> int:
    try:
        return int(float(value))
    except Exception:
        return default

def to_float(value: Any, default: float) -> float:
    try:
        return float(value)
    except Exception:
        return default

def ensure_odd(value: Any, default: int = 3, minimum: int = 1) -> int:
    value = to_int(value, default)
    if value < minimum:
        value = minimum
    if value % 2 == 0:
        value += 1
    return value

def ensure_gray(img: np.ndarray) -> np.ndarray:
    if img is None:
        raise ValueError("输入图像为空")
    if len(img.shape) == 2:
        return img
    return cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

def ensure_bgr(img: np.ndarray) -> np.ndarray:
    if img is None:
        raise ValueError("输入图像为空")
    if len(img.shape) == 2:
        return cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)
    return img

def kernel_from_params(params: Dict[str, Any], default: int = 3) -> np.ndarray:
    ksize = ensure_odd(params.get("ksize", default), default, 1)
    return np.ones((ksize, ksize), np.uint8)
