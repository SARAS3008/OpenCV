from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Protocol

import numpy as np


class ImageResolver(Protocol):
    def resolve(self, image_id: str) -> Path | None: ...

    def resolve_path(self, image_path: str) -> Path | None: ...

    def read(self, path: Path) -> np.ndarray | None: ...


@dataclass(frozen=True)
class ExecutionContext:
    image_id: str | None
    image_store: ImageResolver


OperatorInputs = dict[str, Any]
OperatorParams = dict[str, Any]
OperatorResult = dict[str, Any]
Operator = Callable[[OperatorInputs, OperatorParams, ExecutionContext], OperatorResult]
