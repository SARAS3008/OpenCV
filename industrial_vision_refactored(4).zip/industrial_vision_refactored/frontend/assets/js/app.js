let OPERATOR_META = {};
let OPERATOR_CATALOG = {};
let nodes = [];
let edges = [];
let nodeSeq = 1;
let selectedNodeId = null;
let selectedEdgeId = null;
let connectingSourceId = null;
let connectDrag = null;
let pan = { x: -260, y: -120 };
let zoom = 0.82;
const viewport = document.getElementById("viewport");
const world = document.getElementById("world");
const nodeLayer = document.getElementById("nodeLayer");
const edgeLayer = document.getElementById("edgeLayer");
const statusEl = document.getElementById("status");
const paramPanel = document.getElementById("paramPanel");
const previewPanel = document.getElementById("previewPanel");
const previewWrap = document.getElementById("previewWrap");
const previewToggleText = document.getElementById("previewToggleText");
let previewCollapsed = false;
let nodeLibraryVisible = true;

const ICONS = { io:"⎋", color:"◐", filter:"≋", segment:"⌁", morph:"⬡", geo:"⟲", measure:"▤" };

async function initOperators(){
  const data = await VisionApi.getOperators();
  OPERATOR_META = data.operators || {};
  OPERATOR_CATALOG = data.catalog || {};
  renderOperatorPanel();
  applyTransform();
  createDemoWorkflow();
}
function renderOperatorPanel(){
  const panel = document.getElementById("operatorPanel"); panel.innerHTML = "";
  const q = document.getElementById("opSearch").value.trim().toLowerCase();
  const groups = OPERATOR_CATALOG["图像"] || [];
  groups.forEach(g => {
    const matched = g.items.filter(type => {
      const m = OPERATOR_META[type] || {}; const hay = `${type} ${m.label||''} ${m.description||''} ${g.group}`.toLowerCase();
      return !q || hay.includes(q);
    });
    if(!matched.length) return;
    const group = document.createElement("div"); group.className = "op-group";
    const title = document.createElement("div"); title.className = "group-title"; title.innerHTML = `<span class="chev">▾</span>${g.group}<span style="color:#707b8d;font-weight:700">${matched.length}</span>`;
    title.onclick = () => group.classList.toggle("closed");
    const ops = document.createElement("div"); ops.className = "ops";
    matched.forEach(type => {
      const meta = OPERATOR_META[type];
      const op = document.createElement("div"); op.className = "op"; op.draggable = true; op.dataset.type = type;
      op.innerHTML = `<div class="op-icon" style="background:${kindColor(meta.kind)}">${ICONS[meta.kind]||'□'}</div><div><div class="op-name">${meta.label}</div><div class="op-desc">${meta.description || type}</div></div><div class="op-type">${type}</div>`;
      op.ondragstart = e => e.dataTransfer.setData("operator/type", type);
      op.ondblclick = () => addNode(type, 460 + nodes.length*24, 240 + nodes.length*18);
      ops.appendChild(op);
    });
    group.appendChild(title); group.appendChild(ops); panel.appendChild(group);
  });
}
function kindColor(kind){ return { io:'#7a5728', color:'#514fa0', filter:'#346691', segment:'#8a5631', morph:'#31705a', geo:'#774a8d', measure:'#8b3d4e' }[kind] || '#3f4753'; }
function setNodeLibraryVisible(visible){
  nodeLibraryVisible = Boolean(visible);
  const main = document.querySelector('.main');
  const library = document.getElementById('nodeLibrary');
  const toggle = document.getElementById('nodeLibraryToggle');
  main.classList.toggle('nodes-panel-hidden', !nodeLibraryVisible);
  library.setAttribute('aria-hidden', String(!nodeLibraryVisible));
  toggle.classList.toggle('active', nodeLibraryVisible);
  toggle.setAttribute('aria-expanded', String(nodeLibraryVisible));
  toggle.title = nodeLibraryVisible ? '隐藏节点库' : '显示节点库';
  window.requestAnimationFrame(updateMinimap);
}
function toggleNodeLibrary(){ setNodeLibraryVisible(!nodeLibraryVisible); }
function defaultParams(type){ return JSON.parse(JSON.stringify((OPERATOR_META[type] && OPERATOR_META[type].params) || {})); }
function addNode(type, x, y){
  if(!OPERATOR_META[type]){ toast("不能添加节点", `${type} 尚未实现`, false); return; }
  const id = `n${nodeSeq++}`;
  nodes.push({ id, type, position:{x:Math.round(x), y:Math.round(y)}, params:defaultParams(type), collapsed:false });
  selectedNodeId = id; render(); setStatus(`已添加节点：${id} · ${OPERATOR_META[type].label}`);
}
function clampZoom(value){ return Math.min(2.6, Math.max(0.18, value)); }
function applyTransform(){
  world.style.transform = `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`;
  document.getElementById("zoomLabel").textContent = `${Math.round(zoom*100)}%`;
  const small = 20 * zoom, large = 100 * zoom;
  viewport.style.backgroundSize = `${small}px ${small}px, ${small}px ${small}px, ${large}px ${large}px, ${large}px ${large}px`;
  viewport.style.backgroundPosition = `${pan.x}px ${pan.y}px, ${pan.x}px ${pan.y}px, ${pan.x}px ${pan.y}px, ${pan.x}px ${pan.y}px`;
  updateMinimap();
}
function screenToWorld(clientX, clientY){
  const r = viewport.getBoundingClientRect();
  return { x:(clientX-r.left-pan.x)/zoom, y:(clientY-r.top-pan.y)/zoom, sx:clientX-r.left, sy:clientY-r.top };
}
function setZoom(value, center){
  const next = clampZoom(value);
  if(center){
    pan.x = center.sx - center.x * next;
    pan.y = center.sy - center.y * next;
  }
  zoom = next;
  applyTransform();
}
function zoomBy(delta, clientX, clientY){
  const center = screenToWorld(clientX, clientY);
  const factor = delta > 0 ? 1.1 : 1 / 1.1;
  setZoom(zoom * factor, center);
}
function isCanvasEmptyTarget(target){
  if(!target) return false;
  if(target.closest && target.closest('.node,.port,.canvas-toolbar,.bottom-controls,.toast,button,input,label,textarea,select')) return false;
  return target === viewport || target === world || target === nodeLayer || target === edgeLayer || target.tagName === 'svg' || target.tagName === 'path';
}
viewport.addEventListener("wheel", e => { e.preventDefault(); zoomBy(e.deltaY < 0 ? 1 : -1, e.clientX, e.clientY); }, {passive:false});
viewport.addEventListener("dragover", e => e.preventDefault());
viewport.addEventListener("drop", e => { e.preventDefault(); const type = e.dataTransfer.getData("operator/type"); if(!type) return; const p=screenToWorld(e.clientX,e.clientY); addNode(type,p.x,p.y); });
viewport.addEventListener("mousedown", e => {
  if(e.button !== 0 || !isCanvasEmptyTarget(e.target)) return;
  e.preventDefault();
  selectedNodeId = null; selectedEdgeId = null; renderParams(); renderEdges();
  const sx=e.clientX, sy=e.clientY, start={...pan}; viewport.classList.add("panning");
  function mv(ev){ pan.x=start.x+(ev.clientX-sx); pan.y=start.y+(ev.clientY-sy); applyTransform(); }
  function up(){ viewport.classList.remove("panning"); window.removeEventListener("mousemove",mv); window.removeEventListener("mouseup",up); }
  window.addEventListener("mousemove",mv); window.addEventListener("mouseup",up);
});
function render(){ renderNodes(); renderEdges(); renderParams(); updateMinimap(); }
function nodeHeight(n){ return n.collapsed ? 34 : 128; }
function renderNodes(){
  nodeLayer.innerHTML = "";
  nodes.forEach(n => {
    const meta = OPERATOR_META[n.type] || {label:n.type,kind:'unknown',params:{},has_input:true,has_output:true};
    const el = document.createElement("div"); el.className = `node ${meta.kind||''} ${selectedNodeId===n.id?'selected':''} ${n.collapsed?'collapsed':''}`;
    el.dataset.id = n.id;
    el.style.left = `${n.position.x}px`; el.style.top = `${n.position.y}px`; el.style.minHeight = `${nodeHeight(n)}px`;
    const chips = Object.entries(n.params||{}).map(([k,v]) => `<span class="param-chip">${k}=${v}</span>`).join("") || '<span class="hint">无参数</span>';
    el.innerHTML = `
      <div class="node-head">
        <div class="node-title"><button class="fold-btn" title="折叠/展开">▾</button><span>${meta.label}</span></div><div class="node-badge">${n.id}</div>
      </div>
      ${meta.has_input ? '<div class="port in" title="输入 in"></div>' : ''}
      ${meta.has_output ? '<div class="port out" title="输出 out"></div>' : ''}
      <div class="node-body">
        <div class="socket-row"><span>${meta.has_input?'● image_in':'无输入'}</span><span>${meta.has_output?'image_out ●':'无输出'}</span></div>
        <div class="node-field"><b>${n.type}</b><br>${meta.description || ''}<br><div style="margin-top:5px">${chips}</div></div>
        <div class="node-foot">点击标题左侧箭头可折叠节点</div>
      </div>`;
    el.querySelector('.node-head').addEventListener('mousedown', e => startDragNode(e,n.id));
    el.querySelector('.fold-btn').onclick = e => { e.stopPropagation(); n.collapsed = !n.collapsed; render(); };
    el.ondblclick = e => { e.stopPropagation(); n.collapsed = !n.collapsed; render(); };
    el.addEventListener('mousedown', () => { selectedNodeId=n.id; selectedEdgeId=null; renderParams(); renderEdges(); document.querySelectorAll('.node').forEach(x=>x.classList.remove('selected')); el.classList.add('selected'); });
    const out = el.querySelector('.port.out'); if(out){ out.onclick = e => { e.stopPropagation(); startConnect(n.id); }; out.addEventListener('mousedown', e => startConnectDrag(e,n.id)); }
    const inn = el.querySelector('.port.in'); if(inn){ inn.onclick = e => { e.stopPropagation(); if(connectingSourceId) finishConnect(n.id); else selectIncomingEdge(n.id); }; inn.addEventListener('mousedown', e => { if(connectingSourceId){ e.stopPropagation(); finishConnect(n.id); } }); }
    nodeLayer.appendChild(el);
  });
}
function startConnect(id){
  const sourceMeta = OPERATOR_META[nodes.find(n=>n.id===id)?.type] || {};
  if(!sourceMeta.has_output){ toast("连线失败", "源节点没有输出端口"); return; }
  connectingSourceId = id; selectedEdgeId = null; renderEdges(); setStatus(`请选择目标节点输入端口：${id}.out → ?，也可以拖动到目标输入端口`);
}
function startConnectDrag(e,id){
  if(e.button !== 0) return;
  e.stopPropagation(); e.preventDefault(); startConnect(id);
  connectDrag = { source:id };
  drawTempEdge(e.clientX,e.clientY);
  function mv(ev){ drawTempEdge(ev.clientX,ev.clientY); }
  function up(ev){
    window.removeEventListener('mousemove',mv); window.removeEventListener('mouseup',up);
    clearTempEdge();
    const target = document.elementFromPoint(ev.clientX, ev.clientY);
    const port = target && target.closest ? target.closest('.port.in') : null;
    const nodeEl = port && port.closest ? port.closest('.node') : null;
    const targetId = nodeEl ? nodeEl.dataset.id : null;
    if(targetId) finishConnect(targetId);
    else setStatus(`已选择源端口：${id}.out，请点击目标节点的输入端口完成连线`);
    connectDrag = null;
  }
  window.addEventListener('mousemove',mv);
  window.addEventListener('mouseup',up);
}
function finishConnect(targetId){
  if(!connectingSourceId || connectingSourceId === targetId) return;
  const sourceMeta = OPERATOR_META[nodes.find(n=>n.id===connectingSourceId)?.type] || {};
  const targetMeta = OPERATOR_META[nodes.find(n=>n.id===targetId)?.type] || {};
  if(!sourceMeta.has_output){ toast("连线失败", "源节点没有输出端口"); connectingSourceId=null; return; }
  if(!targetMeta.has_input){ toast("连线失败", "目标节点没有输入端口"); connectingSourceId=null; return; }
  edges = edges.filter(e => !(e.target === targetId && e.targetHandle === 'in'));
  const edgeId = `e${Date.now()}`;
  edges.push({ id:edgeId, source:connectingSourceId, sourceHandle:"out", target:targetId, targetHandle:"in" });
  const msg = `${connectingSourceId} → ${targetId}`; connectingSourceId = null; selectedEdgeId=edgeId; selectedNodeId=null; render(); setStatus(`已创建连线：${msg}`); toast("已创建连线", msg, true);
}
function startDragNode(e,nodeId){
  if(e.target.classList.contains('fold-btn')) return;
  e.stopPropagation(); selectedNodeId=nodeId; selectedEdgeId=null; const n=nodes.find(x=>x.id===nodeId); const sx=e.clientX, sy=e.clientY, start={...n.position};
  function mv(ev){ n.position.x=Math.round(start.x+(ev.clientX-sx)/zoom); n.position.y=Math.round(start.y+(ev.clientY-sy)/zoom); renderNodes(); renderEdges(); updateMinimap(); }
  function up(){ window.removeEventListener('mousemove',mv); window.removeEventListener('mouseup',up); renderParams(); }
  window.addEventListener('mousemove',mv); window.addEventListener('mouseup',up);
}
function getPortPoint(n,kind){ const y = n.position.y + (n.collapsed ? 17 : 50); return { x:n.position.x + (kind==='out'?260:0), y }; }
function makeEdgePath(p1,p2){ const c1=p1.x+95, c2=p2.x-95; return `M ${p1.x} ${p1.y} C ${c1} ${p1.y}, ${c2} ${p2.y}, ${p2.x} ${p2.y}`; }
function drawTempEdge(clientX,clientY){
  clearTempEdge();
  const s=nodes.find(n=>n.id===connectingSourceId); if(!s) return;
  const p1=getPortPoint(s,'out'), p2=screenToWorld(clientX,clientY);
  const path=document.createElementNS('http://www.w3.org/2000/svg','path');
  path.id='tempEdge'; path.setAttribute('class','edge-temp'); path.setAttribute('d', makeEdgePath(p1,p2)); edgeLayer.appendChild(path);
}
function clearTempEdge(){ const t=document.getElementById('tempEdge'); if(t) t.remove(); }
function renderEdges(){
  edgeLayer.innerHTML = "";
  edges.forEach(edge => {
    const s=nodes.find(n=>n.id===edge.source), t=nodes.find(n=>n.id===edge.target); if(!s||!t) return;
    const p1=getPortPoint(s,'out'), p2=getPortPoint(t,'in'); const d=makeEdgePath(p1,p2);
    const hit=document.createElementNS('http://www.w3.org/2000/svg','path'); hit.setAttribute('d',d); hit.setAttribute('class','edge-hit'); hit.dataset.id=edge.id;
    hit.addEventListener('mousedown', ev => { ev.stopPropagation(); });
    hit.addEventListener('click', ev => { ev.stopPropagation(); selectEdge(edge.id); });
    hit.addEventListener('dblclick', ev => { ev.stopPropagation(); deleteEdge(edge.id); });
    hit.addEventListener('contextmenu', ev => { ev.preventDefault(); ev.stopPropagation(); deleteEdge(edge.id); });
    const path=document.createElementNS('http://www.w3.org/2000/svg','path'); path.setAttribute('d',d); path.setAttribute('class',`edge-visible ${selectedEdgeId===edge.id?'selected':''}`);
    edgeLayer.appendChild(hit); edgeLayer.appendChild(path);
  });
}
function selectIncomingEdge(targetId){ const edge=edges.find(e=>e.target===targetId && e.targetHandle==='in'); if(edge) selectEdge(edge.id); }
function selectEdge(edgeId){ selectedEdgeId=edgeId; selectedNodeId=null; connectingSourceId=null; document.querySelectorAll('.node').forEach(x=>x.classList.remove('selected')); renderEdges(); renderParams(); const e=edges.find(x=>x.id===edgeId); if(e) setStatus(`已选择连线：${e.source} → ${e.target}，按 Delete/Backspace 删除，或双击/右键连线删除`); }
function deleteEdge(edgeId){ const e=edges.find(x=>x.id===edgeId); if(!e) return; edges=edges.filter(x=>x.id!==edgeId); if(selectedEdgeId===edgeId) selectedEdgeId=null; render(); toast('已删除连线',`${e.source} → ${e.target}`,true); setStatus(`已删除连线：${e.source} → ${e.target}`); }
function deleteSelectedEdge(){ if(selectedEdgeId) deleteEdge(selectedEdgeId); }
function renderParams(){
  if(selectedEdgeId && !selectedNodeId){
    const edge=edges.find(x=>x.id===selectedEdgeId);
    if(edge){
      paramPanel.className='param-card';
      paramPanel.innerHTML=`<h3>连线 · ${escapeHtml(edge.source)} → ${escapeHtml(edge.target)}</h3><div class="hint" style="margin-bottom:8px">sourceHandle：${escapeHtml(edge.sourceHandle || 'out')}<br>targetHandle：${escapeHtml(edge.targetHandle || 'in')}<br>双击或右键连线也可以删除。</div><div class="row-actions"><button class="btn red" onclick="deleteSelectedEdge()">删除连线</button></div>`;
      return;
    }
  }

  const n=nodes.find(x=>x.id===selectedNodeId);
  if(!n){
    paramPanel.className='param-card hint';
    paramPanel.textContent='请选择一个节点或连线';
    return;
  }

  const meta=OPERATOR_META[n.type] || {label:n.type,params:{}};
  paramPanel.className='param-card';
  paramPanel.innerHTML=`<h3>${escapeHtml(n.id)} · ${escapeHtml(meta.label)}</h3><div class="hint" style="margin-bottom:8px">类型：${escapeHtml(n.type)}<br>${escapeHtml(meta.description||'')}</div>`;

  const defaults=meta.params||{};
  const schema=meta.param_schema||{};
  const keys=Object.keys(defaults);
  if(!keys.length){
    const empty=document.createElement('div');
    empty.className='hint';
    empty.textContent='该节点暂无可编辑参数。';
    paramPanel.appendChild(empty);
  }

  keys.forEach(key=>{
    const spec=schema[key]||{};
    const row=document.createElement('div');
    row.className='param-row';
    const label=document.createElement('label');
    label.textContent=spec.label||key;

    let control;
    if(spec.type==='select'){
      control=document.createElement('select');
      (spec.options||[]).forEach(option=>{
        const item=document.createElement('option');
        item.value=option.value;
        item.textContent=option.label||option.value;
        control.appendChild(item);
      });
    }else{
      control=document.createElement('input');
      control.type=typeof defaults[key]==='number' ? 'number' : 'text';
      if(spec.placeholder) control.placeholder=spec.placeholder;
      if(n.type==='ReadImage' && key==='image_path') control.autocomplete='off';
    }

    control.value=n.params[key] ?? defaults[key];
    control.onchange=()=>{
      const raw=control.value;
      n.params[key]=typeof defaults[key]==='number' && raw!=='' ? Number(raw) : raw;
      setStatus(`已更新参数：${n.id}.${key} = ${n.params[key]}`);
      renderNodes();
    };
    row.appendChild(label);
    row.appendChild(control);
    paramPanel.appendChild(row);

    if(spec.help){
      const help=document.createElement('div');
      help.className='param-help';
      help.textContent=spec.help;
      paramPanel.appendChild(help);
    }
  });

  const actions=document.createElement('div');
  actions.className='row-actions';
  actions.innerHTML = `<button class="btn ghost" onclick="toggleSelectedCollapse()">${n.collapsed?'展开节点':'折叠节点'}</button><button class="btn ghost" onclick="duplicateNode('${escapeHtml(n.id)}')">复制节点</button><button class="btn red" onclick="deleteSelectedNode()">删除节点</button>`;
  paramPanel.appendChild(actions);
}
function toggleSelectedCollapse(){ const n=nodes.find(x=>x.id===selectedNodeId); if(!n) return; n.collapsed=!n.collapsed; render(); }
function collapseAllNodes(){ nodes.forEach(n=>n.collapsed=true); render(); setStatus('已折叠所有画布节点'); }
function expandAllNodes(){ nodes.forEach(n=>n.collapsed=false); render(); setStatus('已展开所有画布节点'); }
function duplicateNode(id){ const n=nodes.find(x=>x.id===id); if(!n) return; const id2=`n${nodeSeq++}`; nodes.push({id:id2,type:n.type,position:{x:n.position.x+36,y:n.position.y+36},params:JSON.parse(JSON.stringify(n.params||{})),collapsed:n.collapsed}); selectedNodeId=id2; render(); }
function deleteSelectedNode(){ if(!selectedNodeId) return; const id=selectedNodeId; nodes=nodes.filter(n=>n.id!==id); edges=edges.filter(e=>e.source!==id&&e.target!==id); selectedNodeId=null; selectedEdgeId=null; render(); toast('已删除节点',id,true); }
document.getElementById('workflowInput').addEventListener('change',async e=>{ const f=e.target.files[0]; if(!f) return; try{applyWorkflow(JSON.parse(await f.text()));toast('JSON流程已导入',f.name,true)}catch(err){toast('导入失败',err.message)} });
function buildWorkflow(){ return { version:'1.2', nodes:nodes.map(n=>({ id:n.id,type:n.type,position:n.position,params:{...(n.params||{})},collapsed:!!n.collapsed })), edges }; }
async function runWorkflow(){
  const wf=buildWorkflow();
  setStatus('运行中...');
  document.getElementById('taskCount').textContent='1';
  if(previewCollapsed) togglePreviewPanel(false);
  previewPanel.innerHTML='<div class="empty-preview">正在运行 OpenCV 流程...</div>';
  try{
    const data=await VisionApi.executeWorkflow(wf);
    renderPreviews(data.previews || []);
    setStatus(`运行成功。执行顺序：${(data.order||[]).join(' → ')}`);
    toast('运行成功',`已生成 ${(data.previews||[]).length} 个预览`,true);
  }catch(err){
    const msg = err && err.message ? err.message : String(err);
    setStatus('运行失败：'+msg);
    previewPanel.innerHTML=`<div class="empty-preview">运行失败：${escapeHtml(msg)}</div>`;
    toast('运行失败',msg);
  } finally{
    document.getElementById('taskCount').textContent='0';
  }
}
function togglePreviewPanel(force){ previewCollapsed = (typeof force === 'boolean') ? force : !previewCollapsed; previewWrap.classList.toggle('collapsed', previewCollapsed); previewToggleText.textContent = previewCollapsed ? '展开' : '折叠'; }
function renderPreviews(previews){ previewPanel.innerHTML=''; if(!previews.length){ previewPanel.innerHTML='<div class="empty-preview">没有生成预览结果</div>'; return; } previews.forEach((item,idx)=>{ const div=document.createElement('div'); div.className='preview-card'; const title = `${idx+1}. ${item.node_id} · ${item.label}`; div.innerHTML=`<div class="preview-meta"><b title="${escapeHtml(title)}">${escapeHtml(title)}</b><span class="tag">${escapeHtml(item.type || '')}</span></div><img src="${item.image || ''}" />`; previewPanel.appendChild(div); }); }
function escapeHtml(value){ return String(value).replace(/[&<>"']/g, s => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[s])); }
function saveWorkflowLocal(){ localStorage.setItem('vision_python_mvp_workflow_v2', JSON.stringify(buildWorkflow(),null,2)); toast('流程已保存','保存到浏览器 localStorage',true); setStatus('流程已保存到浏览器 localStorage'); }
function loadWorkflowLocal(){ const raw=localStorage.getItem('vision_python_mvp_workflow_v2'); if(!raw){toast('加载失败','没有找到本地保存的流程');return;} applyWorkflow(JSON.parse(raw)); toast('流程已加载','来自浏览器 localStorage',true); }
function downloadWorkflowJson(){ const blob=new Blob([JSON.stringify(buildWorkflow(),null,2)],{type:'application/json'}); const url=URL.createObjectURL(blob); const a=document.createElement('a'); a.href=url; a.download='vision_workflow.json'; a.click(); URL.revokeObjectURL(url); }
async function exportAlgorithmScript(){
  if(!nodes.length){
    toast('无法导出','请先编排工作流');
    setStatus('导出失败：当前工作流为空');
    return;
  }
  document.getElementById('taskCount').textContent='1';
  setStatus('正在把当前编排编译为独立算法脚本...');
  try{
    const result=await VisionApi.exportScript(buildWorkflow());
    const url=URL.createObjectURL(result.blob);
    const anchor=document.createElement('a');
    anchor.href=url;
    anchor.download=result.filename || 'vision_algorithm.py';
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    URL.revokeObjectURL(url);
    toast('脚本导出成功','已生成不包含工作流运行时的算法脚本',true);
    setStatus('算法脚本导出成功。新环境安装 opencv-python 和 numpy 后即可直接运行。');
  }catch(err){
    const message=err && err.message ? err.message : String(err);
    toast('脚本导出失败',message);
    setStatus('脚本导出失败：'+message);
  }finally{
    document.getElementById('taskCount').textContent='0';
  }
}
function resetView(){ pan={x:-260,y:-120}; zoom=.82; applyTransform(); setStatus('已重置画布视图'); }
function migrateWorkflowNode(rawNode, legacyImageId){
  let type=rawNode.type;
  const params={...(rawNode.params||{})};
  if(type==='Gray'){
    type='ColorConvert';
    params.mode='GRAY';
  }else if(type==='BGR2RGB'){
    type='ColorConvert';
    params.mode='RGB';
  }
  if(type==='ReadImage' && legacyImageId && !params.image_path && !params.image_id){
    params.image_id=legacyImageId;
  }
  return {id:rawNode.id,type,position:rawNode.position||{x:100,y:100},params:{...defaultParams(type),...params},collapsed:!!rawNode.collapsed};
}
function applyWorkflow(wf){ nodes=(wf.nodes||[]).map(n=>migrateWorkflowNode(n,wf.image_id)).filter(n=>OPERATOR_META[n.type] && !OPERATOR_META[n.type].hidden); edges=(wf.edges||[]).filter(e=>nodes.some(n=>n.id===e.source)&&nodes.some(n=>n.id===e.target)); const maxSeq=nodes.reduce((m,n)=>Math.max(m,Number(String(n.id).replace('n',''))||0),0); nodeSeq=maxSeq+1; selectedNodeId=null; selectedEdgeId=null; render(); }
function createDemoWorkflow(){ nodes=[{id:'n1',type:'ReadImage',position:{x:420,y:230},params:{image_path:''},collapsed:false},{id:'n2',type:'ColorConvert',position:{x:735,y:230},params:{mode:'GRAY'},collapsed:false},{id:'n3',type:'GaussianBlur',position:{x:1050,y:230},params:{ksize:5,sigma:0},collapsed:false},{id:'n4',type:'Canny',position:{x:1365,y:230},params:{threshold1:50,threshold2:150},collapsed:false},{id:'n5',type:'Display',position:{x:1680,y:230},params:{},collapsed:false}]; edges=[{id:'e1',source:'n1',sourceHandle:'out',target:'n2',targetHandle:'in'},{id:'e2',source:'n2',sourceHandle:'out',target:'n3',targetHandle:'in'},{id:'e3',source:'n3',sourceHandle:'out',target:'n4',targetHandle:'in'},{id:'e4',source:'n4',sourceHandle:'out',target:'n5',targetHandle:'in'}]; nodeSeq=6; selectedNodeId='n1'; selectedEdgeId=null; pan={x:-260,y:-120}; zoom=.82; applyTransform(); render(); setStatus('请在右侧为 n1 填写图片路径，然后运行流程'); toast('示例流程已生成','先填写 ReadImage 节点的图片路径',true); }
function clearWorkflow(){ nodes=[]; edges=[]; selectedNodeId=null; selectedEdgeId=null; previewPanel.innerHTML='<div class="empty-preview">运行后显示每步处理结果</div>'; render(); setStatus('流程已清空'); }
function toast(title,text,ok){ const el=document.getElementById('toast'); document.getElementById('toastTitle').textContent=title; document.getElementById('toastText').textContent=text||''; el.className='toast show'+(ok?' ok':''); clearTimeout(window.__toastTimer); window.__toastTimer=setTimeout(()=>el.className='toast',3200); }
function setStatus(t){ statusEl.textContent=t; }
function updateMinimap(){ const mini=document.getElementById('miniNodes'); mini.innerHTML=''; const scale=.045; nodes.forEach(n=>{ const d=document.createElement('div'); d.className='mini-node'; d.style.left=(n.position.x*scale+14)+'px'; d.style.top=(n.position.y*scale+22)+'px'; d.style.width=(260*scale)+'px'; d.style.height=(nodeHeight(n)*scale)+'px'; mini.appendChild(d); }); const rect=viewport.getBoundingClientRect(); const view=document.getElementById('miniView'); view.style.left=((0-pan.x)/zoom*scale+14)+'px'; view.style.top=((0-pan.y)/zoom*scale+22)+'px'; view.style.width=(rect.width/zoom*scale)+'px'; view.style.height=(rect.height/zoom*scale)+'px'; }
document.addEventListener('keydown', e => { if((e.key==='Delete' || e.key==='Backspace') && selectedEdgeId){ e.preventDefault(); deleteSelectedEdge(); } if(e.key==='Escape'){ connectingSourceId=null; clearTempEdge(); setStatus('已取消连线'); } });
window.addEventListener('resize', updateMinimap);
document.getElementById('nodeLibraryToggle').addEventListener('click', toggleNodeLibrary);
document.getElementById('exportScriptButton').addEventListener('click', exportAlgorithmScript);
setNodeLibraryVisible(true);
initOperators();
