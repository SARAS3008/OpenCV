/**
 * 前后端通信层。
 * 页面组件只调用 VisionApi，不直接关心 fetch、HTTP 状态码和错误格式。
 */
(() => {
  const API_BASE = "/api";

  async function request(path, options = {}) {
    const response = await fetch(`${API_BASE}${path}`, options);
    let data;
    try {
      data = await response.json();
    } catch (_error) {
      throw new Error(`服务返回了无法解析的响应（HTTP ${response.status}）`);
    }

    if (!response.ok || data.success === false) {
      throw new Error(data.error || data.detail || `请求失败（HTTP ${response.status}）`);
    }
    return data;
  }

  async function getOperators() {
    return request("/operators");
  }

  async function executeWorkflow(workflow) {
    return request("/run", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(workflow),
    });
  }

  async function exportScript(workflow) {
    const response = await fetch(`${API_BASE}/export-script`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(workflow),
    });

    if (!response.ok) {
      let message = `导出失败（HTTP ${response.status}）`;
      try {
        const data = await response.json();
        message = data.error || data.detail || message;
      } catch (_error) {
        // 保留默认错误信息。
      }
      throw new Error(message);
    }

    const disposition = response.headers.get("Content-Disposition") || "";
    const match = disposition.match(/filename="?([^";]+)"?/i);
    return {
      blob: await response.blob(),
      filename: match ? match[1] : "vision_algorithm.py",
    };
  }

  window.VisionApi = Object.freeze({
    getOperators,
    executeWorkflow,
    exportScript,
  });
})();
