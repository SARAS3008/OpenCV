import type { AssetUploadResponse, CvFlowEdge, CvFlowNode, NodeDefinition, WorkflowRunResponse } from './types';

const API_BASE = import.meta.env.VITE_API_BASE ?? 'http://127.0.0.1:8000';

export async function fetchNodeDefinitions(): Promise<NodeDefinition[]> {
  const res = await fetch(`${API_BASE}/api/nodes`);
  if (!res.ok) throw new Error(await res.text());
  const data = await res.json();
  return data.nodes;
}

export async function uploadImage(file: File): Promise<AssetUploadResponse> {
  const form = new FormData();
  form.append('file', file);
  const res = await fetch(`${API_BASE}/api/assets/upload`, { method: 'POST', body: form });
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}

export async function runWorkflow(nodes: CvFlowNode[], edges: CvFlowEdge[]): Promise<WorkflowRunResponse> {
  const payload = {
    nodes: nodes.map((node) => ({
      id: node.id,
      type: node.data.nodeType,
      params: node.data.params ?? {},
    })),
    edges: edges.map((edge) => ({
      id: edge.id,
      from_node: edge.source,
      from_output: edge.sourceHandle ?? 'image',
      to_node: edge.target,
      to_input: edge.targetHandle ?? 'image',
    })),
    preview: true,
    preview_max_size: 1200,
  };

  const res = await fetch(`${API_BASE}/api/workflows/run`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });

  if (!res.ok) {
    const body = await res.json().catch(() => null);
    throw new Error(body?.detail ?? (await res.text()));
  }
  return res.json();
}

export function createDefaultParams(def: NodeDefinition): Record<string, unknown> {
  return Object.fromEntries(Object.entries(def.params).map(([key, spec]) => [key, spec.default]));
}
