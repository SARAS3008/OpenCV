import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Background,
  Controls,
  MiniMap,
  ReactFlow,
  addEdge,
  reconnectEdge,
  ConnectionMode,
  useEdgesState,
  useNodesState,
  type Connection,
  type Edge,
} from '@xyflow/react';

import { createDefaultParams, fetchNodeDefinitions, runWorkflow, uploadImage } from './api';
import Sidebar from './components/Sidebar';
import Toolbar from './components/Toolbar';
import ParamsPanel from './components/ParamsPanel';
import PreviewPanel from './components/PreviewPanel';
import CvNode from './nodes/CvNode';
import { categoryLabel, nodeTitle, t, type Locale } from './i18n';
import type { AssetUploadResponse, CvFlowEdge, CvFlowNode, NodeDefinition, WorkflowRunResponse } from './types';

const nodeTypes = { cvNode: CvNode };

export default function App() {
  const [definitions, setDefinitions] = useState<NodeDefinition[]>([]);
  const [nodes, setNodes, onNodesChange] = useNodesState<CvFlowNode>([]);
  const [edges, setEdges, onEdgesChange] = useEdgesState<CvFlowEdge>([]);
  const [asset, setAsset] = useState<AssetUploadResponse | null>(null);
  const [selectedNodeIds, setSelectedNodeIds] = useState<string[]>([]);
  const [selectedEdgeIds, setSelectedEdgeIds] = useState<string[]>([]);
  const [result, setResult] = useState<WorkflowRunResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [running, setRunning] = useState(false);
  const [libraryCollapsed, setLibraryCollapsed] = useState(() => localStorage.getItem('comfycv-library-collapsed') === '1');
  const [locale, setLocale] = useState<Locale>(() => (localStorage.getItem('comfycv-locale') as Locale | null) ?? 'zh');

  const defMap = useMemo(() => Object.fromEntries(definitions.map((d) => [d.type, d])), [definitions]);
  const selectedNodeId = selectedNodeIds[selectedNodeIds.length - 1] ?? null;
  const selectedNode = nodes.find((node) => node.id === selectedNodeId) ?? null;
  const canDelete = selectedNodeIds.length > 0 || selectedEdgeIds.length > 0;
  const edgeReconnectSuccessful = useRef(true);

  useEffect(() => {
    fetchNodeDefinitions()
      .then((defs) => {
        setDefinitions(defs);
        const demo = createDemoWorkflow(defs, null, locale);
        setNodes(demo.nodes);
        setEdges(demo.edges);
      })
      .catch((err) => setError(String(err.message ?? err)));
  }, [setEdges, setNodes]);

  useEffect(() => {
    localStorage.setItem('comfycv-locale', locale);
  }, [locale]);

  useEffect(() => {
    localStorage.setItem('comfycv-library-collapsed', libraryCollapsed ? '1' : '0');
  }, [libraryCollapsed]);

  useEffect(() => {
    setNodes((nds) =>
      nds.map((node) => {
        const nodeResult = result?.results[node.id];
        const imageOutput = nodeResult ? Object.values(nodeResult.outputs).find((out) => out.kind === 'image' && out.preview) : undefined;
        return {
          ...node,
          data: {
            ...node.data,
            hasResult: Boolean(nodeResult),
            lastElapsedMs: nodeResult?.elapsed_ms ?? null,
            lastPreview: imageOutput?.preview ?? null,
          },
        };
      }),
    );
  }, [result, setNodes]);

  const createNode = useCallback((def: NodeDefinition, position?: { x: number; y: number }, overrides: Record<string, unknown> = {}): CvFlowNode => {
    const params = { ...createDefaultParams(def), ...overrides };
    if (def.type === 'ImageInput' && asset?.asset_id && !params.asset_id) {
      params.asset_id = asset.asset_id;
    }

    return {
      id: `${def.type}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`,
      type: 'cvNode',
      position: position ?? { x: 220 + Math.random() * 360, y: 120 + Math.random() * 360 },
      data: {
        nodeType: def.type,
        title: nodeTitle(locale, def.type, def.title),
        category: categoryLabel(locale, def.category),
        connectHint: t(locale, 'connectHint'),
        params,
        def,
      },
      selected: true,
    };
  }, [asset?.asset_id, locale]);

  const addImageInputForAsset = useCallback((assetId: string) => {
    const imageInputDef = defMap.ImageInput;
    if (!imageInputDef) return;
    const inputNode = createNode(imageInputDef, { x: 80, y: 160 }, { asset_id: assetId });
    setNodes((nds) => nds.map((node) => ({ ...node, selected: false })).concat(inputNode));
    setEdges((eds) => eds.map((edge) => ({ ...edge, selected: false })));
    setSelectedNodeIds([inputNode.id]);
    setSelectedEdgeIds([]);
  }, [createNode, defMap.ImageInput, setEdges, setNodes]);

  const makeEdgeId = useCallback((connection: Connection) => {
    return `e_${connection.source}_${connection.sourceHandle ?? 'out'}_${connection.target}_${connection.targetHandle ?? 'in'}_${Date.now().toString(36)}`;
  }, []);

  const isValidConnection = useCallback((connection: Connection | Edge) => {
    return Boolean(connection.source && connection.target && connection.source !== connection.target);
  }, []);

  const onConnect = useCallback(
    (connection: Connection) => {
      if (!isValidConnection(connection)) return;

      setEdges((eds) => {
        // 一个输入端口默认只保留一条连线。重新连到该输入时，会自动替换旧线，方便修改工作流。
        const withoutSameTarget = eds.filter(
          (edge) => !(edge.target === connection.target && edge.targetHandle === connection.targetHandle),
        );
        return addEdge(
          {
            ...connection,
            id: makeEdgeId(connection),
            animated: true,
            type: 'smoothstep',
          },
          withoutSameTarget,
        );
      });
      setResult(null);
      setError(null);
    },
    [isValidConnection, makeEdgeId, setEdges],
  );

  const onReconnectStart = useCallback(() => {
    edgeReconnectSuccessful.current = false;
  }, []);

  const onReconnect = useCallback(
    (oldEdge: Edge, newConnection: Connection) => {
      if (!isValidConnection(newConnection)) return;
      edgeReconnectSuccessful.current = true;
      setEdges((eds) => {
        const withoutSameTarget = eds.filter(
          (edge) => edge.id === oldEdge.id || !(edge.target === newConnection.target && edge.targetHandle === newConnection.targetHandle),
        );
        return reconnectEdge(oldEdge, newConnection, withoutSameTarget);
      });
      setResult(null);
      setError(null);
    },
    [isValidConnection, setEdges],
  );

  const onReconnectEnd = useCallback((_: MouseEvent | TouchEvent, edge: Edge) => {
    if (!edgeReconnectSuccessful.current) {
      setEdges((eds) => eds.filter((candidate) => candidate.id !== edge.id));
    }
    edgeReconnectSuccessful.current = true;
  }, [setEdges]);

  const handleUpload = useCallback(async (file: File) => {
    setError(null);
    try {
      const uploaded = await uploadImage(file);
      setAsset(uploaded);
      const hasImageInput = nodes.some((node) => node.data.nodeType === 'ImageInput');

      setNodes((nds) =>
        nds.map((node) =>
          node.data.nodeType === 'ImageInput'
            ? {
                ...node,
                data: {
                  ...node.data,
                  params: { ...node.data.params, asset_id: uploaded.asset_id },
                },
              }
            : node,
        ),
      );

      if (!hasImageInput) addImageInputForAsset(uploaded.asset_id);
    } catch (err) {
      setError(String((err as Error).message ?? err));
    }
  }, [addImageInputForAsset, nodes, setNodes]);

  const handleRun = useCallback(async () => {
    setRunning(true);
    setError(null);
    try {
      const response = await runWorkflow(nodes, edges);
      setResult(response);
    } catch (err) {
      setResult(null);
      setError(String((err as Error).message ?? err));
    } finally {
      setRunning(false);
    }
  }, [nodes, edges]);

  const handleNewWorkflow = useCallback(() => {
    setNodes([]);
    setEdges([]);
    setResult(null);
    setError(null);
    setSelectedNodeIds([]);
    setSelectedEdgeIds([]);
  }, [setEdges, setNodes]);

  const handleLoadDemo = useCallback(() => {
    const demo = createDemoWorkflow(definitions, asset?.asset_id ?? null, locale);
    setNodes(demo.nodes);
    setEdges(demo.edges);
    setResult(null);
    setError(null);
    setSelectedNodeIds([]);
    setSelectedEdgeIds([]);
  }, [asset?.asset_id, definitions, locale, setEdges, setNodes]);

  const handleAddNode = useCallback((def: NodeDefinition) => {
    const newNode = createNode(def);
    setNodes((nds) => nds.map((node) => ({ ...node, selected: false })).concat(newNode));
    setEdges((eds) => eds.map((edge) => ({ ...edge, selected: false })));
    setSelectedNodeIds([newNode.id]);
    setSelectedEdgeIds([]);
    setResult(null);
    setError(null);
  }, [createNode, setEdges, setNodes]);

  const handleChangeParam = useCallback((nodeId: string, key: string, value: unknown) => {
    setNodes((nds) =>
      nds.map((node) =>
        node.id === nodeId
          ? {
              ...node,
              data: {
                ...node.data,
                params: { ...node.data.params, [key]: value },
                hasResult: false,
                lastElapsedMs: null,
                lastPreview: null,
              },
            }
          : node,
      ),
    );
    setResult(null);
  }, [setNodes]);

  const deleteByIds = useCallback((nodeIds: string[], edgeIds: string[]) => {
    if (nodeIds.length === 0 && edgeIds.length === 0) return;
    const nodeIdSet = new Set(nodeIds);
    const edgeIdSet = new Set(edgeIds);
    setNodes((nds) => nds.filter((node) => !nodeIdSet.has(node.id)));
    setEdges((eds) => eds.filter((edge) => !edgeIdSet.has(edge.id) && !nodeIdSet.has(edge.source) && !nodeIdSet.has(edge.target)));
    setSelectedNodeIds([]);
    setSelectedEdgeIds([]);
    setResult(null);
  }, [setEdges, setNodes]);

  const handleDeleteSelection = useCallback(() => {
    deleteByIds(selectedNodeIds, selectedEdgeIds);
  }, [deleteByIds, selectedEdgeIds, selectedNodeIds]);

  const handleDeleteNode = useCallback((nodeId: string) => {
    deleteByIds([nodeId], []);
  }, [deleteByIds]);

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement | null;
      const tag = target?.tagName?.toLowerCase();
      const isEditing = tag === 'input' || tag === 'textarea' || tag === 'select' || target?.isContentEditable;
      if (isEditing) return;
      if (event.key === 'Delete' || event.key === 'Backspace') {
        if (canDelete) {
          event.preventDefault();
          handleDeleteSelection();
        }
      }
    };

    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [canDelete, handleDeleteSelection]);

  useEffect(() => {
    if (definitions.length === 0) return;
    setNodes((nds) => nds.map((node) => {
      const def = defMap[node.data.nodeType];
      return {
        ...node,
        data: {
          ...node.data,
          def,
          title: def ? nodeTitle(locale, def.type, def.title) : node.data.title,
          category: def ? categoryLabel(locale, def.category) : node.data.category,
          connectHint: t(locale, 'connectHint'),
        },
      };
    }));
  }, [definitions.length, defMap, locale, setNodes]);

  return (
    <div className={`app-shell ${libraryCollapsed ? 'library-collapsed' : ''}`}>
      <Toolbar
        locale={locale}
        onLocaleChange={setLocale}
        onUpload={handleUpload}
        onRun={handleRun}
        onNewWorkflow={handleNewWorkflow}
        onLoadDemo={handleLoadDemo}
        onDeleteSelection={handleDeleteSelection}
        running={running}
        canDelete={canDelete}
        asset={asset}
      />

      <Sidebar
        definitions={definitions}
        locale={locale}
        collapsed={libraryCollapsed}
        onToggleCollapsed={() => setLibraryCollapsed((value) => !value)}
        onAddNode={handleAddNode}
      />

      <main className="main-area">
        <div className="canvas-wrap">
          <ReactFlow
            nodes={nodes}
            edges={edges}
            nodeTypes={nodeTypes}
            onNodesChange={onNodesChange}
            onEdgesChange={onEdgesChange}
            onConnect={onConnect}
            onReconnectStart={onReconnectStart}
            onReconnect={onReconnect}
            onReconnectEnd={onReconnectEnd}
            isValidConnection={isValidConnection}
            connectionMode={ConnectionMode.Loose}
            edgesReconnectable
            nodesConnectable
            elementsSelectable
            defaultEdgeOptions={{ animated: true, type: 'smoothstep' }}
            onNodeClick={(_, node) => {
              setSelectedNodeIds([node.id]);
              setSelectedEdgeIds([]);
            }}
            onEdgeClick={(_, edge) => {
              setSelectedNodeIds([]);
              setSelectedEdgeIds([edge.id]);
            }}
            onPaneClick={() => {
              setSelectedNodeIds([]);
              setSelectedEdgeIds([]);
            }}
            onSelectionChange={({ nodes: selectedNodes, edges: selectedEdges }) => {
              setSelectedNodeIds(selectedNodes.map((node) => node.id));
              setSelectedEdgeIds(selectedEdges.map((edge) => edge.id));
            }}
            fitView
          >
            <Background gap={18} />
            <Controls />
            <MiniMap pannable zoomable />
          </ReactFlow>
          <div className="canvas-hint">{t(locale, 'canvasHint')}</div>
        </div>
      </main>

      <aside className="right-workbench">
        <ParamsPanel locale={locale} node={selectedNode} onChangeParam={handleChangeParam} onDeleteNode={handleDeleteNode} />
        <PreviewPanel locale={locale} selectedNode={selectedNode} result={result} error={error} />
      </aside>
    </div>
  );
}

function createDemoWorkflow(defs: NodeDefinition[], assetId: string | null, locale: Locale) {
  const byType = Object.fromEntries(defs.map((def) => [def.type, def]));

  const make = (id: string, type: string, x: number, y: number, overrides: Record<string, unknown> = {}): CvFlowNode => {
    const def = byType[type];
    return {
      id,
      type: 'cvNode',
      position: { x, y },
      data: {
        nodeType: type,
        title: def ? nodeTitle(locale, def.type, def.title) : type,
        category: def ? categoryLabel(locale, def.category) : 'Unknown',
        connectHint: t(locale, 'connectHint'),
        params: { ...(def ? createDefaultParams(def) : {}), ...overrides },
        def,
      },
    };
  };

  const nodes = [
    make('input_1', 'ImageInput', 60, 180, { asset_id: assetId ?? '' }),
    make('gray_1', 'CvtColor', 330, 180, { code: 'BGR2GRAY' }),
    make('blur_1', 'GaussianBlur', 600, 180, { ksize: 5, sigmaX: 0 }),
    make('canny_1', 'Canny', 870, 180, { threshold1: 80, threshold2: 160, apertureSize: 3, L2gradient: false }),
    make('preview_1', 'Preview', 1140, 180),
  ];

  const edges: CvFlowEdge[] = [
    { id: 'e_input_gray', source: 'input_1', sourceHandle: 'image', target: 'gray_1', targetHandle: 'image', animated: true },
    { id: 'e_gray_blur', source: 'gray_1', sourceHandle: 'image', target: 'blur_1', targetHandle: 'image', animated: true },
    { id: 'e_blur_canny', source: 'blur_1', sourceHandle: 'image', target: 'canny_1', targetHandle: 'image', animated: true },
    { id: 'e_canny_preview', source: 'canny_1', sourceHandle: 'edges', target: 'preview_1', targetHandle: 'image', animated: true },
  ];

  return { nodes, edges };
}
