export type Locale = 'zh' | 'en';

const ui = {
  zh: {
    appSubtitle: 'OpenCV 节点式图像处理工作台',
    uploadImage: '上传图片',
    runWorkflow: '运行工作流',
    running: '运行中...',
    newWorkflow: '新建空白',
    loadDemo: '加载示例',
    deleteSelection: '删除选中',
    deleteNode: '删除节点',
    noSelectionToDelete: '请先选择节点或连线',
    language: '语言',
    algorithmLibrary: '算法库',
    algorithmLibraryHint: '按类别折叠管理；点击算子添加到画布。',
    searchNodes: '搜索节点...',
    params: '参数',
    selectNodeForParams: '选择一个节点查看参数。',
    noParams: '该节点没有可调参数。',
    preview: '预览',
    uploadAndRun: '上传图片，连接节点，然后点击“运行工作流”。运行后点击任意节点可查看该节点输出。',
    selectedOutput: '当前节点输出',
    latestImageOutput: '最近图像输出',
    canvasHint: '从左侧添加算子，鼠标移到节点上会显示输入/输出端口；从右侧输出端口拖到左侧输入端口完成连接。',
    connectHint: '拖动端口连接节点',
    imageInputUpdated: '图片已绑定到 ImageInput 节点',
    aiComingSoon: 'YOLO/AI 接口已预留，后续可接入 ultralytics、ONNXRuntime 或 OpenVINO。',
    collapseLibrary: '折叠算法库',
    expandLibrary: '展开算法库',
    operators: '算子',
    nodeResults: '节点执行结果',
    dataOutputs: '数据输出',
    noImageOutput: '当前节点没有图像输出，可查看下方数据输出。',
  },
  en: {
    appSubtitle: 'Node-based OpenCV image processing workbench',
    uploadImage: 'Upload image',
    runWorkflow: 'Run workflow',
    running: 'Running...',
    newWorkflow: 'New blank',
    loadDemo: 'Load demo',
    deleteSelection: 'Delete selected',
    deleteNode: 'Delete node',
    noSelectionToDelete: 'Select a node or edge first',
    language: 'Language',
    algorithmLibrary: 'Algorithm library',
    algorithmLibraryHint: 'Grouped by category; click an operator to add it to the canvas.',
    searchNodes: 'Search nodes...',
    params: 'Parameters',
    selectNodeForParams: 'Select a node to edit parameters.',
    noParams: 'This node has no editable parameters.',
    preview: 'Preview',
    uploadAndRun: 'Upload an image, connect nodes, then click “Run workflow”. Select any node to inspect its output.',
    selectedOutput: 'Selected node output',
    latestImageOutput: 'Latest image output',
    canvasHint: 'Add operators from the left. Hover a node to reveal input/output ports; drag an output port to an input port to connect.',
    connectHint: 'Drag ports to connect',
    imageInputUpdated: 'Image bound to ImageInput node',
    aiComingSoon: 'YOLO/AI extension points are ready for ultralytics, ONNXRuntime, or OpenVINO.',
    collapseLibrary: 'Collapse library',
    expandLibrary: 'Expand library',
    operators: 'Operators',
    nodeResults: 'Node results',
    dataOutputs: 'Data outputs',
    noImageOutput: 'The selected node has no image output. Check data outputs below.',
  },
} satisfies Record<Locale, Record<string, string>>;

export function t(locale: Locale, key: keyof typeof ui.zh): string {
  return ui[locale][key] ?? ui.zh[key] ?? key;
}

const categoryLabels: Record<Locale, Record<string, string>> = {
  zh: {
    IO: '输入 / 输出',
    Basic: '基础处理',
    Filter: '滤波降噪',
    Edge: '边缘检测',
    Threshold: '阈值分割',
    Morphology: '形态学',
    Contours: '轮廓分析',
    Contour: '轮廓分析',
    'AI / YOLO': 'AI / YOLO',
  },
  en: {
    IO: 'Input / Output',
    Basic: 'Basic processing',
    Filter: 'Filtering',
    Edge: 'Edge detection',
    Threshold: 'Thresholding',
    Morphology: 'Morphology',
    Contours: 'Contour analysis',
    Contour: 'Contour analysis',
    'AI / YOLO': 'AI / YOLO',
  },
};

const nodeTitles: Record<Locale, Record<string, string>> = {
  zh: {
    ImageInput: '图像输入',
    Preview: '预览',
    CvtColor: '颜色空间转换',
    GaussianBlur: '高斯模糊',
    MedianBlur: '中值滤波',
    Canny: 'Canny 边缘',
    Threshold: '固定阈值',
    AdaptiveThreshold: '自适应阈值',
    Resize: '缩放',
    Erode: '腐蚀',
    Dilate: '膨胀',
    MorphologyEx: '形态学操作',
    FindContours: '查找轮廓',
    FilterContours: '筛选轮廓',
    DrawContours: '绘制轮廓',
    YOLODetect: 'YOLO 检测',
  },
  en: {
    ImageInput: 'Image Input',
    Preview: 'Preview',
    CvtColor: 'Convert Color',
    GaussianBlur: 'Gaussian Blur',
    MedianBlur: 'Median Blur',
    Canny: 'Canny Edge',
    Threshold: 'Threshold',
    AdaptiveThreshold: 'Adaptive Threshold',
    Resize: 'Resize',
    Erode: 'Erode',
    Dilate: 'Dilate',
    MorphologyEx: 'Morphology Ex',
    FindContours: 'Find Contours',
    FilterContours: 'Filter Contours',
    DrawContours: 'Draw Contours',
    YOLODetect: 'YOLO Detect',
  },
};

const nodeDescriptions: Record<Locale, Record<string, string>> = {
  zh: {
    ImageInput: '从上传资源读取图像。',
    Preview: '用于标记和查看工作流输出。',
    CvtColor: '颜色空间转换。',
    GaussianBlur: '高斯模糊，常用于降噪和平滑。',
    MedianBlur: '中值滤波，适合椒盐噪声。',
    Canny: 'Canny 边缘检测，建议输入灰度图。',
    Threshold: '固定阈值或 Otsu 阈值分割。',
    AdaptiveThreshold: '根据局部邻域自适应计算阈值。',
    Resize: '按比例缩放图像。',
    Erode: '腐蚀操作，收缩白色区域。',
    Dilate: '膨胀操作，扩张白色区域。',
    MorphologyEx: '开运算、闭运算、梯度、顶帽、黑帽等形态学操作。',
    FindContours: '从二值图中查找轮廓。',
    FilterContours: '按面积筛选轮廓。',
    DrawContours: '把轮廓绘制回图像。',
    YOLODetect: 'YOLO 推理接口占位节点，后续可接入 ultralytics、ONNXRuntime 或 OpenVINO。',
  },
  en: {
    ImageInput: 'Read an uploaded image asset.',
    Preview: 'Mark and inspect a workflow output.',
    CvtColor: 'Convert image color space.',
    GaussianBlur: 'Gaussian blur for denoising and smoothing.',
    MedianBlur: 'Median filtering, useful for salt-and-pepper noise.',
    Canny: 'Canny edge detection. Grayscale input is recommended.',
    Threshold: 'Fixed or Otsu thresholding.',
    AdaptiveThreshold: 'Adaptive local thresholding.',
    Resize: 'Scale an image by ratio.',
    Erode: 'Erode bright regions in a mask.',
    Dilate: 'Dilate bright regions in a mask.',
    MorphologyEx: 'Open, close, gradient, top-hat, and black-hat operations.',
    FindContours: 'Find contours from a binary image.',
    FilterContours: 'Filter contours by area.',
    DrawContours: 'Draw contours back onto an image.',
    YOLODetect: 'Reserved YOLO inference node for ultralytics, ONNXRuntime, or OpenVINO.',
  },
};

const paramLabels: Record<Locale, Record<string, string>> = {
  zh: {
    asset_id: '资源 ID',
    code: '转换方式',
    ksize: '核大小',
    sigmaX: 'Sigma X',
    threshold1: '阈值 1',
    threshold2: '阈值 2',
    apertureSize: '孔径大小',
    L2gradient: 'L2 梯度',
    thresh: '阈值',
    maxval: '最大值',
    maxValue: '最大值',
    mode: '模式',
    method: '方法',
    thresholdType: '阈值类型',
    blockSize: '块大小',
    C: '常数 C',
    scale: '缩放比例',
    interpolation: '插值方式',
    iterations: '迭代次数',
    operation: '操作',
    retrievalMode: '检索模式',
    approximation: '近似方式',
    min_area: '最小面积',
    max_area: '最大面积',
    minArea: '最小面积',
    maxArea: '最大面积',
    thickness: '线宽',
    model_path: '模型路径',
    conf: '置信度',
    iou: 'IOU 阈值',
    imgsz: '输入尺寸',
    classes: '类别过滤',
    draw_bounding_rect: '绘制外接矩形',
  },
  en: {},
};

export function categoryLabel(locale: Locale, category: string): string {
  return categoryLabels[locale][category] ?? category;
}

export function nodeTitle(locale: Locale, type: string, fallback: string): string {
  return nodeTitles[locale][type] ?? fallback;
}

export function nodeDescription(locale: Locale, type: string, fallback?: string): string {
  return nodeDescriptions[locale][type] ?? fallback ?? '';
}

export function paramLabel(locale: Locale, key: string, fallback?: string | null): string {
  if (locale === 'zh') return paramLabels.zh[key] ?? fallback ?? key;
  return fallback ?? key;
}
