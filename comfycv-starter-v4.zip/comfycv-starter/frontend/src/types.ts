import type { Edge, Node } from '@xyflow/react';

export type ParamType = 'int' | 'float' | 'bool' | 'select' | 'text';

export type PortSpec = {
  name: string;
  type: string;
  label?: string | null;
};

export type ParamSpec = {
  type: ParamType;
  default?: unknown;
  label?: string | null;
  min?: number | null;
  max?: number | null;
  step?: number | null;
  options?: unknown[] | null;
  help?: string | null;
};

export type NodeDefinition = {
  type: string;
  title: string;
  category: string;
  description: string;
  inputs: PortSpec[];
  outputs: PortSpec[];
  params: Record<string, ParamSpec>;
};

export type CvNodeData = {
  nodeType: string;
  title: string;
  category: string;
  params: Record<string, unknown>;
  def?: NodeDefinition;
  hasResult?: boolean;
  lastPreview?: string | null;
  lastElapsedMs?: number | null;
  connectHint?: string;
};

export type CvFlowNode = Node<CvNodeData, 'cvNode'>;
export type CvFlowEdge = Edge;

export type AssetUploadResponse = {
  asset_id: string;
  filename: string;
  width: number;
  height: number;
  channels: number;
  preview: string;
};

export type OutputPreview = {
  kind: 'image' | 'data';
  type: string;
  shape?: number[] | null;
  preview?: string | null;
  summary?: unknown;
};

export type NodeRunResult = {
  node_id: string;
  node_type: string;
  title: string;
  outputs: Record<string, OutputPreview>;
  elapsed_ms: number;
};

export type WorkflowRunResponse = {
  ok: boolean;
  results: Record<string, NodeRunResult>;
  execution_order: string[];
};
