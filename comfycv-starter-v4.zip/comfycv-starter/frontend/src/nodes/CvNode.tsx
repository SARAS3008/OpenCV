import { Handle, Position, type NodeProps } from '@xyflow/react';
import type { CvFlowNode, PortSpec } from '../types';

function PortLabel({ port }: { port: PortSpec }) {
  return (
    <span className="port-label-wrap" title={`${port.name}: ${port.type}`}>
      <span className="port-label">{port.label ?? port.name}</span>
      <span className="port-type">{port.type}</span>
    </span>
  );
}

export default function CvNode({ data, selected, isConnectable }: NodeProps<CvFlowNode>) {
  const inputs = data.def?.inputs ?? [];
  const outputs = data.def?.outputs ?? [];
  const hasInputs = inputs.length > 0;
  const hasOutputs = outputs.length > 0;

  return (
    <div className={`cv-node ${selected ? 'selected' : ''} ${data.hasResult ? 'has-result' : ''}`}>
      <div className="node-connect-hint">{data.connectHint ?? 'Drag ports to connect'}</div>

      <div className="cv-node-header">
        <div>
          <div className="cv-node-title">{data.title}</div>
          <div className="cv-node-category">{data.category}</div>
        </div>
        {data.lastElapsedMs != null && <div className="node-time">{data.lastElapsedMs.toFixed(1)} ms</div>}
      </div>

      {data.lastPreview && (
        <div className="node-thumb-wrap">
          <img src={data.lastPreview} className="node-thumb" alt="node preview" />
        </div>
      )}

      <div className="cv-node-ports">
        <div className="cv-node-inputs">
          {hasInputs ? (
            inputs.map((port) => (
              <div key={port.name} className="port-row input-row">
                <Handle
                  className="cv-handle cv-handle-input"
                  type="target"
                  id={port.name}
                  position={Position.Left}
                  isConnectable={isConnectable}
                  title={`Input: ${port.name} (${port.type})`}
                />
                <PortLabel port={port} />
              </div>
            ))
          ) : (
            <div className="port-row empty-row">No input</div>
          )}
        </div>

        <div className="cv-node-outputs">
          {hasOutputs ? (
            outputs.map((port) => (
              <div key={port.name} className="port-row output-row">
                <PortLabel port={port} />
                <Handle
                  className="cv-handle cv-handle-output"
                  type="source"
                  id={port.name}
                  position={Position.Right}
                  isConnectable={isConnectable}
                  title={`Output: ${port.name} (${port.type})`}
                />
              </div>
            ))
          ) : (
            <div className="port-row empty-row">No output</div>
          )}
        </div>
      </div>
    </div>
  );
}
