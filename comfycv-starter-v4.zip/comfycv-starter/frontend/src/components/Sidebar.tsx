import { useMemo, useState } from 'react';
import type { Locale } from '../i18n';
import { categoryLabel, nodeDescription, nodeTitle, t } from '../i18n';
import type { NodeDefinition } from '../types';

type Props = {
  definitions: NodeDefinition[];
  locale: Locale;
  collapsed: boolean;
  onToggleCollapsed: () => void;
  onAddNode: (def: NodeDefinition) => void;
};

const CATEGORY_ORDER = ['IO', 'Basic', 'Filter', 'Edge', 'Threshold', 'Morphology', 'Contours', 'AI / YOLO'];

export default function Sidebar({ definitions, locale, collapsed, onToggleCollapsed, onAddNode }: Props) {
  const [query, setQuery] = useState('');
  const [collapsedGroups, setCollapsedGroups] = useState<Record<string, boolean>>({});

  const groups = useMemo(() => {
    const q = query.trim().toLowerCase();
    const filtered = q
      ? definitions.filter((def) => {
          const haystack = [def.type, def.title, def.category, def.description, nodeTitle(locale, def.type, def.title), nodeDescription(locale, def.type, def.description)]
            .join(' ')
            .toLowerCase();
          return haystack.includes(q);
        })
      : definitions;

    const grouped = filtered.reduce<Record<string, NodeDefinition[]>>((acc, def) => {
      acc[def.category] ??= [];
      acc[def.category].push(def);
      return acc;
    }, {});

    return Object.entries(grouped).sort(([a], [b]) => {
      const ai = CATEGORY_ORDER.indexOf(a);
      const bi = CATEGORY_ORDER.indexOf(b);
      if (ai === -1 && bi === -1) return a.localeCompare(b);
      if (ai === -1) return 1;
      if (bi === -1) return -1;
      return ai - bi;
    });
  }, [definitions, locale, query]);

  if (collapsed) {
    return (
      <aside className="library-rail" aria-label={t(locale, 'algorithmLibrary')}>
        <button className="rail-expand-button" onClick={onToggleCollapsed} title={t(locale, 'expandLibrary')}>
          <span>›</span>
        </button>
        <div className="rail-title">{t(locale, 'operators')}</div>
        <div className="rail-count">{definitions.length}</div>
      </aside>
    );
  }

  return (
    <aside className="library-panel panel-card">
      <div className="section-title-row sticky-panel-header">
        <div>
          <h3>{t(locale, 'algorithmLibrary')}</h3>
          <p className="muted compact">{t(locale, 'algorithmLibraryHint')}</p>
        </div>
        <button className="icon-button" onClick={onToggleCollapsed} title={t(locale, 'collapseLibrary')}>
          ‹
        </button>
      </div>

      <input
        className="search-input"
        value={query}
        placeholder={t(locale, 'searchNodes')}
        onChange={(event) => setQuery(event.target.value)}
      />

      <div className="node-groups">
        {groups.map(([category, defs]) => {
          const isCollapsed = Boolean(collapsedGroups[category]);
          return (
            <section key={category} className="node-group-card">
              <button
                className="node-group-header"
                onClick={() => setCollapsedGroups((state) => ({ ...state, [category]: !state[category] }))}
              >
                <span className="chevron">{isCollapsed ? '›' : '⌄'}</span>
                <span>{categoryLabel(locale, category)}</span>
                <span className="group-count">{defs.length}</span>
              </button>

              <div className={`node-group-body ${isCollapsed ? 'collapsed' : ''}`}>
                {defs.map((def) => (
                  <button key={def.type} className="node-button" onClick={() => onAddNode(def)} title={nodeDescription(locale, def.type, def.description)}>
                    <span className="node-button-title">{nodeTitle(locale, def.type, def.title)}</span>
                    <span className="node-button-type">{def.type}</span>
                  </button>
                ))}
              </div>
            </section>
          );
        })}
      </div>
    </aside>
  );
}
