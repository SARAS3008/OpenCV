import type { Locale } from '../i18n';
import { t } from '../i18n';
import type { AssetUploadResponse } from '../types';

type Props = {
  locale: Locale;
  onLocaleChange: (locale: Locale) => void;
  onUpload: (file: File) => void;
  onRun: () => void;
  onNewWorkflow: () => void;
  onLoadDemo: () => void;
  onDeleteSelection: () => void;
  running: boolean;
  canDelete: boolean;
  asset?: AssetUploadResponse | null;
};

export default function Toolbar({ locale, onLocaleChange, onUpload, onRun, onNewWorkflow, onLoadDemo, onDeleteSelection, running, canDelete, asset }: Props) {
  return (
    <div className="toolbar">
      <div className="brand-block">
        <div className="brand-mark">CV</div>
        <div>
          <div className="brand-title">ComfyCV</div>
          <div className="brand-subtitle">{t(locale, 'appSubtitle')}</div>
        </div>
      </div>

      <div className="toolbar-actions">
        <button onClick={onNewWorkflow}>{t(locale, 'newWorkflow')}</button>
        <button onClick={onLoadDemo}>{t(locale, 'loadDemo')}</button>
        <label className="upload-btn">
          {t(locale, 'uploadImage')}
          <input
            type="file"
            accept="image/*"
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) onUpload(file);
              e.currentTarget.value = '';
            }}
          />
        </label>
        <button className="primary" onClick={onRun} disabled={running}>
          {running ? t(locale, 'running') : t(locale, 'runWorkflow')}
        </button>
        <button className="danger-soft" onClick={onDeleteSelection} disabled={!canDelete} title={canDelete ? undefined : t(locale, 'noSelectionToDelete')}>
          {t(locale, 'deleteSelection')}
        </button>
        <label className="locale-switcher">
          <span>{t(locale, 'language')}</span>
          <select value={locale} onChange={(event) => onLocaleChange(event.target.value as Locale)}>
            <option value="zh">中文</option>
            <option value="en">English</option>
          </select>
        </label>
      </div>

      {asset && (
        <span className="asset-info">
          {asset.filename} · {asset.width}×{asset.height} · {asset.channels}ch
        </span>
      )}
    </div>
  );
}
