import type { Locale } from '../i18n';
import { t } from '../i18n';
import type { CvFlowNode, NodeRunResult, WorkflowRunResponse } from '../types';

type Props = {
  locale: Locale;
  selectedNode?: CvFlowNode | null;
  result?: WorkflowRunResponse | null;
  error?: string | null;
};

export default function PreviewPanel({ locale, selectedNode, result, error }: Props) {
  const nodeResult = selectedNode ? result?.results[selectedNode.id] : pickLastImageNode(result);
  const imageOutputs = nodeResult ? Object.entries(nodeResult.outputs).filter(([, out]) => out.kind === 'image' && out.preview) : [];
  const dataOutputs = nodeResult ? Object.entries(nodeResult.outputs).filter(([, out]) => out.kind !== 'image' || !out.preview) : [];
  const runItems = result?.execution_order.map((nodeId) => result.results[nodeId]).filter(Boolean) ?? [];

  return (
    <aside className="preview-panel panel-card">
      <div className="section-title-row">
        <div>
          <h3>{t(locale, 'preview')}</h3>
          <p className="muted compact">{selectedNode ? t(locale, 'selectedOutput') : t(locale, 'latestImageOutput')}</p>
        </div>
      </div>

      {error && <div className="error-box">{error}</div>}
      {!result && !error && <p className="muted">{t(locale, 'uploadAndRun')}</p>}

      {runItems.length > 0 && (
        <div className="run-list">
          <div className="run-list-title">{t(locale, 'nodeResults')}</div>
          {runItems.map((item) => (
            <div key={item.node_id} className={`run-list-item ${selectedNode?.id === item.node_id ? 'active' : ''}`}>
              <span>{item.title}</span>
              <em>{item.elapsed_ms.toFixed(1)} ms</em>
            </div>
          ))}
        </div>
      )}

      {nodeResult && (
        <div className="result-meta">
          <strong>{nodeResult.title}</strong>
          <span>{nodeResult.elapsed_ms.toFixed(1)} ms</span>
        </div>
      )}

      {imageOutputs.length > 0 ? (
        <div className="image-preview-list">
          {imageOutputs.map(([name, output]) => (
            <div className="image-preview-wrap" key={name}>
              <div className="output-name">{name}</div>
              <img src={output.preview ?? ''} alt={`${nodeResult?.title ?? 'node'} ${name}`} className="image-preview" />
              <pre className="summary">{JSON.stringify(output.summary, null, 2)}</pre>
            </div>
          ))}
        </div>
      ) : nodeResult ? (
        <p className="muted">{t(locale, 'noImageOutput')}</p>
      ) : null}

      {dataOutputs.length > 0 && (
        <div className="data-output-block">
          <div className="run-list-title">{t(locale, 'dataOutputs')}</div>
          <pre className="summary">{JSON.stringify(Object.fromEntries(dataOutputs), null, 2)}</pre>
        </div>
      )}
    </aside>
  );
}

function pickLastImageNode(result?: WorkflowRunResponse | null): NodeRunResult | undefined {
  if (!result) return undefined;
  for (const nodeId of [...result.execution_order].reverse()) {
    const item = result.results[nodeId];
    if (Object.values(item.outputs).some((out) => out.kind === 'image' && out.preview)) return item;
  }
  return undefined;
}
