import type { Locale } from '../i18n';
import { nodeDescription, paramLabel, t } from '../i18n';
import type { CvFlowNode } from '../types';

type Props = {
  locale: Locale;
  node?: CvFlowNode | null;
  onChangeParam: (nodeId: string, key: string, value: unknown) => void;
  onDeleteNode: (nodeId: string) => void;
};

export default function ParamsPanel({ locale, node, onChangeParam, onDeleteNode }: Props) {
  if (!node) {
    return (
      <aside className="params-panel panel-card">
        <h3>{t(locale, 'params')}</h3>
        <p className="muted">{t(locale, 'selectNodeForParams')}</p>
      </aside>
    );
  }

  const def = node.data.def;
  const params = node.data.params ?? {};

  return (
    <aside className="params-panel panel-card">
      <div className="section-title-row">
        <div>
          <h3>{node.data.title}</h3>
          <p className="muted compact">{def ? nodeDescription(locale, def.type, def.description) : ''}</p>
        </div>
        <button className="icon-danger" onClick={() => onDeleteNode(node.id)} title={t(locale, 'deleteNode')}>
          ×
        </button>
      </div>

      {def && Object.entries(def.params).length === 0 && <p className="muted">{t(locale, 'noParams')}</p>}

      {def && Object.entries(def.params).map(([key, spec]) => {
        const value = params[key] ?? spec.default;
        const label = paramLabel(locale, key, spec.label);

        return (
          <label key={key} className="param-row">
            <span className="param-label">{label}</span>
            {spec.type === 'int' || spec.type === 'float' ? (
              <div className="range-row">
                <input
                  type="range"
                  min={spec.min ?? 0}
                  max={spec.max ?? 100}
                  step={spec.step ?? (spec.type === 'int' ? 1 : 0.1)}
                  value={Number(value)}
                  onChange={(e) => {
                    const raw = e.target.value;
                    onChangeParam(node.id, key, spec.type === 'int' ? parseInt(raw, 10) : parseFloat(raw));
                  }}
                />
                <input
                  className="number-input"
                  type="number"
                  min={spec.min ?? undefined}
                  max={spec.max ?? undefined}
                  step={spec.step ?? (spec.type === 'int' ? 1 : 0.1)}
                  value={Number(value)}
                  onChange={(e) => {
                    const raw = e.target.value;
                    onChangeParam(node.id, key, spec.type === 'int' ? parseInt(raw, 10) : parseFloat(raw));
                  }}
                />
              </div>
            ) : spec.type === 'bool' ? (
              <span className="switch-row">
                <input
                  type="checkbox"
                  checked={Boolean(value)}
                  onChange={(e) => onChangeParam(node.id, key, e.target.checked)}
                />
                <span>{Boolean(value) ? 'ON' : 'OFF'}</span>
              </span>
            ) : spec.type === 'select' ? (
              <select value={String(value)} onChange={(e) => onChangeParam(node.id, key, parseMaybeNumber(e.target.value))}>
                {(spec.options ?? []).map((opt) => (
                  <option key={String(opt)} value={String(opt)}>{String(opt)}</option>
                ))}
              </select>
            ) : (
              <input
                type="text"
                value={String(value ?? '')}
                onChange={(e) => onChangeParam(node.id, key, e.target.value)}
              />
            )}
            {spec.help && <small>{spec.help}</small>}
          </label>
        );
      })}
    </aside>
  );
}

function parseMaybeNumber(value: string): string | number {
  if (/^-?\d+(\.\d+)?$/.test(value)) return Number(value);
  return value;
}
