# ComfyCV Starter v3

ComfyCV is a ComfyUI-style visual workflow starter for OpenCV image processing.

本项目是一个可运行的 OpenCV 节点式图像处理工作流原型，包含：

- FastAPI + OpenCV 后端执行引擎
- React + React Flow 前端节点画布
- 左侧可折叠算子库：折叠后保留窄侧栏，不会完全消失
- 新建空白工作流、加载示例工作流
- 手动添加节点、连接任意两个节点端口
- 上传图片后自动绑定已有 ImageInput；空白画布上传时会自动添加 ImageInput
- 运行后可查看每个节点的处理结果预览图：点击节点即可在右侧预览，也会在节点卡片里显示缩略图
- 中英文界面切换
- 节点/连线删除：工具栏按钮、参数面板删除按钮、Delete / Backspace 快捷键
- OpenCV 算子注册机制
- YOLO/AI 节点接口占位，方便后续扩展

## Run backend

```bash
cd backend
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```

## Run frontend

```bash
cd frontend
npm install
npm run dev
```

Open:

```text
http://127.0.0.1:5173
```

## How to use

### 示例工作流

1. 点击 `加载示例`。
2. 上传图片。
3. 点击 `运行工作流`。
4. 点击任意节点，在右侧查看该节点输出预览。

默认示例是：

```text
ImageInput → CvtColor → GaussianBlur → Canny → Preview
```

### 新建空白工作流

1. 点击 `新建空白`。
2. 上传图片，系统会自动添加一个 `ImageInput` 节点。
3. 从左侧算子库添加节点，例如 `CvtColor`、`Canny`、`Preview`。
4. 拖动节点右侧输出端口到另一个节点左侧输入端口，即可连接两个节点。
5. 点击 `运行工作流`。
6. 点击每个节点查看该节点的处理结果。

## Add a new OpenCV node

Create a node class under `backend/app/nodes/`:

```python
from app.core.models import ParamSpec, PortSpec
from app.nodes.base import CvNode, RunContext, ensure_odd
import cv2

class BoxBlur(CvNode):
    type = "BoxBlur"
    title = "Box Blur"
    category = "Filter"
    description = "Simple box blur."
    inputs = [PortSpec(name="image", type="Image", label="Image")]
    outputs = [PortSpec(name="image", type="Image", label="Image")]
    params = {
        "ksize": ParamSpec(type="int", default=3, min=1, max=99, step=2, label="Kernel size"),
    }

    def run(self, ctx: RunContext, image, ksize=3, **_):
        k = ensure_odd(int(ksize))
        return {"image": cv2.blur(image, (k, k))}
```

Then register it in `backend/app/core/registry.py`.

The frontend will automatically read metadata from `/api/nodes` and render the parameter controls.

## YOLO extension point

`backend/app/nodes/yolo.py` contains a lightweight `YOLODetect` placeholder node. It does not require `ultralytics` unless you set `model_path` and run that node.

You can later replace its `run()` implementation with:

- `ultralytics`
- ONNXRuntime
- OpenVINO
- TensorRT
- a remote inference service

Keep the same node contract:

```text
input:  image
output: image, detections
```

## v4 更新

- 修复新建工作流中节点之间无法拖拽连线的问题。
- 节点连接点默认收起，鼠标移到节点上或选中节点后显示输入/输出端口。
- 端口显示名称和数据类型，便于后续扩展更多 OpenCV / YOLO 节点。
- 一个输入端口重新连接时会自动替换旧连线，便于修改工作流。
- 支持拖动已有连线端点进行重连；拖到空白处会删除该连线。
