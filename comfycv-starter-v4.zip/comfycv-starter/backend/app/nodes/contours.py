from __future__ import annotations

from typing import Any

import cv2
import numpy as np

from app.core.models import ParamSpec, PortSpec
from app.nodes.base import CvNode, RunContext


class FindContours(CvNode):
    type = "FindContours"
    title = "Find Contours"
    category = "Contours"
    description = "从二值图中查找轮廓。"
    inputs = [PortSpec(name="mask", type="Image.Mask", label="Mask")]
    outputs = [
        PortSpec(name="contours", type="Contours", label="Contours"),
        PortSpec(name="debug", type="Image.BGR", label="Debug"),
    ]
    params = {
        "mode": ParamSpec(type="select", default="EXTERNAL", options=["EXTERNAL", "LIST", "TREE", "CCOMP"], label="Mode"),
        "method": ParamSpec(type="select", default="SIMPLE", options=["SIMPLE", "NONE"], label="Method"),
    }

    MODES = {
        "EXTERNAL": cv2.RETR_EXTERNAL,
        "LIST": cv2.RETR_LIST,
        "TREE": cv2.RETR_TREE,
        "CCOMP": cv2.RETR_CCOMP,
    }
    METHODS = {
        "SIMPLE": cv2.CHAIN_APPROX_SIMPLE,
        "NONE": cv2.CHAIN_APPROX_NONE,
    }

    def run(self, ctx: RunContext, mask, mode="EXTERNAL", method="SIMPLE", **_: Any) -> dict[str, Any]:
        if mask.ndim == 3:
            mask = cv2.cvtColor(mask, cv2.COLOR_BGR2GRAY)
        contours, _hierarchy = cv2.findContours(mask, self.MODES[mode], self.METHODS[method])
        debug = cv2.cvtColor(mask, cv2.COLOR_GRAY2BGR)
        cv2.drawContours(debug, contours, -1, (0, 255, 0), 2)
        return {"contours": list(contours), "debug": debug}


class FilterContours(CvNode):
    type = "FilterContours"
    title = "Filter Contours"
    category = "Contours"
    description = "按面积过滤轮廓。"
    inputs = [PortSpec(name="contours", type="Contours", label="Contours")]
    outputs = [PortSpec(name="contours", type="Contours", label="Contours")]
    params = {
        "min_area": ParamSpec(type="float", default=100.0, min=0, max=1000000, step=10, label="Min area"),
        "max_area": ParamSpec(type="float", default=1000000.0, min=0, max=10000000, step=100, label="Max area"),
    }

    def run(self, ctx: RunContext, contours, min_area=100.0, max_area=1000000.0, **_: Any) -> dict[str, Any]:
        result = []
        for c in contours:
            area = cv2.contourArea(c)
            if float(min_area) <= area <= float(max_area):
                result.append(c)
        return {"contours": result}


class DrawContours(CvNode):
    type = "DrawContours"
    title = "Draw Contours"
    category = "Contours"
    description = "把轮廓绘制到图像上。"
    inputs = [
        PortSpec(name="image", type="Image", label="Image"),
        PortSpec(name="contours", type="Contours", label="Contours"),
    ]
    outputs = [PortSpec(name="image", type="Image.BGR", label="Image")]
    params = {
        "thickness": ParamSpec(type="int", default=2, min=-1, max=20, step=1, label="Thickness"),
        "draw_bounding_rect": ParamSpec(type="bool", default=True, label="Draw bounding rect"),
    }

    def run(self, ctx: RunContext, image, contours, thickness=2, draw_bounding_rect=True, **_: Any) -> dict[str, Any]:
        if image.ndim == 2:
            out = cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
        else:
            out = image.copy()
        cv2.drawContours(out, contours, -1, (0, 255, 0), int(thickness))
        if draw_bounding_rect:
            for c in contours:
                x, y, w, h = cv2.boundingRect(c)
                cv2.rectangle(out, (x, y), (x + w, y + h), (0, 0, 255), 2)
        return {"image": out}
