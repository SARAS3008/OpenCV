from __future__ import annotations

from typing import Any

from app.core.models import ParamSpec, PortSpec
from app.nodes.base import CvNode, RunContext


class ImageInput(CvNode):
    type = "ImageInput"
    title = "Image Input"
    category = "IO"
    description = "从上传的图片资产中读取 OpenCV 图像。"
    inputs = []
    outputs = [PortSpec(name="image", type="Image.BGR", label="Image")]
    params = {
        "asset_id": ParamSpec(type="text", default="", label="Asset ID", help="上传图片后自动填入")
    }

    def run(self, ctx: RunContext, asset_id: str = "", **_: Any) -> dict[str, Any]:
        if not asset_id:
            raise ValueError("ImageInput 缺少 asset_id，请先上传图片")
        image = ctx.image_store.load(asset_id)
        return {"image": image}


class Preview(CvNode):
    type = "Preview"
    title = "Preview"
    category = "IO"
    description = "预览输入图像，输出保持不变。"
    inputs = [PortSpec(name="image", type="Image", label="Image")]
    outputs = [PortSpec(name="image", type="Image", label="Image")]
    params = {}

    def run(self, ctx: RunContext, image, **_: Any) -> dict[str, Any]:
        return {"image": image}
