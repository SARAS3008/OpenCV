from __future__ import annotations

from typing import Any

import cv2
import numpy as np

from app.core.models import ParamSpec, PortSpec
from app.nodes.base import CvNode, RunContext, ensure_odd


class CvtColor(CvNode):
    type = "CvtColor"
    title = "Convert Color"
    category = "Basic"
    description = "颜色空间转换。"
    inputs = [PortSpec(name="image", type="Image", label="Image")]
    outputs = [PortSpec(name="image", type="Image", label="Image")]
    params = {
        "code": ParamSpec(
            type="select",
            default="BGR2GRAY",
            label="Code",
            options=["BGR2GRAY", "GRAY2BGR", "BGR2RGB", "RGB2BGR", "BGR2HSV", "HSV2BGR", "BGR2LAB", "LAB2BGR"],
        )
    }

    CODES = {
        "BGR2GRAY": cv2.COLOR_BGR2GRAY,
        "GRAY2BGR": cv2.COLOR_GRAY2BGR,
        "BGR2RGB": cv2.COLOR_BGR2RGB,
        "RGB2BGR": cv2.COLOR_RGB2BGR,
        "BGR2HSV": cv2.COLOR_BGR2HSV,
        "HSV2BGR": cv2.COLOR_HSV2BGR,
        "BGR2LAB": cv2.COLOR_BGR2LAB,
        "LAB2BGR": cv2.COLOR_LAB2BGR,
    }

    def run(self, ctx: RunContext, image, code="BGR2GRAY", **_: Any) -> dict[str, Any]:
        return {"image": cv2.cvtColor(image, self.CODES[code])}


class GaussianBlur(CvNode):
    type = "GaussianBlur"
    title = "Gaussian Blur"
    category = "Filter"
    description = "高斯模糊。ksize 必须是正奇数。"
    inputs = [PortSpec(name="image", type="Image", label="Image")]
    outputs = [PortSpec(name="image", type="Image", label="Image")]
    params = {
        "ksize": ParamSpec(type="int", default=5, min=1, max=99, step=2, label="Kernel size"),
        "sigmaX": ParamSpec(type="float", default=0.0, min=0, max=50, step=0.1, label="Sigma X"),
    }

    def run(self, ctx: RunContext, image, ksize=5, sigmaX=0.0, **_: Any) -> dict[str, Any]:
        k = ensure_odd(int(ksize))
        return {"image": cv2.GaussianBlur(image, (k, k), float(sigmaX))}


class MedianBlur(CvNode):
    type = "MedianBlur"
    title = "Median Blur"
    category = "Filter"
    description = "中值滤波，适合椒盐噪声。"
    inputs = [PortSpec(name="image", type="Image", label="Image")]
    outputs = [PortSpec(name="image", type="Image", label="Image")]
    params = {
        "ksize": ParamSpec(type="int", default=5, min=1, max=99, step=2, label="Kernel size"),
    }

    def run(self, ctx: RunContext, image, ksize=5, **_: Any) -> dict[str, Any]:
        return {"image": cv2.medianBlur(image, ensure_odd(int(ksize)))}


class Canny(CvNode):
    type = "Canny"
    title = "Canny"
    category = "Edge"
    description = "Canny 边缘检测。建议输入灰度图。"
    inputs = [PortSpec(name="image", type="Image", label="Image")]
    outputs = [PortSpec(name="edges", type="Image.Mask", label="Edges")]
    params = {
        "threshold1": ParamSpec(type="int", default=80, min=0, max=500, step=1, label="Threshold 1"),
        "threshold2": ParamSpec(type="int", default=160, min=0, max=500, step=1, label="Threshold 2"),
        "apertureSize": ParamSpec(type="select", default=3, options=[3, 5, 7], label="Aperture size"),
        "L2gradient": ParamSpec(type="bool", default=False, label="L2 gradient"),
    }

    def run(self, ctx: RunContext, image, threshold1=80, threshold2=160, apertureSize=3, L2gradient=False, **_: Any) -> dict[str, Any]:
        if image.ndim == 3:
            image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        edges = cv2.Canny(image, int(threshold1), int(threshold2), apertureSize=int(apertureSize), L2gradient=bool(L2gradient))
        return {"edges": edges}


class Threshold(CvNode):
    type = "Threshold"
    title = "Threshold"
    category = "Threshold"
    description = "固定阈值 / Otsu 阈值。"
    inputs = [PortSpec(name="image", type="Image", label="Image")]
    outputs = [PortSpec(name="mask", type="Image.Mask", label="Mask")]
    params = {
        "thresh": ParamSpec(type="int", default=127, min=0, max=255, step=1, label="Threshold"),
        "maxval": ParamSpec(type="int", default=255, min=0, max=255, step=1, label="Max value"),
        "mode": ParamSpec(type="select", default="BINARY", options=["BINARY", "BINARY_INV", "TRUNC", "TOZERO", "TOZERO_INV", "OTSU"], label="Mode"),
    }

    MODES = {
        "BINARY": cv2.THRESH_BINARY,
        "BINARY_INV": cv2.THRESH_BINARY_INV,
        "TRUNC": cv2.THRESH_TRUNC,
        "TOZERO": cv2.THRESH_TOZERO,
        "TOZERO_INV": cv2.THRESH_TOZERO_INV,
        "OTSU": cv2.THRESH_BINARY | cv2.THRESH_OTSU,
    }

    def run(self, ctx: RunContext, image, thresh=127, maxval=255, mode="BINARY", **_: Any) -> dict[str, Any]:
        if image.ndim == 3:
            image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        _, mask = cv2.threshold(image, int(thresh), int(maxval), self.MODES[mode])
        return {"mask": mask}


class AdaptiveThreshold(CvNode):
    type = "AdaptiveThreshold"
    title = "Adaptive Threshold"
    category = "Threshold"
    description = "自适应阈值。"
    inputs = [PortSpec(name="image", type="Image", label="Image")]
    outputs = [PortSpec(name="mask", type="Image.Mask", label="Mask")]
    params = {
        "maxValue": ParamSpec(type="int", default=255, min=0, max=255, step=1, label="Max value"),
        "method": ParamSpec(type="select", default="GAUSSIAN_C", options=["MEAN_C", "GAUSSIAN_C"], label="Method"),
        "thresholdType": ParamSpec(type="select", default="BINARY", options=["BINARY", "BINARY_INV"], label="Type"),
        "blockSize": ParamSpec(type="int", default=11, min=3, max=99, step=2, label="Block size"),
        "C": ParamSpec(type="float", default=2.0, min=-50, max=50, step=0.5, label="C"),
    }

    def run(self, ctx: RunContext, image, maxValue=255, method="GAUSSIAN_C", thresholdType="BINARY", blockSize=11, C=2.0, **_: Any) -> dict[str, Any]:
        if image.ndim == 3:
            image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        method_cv = cv2.ADAPTIVE_THRESH_GAUSSIAN_C if method == "GAUSSIAN_C" else cv2.ADAPTIVE_THRESH_MEAN_C
        type_cv = cv2.THRESH_BINARY_INV if thresholdType == "BINARY_INV" else cv2.THRESH_BINARY
        mask = cv2.adaptiveThreshold(image, int(maxValue), method_cv, type_cv, ensure_odd(int(blockSize), 3), float(C))
        return {"mask": mask}


class Resize(CvNode):
    type = "Resize"
    title = "Resize"
    category = "Basic"
    description = "按比例缩放图像。"
    inputs = [PortSpec(name="image", type="Image", label="Image")]
    outputs = [PortSpec(name="image", type="Image", label="Image")]
    params = {
        "scale": ParamSpec(type="float", default=0.5, min=0.05, max=4.0, step=0.05, label="Scale"),
        "interpolation": ParamSpec(type="select", default="AREA", options=["NEAREST", "LINEAR", "AREA", "CUBIC", "LANCZOS4"], label="Interpolation"),
    }

    INTERP = {
        "NEAREST": cv2.INTER_NEAREST,
        "LINEAR": cv2.INTER_LINEAR,
        "AREA": cv2.INTER_AREA,
        "CUBIC": cv2.INTER_CUBIC,
        "LANCZOS4": cv2.INTER_LANCZOS4,
    }

    def run(self, ctx: RunContext, image, scale=0.5, interpolation="AREA", **_: Any) -> dict[str, Any]:
        s = float(scale)
        h, w = image.shape[:2]
        return {"image": cv2.resize(image, (max(1, int(w * s)), max(1, int(h * s))), interpolation=self.INTERP[interpolation])}
