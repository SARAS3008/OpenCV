from __future__ import annotations

from typing import Any

import cv2

from app.core.models import ParamSpec, PortSpec
from app.nodes.base import CvNode, RunContext


class YOLODetect(CvNode):
    """YOLO interface placeholder.

    This node is intentionally lightweight: it does not require ultralytics unless
    a model path is provided and the node is executed. You can later replace this
    implementation with ultralytics, ONNXRuntime, OpenVINO, TensorRT, or your own
    inference service while keeping the same node contract.
    """

    type = "YOLODetect"
    title = "YOLO Detect"
    category = "AI / YOLO"
    description = "预留 YOLO 检测接口。填写 model_path 后可接入 ultralytics；也可以替换为 ONNXRuntime/OpenVINO。"
    inputs = [PortSpec(name="image", type="Image", label="Image")]
    outputs = [
        PortSpec(name="image", type="Image.BGR", label="Preview"),
        PortSpec(name="detections", type="Detections", label="Detections"),
    ]
    params = {
        "model_path": ParamSpec(type="text", default="", label="Model path", help="例如 yolov8n.pt / best.pt。留空时只输出原图和空检测结果。"),
        "conf": ParamSpec(type="float", default=0.25, min=0.01, max=1.0, step=0.01, label="Confidence"),
        "iou": ParamSpec(type="float", default=0.45, min=0.01, max=1.0, step=0.01, label="IOU"),
        "imgsz": ParamSpec(type="int", default=640, min=64, max=2048, step=32, label="Image size"),
        "classes": ParamSpec(type="text", default="", label="Classes", help="可选：逗号分隔类别 ID，例如 0,1,2。"),
    }

    def run(self, ctx: RunContext, image, model_path="", conf=0.25, iou=0.45, imgsz=640, classes="", **_: Any) -> dict[str, Any]:
        preview = image.copy()
        if not model_path:
            return {
                "image": preview,
                "detections": {
                    "count": 0,
                    "items": [],
                    "message": "YOLODetect is a reserved interface. Set model_path and install an inference backend to enable detection.",
                },
            }

        try:
            from ultralytics import YOLO  # type: ignore
        except Exception as exc:  # pragma: no cover - optional dependency
            raise RuntimeError("未安装 ultralytics。请执行：pip install ultralytics，或把 YOLODetect 替换为 ONNXRuntime/OpenVINO 实现。") from exc

        class_filter = _parse_classes(classes)
        model = YOLO(str(model_path))
        results = model.predict(image, conf=float(conf), iou=float(iou), imgsz=int(imgsz), classes=class_filter, verbose=False)

        detections: list[dict[str, Any]] = []
        names = getattr(model, "names", {}) or {}
        for result in results:
            boxes = getattr(result, "boxes", None)
            if boxes is None:
                continue
            for box in boxes:
                xyxy = box.xyxy[0].detach().cpu().numpy().tolist()
                cls_id = int(box.cls[0].detach().cpu().item()) if box.cls is not None else -1
                score = float(box.conf[0].detach().cpu().item()) if box.conf is not None else 0.0
                x1, y1, x2, y2 = [int(v) for v in xyxy]
                label = str(names.get(cls_id, cls_id))
                detections.append({"box": [x1, y1, x2, y2], "class_id": cls_id, "label": label, "confidence": score})
                cv2.rectangle(preview, (x1, y1), (x2, y2), (0, 255, 0), 2)
                cv2.putText(preview, f"{label} {score:.2f}", (x1, max(0, y1 - 6)), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)

        return {"image": preview, "detections": {"count": len(detections), "items": detections}}


def _parse_classes(value: Any):
    text = str(value or "").strip()
    if not text:
        return None
    result: list[int] = []
    for item in text.split(","):
        item = item.strip()
        if not item:
            continue
        result.append(int(item))
    return result
