from __future__ import annotations

from typing import Any

from app.core.models import NodeDefinition, ParamSpec, PortSpec


class RunContext:
    def __init__(self, image_store) -> None:
        self.image_store = image_store


class CvNode:
    type: str = "CvNode"
    title: str = "CV Node"
    category: str = "Base"
    description: str = ""
    inputs: list[PortSpec] = []
    outputs: list[PortSpec] = []
    params: dict[str, ParamSpec] = {}

    @classmethod
    def definition(cls) -> NodeDefinition:
        return NodeDefinition(
            type=cls.type,
            title=cls.title,
            category=cls.category,
            description=cls.description,
            inputs=cls.inputs,
            outputs=cls.outputs,
            params=cls.params,
        )

    def run(self, ctx: RunContext, **kwargs: Any) -> dict[str, Any]:
        raise NotImplementedError


def ensure_odd(value: int, minimum: int = 1) -> int:
    value = max(int(value), minimum)
    if value % 2 == 0:
        value += 1
    return value


def clamp_int(value: Any, low: int, high: int) -> int:
    return max(low, min(high, int(value)))
