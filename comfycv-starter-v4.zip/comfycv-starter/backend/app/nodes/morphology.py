from __future__ import annotations

from typing import Any

import cv2
import numpy as np

from app.core.models import ParamSpec, PortSpec
from app.nodes.base import CvNode, RunContext


def kernel(shape: str, ksize: int) -> np.ndarray:
    ksize = max(1, int(ksize))
    if shape == "ELLIPSE":
        flag = cv2.MORPH_ELLIPSE
    elif shape == "CROSS":
        flag = cv2.MORPH_CROSS
    else:
        flag = cv2.MORPH_RECT
    return cv2.getStructuringElement(flag, (ksize, ksize))


class Erode(CvNode):
    type = "Erode"
    title = "Erode"
    category = "Morphology"
    description = "腐蚀。"
    inputs = [PortSpec(name="image", type="Image", label="Image")]
    outputs = [PortSpec(name="image", type="Image", label="Image")]
    params = {
        "ksize": ParamSpec(type="int", default=3, min=1, max=99, step=1, label="Kernel size"),
        "iterations": ParamSpec(type="int", default=1, min=1, max=20, step=1, label="Iterations"),
        "shape": ParamSpec(type="select", default="RECT", options=["RECT", "ELLIPSE", "CROSS"], label="Kernel shape"),
    }

    def run(self, ctx: RunContext, image, ksize=3, iterations=1, shape="RECT", **_: Any) -> dict[str, Any]:
        return {"image": cv2.erode(image, kernel(shape, int(ksize)), iterations=int(iterations))}


class Dilate(CvNode):
    type = "Dilate"
    title = "Dilate"
    category = "Morphology"
    description = "膨胀。"
    inputs = [PortSpec(name="image", type="Image", label="Image")]
    outputs = [PortSpec(name="image", type="Image", label="Image")]
    params = {
        "ksize": ParamSpec(type="int", default=3, min=1, max=99, step=1, label="Kernel size"),
        "iterations": ParamSpec(type="int", default=1, min=1, max=20, step=1, label="Iterations"),
        "shape": ParamSpec(type="select", default="RECT", options=["RECT", "ELLIPSE", "CROSS"], label="Kernel shape"),
    }

    def run(self, ctx: RunContext, image, ksize=3, iterations=1, shape="RECT", **_: Any) -> dict[str, Any]:
        return {"image": cv2.dilate(image, kernel(shape, int(ksize)), iterations=int(iterations))}


class MorphologyEx(CvNode):
    type = "MorphologyEx"
    title = "Morphology Ex"
    category = "Morphology"
    description = "开运算、闭运算、形态学梯度、顶帽、黑帽。"
    inputs = [PortSpec(name="image", type="Image", label="Image")]
    outputs = [PortSpec(name="image", type="Image", label="Image")]
    params = {
        "op": ParamSpec(type="select", default="OPEN", options=["OPEN", "CLOSE", "GRADIENT", "TOPHAT", "BLACKHAT"], label="Operation"),
        "ksize": ParamSpec(type="int", default=3, min=1, max=99, step=1, label="Kernel size"),
        "iterations": ParamSpec(type="int", default=1, min=1, max=20, step=1, label="Iterations"),
        "shape": ParamSpec(type="select", default="RECT", options=["RECT", "ELLIPSE", "CROSS"], label="Kernel shape"),
    }

    OPS = {
        "OPEN": cv2.MORPH_OPEN,
        "CLOSE": cv2.MORPH_CLOSE,
        "GRADIENT": cv2.MORPH_GRADIENT,
        "TOPHAT": cv2.MORPH_TOPHAT,
        "BLACKHAT": cv2.MORPH_BLACKHAT,
    }

    def run(self, ctx: RunContext, image, op="OPEN", ksize=3, iterations=1, shape="RECT", **_: Any) -> dict[str, Any]:
        out = cv2.morphologyEx(image, self.OPS[op], kernel(shape, int(ksize)), iterations=int(iterations))
        return {"image": out}
