from __future__ import annotations

import hashlib
import os
import uuid
from dataclasses import dataclass
from pathlib import Path

import cv2
import numpy as np


@dataclass
class ImageAsset:
    asset_id: str
    filename: str
    path: Path
    width: int
    height: int
    channels: int


class ImageStore:
    def __init__(self, root: str | os.PathLike[str] = "./runtime_assets") -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self._assets: dict[str, ImageAsset] = {}

    def save_upload(self, filename: str, content: bytes) -> tuple[ImageAsset, np.ndarray]:
        arr = np.frombuffer(content, dtype=np.uint8)
        image = cv2.imdecode(arr, cv2.IMREAD_UNCHANGED)
        if image is None:
            raise ValueError("无法读取图片，请确认文件是 jpg/png/webp/bmp 等 OpenCV 支持的格式")

        if image.ndim == 2:
            channels = 1
        else:
            channels = int(image.shape[2])

        asset_id = self._make_asset_id(filename, content)
        ext = Path(filename).suffix.lower() or ".png"
        safe_path = self.root / f"{asset_id}{ext}"
        cv2.imwrite(str(safe_path), image)

        height, width = image.shape[:2]
        asset = ImageAsset(
            asset_id=asset_id,
            filename=filename,
            path=safe_path,
            width=int(width),
            height=int(height),
            channels=channels,
        )
        self._assets[asset_id] = asset
        return asset, image

    def load(self, asset_id: str) -> np.ndarray:
        asset = self._assets.get(asset_id)
        if asset is None:
            # 允许服务重启后，从磁盘尝试按 asset_id 查找
            matches = list(self.root.glob(f"{asset_id}.*"))
            if not matches:
                raise KeyError(f"图片资产不存在: {asset_id}")
            path = matches[0]
        else:
            path = asset.path

        image = cv2.imread(str(path), cv2.IMREAD_UNCHANGED)
        if image is None:
            raise ValueError(f"图片资产读取失败: {asset_id}")
        return image

    @staticmethod
    def _make_asset_id(filename: str, content: bytes) -> str:
        h = hashlib.sha1()
        h.update(filename.encode("utf-8", errors="ignore"))
        h.update(content[:1024 * 1024])
        return f"img_{uuid.uuid4().hex[:8]}_{h.hexdigest()[:10]}"
