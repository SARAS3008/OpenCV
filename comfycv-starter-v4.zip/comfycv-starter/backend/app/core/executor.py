from __future__ import annotations

import time
from collections import defaultdict, deque
from typing import Any

from app.core.models import NodeRunResult, OutputPreview, WorkflowRequest
from app.core.preview import image_to_data_url, is_image_like, summarize_value
from app.core.registry import registry
from app.nodes.base import RunContext


class WorkflowExecutionError(RuntimeError):
    pass


class WorkflowExecutor:
    def __init__(self, image_store) -> None:
        self.image_store = image_store

    def run(self, workflow: WorkflowRequest):
        node_map = {n.id: n for n in workflow.nodes}
        if len(node_map) != len(workflow.nodes):
            raise WorkflowExecutionError("工作流中存在重复 node id")

        order = self._topological_order(workflow)
        incoming = defaultdict(list)
        for edge in workflow.edges:
            incoming[edge.to_node].append(edge)

        ctx = RunContext(image_store=self.image_store)
        raw_outputs: dict[str, dict[str, Any]] = {}
        results: dict[str, NodeRunResult] = {}

        for node_id in order:
            node = node_map[node_id]
            node_cls = registry.get(node.type)
            node_instance = node_cls()

            kwargs: dict[str, Any] = dict(node.params)
            for edge in incoming[node_id]:
                if edge.from_node not in raw_outputs:
                    raise WorkflowExecutionError(f"上游节点尚未执行: {edge.from_node}")
                source_outputs = raw_outputs[edge.from_node]
                if edge.from_output not in source_outputs:
                    raise WorkflowExecutionError(f"节点 {edge.from_node} 没有输出端口 {edge.from_output}")
                kwargs[edge.to_input] = source_outputs[edge.from_output]

            self._validate_required_inputs(node_cls, kwargs)

            start = time.perf_counter()
            try:
                outputs = node_instance.run(ctx, **kwargs)
            except Exception as exc:
                raise WorkflowExecutionError(f"节点 {node_id} ({node.type}) 执行失败: {exc}") from exc
            elapsed_ms = (time.perf_counter() - start) * 1000

            raw_outputs[node_id] = outputs
            results[node_id] = NodeRunResult(
                node_id=node_id,
                node_type=node.type,
                title=node_cls.title,
                outputs={
                    name: self._serialize_output(value, workflow.preview_max_size)
                    for name, value in outputs.items()
                },
                elapsed_ms=elapsed_ms,
            )

        return results, order

    def _serialize_output(self, value: Any, preview_max_size: int) -> OutputPreview:
        if is_image_like(value):
            return OutputPreview(
                kind="image",
                type="Image",
                shape=list(value.shape),
                preview=image_to_data_url(value, max_size=preview_max_size),
                summary=summarize_value(value),
            )
        return OutputPreview(
            kind="data",
            type=type(value).__name__,
            shape=None,
            preview=None,
            summary=summarize_value(value),
        )

    def _topological_order(self, workflow: WorkflowRequest) -> list[str]:
        node_ids = {node.id for node in workflow.nodes}
        indegree = {node.id: 0 for node in workflow.nodes}
        graph = defaultdict(list)

        for edge in workflow.edges:
            if edge.from_node not in node_ids:
                raise WorkflowExecutionError(f"边引用了不存在的 from_node: {edge.from_node}")
            if edge.to_node not in node_ids:
                raise WorkflowExecutionError(f"边引用了不存在的 to_node: {edge.to_node}")
            graph[edge.from_node].append(edge.to_node)
            indegree[edge.to_node] += 1

        queue = deque([node_id for node_id, degree in indegree.items() if degree == 0])
        order = []

        while queue:
            node_id = queue.popleft()
            order.append(node_id)
            for nxt in graph[node_id]:
                indegree[nxt] -= 1
                if indegree[nxt] == 0:
                    queue.append(nxt)

        if len(order) != len(workflow.nodes):
            raise WorkflowExecutionError("工作流存在环，无法执行")
        return order

    def _validate_required_inputs(self, node_cls, kwargs: dict[str, Any]) -> None:
        missing = [port.name for port in node_cls.inputs if port.name not in kwargs]
        if missing:
            raise WorkflowExecutionError(f"节点 {node_cls.type} 缺少输入: {', '.join(missing)}")
