from __future__ import annotations

from app.nodes.base import CvNode
from app.nodes.basic import AdaptiveThreshold, Canny, CvtColor, GaussianBlur, MedianBlur, Resize, Threshold
from app.nodes.contours import DrawContours, FilterContours, FindContours
from app.nodes.io import ImageInput, Preview
from app.nodes.morphology import Dilate, Erode, MorphologyEx
from app.nodes.yolo import YOLODetect


class NodeRegistry:
    def __init__(self) -> None:
        self._nodes: dict[str, type[CvNode]] = {}

    def register(self, node_cls: type[CvNode]) -> None:
        if node_cls.type in self._nodes:
            raise ValueError(f"重复注册节点类型: {node_cls.type}")
        self._nodes[node_cls.type] = node_cls

    def get(self, node_type: str) -> type[CvNode]:
        if node_type not in self._nodes:
            raise KeyError(f"未知节点类型: {node_type}")
        return self._nodes[node_type]

    def definitions(self):
        defs = [cls.definition() for cls in self._nodes.values()]
        return sorted(defs, key=lambda d: (d.category, d.title))


registry = NodeRegistry()

for cls in [
    ImageInput,
    Preview,
    CvtColor,
    GaussianBlur,
    MedianBlur,
    Canny,
    Threshold,
    AdaptiveThreshold,
    Resize,
    Erode,
    Dilate,
    MorphologyEx,
    FindContours,
    FilterContours,
    DrawContours,
    YOLODetect,
]:
    registry.register(cls)
