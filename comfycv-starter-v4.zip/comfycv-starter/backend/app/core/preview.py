from __future__ import annotations

import base64
from typing import Any

import cv2
import numpy as np


def is_image_like(value: Any) -> bool:
    return isinstance(value, np.ndarray) and value.ndim in (2, 3)


def normalize_for_preview(image: np.ndarray) -> np.ndarray:
    """把任意 OpenCV 图像转成适合浏览器展示的 RGB/RGBA/Gray uint8。"""
    img = image

    if img.dtype != np.uint8:
        img = img.astype(np.float32)
        min_v = float(np.nanmin(img)) if img.size else 0.0
        max_v = float(np.nanmax(img)) if img.size else 1.0
        if max_v > min_v:
            img = (img - min_v) / (max_v - min_v) * 255.0
        img = np.clip(img, 0, 255).astype(np.uint8)

    if img.ndim == 2:
        return img

    if img.shape[2] == 1:
        return img[:, :, 0]
    if img.shape[2] == 3:
        return cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    if img.shape[2] == 4:
        return cv2.cvtColor(img, cv2.COLOR_BGRA2RGBA)
    return img[:, :, :3]


def downscale(image: np.ndarray, max_size: int = 1200) -> np.ndarray:
    h, w = image.shape[:2]
    long_side = max(h, w)
    if long_side <= max_size:
        return image
    scale = max_size / float(long_side)
    return cv2.resize(image, (int(w * scale), int(h * scale)), interpolation=cv2.INTER_AREA)


def image_to_data_url(image: np.ndarray, max_size: int = 1200) -> str:
    img = downscale(normalize_for_preview(image), max_size=max_size)
    ok, encoded = cv2.imencode(".png", img)
    if not ok:
        raise ValueError("图像预览编码失败")
    b64 = base64.b64encode(encoded.tobytes()).decode("ascii")
    return f"data:image/png;base64,{b64}"


def summarize_value(value: Any) -> Any:
    if isinstance(value, np.ndarray):
        return {
            "dtype": str(value.dtype),
            "shape": list(value.shape),
            "min": float(np.min(value)) if value.size else None,
            "max": float(np.max(value)) if value.size else None,
        }
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    if isinstance(value, list):
        if value and hasattr(value[0], "shape"):
            return {"count": len(value), "first_shape": list(value[0].shape)}
        return {"count": len(value), "items": value[:10]}
    if isinstance(value, dict):
        return value
    return str(type(value).__name__)
