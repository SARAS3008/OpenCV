from __future__ import annotations

from typing import Any, Literal
from pydantic import BaseModel, Field


class PortSpec(BaseModel):
    name: str
    type: str = "Any"
    label: str | None = None


class ParamSpec(BaseModel):
    type: Literal["int", "float", "bool", "select", "text"]
    default: Any = None
    label: str | None = None
    min: float | None = None
    max: float | None = None
    step: float | None = None
    options: list[Any] | None = None
    help: str | None = None


class NodeDefinition(BaseModel):
    type: str
    title: str
    category: str
    description: str = ""
    inputs: list[PortSpec] = Field(default_factory=list)
    outputs: list[PortSpec] = Field(default_factory=list)
    params: dict[str, ParamSpec] = Field(default_factory=dict)


class WorkflowNode(BaseModel):
    id: str
    type: str
    params: dict[str, Any] = Field(default_factory=dict)


class WorkflowEdge(BaseModel):
    id: str | None = None
    from_node: str
    from_output: str
    to_node: str
    to_input: str


class WorkflowRequest(BaseModel):
    nodes: list[WorkflowNode]
    edges: list[WorkflowEdge] = Field(default_factory=list)
    preview: bool = True
    preview_max_size: int = 1200


class AssetUploadResponse(BaseModel):
    asset_id: str
    filename: str
    width: int
    height: int
    channels: int
    preview: str


class OutputPreview(BaseModel):
    kind: str
    type: str
    shape: list[int] | None = None
    preview: str | None = None
    summary: Any = None


class NodeRunResult(BaseModel):
    node_id: str
    node_type: str
    title: str
    outputs: dict[str, OutputPreview]
    elapsed_ms: float


class WorkflowRunResponse(BaseModel):
    ok: bool
    results: dict[str, NodeRunResult]
    execution_order: list[str]
