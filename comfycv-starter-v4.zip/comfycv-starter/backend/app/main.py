from __future__ import annotations

from pathlib import Path

from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware

from app.core.executor import WorkflowExecutionError, WorkflowExecutor
from app.core.image_store import ImageStore
from app.core.models import AssetUploadResponse, WorkflowRequest, WorkflowRunResponse
from app.core.preview import image_to_data_url
from app.core.registry import registry

app = FastAPI(title="ComfyCV Starter", version="0.2.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://127.0.0.1:5173", "http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

image_store = ImageStore(root=Path(__file__).resolve().parents[2] / "runtime_assets")
executor = WorkflowExecutor(image_store=image_store)


@app.get("/api/health")
def health():
    return {"ok": True}


@app.get("/api/nodes")
def list_nodes():
    return {"nodes": [d.model_dump() for d in registry.definitions()]}


@app.post("/api/assets/upload", response_model=AssetUploadResponse)
async def upload_asset(file: UploadFile = File(...)):
    try:
        content = await file.read()
        asset, image = image_store.save_upload(file.filename or "image.png", content)
        return AssetUploadResponse(
            asset_id=asset.asset_id,
            filename=asset.filename,
            width=asset.width,
            height=asset.height,
            channels=asset.channels,
            preview=image_to_data_url(image, max_size=600),
        )
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.post("/api/workflows/run", response_model=WorkflowRunResponse)
def run_workflow(workflow: WorkflowRequest):
    try:
        results, order = executor.run(workflow)
        return WorkflowRunResponse(ok=True, results=results, execution_order=order)
    except WorkflowExecutionError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc
