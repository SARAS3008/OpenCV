from pathlib import Path
import subprocess
import sys

import cv2
import numpy as np
import pytest

from backend.algorithms.registry import OPERATORS, OPERATOR_CATALOG, OPERATOR_META
from backend.models.workflow import WorkflowRequest
from backend.services.image_store import ImageStore
from backend.services.script_exporter import generate_algorithm_script
from backend.services.workflow_engine import WorkflowExecutionError, run_workflow
from tests.auth_utils import auth_headers


def make_store(tmp_path: Path) -> ImageStore:
    return ImageStore(tmp_path, {".png", ".jpg", ".jpeg"})


def encode_png(image: np.ndarray) -> bytes:
    ok, encoded = cv2.imencode(".png", image)
    assert ok
    return encoded.tobytes()


def test_python_snippet_is_registered_in_logic_library() -> None:
    assert "PythonSnippet" in OPERATORS
    meta = OPERATOR_META["PythonSnippet"]
    assert meta["label"] == "Python自定义算子"
    assert meta["param_schema"]["code"]["type"] == "textarea"
    assert [port["handle"] for port in meta["inputs"]] == ["in", "aux", "value"]
    assert meta["configurable_inputs"]["param"] == "input_bindings"
    assert meta["configurable_inputs"]["max_count"] == 20
    assert any(group["group"] == "脚本扩展" and "PythonSnippet" in group["items"] for group in OPERATOR_CATALOG["逻辑"])


def test_python_snippet_processes_image_and_metrics(tmp_path: Path) -> None:
    store = make_store(tmp_path)
    image = np.zeros((30, 40, 3), dtype=np.uint8)
    image[:, :20] = (10, 20, 30)
    record = store.save("source.png", encode_png(image))
    code = """
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
out = cv2.Canny(gray, 10, 30)
metrics = {"edge_pixels": int(np.count_nonzero(out))}
data = {"custom": {"shape": list(out.shape)}}
"""
    workflow = WorkflowRequest.model_validate(
        {
            "image_id": record.image_id,
            "nodes": [
                {"id": "read", "type": "ReadImage"},
                {"id": "snippet", "type": "PythonSnippet", "params": {"code": code, "timeout_ms": 2000}},
            ],
            "edges": [{"source": "read", "target": "snippet", "targetHandle": "in"}],
        }
    )
    result = run_workflow(workflow, store)
    preview = next(item for item in result["previews"] if item["node_id"] == "snippet")
    assert result["success"] is True
    assert preview["result_type"] == "image"
    assert preview["metrics"]["edge_pixels"] > 0
    assert preview["data"]["custom"]["shape"] == [30, 40]


def test_python_snippet_function_can_return_scalar_value(tmp_path: Path) -> None:
    workflow = WorkflowRequest.model_validate(
        {
            "nodes": [
                {"id": "a", "type": "LogicConstant", "params": {"value_type": "NUMBER", "value": "6"}},
                {"id": "b", "type": "LogicConstant", "params": {"value_type": "NUMBER", "value": "7"}},
                {
                    "id": "snippet",
                    "type": "PythonSnippet",
                    "params": {
                        "code": "def process(inputs, params, context):\n    return {'out': inputs['value'] * inputs['aux'], 'metrics': {'product': inputs['value'] * inputs['aux']}}\n",
                        "isolated": "YES",
                    },
                },
            ],
            "edges": [
                {"source": "a", "target": "snippet", "targetHandle": "value"},
                {"source": "b", "target": "snippet", "targetHandle": "aux"},
            ],
        }
    )
    result = run_workflow(workflow, make_store(tmp_path))
    preview = next(item for item in result["previews"] if item["node_id"] == "snippet")
    assert preview["result_type"] == "metrics"
    assert preview["metrics"]["product"] == 42


def test_python_snippet_named_inputs_support_dynamic_ports(tmp_path: Path) -> None:
    workflow = WorkflowRequest.model_validate(
        {
            "nodes": [
                {"id": "left", "type": "LogicConstant", "params": {"value_type": "NUMBER", "value": "6"}},
                {"id": "right", "type": "LogicConstant", "params": {"value_type": "NUMBER", "value": "7"}},
                {
                    "id": "snippet",
                    "type": "PythonSnippet",
                    "params": {
                        "code": "def process(width, height):\n    product = width * height\n    return {'out': product, 'metrics': {'product': product}}\n",
                        "input_bindings": [
                            {"handle": "in", "name": "width", "label": "宽度", "type": "number", "required": True},
                            {"handle": "arg1", "name": "height", "label": "高度", "type": "number", "required": True},
                        ],
                    },
                },
            ],
            "edges": [
                {"source": "left", "sourceHandle": "out", "target": "snippet", "targetHandle": "in"},
                {"source": "right", "sourceHandle": "out", "target": "snippet", "targetHandle": "arg1"},
            ],
        }
    )
    result = run_workflow(workflow, make_store(tmp_path))
    preview = next(item for item in result["previews"] if item["node_id"] == "snippet")
    assert preview["metrics"]["product"] == 42


def test_python_snippet_process_defaults_are_used_for_unconnected_optional_inputs(tmp_path: Path) -> None:
    workflow = WorkflowRequest.model_validate(
        {
            "nodes": [
                {"id": "source", "type": "LogicConstant", "params": {"value_type": "NUMBER", "value": "5"}},
                {
                    "id": "snippet",
                    "type": "PythonSnippet",
                    "params": {
                        "code": "def process(value, scale=3):\n    result = value * scale\n    return {'out': result, 'metrics': {'result': result}}\n",
                        "input_bindings": [
                            {"handle": "in", "name": "value", "label": "值", "type": "number", "required": True},
                            {"handle": "arg1", "name": "scale", "label": "倍率", "type": "number", "required": False},
                        ],
                    },
                },
            ],
            "edges": [{"source": "source", "target": "snippet", "targetHandle": "in"}],
        }
    )
    result = run_workflow(workflow, make_store(tmp_path))
    preview = next(item for item in result["previews"] if item["node_id"] == "snippet")
    assert preview["metrics"]["result"] == 15


def test_python_snippet_plain_dict_return_is_automatically_forwarded(tmp_path: Path) -> None:
    workflow = WorkflowRequest.model_validate(
        {
            "nodes": [
                {"id": "source", "type": "LogicConstant", "params": {"value_type": "NUMBER", "value": "9"}},
                {
                    "id": "producer",
                    "type": "PythonSnippet",
                    "params": {
                        "code": "def process(score):\n    return {'score': score, 'passed': score >= 8}\n",
                        "input_bindings": [{"handle": "in", "name": "score", "label": "分数", "type": "number", "required": True}],
                    },
                },
                {
                    "id": "consumer",
                    "type": "PythonSnippet",
                    "params": {
                        "code": "def process(result):\n    return {'out': result['passed'], 'metrics': {'score': result['score'], 'passed': result['passed']}}\n",
                        "input_bindings": [{"handle": "in", "name": "result", "label": "结果对象", "type": "object", "required": True}],
                    },
                },
            ],
            "edges": [
                {"source": "source", "target": "producer", "targetHandle": "in"},
                {"source": "producer", "sourceHandle": "value", "target": "consumer", "targetHandle": "in"},
            ],
        }
    )
    result = run_workflow(workflow, make_store(tmp_path))
    preview = next(item for item in result["previews"] if item["node_id"] == "consumer")
    assert preview["metrics"]["score"] == 9
    assert preview["metrics"]["passed"] is True


def test_python_snippet_required_named_input_is_validated(tmp_path: Path) -> None:
    workflow = WorkflowRequest.model_validate(
        {
            "nodes": [
                {
                    "id": "snippet",
                    "type": "PythonSnippet",
                    "params": {
                        "code": "def process(image):\n    return image\n",
                        "input_bindings": [{"handle": "in", "name": "image", "label": "图像", "type": "image", "required": True}],
                    },
                }
            ]
        }
    )
    with pytest.raises(WorkflowExecutionError) as exc_info:
        run_workflow(workflow, make_store(tmp_path))
    assert "缺少输入端口" in str(exc_info.value) or "缺少必填输入参数" in str(exc_info.value)


def test_python_snippet_captures_print_output(tmp_path: Path) -> None:
    workflow = WorkflowRequest.model_validate(
        {
            "nodes": [
                {
                    "id": "snippet",
                    "type": "PythonSnippet",
                    "params": {"code": "print('debug-value', 123)\nout = 1\nmetrics = {'ok': True}\n"},
                }
            ]
        }
    )
    result = run_workflow(workflow, make_store(tmp_path))
    preview = next(item for item in result["previews"] if item["node_id"] == "snippet")
    assert preview["data"]["console"] == "debug-value 123"


def test_python_snippet_rejects_imports(tmp_path: Path) -> None:
    workflow = WorkflowRequest.model_validate(
        {
            "nodes": [
                {"id": "snippet", "type": "PythonSnippet", "params": {"code": "import os\nout = 1"}},
            ],
            "edges": [],
        }
    )
    with pytest.raises(WorkflowExecutionError) as exc_info:
        run_workflow(workflow, make_store(tmp_path))
    assert "Import" in str(exc_info.value)


@pytest.mark.parametrize(
    "code",
    ["out = np.fromfile('/etc/passwd')", "out = cv2.imread('/tmp/a.png')"],
)
def test_python_snippet_rejects_file_access_apis(tmp_path: Path, code: str) -> None:
    workflow = WorkflowRequest.model_validate(
        {
            "nodes": [{"id": "snippet", "type": "PythonSnippet", "params": {"code": code}}],
            "edges": [],
        }
    )
    with pytest.raises(WorkflowExecutionError) as exc_info:
        run_workflow(workflow, make_store(tmp_path))
    assert "文件、设备或模型加载接口" in str(exc_info.value)


def test_python_snippet_inline_mode_is_disabled_by_default(tmp_path: Path) -> None:
    workflow = WorkflowRequest.model_validate(
        {
            "nodes": [
                {
                    "id": "snippet",
                    "type": "PythonSnippet",
                    "params": {"code": "out = 1", "isolated": "NO"},
                }
            ],
            "edges": [],
        }
    )
    with pytest.raises(WorkflowExecutionError) as exc_info:
        run_workflow(workflow, make_store(tmp_path))
    assert "必须使用隔离执行" in str(exc_info.value)


def test_python_snippet_export_runs_as_standalone_script(tmp_path: Path) -> None:
    image = np.full((20, 24, 3), 30, dtype=np.uint8)
    input_path = tmp_path / "input.png"
    output_path = tmp_path / "result.png"
    script_path = tmp_path / "snippet_algorithm.py"
    assert cv2.imwrite(str(input_path), image)
    workflow = WorkflowRequest.model_validate(
        {
            "nodes": [
                {"id": "read", "type": "ReadImage"},
                {
                    "id": "snippet",
                    "type": "PythonSnippet",
                    "params": {
                        "code": "out = cv2.bitwise_not(image)\nmetrics = {'mean': float(np.mean(out))}\n",
                        "output_kind": "IMAGE",
                        "output_color_space": "BGR",
                    },
                },
            ],
            "edges": [{"source": "read", "target": "snippet", "targetHandle": "in"}],
        }
    )
    source = generate_algorithm_script(workflow)
    assert "<PythonSnippet>" in source
    script_path.write_text(source, encoding="utf-8")
    subprocess.run([sys.executable, str(script_path), "--input", str(input_path), "--output", str(output_path)], check=True)
    result = cv2.imread(str(output_path), cv2.IMREAD_COLOR)
    assert result is not None
    assert int(result[0, 0, 0]) == 225


def test_python_snippet_named_process_export_runs_as_standalone_script(tmp_path: Path) -> None:
    image = np.full((12, 16, 3), 10, dtype=np.uint8)
    input_path = tmp_path / "named-input.png"
    output_path = tmp_path / "named-result.png"
    script_path = tmp_path / "named-snippet.py"
    assert cv2.imwrite(str(input_path), image)
    workflow = WorkflowRequest.model_validate(
        {
            "nodes": [
                {"id": "read", "type": "ReadImage"},
                {
                    "id": "snippet",
                    "type": "PythonSnippet",
                    "params": {
                        "code": "def process(source_image):\n    return cv2.bitwise_not(source_image)\n",
                        "input_bindings": [
                            {"handle": "in", "name": "source_image", "label": "源图", "type": "image", "required": True}
                        ],
                        "output_kind": "IMAGE",
                        "output_color_space": "BGR",
                    },
                },
            ],
            "edges": [{"source": "read", "target": "snippet", "targetHandle": "in"}],
        }
    )
    script_path.write_text(generate_algorithm_script(workflow), encoding="utf-8")
    subprocess.run([sys.executable, str(script_path), "--input", str(input_path), "--output", str(output_path)], check=True)
    result = cv2.imread(str(output_path), cv2.IMREAD_COLOR)
    assert result is not None
    assert int(result[0, 0, 0]) == 245


def test_python_snippet_validation_api_reports_outputs() -> None:
    from fastapi.testclient import TestClient
    from backend.main import app

    client = TestClient(app)
    _, headers = auth_headers(client, "snippet-valid")
    response = client.post("/api/python-snippet/validate", json={"code": "out = 1\nmetrics = {'ok': True}\n"}, headers=headers)
    assert response.status_code == 200
    payload = response.json()
    assert payload["valid"] is True
    assert "out" in payload["analysis"]["assigned_outputs"]
    assert "metrics" in payload["analysis"]["assigned_outputs"]


def test_python_snippet_validation_api_reports_named_process_parameters() -> None:
    from fastapi.testclient import TestClient
    from backend.main import app

    client = TestClient(app)
    _, headers = auth_headers(client, "snippet-named-valid")
    response = client.post(
        "/api/python-snippet/validate",
        json={
            "code": "def process(image, threshold=128):\n    return image\n",
            "input_bindings": [
                {"handle": "in", "name": "image", "label": "图像", "type": "image", "required": True},
                {"handle": "arg1", "name": "threshold", "label": "阈值", "type": "number", "required": False},
            ],
        },
        headers=headers,
    )
    assert response.status_code == 200
    analysis = response.json()["analysis"]
    assert analysis["process_parameters"] == ["image", "threshold"]
    assert analysis["available_input_names"] == ["image", "threshold"]


def test_python_snippet_validation_api_rejects_unsafe_code() -> None:
    from fastapi.testclient import TestClient
    from backend.main import app

    client = TestClient(app)
    _, headers = auth_headers(client, "snippet-invalid")
    response = client.post("/api/python-snippet/validate", json={"code": "import os\nout = 1"}, headers=headers)
    assert response.status_code == 400
    payload = response.json()
    assert payload["valid"] is False
    assert "Import" in payload["error"]


def test_python_snippet_frontend_ide_assets_present() -> None:
    index = Path("frontend/index.html").read_text(encoding="utf-8")
    js = Path("frontend/assets/js/app/python_snippet_ide.js").read_text(encoding="utf-8")
    css = Path("frontend/assets/css/styles.css").read_text(encoding="utf-8")
    assert "python_snippet_ide.js" in index
    assert "openPythonSnippetIde" in js
    assert "renderPythonSnippetInlineEditor" in js
    assert "normalizePythonSnippetInputBindings" in js
    assert "保存并运行到此节点" in js
    assert "validatePythonSnippet" in Path("frontend/assets/js/api.js").read_text(encoding="utf-8")
    assert ".snippet-ide" in css
    assert 'focus({ preventScroll:true })' in js
    assert 'requestAnimationFrame(resetEditorViewport)' in js
    assert 'editor.textarea.setSelectionRange(0, 0)' in js
    assert '#snippetIdeEditorMount{display:flex;flex:1 1 auto;min-width:0;min-height:0;overflow:hidden}' in css
    assert '.snippet-ide-topbar{height:58px;min-height:58px;flex:0 0 58px' in css
    assert OPERATOR_META["PythonSnippet"]["param_schema"]["isolated"]["options"] == [
        {"value": "YES", "label": "是，子进程执行"}
    ]
