/**
 * PythonSnippet 专用开发体验。
 * 核心目标：端口可命名、process 参数自动注入、普通 Python 返回值自动适配节点输出。
 */
(() => {
  const MAX_BINDINGS = 20;
  const DEFAULT_BINDINGS = [
    { handle:"in", name:"image", label:"主图像", type:"image", required:false },
    { handle:"aux", name:"aux", label:"辅助输入", type:"any", required:false },
    { handle:"value", name:"value", label:"数值/对象", type:"any", required:false },
  ];
  const RESERVED_NAMES = new Set([
    "inputs", "ports", "args", "params", "settings", "context", "input_meta",
    "np", "cv2", "math", "statistics", "json", "emit", "get_input",
    "out", "metrics", "data", "process",
  ]);
  const PYTHON_KEYWORDS = new Set([
    "False", "None", "True", "and", "as", "assert", "async", "await", "break", "class", "continue",
    "def", "del", "elif", "else", "except", "finally", "for", "from", "global", "if", "import", "in",
    "is", "lambda", "nonlocal", "not", "or", "pass", "raise", "return", "try", "while", "with", "yield",
  ]);
  const INPUT_TYPES = [
    ["any", "任意"], ["image", "图像"], ["number", "数值"], ["boolean", "布尔"],
    ["string", "字符串"], ["object", "对象"], ["list", "列表"],
  ];
  const RUNTIME_VARIABLES = [
    ["命名参数", "any", "每个输入端口配置的 Python 名称会成为直接变量，并自动注入 process() 同名参数"],
    ["args", "dict", "只包含命名输入，例如 args['mask']"],
    ["inputs", "dict", "同时支持端口 handle 和命名参数，兼容旧代码 inputs['in']"],
    ["ports", "dict", "原始端口字典，只按 handle 访问"],
    ["settings", "dict", "开发界面中配置的代码参数"],
    ["params", "dict", "节点全部运行参数，包含 settings 对应的 custom_params"],
    ["context", "dict", "运行上下文：image_id、batch_index、batch_total"],
    ["emit(value, **outputs)", "function", "可选输出助手；大多数情况下直接 return 即可"],
    ["get_input(name, default)", "function", "按名称安全取值，空值时使用 default"],
    ["np / cv2", "module", "NumPy 与 OpenCV"],
    ["math / statistics / json", "module", "常用标准库模块"],
  ];
  const OUTPUT_CONTRACT = [
    ["return ndarray", "自动图像输出", "自动同时填充 out 和 image"],
    ["return 数值/布尔/字符串", "自动值输出", "自动同时填充 out 和 value"],
    ["return 普通 dict", "自动对象输出", "自动填充 out、value，并在 data.result 中保留结构化结果"],
    ["return {'out': ..., 'metrics': ...}", "高级输出", "需要多个输出或预览指标时使用保留字段"],
    ["metrics", "预览指标", "显示在节点最近运行结果中"],
    ["data", "结构化数据", "并入流程 data，适合检测结果、坐标和统计信息"],
    ["print(...) ", "控制台输出", "最近一次运行会在 data.console 中显示"],
  ];

  function esc(value){
    return String(value ?? "").replace(/[&<>'"]/g, ch => ({"&":"&amp;","<":"&lt;",">":"&gt;","'":"&#39;",'"':"&quot;"}[ch]));
  }
  function clone(value){ return JSON.parse(JSON.stringify(value)); }
  function getNode(nodeId){ return (window.nodes || nodes || []).find(item => item.id === nodeId) || null; }
  function getMeta(type){ return (window.OPERATOR_META || OPERATOR_META || {})[type] || {}; }
  function isValidIdentifier(value){
    return /^[A-Za-z_][A-Za-z0-9_]*$/.test(value) && !PYTHON_KEYWORDS.has(value) && !RESERVED_NAMES.has(value);
  }
  function safeIdentifier(value, fallback="input"){
    let text = String(value || "").trim().replace(/[^A-Za-z0-9_]+/g, "_").replace(/^_+|_+$/g, "");
    if(!text) text = fallback;
    if(/^\d/.test(text)) text = `input_${text}`;
    if(PYTHON_KEYWORDS.has(text) || RESERVED_NAMES.has(text)) text = `${text}_input`;
    return text;
  }
  function parseMaybeJson(value, fallback){
    if(typeof value !== "string") return value;
    try{ return JSON.parse(value); }catch(_error){ return fallback; }
  }

  function normalizePythonSnippetInputBindings(value){
    let raw = parseMaybeJson(value, null);
    if(!Array.isArray(raw) || !raw.length) raw = clone(DEFAULT_BINDINGS);
    const result = [];
    const handles = new Set();
    const names = new Set();
    raw.slice(0, MAX_BINDINGS).forEach((item, index) => {
      if(!item || typeof item !== "object") return;
      let handle = safeIdentifier(item.handle, index === 0 ? "in" : `arg${index}`);
      while(handles.has(handle)) handle = `${handle}_${index + 1}`;
      let name = safeIdentifier(item.name || handle, `input_${index + 1}`);
      let suffix = 2;
      const baseName = name;
      while(names.has(name)) name = `${baseName}_${suffix++}`;
      handles.add(handle);
      names.add(name);
      const normalized = {
        handle,
        name,
        label:String(item.label || name).trim().slice(0, 80) || name,
        type:INPUT_TYPES.some(([type]) => type === item.type) ? item.type : "any",
        required:item.required === true,
      };
      if(item.default_enabled === true){
        normalized.default_enabled = true;
        normalized.default = item.default;
      }
      result.push(normalized);
    });
    return result.length ? result : clone(DEFAULT_BINDINGS);
  }
  window.normalizePythonSnippetInputBindings = normalizePythonSnippetInputBindings;

  function getBindings(node){
    const meta = getMeta(node?.type);
    return normalizePythonSnippetInputBindings(node?.params?.input_bindings ?? meta?.params?.input_bindings);
  }
  function getIncomingConnections(node){
    if(!node) return [];
    return (window.edges || edges || []).filter(edge => edge.target === node.id).map(edge => {
      const source = getNode(edge.source);
      const sourceMeta = getMeta(source?.type);
      const outputs = typeof window.nodeOutputPorts === "function"
        ? window.nodeOutputPorts(sourceMeta, source)
        : (Array.isArray(sourceMeta.outputs) ? sourceMeta.outputs : [{ handle:"out", label:"输出", type:sourceMeta.result_type || "any" }]);
      const sourceHandle = edge.sourceHandle || "out";
      const targetHandle = edge.targetHandle || "in";
      const port = outputs.find(item => (item.handle || "out") === sourceHandle) || { handle:sourceHandle, type:"any" };
      return { edge, source, sourceMeta, sourceHandle, targetHandle, port };
    });
  }
  function inputRows(node){
    const connections = getIncomingConnections(node);
    const byTarget = new Map(connections.map(item => [item.targetHandle, item]));
    return getBindings(node).map(binding => ({ ...binding, connection:byTarget.get(binding.handle) || null }));
  }
  function previewFor(nodeId){
    try{ return nodePreviews.get(nodeId) || null; }catch(_error){ return null; }
  }
  function objectTable(rows){
    return `<div class="snippet-table">${rows.map(row => `<div class="snippet-table-row"><b>${esc(row[0])}</b><span>${esc(row[1])}</span><em>${esc(row[2])}</em></div>`).join("")}</div>`;
  }
  function defaultLiteral(binding){
    if(binding.default_enabled !== true) return "None";
    const value = binding.default;
    if(value === null) return "None";
    if(value === true) return "True";
    if(value === false) return "False";
    if(typeof value === "string") return JSON.stringify(value);
    try{ return JSON.stringify(value); }catch(_error){ return "None"; }
  }
  function processSignature(node, includeBody=false){
    const bindings = getBindings(node);
    const required = bindings.filter(item => item.required && !item.default_enabled);
    const optional = bindings.filter(item => !required.includes(item));
    const params = [
      ...required.map(item => item.name),
      ...optional.map(item => `${item.name}=${defaultLiteral(item)}`),
    ];
    const header = `def process(${params.join(", ")}):`;
    if(!includeBody) return header;
    const primary = bindings.find(item => item.type === "image")?.name || bindings[0]?.name || "value";
    return `${header}\n    # 在这里编写图像处理逻辑；直接 return ndarray、数值、布尔或 dict 即可\n    return ${primary}\n`;
  }
  function renderInputContract(node){
    const rows = inputRows(node);
    if(!rows.length) return '<div class="snippet-empty">尚未配置输入参数。</div>';
    return `<div class="snippet-signature"><code>${esc(processSignature(node))}</code></div><div class="snippet-port-list">${rows.map(row => {
      const c = row.connection;
      const hasDefault = row.default_enabled === true;
      const status = c ? "connected" : row.required && !hasDefault ? "missing" : "optional";
      const statusText = c ? `${c.source?.id || c.edge.source}.${c.sourceHandle}` : hasDefault ? `默认值 ${JSON.stringify(row.default)}` : row.required ? "必填但未连接" : "可选，值为 None";
      const desc = c ? `${c.sourceMeta?.label || c.source?.type || "上游节点"} → ${c.port?.label || c.sourceHandle}` : `端口 ${row.handle} → Python 参数 ${row.name}`;
      return `<div class="snippet-port ${status}"><div><strong>${esc(row.name)}</strong><span>${esc(row.label)} · ${esc(row.type)}</span></div><small>${esc(statusText)}</small><p>${esc(desc)}</p></div>`;
    }).join("")}</div>`;
  }
  function renderLastRun(node){
    const preview = previewFor(node?.id);
    if(!preview) return '<div class="snippet-empty">还没有运行结果。点击“保存并运行到此节点”会自动执行依赖节点并停在这里。</div>';
    const metrics = preview.metrics || {};
    const data = preview.data || {};
    const metricRows = Object.entries(metrics).map(([k, v]) => [k, typeof v, JSON.stringify(v)]);
    const dataRows = Object.entries(data).filter(([k]) => k !== "console").slice(0, 20).map(([k, v]) => [k, Array.isArray(v) ? "array" : typeof v, typeof v === "object" ? JSON.stringify(v).slice(0, 240) : String(v)]);
    const consoleBlock = data.console ? `<h5>console</h5><pre class="snippet-console">${esc(data.console)}</pre>` : "";
    return `<div class="snippet-last-run"><div class="snippet-run-head"><b>${esc(preview.status || "success")}</b><span>${esc(preview.result_type || "")}</span></div>
      <h5>metrics</h5>${metricRows.length ? objectTable(metricRows) : '<div class="snippet-empty compact">无 metrics</div>'}
      <h5>data</h5>${dataRows.length ? objectTable(dataRows) : '<div class="snippet-empty compact">无 data</div>'}${consoleBlock}</div>`;
  }

  function selectedLineRange(textarea){
    const value = textarea.value;
    const start = value.lastIndexOf("\n", Math.max(0, textarea.selectionStart - 1)) + 1;
    const endBreak = value.indexOf("\n", textarea.selectionEnd);
    return { start, end:endBreak < 0 ? value.length : endBreak };
  }
  function replaceSelectionLines(textarea, transform){
    const range = selectedLineRange(textarea);
    const original = textarea.value.slice(range.start, range.end);
    const next = transform(original.split("\n")).join("\n");
    textarea.setRangeText(next, range.start, range.end, "select");
    textarea.dispatchEvent(new Event("input", { bubbles:true }));
  }
  function makeTextarea(value, onChange){
    const outer = document.createElement("div");
    outer.className = "snippet-editor-wrap";
    const wrap = document.createElement("div");
    wrap.className = "snippet-code-shell";
    const gutter = document.createElement("div");
    gutter.className = "snippet-line-gutter";
    const textarea = document.createElement("textarea");
    textarea.className = "snippet-code-textarea";
    textarea.value = value || "";
    textarea.spellcheck = false;
    textarea.wrap = "off";
    textarea.autocapitalize = "off";
    textarea.autocomplete = "off";
    const status = document.createElement("div");
    status.className = "snippet-editor-status";
    function updateStatus(){
      const before = textarea.value.slice(0, textarea.selectionStart);
      const line = before.split("\n").length;
      const column = before.length - before.lastIndexOf("\n");
      status.textContent = `Ln ${line}, Col ${column} · Python · UTF-8`;
    }
    function updateLines(){
      const count = Math.max(1, textarea.value.split("\n").length);
      gutter.innerHTML = Array.from({ length:count }, (_, index) => `<span>${index + 1}</span>`).join("");
      updateStatus();
      if(typeof onChange === "function") onChange(textarea.value);
    }
    textarea.addEventListener("input", updateLines);
    textarea.addEventListener("click", updateStatus);
    textarea.addEventListener("keyup", updateStatus);
    textarea.addEventListener("scroll", () => { gutter.scrollTop = textarea.scrollTop; });
    textarea.addEventListener("keydown", event => {
      if(event.key === "Tab"){
        event.preventDefault();
        if(textarea.selectionStart !== textarea.selectionEnd){
          replaceSelectionLines(textarea, lines => lines.map(line => event.shiftKey ? line.replace(/^ {1,4}/, "") : `    ${line}`));
        }else if(event.shiftKey){
          const lineStart = textarea.value.lastIndexOf("\n", textarea.selectionStart - 1) + 1;
          const prefix = textarea.value.slice(lineStart, textarea.selectionStart);
          const removable = Math.min(4, (prefix.match(/^ */)?.[0] || "").length);
          if(removable) textarea.setRangeText("", lineStart, lineStart + removable, "end");
        }else{
          textarea.setRangeText("    ", textarea.selectionStart, textarea.selectionEnd, "end");
        }
        updateLines();
      }else if(event.key === "Enter"){
        event.preventDefault();
        const before = textarea.value.slice(0, textarea.selectionStart);
        const currentLine = before.slice(before.lastIndexOf("\n") + 1);
        const indent = currentLine.match(/^\s*/)?.[0] || "";
        const extra = currentLine.trimEnd().endsWith(":") ? "    " : "";
        textarea.setRangeText(`\n${indent}${extra}`, textarea.selectionStart, textarea.selectionEnd, "end");
        updateLines();
      }else if((event.ctrlKey || event.metaKey) && event.key === "/"){
        event.preventDefault();
        replaceSelectionLines(textarea, lines => {
          const uncomment = lines.filter(line => line.trim()).every(line => /^\s*#/.test(line));
          return lines.map(line => uncomment ? line.replace(/^(\s*)# ?/, "$1") : line.replace(/^(\s*)/, "$1# "));
        });
      }
    });
    wrap.append(gutter, textarea);
    outer.append(wrap, status);
    updateLines();
    return { wrap:outer, shell:wrap, textarea, gutter, status, updateLines };
  }
  function insertAtCursor(textarea, text){
    const start = textarea.selectionStart ?? textarea.value.length;
    const end = textarea.selectionEnd ?? textarea.value.length;
    textarea.setRangeText(text, start, end, "end");
    textarea.dispatchEvent(new Event("input", { bubbles:true }));
    textarea.focus();
  }

  async function validateCode(code, targetEl, node){
    targetEl.className = "snippet-validation pending";
    targetEl.textContent = "正在校验代码和 process 参数映射...";
    try{
      const bindings = node ? getBindings(node) : clone(DEFAULT_BINDINGS);
      const result = await VisionApi.validatePythonSnippet(code, bindings);
      const analysis = result.analysis || {};
      const outputs = (analysis.assigned_outputs || []).join("、") || "由 return 自动判断";
      const processParams = (analysis.process_parameters || []).join("、") || "未定义 process";
      const warnings = (analysis.warnings || []).map(item => `<li>${esc(item)}</li>`).join("");
      targetEl.className = `snippet-validation ${warnings ? "warning" : "ok"}`;
      targetEl.innerHTML = `<b>语法、安全限制和参数映射校验通过</b><br>行数：${Number(analysis.line_count || 0)}；process 参数：${esc(processParams)}；显式输出：${esc(outputs)}${warnings ? `<ul>${warnings}</ul>` : ""}`;
      return true;
    }catch(error){
      targetEl.className = "snippet-validation error";
      targetEl.textContent = error?.message || String(error);
      return false;
    }
  }
  function commitCode(nodeId, key, code){
    const node = getNode(nodeId);
    if(!node) return;
    updateNodeParam(nodeId, key || "code", code);
  }
  function setParamSilently(nodeId, key, value){
    const node = getNode(nodeId);
    if(!node) return;
    node.params[key] = value;
    invalidateNodeAndDownstreamPreviews(nodeId);
    commitActiveWorkflowChange();
  }
  function commitBindings(nodeId, bindings, { rerender=true } = {}){
    const node = getNode(nodeId);
    if(!node) return;
    node.params.input_bindings = normalizePythonSnippetInputBindings(bindings);
    if(typeof pruneInvalidEdgesForNode === "function") pruneInvalidEdgesForNode(nodeId);
    invalidateNodeAndDownstreamPreviews(nodeId);
    commitActiveWorkflowChange();
    if(rerender && typeof render === "function") render();
  }
  function nextHandle(bindings){
    const used = new Set(bindings.map(item => item.handle));
    for(let index = 1; index <= MAX_BINDINGS; index += 1){
      const handle = `arg${index}`;
      if(!used.has(handle)) return handle;
    }
    return `arg${bindings.length + 1}`;
  }
  function nextName(bindings){
    const used = new Set(bindings.map(item => item.name));
    for(let index = 1; index <= MAX_BINDINGS; index += 1){
      const name = `input_${index}`;
      if(!used.has(name)) return name;
    }
    return `input_${bindings.length + 1}`;
  }

  function renderBindingManager(container, node, refresh){
    container.innerHTML = "";
    const bindings = getBindings(node);
    const connections = getIncomingConnections(node);
    const connectionByHandle = new Map(connections.map(item => [item.targetHandle, item]));
    const toolbar = document.createElement("div");
    toolbar.className = "snippet-binding-toolbar";
    const summary = document.createElement("span");
    summary.textContent = `${bindings.length} / ${MAX_BINDINGS} 个命名输入`;
    const actions = document.createElement("div");
    const autoName = document.createElement("button");
    autoName.type = "button";
    autoName.textContent = "按连线自动命名";
    autoName.onclick = event => {
      event.stopPropagation();
      const used = new Set();
      const next = bindings.map((binding, index) => {
        const connection = connectionByHandle.get(binding.handle);
        const suggested = connection
          ? safeIdentifier(`${connection.source?.id || "input"}_${connection.sourceHandle}`, `input_${index + 1}`)
          : binding.name;
        let name = suggested;
        let suffix = 2;
        while(used.has(name) || RESERVED_NAMES.has(name)) name = `${suggested}_${suffix++}`;
        used.add(name);
        return { ...binding, name };
      });
      commitBindings(node.id, next);
      refresh();
    };
    const add = document.createElement("button");
    add.type = "button";
    add.textContent = "+ 添加输入";
    add.disabled = bindings.length >= MAX_BINDINGS;
    add.onclick = event => {
      event.stopPropagation();
      if(bindings.length >= MAX_BINDINGS) return;
      const next = [...bindings, { handle:nextHandle(bindings), name:nextName(bindings), label:"新输入", type:"any", required:false }];
      commitBindings(node.id, next);
      refresh();
    };
    actions.append(autoName, add);
    toolbar.append(summary, actions);
    container.appendChild(toolbar);

    const list = document.createElement("div");
    list.className = "snippet-binding-list";
    bindings.forEach((binding, index) => {
      const connection = connectionByHandle.get(binding.handle);
      const row = document.createElement("div");
      row.className = `snippet-binding-row ${connection ? "connected" : ""}`;
      const head = document.createElement("div");
      head.className = "snippet-binding-head";
      head.innerHTML = `<code>${esc(binding.handle)}</code><span>${connection ? `${esc(connection.source?.id || connection.edge.source)}.${esc(connection.sourceHandle)}` : "未连接"}</span>`;
      const remove = document.createElement("button");
      remove.type = "button";
      remove.textContent = "删除";
      remove.disabled = bindings.length <= 1;
      remove.onclick = event => {
        event.stopPropagation();
        if(connection && !confirm(`输入 ${binding.name} 已连接 ${connection.source?.id || connection.edge.source}.${connection.sourceHandle}，删除会同时移除连线。继续吗？`)) return;
        const next = bindings.filter((_, itemIndex) => itemIndex !== index);
        commitBindings(node.id, next);
        refresh();
      };
      head.appendChild(remove);

      const grid = document.createElement("div");
      grid.className = "snippet-binding-grid";
      const nameLabel = document.createElement("label");
      nameLabel.innerHTML = "<span>Python 参数名</span>";
      const nameInput = document.createElement("input");
      nameInput.value = binding.name;
      nameInput.spellcheck = false;
      nameInput.onchange = () => {
        const name = nameInput.value.trim();
        if(!isValidIdentifier(name) || bindings.some((item, itemIndex) => itemIndex !== index && item.name === name)){
          toast("参数名无效", "请使用不重复的 Python 变量名，且不要使用运行时保留名称");
          nameInput.value = binding.name;
          return;
        }
        const next = bindings.map((item, itemIndex) => itemIndex === index ? { ...item, name } : item);
        commitBindings(node.id, next);
        refresh();
      };
      nameLabel.appendChild(nameInput);

      const displayLabel = document.createElement("label");
      displayLabel.innerHTML = "<span>端口显示名</span>";
      const labelInput = document.createElement("input");
      labelInput.value = binding.label;
      labelInput.onchange = () => {
        const label = labelInput.value.trim() || binding.name;
        const next = bindings.map((item, itemIndex) => itemIndex === index ? { ...item, label } : item);
        commitBindings(node.id, next);
        refresh();
      };
      displayLabel.appendChild(labelInput);

      const typeLabel = document.createElement("label");
      typeLabel.innerHTML = "<span>数据类型</span>";
      const typeSelect = document.createElement("select");
      INPUT_TYPES.forEach(([value, text]) => {
        const option = document.createElement("option");
        option.value = value;
        option.textContent = text;
        option.selected = value === binding.type;
        typeSelect.appendChild(option);
      });
      typeSelect.onchange = () => {
        const next = bindings.map((item, itemIndex) => itemIndex === index ? { ...item, type:typeSelect.value } : item);
        commitBindings(node.id, next);
        refresh();
      };
      typeLabel.appendChild(typeSelect);

      const flags = document.createElement("div");
      flags.className = "snippet-binding-flags";
      const requiredLabel = document.createElement("label");
      const required = document.createElement("input");
      required.type = "checkbox";
      required.checked = binding.required === true;
      required.onchange = () => {
        const next = bindings.map((item, itemIndex) => itemIndex === index ? { ...item, required:required.checked } : item);
        commitBindings(node.id, next);
        refresh();
      };
      requiredLabel.append(required, document.createTextNode("必填"));
      const defaultLabel = document.createElement("label");
      const defaultEnabled = document.createElement("input");
      defaultEnabled.type = "checkbox";
      defaultEnabled.checked = binding.default_enabled === true;
      defaultEnabled.onchange = () => {
        const next = bindings.map((item, itemIndex) => itemIndex === index
          ? { ...item, default_enabled:defaultEnabled.checked, default:defaultEnabled.checked ? (item.default ?? null) : undefined }
          : item);
        commitBindings(node.id, next);
        refresh();
      };
      defaultLabel.append(defaultEnabled, document.createTextNode("未连接时使用默认值"));
      flags.append(requiredLabel, defaultLabel);

      const defaultInput = document.createElement("input");
      defaultInput.className = "snippet-binding-default";
      defaultInput.placeholder = '默认值 JSON，例如 128、true、"text"、[1,2]';
      defaultInput.value = binding.default_enabled ? JSON.stringify(binding.default) : "";
      defaultInput.disabled = !binding.default_enabled;
      defaultInput.onchange = () => {
        try{
          const parsed = defaultInput.value.trim() ? JSON.parse(defaultInput.value) : null;
          const next = bindings.map((item, itemIndex) => itemIndex === index ? { ...item, default_enabled:true, default:parsed } : item);
          commitBindings(node.id, next);
          refresh();
        }catch(error){
          toast("默认值格式错误", error.message || String(error));
          defaultInput.value = JSON.stringify(binding.default);
        }
      };
      grid.append(nameLabel, displayLabel, typeLabel, flags, defaultInput);
      row.append(head, grid);
      list.appendChild(row);
    });
    container.appendChild(list);
  }

  function renderCustomParams(container, node){
    container.innerHTML = "";
    const hint = document.createElement("p");
    hint.className = "snippet-setting-hint";
    hint.textContent = "可选。这里配置不会生成端口，代码中通过 settings['key'] 读取。";
    const textarea = document.createElement("textarea");
    textarea.className = "snippet-json-editor";
    textarea.spellcheck = false;
    textarea.value = JSON.stringify(node.params?.custom_params || {}, null, 2);
    const status = document.createElement("div");
    status.className = "snippet-validation compact";
    status.textContent = "必须是 JSON 对象。";
    function save(){
      try{
        const parsed = textarea.value.trim() ? JSON.parse(textarea.value) : {};
        if(!parsed || Array.isArray(parsed) || typeof parsed !== "object") throw new Error("代码参数必须是 JSON 对象");
        setParamSilently(node.id, "custom_params", parsed);
        status.className = "snippet-validation compact ok";
        status.textContent = "代码参数已保存。";
      }catch(error){
        status.className = "snippet-validation compact error";
        status.textContent = error.message || String(error);
      }
    }
    textarea.addEventListener("blur", save);
    textarea.addEventListener("keydown", event => {
      if((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "s"){
        event.preventDefault();
        save();
      }
    });
    container.append(hint, textarea, status);
  }

  function renderPythonSnippetInlineEditor(container, node, key, value, schema){
    const wrapper = document.createElement("div");
    wrapper.className = "python-snippet-inline";
    const header = document.createElement("div");
    header.className = "python-snippet-inline-head";
    header.innerHTML = `<b>Python 自定义算子</b><span>${getBindings(node).length} 个命名输入 · Ctrl/⌘+Enter 运行到此节点</span>`;
    const actions = document.createElement("div");
    actions.className = "python-snippet-inline-actions";
    const open = document.createElement("button");
    open.type = "button";
    open.textContent = "打开开发界面";
    open.onclick = event => { event.stopPropagation(); openPythonSnippetIde(node.id); };
    const validate = document.createElement("button");
    validate.type = "button";
    validate.textContent = "校验";
    const skeleton = document.createElement("button");
    skeleton.type = "button";
    skeleton.textContent = "插入函数骨架";
    const validation = document.createElement("div");
    validation.className = "snippet-validation compact";
    validation.textContent = "推荐使用 process(命名参数...)；普通返回值会自动适配。";
    const editor = makeTextarea(value ?? "", null);
    editor.textarea.classList.add("node-param-textarea");
    editor.textarea.rows = Math.max(8, Number(schema.rows || 12));
    editor.textarea.addEventListener("mousedown", event => selectNodeWithoutRerender(node.id, event));
    editor.textarea.addEventListener("keydown", event => {
      if((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "s"){
        event.preventDefault();
        commitCode(node.id, key, editor.textarea.value);
      }else if((event.ctrlKey || event.metaKey) && event.key === "Enter"){
        event.preventDefault();
        commitCode(node.id, key, editor.textarea.value);
        selectedNodeId = node.id;
        if(typeof executeDebugAction === "function") executeDebugAction("run_to_node");
        else runWorkflow();
      }
    });
    editor.textarea.onchange = () => commitCode(node.id, key, editor.textarea.value);
    validate.onclick = event => { event.stopPropagation(); validateCode(editor.textarea.value, validation, node); };
    skeleton.onclick = event => { event.stopPropagation(); insertAtCursor(editor.textarea, processSignature(node, true)); };
    actions.append(open, validate, skeleton);
    wrapper.append(header, actions, editor.wrap, validation);
    container.appendChild(wrapper);
  }

  function renderPythonSnippetParamPanel(node, meta){
    const previewState = previewFor(node.id) ? "已生成节点输出" : "尚未运行";
    return `<h3>${esc(node.id)} · ${esc(meta.label || node.type)}</h3>
      <div class="snippet-param-summary">
        <div><b>${getBindings(node).length} 个命名输入</b><span>${esc(processSignature(node))}<br>${esc(meta.description || "")}</span></div>
        <button class="btn" onclick="openPythonSnippetIde('${esc(node.id)}')">打开 Python 开发界面</button>
      </div>
      <div class="snippet-side-section"><h4>当前接口</h4>${renderInputContract(node)}</div>
      <div class="snippet-side-section"><h4>自动输出规则</h4>${objectTable(OUTPUT_CONTRACT)}</div>
      <div class="snippet-side-section"><h4>最近运行</h4><div class="hint">${esc(previewState)}</div>${renderLastRun(node)}</div>
      <div class="row-actions"><button class="btn ghost" onclick="duplicateNode('${esc(node.id)}')">复制节点</button><button class="btn red" onclick="deleteNode('${esc(node.id)}')">删除节点</button></div>`;
  }

  function createModal(){
    let modal = document.getElementById("pythonSnippetIde");
    if(modal) return modal;
    modal = document.createElement("div");
    modal.id = "pythonSnippetIde";
    modal.className = "snippet-ide";
    modal.innerHTML = `<div class="snippet-ide-backdrop" data-close="1"></div>
      <div class="snippet-ide-dialog" role="dialog" aria-modal="true" aria-labelledby="snippetIdeTitle">
        <div class="snippet-ide-topbar">
          <div><strong id="snippetIdeTitle">Python 自定义算子</strong><span id="snippetIdeSubtitle"></span></div>
          <div class="snippet-ide-top-actions">
            <button type="button" data-action="run">保存并运行到此节点</button>
            <button type="button" data-action="save" class="primary">保存代码</button>
            <button type="button" data-action="close" class="icon">×</button>
          </div>
        </div>
        <div class="snippet-ide-body">
          <aside class="snippet-ide-left">
            <section><h4>命名输入参数</h4><div id="snippetIdeBindingManager"></div></section>
            <section><h4>当前接口</h4><div id="snippetIdeInputs"></div></section>
            <section><h4>运行时 API</h4><div id="snippetIdeVariables"></div></section>
          </aside>
          <main class="snippet-ide-center">
            <div class="snippet-template-bar" id="snippetTemplateBar"></div>
            <div id="snippetIdeEditorMount"></div>
            <div id="snippetIdeValidation" class="snippet-validation compact">保存前可校验语法、安全限制和 process 参数映射。</div>
          </main>
          <aside class="snippet-ide-right">
            <section><h4>代码参数 settings</h4><div id="snippetIdeCustomParams"></div></section>
            <section><h4>运行设置</h4><div id="snippetIdeParams"></div></section>
            <section><h4>自动输出规则</h4><div id="snippetIdeOutputs"></div></section>
            <section><h4>最近运行输出</h4><div id="snippetIdeLastRun"></div></section>
            <section><h4>快捷键</h4><div class="snippet-shortcuts"><kbd>Tab / Shift+Tab</kbd><span>缩进 / 反缩进</span><kbd>Ctrl/⌘ + /</kbd><span>切换行注释</span><kbd>Ctrl/⌘ + S</kbd><span>保存代码</span><kbd>Ctrl/⌘ + Enter</kbd><span>运行到此节点</span></div></section>
          </aside>
        </div>
      </div>`;
    document.body.appendChild(modal);
    modal.addEventListener("mousedown", event => { if(event.target?.dataset?.close) closePythonSnippetIde(); });
    modal.querySelector('[data-action="close"]').onclick = closePythonSnippetIde;
    return modal;
  }
  function renderParamsControls(node){
    const controls = [
      ["timeout_ms", "超时ms", "number"],
      ["isolated", "隔离执行", "select", [["YES", "是，独立子进程"]]],
      ["output_kind", "导出类型", "select", [["AUTO", "自动"], ["IMAGE", "图像"], ["VALUE", "值"], ["BOOLEAN", "布尔"]]],
      ["output_color_space", "输出颜色", "select", [["AUTO", "自动"], ["BGR", "BGR"], ["RGB", "RGB"], ["GRAY", "GRAY"]]],
    ];
    return controls.map(([key, label, type, options]) => {
      const value = node.params?.[key] ?? getMeta(node.type).params?.[key] ?? "";
      if(type === "select"){
        return `<label class="snippet-setting"><span>${esc(label)}</span><select data-snippet-param="${esc(key)}">${options.map(([v, text]) => `<option value="${esc(v)}" ${String(v) === String(value) ? "selected" : ""}>${esc(text)}</option>`).join("")}</select></label>`;
      }
      return `<label class="snippet-setting"><span>${esc(label)}</span><input data-snippet-param="${esc(key)}" type="number" value="${esc(value)}"></label>`;
    }).join("");
  }
  function templateDefinitions(node){
    const bindings = getBindings(node);
    const imageName = bindings.find(item => item.type === "image")?.name || bindings[0]?.name || "image";
    const secondName = bindings.find(item => item.name !== imageName)?.name || "mask";
    return {
      skeleton:{ label:"函数骨架", description:"按当前输入参数生成 process()", code:processSignature(node, true) },
      image:{ label:"图像透传", description:"返回图像并输出统计指标", code:`def process(${imageName}=None):\n    if ${imageName} is None:\n        raise ValueError("输入图像不能为空")\n    result = ${imageName}.copy()\n    return {\n        "out": result,\n        "metrics": {"shape": list(result.shape), "dtype": str(result.dtype)},\n    }\n` },
      multi:{ label:"多输入图像", description:"演示两个命名输入共同参与处理", code:`def process(${imageName}=None, ${secondName}=None):\n    if ${imageName} is None:\n        raise ValueError("主输入不能为空")\n    if ${secondName} is None:\n        return ${imageName}\n    mask = ${secondName}\n    if isinstance(mask, np.ndarray) and mask.ndim == 3:\n        mask = cv2.cvtColor(mask, cv2.COLOR_BGR2GRAY)\n    mask = (mask > 0).astype(np.uint8) * 255\n    return cv2.bitwise_and(${imageName}, ${imageName}, mask=mask)\n` },
      contour:{ label:"轮廓测量", description:"返回图像和结构化测量结果", code:`def process(${imageName}=None):\n    if ${imageName} is None:\n        raise ValueError("输入图像不能为空")\n    gray = cv2.cvtColor(${imageName}, cv2.COLOR_BGR2GRAY) if ${imageName}.ndim == 3 else ${imageName}\n    _, binary = cv2.threshold(gray, int(settings.get("threshold", 128)), 255, cv2.THRESH_BINARY)\n    contours, _ = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)\n    areas = [float(cv2.contourArea(item)) for item in contours]\n    return {\n        "out": binary,\n        "metrics": {"count": len(contours), "max_area": max(areas) if areas else 0.0},\n        "data": {"areas": areas},\n    }\n` },
      object:{ label:"普通对象返回", description:"无需记忆输出契约，直接返回业务字典", code:`def process(**kwargs):\n    return {\n        "received": list(kwargs.keys()),\n        "types": {key: type(value).__name__ for key, value in kwargs.items()},\n    }\n` },
      legacy:{ label:"兼容旧接口", description:"旧工作流仍可使用 inputs/params/context", code:`def process(inputs, params, context):\n    image = inputs.get("in")\n    return image\n` },
    };
  }

  function openPythonSnippetIde(nodeId){
    const node = getNode(nodeId);
    if(!node || node.type !== "PythonSnippet"){
      toast("无法打开", "请选择一个 Python 自定义算子节点");
      return;
    }
    selectedNodeId = node.id;
    selectedEdgeId = null;
    const meta = getMeta(node.type);
    const modal = createModal();
    modal.dataset.nodeId = node.id;
    modal.classList.add("open");
    document.body.classList.add("snippet-ide-open");
    document.getElementById("snippetIdeTitle").textContent = `${node.id} · ${meta.label || node.type}`;
    document.getElementById("snippetIdeSubtitle").textContent = "命名端口即函数参数；直接 return 常见 Python 对象即可";

    const mount = document.getElementById("snippetIdeEditorMount");
    mount.innerHTML = "";
    const currentCode = node.params?.code ?? meta.params?.code ?? "";
    let dirty = false;
    const editor = makeTextarea(currentCode, () => { dirty = true; });
    mount.appendChild(editor.wrap);

    function refreshSidebars(){
      const latest = getNode(nodeId);
      if(!latest) return;
      document.getElementById("snippetIdeInputs").innerHTML = renderInputContract(latest);
      document.getElementById("snippetIdeVariables").innerHTML = objectTable(RUNTIME_VARIABLES);
      document.getElementById("snippetIdeOutputs").innerHTML = objectTable(OUTPUT_CONTRACT);
      document.getElementById("snippetIdeLastRun").innerHTML = renderLastRun(latest);
      renderBindingManager(document.getElementById("snippetIdeBindingManager"), latest, refreshAll);
      renderCustomParams(document.getElementById("snippetIdeCustomParams"), latest);
      renderTemplateBar(latest);
    }
    function refreshAll(){
      const latest = getNode(nodeId);
      if(!latest) return;
      refreshSidebars();
      if(typeof render === "function") render();
    }
    function renderTemplateBar(latest){
      const templateBar = document.getElementById("snippetTemplateBar");
      const templates = templateDefinitions(latest);
      templateBar.innerHTML = Object.entries(templates).map(([key, item]) => `<button type="button" data-template="${esc(key)}" title="${esc(item.description)}">${esc(item.label)}</button>`).join("") + `<button type="button" data-action="validate">校验代码</button>`;
      templateBar.querySelectorAll("[data-template]").forEach(button => {
        button.onclick = event => {
          event.stopPropagation();
          const tpl = templates[button.dataset.template];
          if(!tpl) return;
          if(editor.textarea.value.trim() && !confirm(`用“${tpl.label}”替换当前代码？选择取消会插入到光标位置。`)){
            insertAtCursor(editor.textarea, `\n\n${tpl.code}`);
          }else{
            editor.textarea.value = tpl.code;
            editor.textarea.dispatchEvent(new Event("input", { bubbles:true }));
          }
        };
      });
      templateBar.querySelector('[data-action="validate"]').onclick = event => {
        event.stopPropagation();
        validateCode(editor.textarea.value, document.getElementById("snippetIdeValidation"), getNode(nodeId));
      };
    }
    function save(){
      const latest = getNode(nodeId);
      if(!latest) return false;
      latest.params.code = editor.textarea.value;
      latest.params.input_bindings = getBindings(latest);
      invalidateNodeAndDownstreamPreviews(nodeId);
      commitActiveWorkflowChange();
      if(typeof render === "function") render();
      dirty = false;
      setStatus(`已保存 ${nodeId} 的 Python 代码`);
      toast("代码已保存", processSignature(latest), true);
      return true;
    }
    async function runToNode(){
      if(!save()) return;
      selectedNodeId = nodeId;
      const runButton = modal.querySelector('[data-action="run"]');
      runButton.disabled = true;
      try{
        if(typeof executeDebugAction === "function") await executeDebugAction("run_to_node");
        else await runWorkflow();
      }finally{
        runButton.disabled = false;
        refreshSidebars();
      }
    }

    document.getElementById("snippetIdeParams").innerHTML = renderParamsControls(node);
    modal.querySelectorAll("[data-snippet-param]").forEach(control => {
      control.onchange = () => {
        const key = control.dataset.snippetParam;
        const value = control.type === "number" ? Number(control.value) : control.value;
        setParamSilently(nodeId, key, value);
        setStatus(`已更新 ${nodeId}.${key}`);
      };
    });
    modal.querySelector('[data-action="save"]').onclick = event => { event.stopPropagation(); save(); };
    modal.querySelector('[data-action="run"]').onclick = event => { event.stopPropagation(); runToNode(); };
    editor.textarea.addEventListener("keydown", event => {
      if((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "s"){
        event.preventDefault();
        save();
      }else if((event.ctrlKey || event.metaKey) && event.key === "Enter"){
        event.preventDefault();
        runToNode();
      }
    });
    modal.dataset.dirty = "0";
    editor.textarea.addEventListener("input", () => { modal.dataset.dirty = dirty ? "1" : "0"; });
    function resetEditorViewport(){
      const scrollTargets = [
        modal,
        modal.querySelector(".snippet-ide-dialog"),
        modal.querySelector(".snippet-ide-body"),
        modal.querySelector(".snippet-ide-left"),
        modal.querySelector(".snippet-ide-center"),
        modal.querySelector(".snippet-ide-right"),
        mount,
        editor.wrap,
        editor.shell,
      ];
      scrollTargets.forEach(element => {
        if(!element) return;
        element.scrollTop = 0;
        element.scrollLeft = 0;
      });
      editor.textarea.setSelectionRange(0, 0);
      editor.textarea.scrollTop = 0;
      editor.textarea.scrollLeft = 0;
      editor.gutter.scrollTop = 0;
    }

    refreshSidebars();
    resetEditorViewport();
    requestAnimationFrame(() => {
      try{
        editor.textarea.focus({ preventScroll:true });
      }catch(_error){
        editor.textarea.focus();
      }
      // 某些浏览器会在聚焦长文本末尾时滚动 overflow:hidden 的祖先容器。
      // 聚焦后再次复位，确保开发界面始终从标题栏和代码第一行开始显示。
      resetEditorViewport();
      requestAnimationFrame(resetEditorViewport);
    });
    window.__activePythonSnippetEditor = editor;
  }
  function closePythonSnippetIde(){
    const modal = document.getElementById("pythonSnippetIde");
    if(modal) modal.classList.remove("open");
    document.body.classList.remove("snippet-ide-open");
  }

  window.renderPythonSnippetInlineEditor = renderPythonSnippetInlineEditor;
  window.renderPythonSnippetParamPanel = renderPythonSnippetParamPanel;
  window.openPythonSnippetIde = openPythonSnippetIde;
  window.closePythonSnippetIde = closePythonSnippetIde;
})();
