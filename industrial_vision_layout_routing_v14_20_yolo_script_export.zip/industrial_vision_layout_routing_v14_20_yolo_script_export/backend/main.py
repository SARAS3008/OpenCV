from __future__ import annotations

from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from backend.algorithms.ai.yolo.model_manager import YoloModelManager
from backend.algorithms.contract_validation import validate_operator_contracts
from backend.algorithms.registry import OPERATORS, OPERATOR_META
from backend.api.router import api_router
from backend.config import (
    ALLOWED_IMAGE_EXTENSIONS,
    ARTIFACTS_DIR,
    ARTIFACT_BACKEND,
    AUTH_DIR,
    DATABASE_URL,
    DATASETS_DIR,
    FRONTEND_DIR,
    JOBS_DIR,
    JOB_WORKERS,
    LOG_LEVEL,
    MODEL_CACHE_MAX_ITEMS,
    MODEL_CACHE_TTL_SECONDS,
    MODEL_DIR,
    MODEL_METADATA_PATH,
    OBJECT_STORAGE_ACCESS_KEY,
    OBJECT_STORAGE_BUCKET,
    OBJECT_STORAGE_ENDPOINT,
    OBJECT_STORAGE_SECRET_KEY,
    OBJECT_STORAGE_SECURE,
    PROJECTS_DIR,
    PROJECT_ROOT,
    REDIS_URL,
    RUN_HISTORY_DIR,
    SESSION_BACKEND,
    STATE_BACKEND,
    STATE_DIR,
    UPLOAD_DIR,
    WORKSPACES_DIR,
)
from backend.infrastructure.artifact_store import FileArtifactStore, S3ArtifactStore
from backend.infrastructure.observability import ApplicationMetrics, configure_logging, request_observability_middleware
from backend.infrastructure.state_backend import FileJsonStateBackend, create_state_backend
from backend.services.auth_store import AuthStore
from backend.services.dataset_store import DatasetStore
from backend.services.image_store import ImageStore
from backend.services.job_queue import JobQueue
from backend.services.project_store import ProjectStore
from backend.services.run_history_store import RunHistoryStore
from backend.services.team_store import WorkspaceStore
from backend.services.workflow_debugger import workflow_debug_manager
from backend.services.workflow_run_manager import workflow_run_manager


def _create_artifact_store():
    if ARTIFACT_BACKEND in {"file", "filesystem", "local"}:
        return FileArtifactStore(ARTIFACTS_DIR)
    if ARTIFACT_BACKEND in {"s3", "minio"}:
        return S3ArtifactStore(
            endpoint=OBJECT_STORAGE_ENDPOINT,
            bucket=OBJECT_STORAGE_BUCKET,
            access_key=OBJECT_STORAGE_ACCESS_KEY,
            secret_key=OBJECT_STORAGE_SECRET_KEY,
            secure=OBJECT_STORAGE_SECURE,
        )
    raise ValueError(f"不支持的产物存储后端：{ARTIFACT_BACKEND}")


def create_app() -> FastAPI:
    configure_logging(LOG_LEVEL)
    contract_report = validate_operator_contracts(OPERATORS, OPERATOR_META)
    contract_report.raise_for_errors()

    state_backend = create_state_backend(
        STATE_BACKEND,
        root_dir=STATE_DIR / "domain",
        database_url=DATABASE_URL,
        redis_url=REDIS_URL,
    )
    session_backend = create_state_backend(
        SESSION_BACKEND,
        root_dir=STATE_DIR / "sessions",
        database_url=DATABASE_URL,
        redis_url=REDIS_URL,
    )
    # Jobs are persisted even in local mode so a restart marks unfinished work as interrupted.
    job_state_backend = session_backend if SESSION_BACKEND != "file" else FileJsonStateBackend(JOBS_DIR / "state")
    domain_backend = state_backend if STATE_BACKEND != "file" else None
    distributed_session_backend = session_backend if SESSION_BACKEND != "file" else None
    artifact_store = _create_artifact_store()

    model_manager = YoloModelManager(
        model_dir=MODEL_DIR,
        metadata_path=MODEL_METADATA_PATH,
        max_items=MODEL_CACHE_MAX_ITEMS,
        ttl_seconds=MODEL_CACHE_TTL_SECONDS,
        path_base=PROJECT_ROOT,
    )
    job_queue = JobQueue(max_workers=JOB_WORKERS, state_backend=job_state_backend)

    @asynccontextmanager
    async def lifespan(application: FastAPI):
        yield
        workflow_debug_manager.clear()
        workflow_run_manager.clear()
        job_queue.shutdown(wait=False, cancel_futures=True)
        model_manager.clear_cache()
        closed: set[int] = set()
        for resource in (artifact_store, job_state_backend, session_backend, state_backend):
            if id(resource) in closed:
                continue
            closed.add(id(resource))
            resource.close()

    application = FastAPI(
        title="Industrial Vision Workflow",
        version="2.9.0",
        lifespan=lifespan,
    )
    application.state.metrics = ApplicationMetrics()
    application.state.operator_contract_report = contract_report
    application.state.state_backend = state_backend
    application.state.session_backend = session_backend
    application.state.artifact_store = artifact_store
    application.state.auth_store = AuthStore(AUTH_DIR, session_backend=distributed_session_backend, user_backend=domain_backend)
    application.state.image_store = ImageStore(
        upload_dir=UPLOAD_DIR,
        allowed_extensions=ALLOWED_IMAGE_EXTENSIONS,
    )
    application.state.model_manager = model_manager
    application.state.project_store = ProjectStore(PROJECTS_DIR, state_backend=domain_backend)
    application.state.workspace_store = WorkspaceStore(WORKSPACES_DIR, presence_backend=distributed_session_backend, state_backend=domain_backend)
    application.state.dataset_store = DatasetStore(DATASETS_DIR, state_backend=domain_backend)
    application.state.run_history_store = RunHistoryStore(RUN_HISTORY_DIR, state_backend=domain_backend)
    application.state.job_queue = job_queue
    application.middleware("http")(request_observability_middleware)
    application.include_router(api_router, prefix="/api")
    application.mount(
        "/assets",
        StaticFiles(directory=FRONTEND_DIR / "assets"),
        name="assets",
    )

    @application.get("/", include_in_schema=False)
    def index() -> FileResponse:
        return FileResponse(FRONTEND_DIR / "index.html")

    return application


app = create_app()
