from __future__ import annotations

import ast
import inspect
import re
import textwrap
from collections import defaultdict
from typing import Any

from backend.algorithms.registry import CUSTOM_SCRIPT_COMPILERS
from backend.models.workflow import WorkflowRequest
from backend.services.workflow_engine import topological_sort


def _normalize_type(node_type: str, params: dict[str, Any]) -> tuple[str, dict[str, Any]]:
    normalized = dict(params)
    if node_type == "Gray":
        normalized["mode"] = "GRAY"
        return "ColorConvert", normalized
    if node_type == "BGR2RGB":
        normalized["mode"] = "RGB"
        return "ColorConvert", normalized
    if node_type == "BatchReadImages":
        return "ReadImage", normalized
    if node_type == "SaveBatchResults":
        return "Display", normalized
    return node_type, normalized


def _safe_identifier(value: str) -> str:
    cleaned = re.sub(r"\W+", "_", value, flags=re.UNICODE).strip("_")
    if not cleaned or cleaned[0].isdigit():
        cleaned = f"node_{cleaned}"
    return cleaned


def _statement(source: str) -> ast.stmt:
    return ast.parse(source).body[0]


def _expression(source: str) -> ast.expr:
    return ast.parse(source, mode="eval").body


def _gray_expression(variable: str, color_space: str) -> str:
    if color_space == "GRAY":
        return variable
    if color_space == "RGB":
        return f"cv2.cvtColor({variable}, cv2.COLOR_RGB2GRAY)"
    return f"cv2.cvtColor({variable}, cv2.COLOR_BGR2GRAY)"


def _bgr_expression(variable: str, color_space: str) -> str:
    if color_space == "BGR":
        return variable
    if color_space == "RGB":
        return f"cv2.cvtColor({variable}, cv2.COLOR_RGB2BGR)"
    return f"cv2.cvtColor({variable}, cv2.COLOR_GRAY2BGR)"


def _odd(value: Any, default: int, minimum: int = 1) -> int:
    try:
        result = int(float(value))
    except (TypeError, ValueError):
        result = default
    result = max(minimum, result)
    return result if result % 2 else result + 1


def _integer(value: Any, default: int) -> int:
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return default


def _floating(value: Any, default: float) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _compile_operator(
    node_type: str,
    params: dict[str, Any],
    input_var: str,
    input_color: str,
) -> tuple[list[ast.stmt], str, str]:
    """Return statements, result expression variable placeholder, and output color space."""
    statements: list[ast.stmt] = []
    output_color = input_color

    if node_type == "Display":
        expression = input_var
    elif node_type == "ColorConvert":
        mode = str(params.get("mode", "GRAY")).upper()
        if mode == "GRAY":
            expression = _gray_expression(input_var, input_color)
            output_color = "GRAY"
        elif mode == "RGB":
            if input_color == "RGB":
                expression = f"{input_var}.copy()"
            elif input_color == "GRAY":
                expression = f"cv2.cvtColor({input_var}, cv2.COLOR_GRAY2RGB)"
            else:
                expression = f"cv2.cvtColor({input_var}, cv2.COLOR_BGR2RGB)"
            output_color = "RGB"
        else:
            raise ValueError(f"不支持的颜色转换模式：{mode}")
    elif node_type == "Invert":
        expression = f"cv2.bitwise_not({input_var})"
    elif node_type == "Normalize":
        expression = f"cv2.normalize({input_var}, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)"
    elif node_type == "EqualizeHist":
        expression = f"cv2.equalizeHist({_gray_expression(input_var, input_color)})"
        output_color = "GRAY"
    elif node_type == "CLAHE":
        clip = _floating(params.get("clip_limit", 2.0), 2.0)
        tile = max(1, _integer(params.get("tile_grid", 8), 8))
        statements.append(_statement(f"clahe = cv2.createCLAHE(clipLimit={clip!r}, tileGridSize=({tile}, {tile}))"))
        expression = f"clahe.apply({_gray_expression(input_var, input_color)})"
        output_color = "GRAY"
    elif node_type == "MeanBlur":
        size = _odd(params.get("ksize", 5), 5)
        expression = f"cv2.blur({input_var}, ({size}, {size}))"
    elif node_type == "GaussianBlur":
        size = _odd(params.get("ksize", 5), 5)
        sigma = _floating(params.get("sigma", 0), 0.0)
        expression = f"cv2.GaussianBlur({input_var}, ({size}, {size}), {sigma!r})"
    elif node_type == "MedianBlur":
        size = _odd(params.get("ksize", 5), 5)
        expression = f"cv2.medianBlur({input_var}, {size})"
    elif node_type == "BilateralFilter":
        diameter = _integer(params.get("d", 7), 7)
        sigma_color = _floating(params.get("sigma_color", 75), 75.0)
        sigma_space = _floating(params.get("sigma_space", 75), 75.0)
        expression = f"cv2.bilateralFilter({input_var}, {diameter}, {sigma_color!r}, {sigma_space!r})"
    elif node_type == "Sharpen":
        amount = _floating(params.get("amount", 1.0), 1.0)
        statements.append(_statement(f"sharpen_kernel = np.array([[0, -1, 0], [-1, {4 + amount!r}, -1], [0, -1, 0]], dtype=np.float32)"))
        expression = f"cv2.filter2D({input_var}, -1, sharpen_kernel)"
    elif node_type == "Threshold":
        threshold = _integer(params.get("threshold", 127), 127)
        maximum = _integer(params.get("max_value", 255), 255)
        expression = f"cv2.threshold({_gray_expression(input_var, input_color)}, {threshold}, {maximum}, cv2.THRESH_BINARY)[1]"
        output_color = "GRAY"
    elif node_type == "OtsuThreshold":
        expression = f"cv2.threshold({_gray_expression(input_var, input_color)}, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1]"
        output_color = "GRAY"
    elif node_type == "AdaptiveThreshold":
        block = _odd(params.get("block_size", 11), 11, 3)
        constant = _integer(params.get("c", 2), 2)
        gray = _gray_expression(input_var, input_color)
        expression = f"cv2.adaptiveThreshold({gray}, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, {block}, {constant})"
        output_color = "GRAY"
    elif node_type == "Canny":
        low = _integer(params.get("threshold1", 50), 50)
        high = _integer(params.get("threshold2", 150), 150)
        expression = f"cv2.Canny({_gray_expression(input_var, input_color)}, {low}, {high})"
        output_color = "GRAY"
    elif node_type == "Sobel":
        dx = _integer(params.get("dx", 1), 1)
        dy = _integer(params.get("dy", 0), 0)
        size = _odd(params.get("ksize", 3), 3)
        statements.append(_statement(f"gradient = cv2.Sobel({_gray_expression(input_var, input_color)}, cv2.CV_16S, {dx}, {dy}, ksize={size})"))
        expression = "cv2.convertScaleAbs(gradient)"
        output_color = "GRAY"
    elif node_type == "Laplacian":
        size = _odd(params.get("ksize", 3), 3)
        statements.append(_statement(f"laplacian = cv2.Laplacian({_gray_expression(input_var, input_color)}, cv2.CV_16S, ksize={size})"))
        expression = "cv2.convertScaleAbs(laplacian)"
        output_color = "GRAY"
    elif node_type in {"Erode", "Dilate", "MorphOpen", "MorphClose", "MorphGradient"}:
        size = _odd(params.get("ksize", 3), 3)
        statements.append(_statement(f"kernel = np.ones(({size}, {size}), np.uint8)"))
        if node_type == "Erode":
            iterations = max(0, _integer(params.get("iterations", 1), 1))
            expression = f"cv2.erode({input_var}, kernel, iterations={iterations})"
        elif node_type == "Dilate":
            iterations = max(0, _integer(params.get("iterations", 1), 1))
            expression = f"cv2.dilate({input_var}, kernel, iterations={iterations})"
        else:
            operation = {
                "MorphOpen": "cv2.MORPH_OPEN",
                "MorphClose": "cv2.MORPH_CLOSE",
                "MorphGradient": "cv2.MORPH_GRADIENT",
            }[node_type]
            expression = f"cv2.morphologyEx({input_var}, {operation}, kernel)"
    elif node_type == "Resize":
        scale = max(1.0, _floating(params.get("scale_percent", 50), 50.0))
        statements.extend(
            [
                _statement(f"height, width = {input_var}.shape[:2]"),
                _statement(f"new_width = max(1, int(width * {scale!r} / 100.0))"),
                _statement(f"new_height = max(1, int(height * {scale!r} / 100.0))"),
            ]
        )
        expression = f"cv2.resize({input_var}, (new_width, new_height), interpolation=cv2.INTER_AREA)"
    elif node_type == "Flip":
        code = _integer(params.get("flip_code", 1), 1)
        code = code if code in {-1, 0, 1} else 1
        expression = f"cv2.flip({input_var}, {code})"
    elif node_type == "Rotate90":
        direction = _integer(params.get("direction", 0), 0)
        rotation = {1:"cv2.ROTATE_90_COUNTERCLOCKWISE", 2:"cv2.ROTATE_180"}.get(direction, "cv2.ROTATE_90_CLOCKWISE")
        expression = f"cv2.rotate({input_var}, {rotation})"
    elif node_type == "FindContours":
        threshold = _integer(params.get("threshold", 127), 127)
        minimum = _floating(params.get("min_area", 20), 20.0)
        gray = _gray_expression(input_var, input_color)
        bgr = _bgr_expression(input_var, input_color)
        statements.extend(
            [
                _statement(f"binary = cv2.threshold({gray}, {threshold}, 255, cv2.THRESH_BINARY)[1]"),
                _statement("contours, _ = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)"),
                _statement(f"canvas = {bgr}.copy()"),
                _statement("contour_count = 0"),
                ast.parse(
                    f"""for contour in contours:
    if cv2.contourArea(contour) < {minimum!r}:
        continue
    cv2.drawContours(canvas, [contour], -1, (0, 255, 0), 2)
    x, y, w, h = cv2.boundingRect(contour)
    cv2.rectangle(canvas, (x, y), (x + w, y + h), (0, 180, 255), 1)
    contour_count += 1"""
                ).body[0],
                _statement("cv2.putText(canvas, f'contours: {contour_count}', (12, 28), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 220, 255), 2)"),
            ]
        )
        expression = "canvas"
        output_color = "BGR"
    elif node_type == "FilterContours":
        threshold = _integer(params.get("threshold", 127), 127)
        sort_by = str(params.get("sort_by", "area") or "area")
        if sort_by not in {"area", "perimeter", "bbox_width", "bbox_height", "bbox_area", "aspect_ratio", "circularity", "solidity", "extent", "center_x", "center_y"}:
            sort_by = "area"
        select_mode = str(params.get("select_mode", "MAX") or "MAX").upper()
        top_k = max(1, _integer(params.get("top_k", 1), 1))
        nth_index = max(0, _integer(params.get("nth_index", 0), 0))
        min_area = _floating(params.get("min_area", 0), 0.0)
        max_area = _floating(params.get("max_area", 0), 0.0)
        min_perimeter = _floating(params.get("min_perimeter", 0), 0.0)
        max_perimeter = _floating(params.get("max_perimeter", 0), 0.0)
        gray = _gray_expression(input_var, input_color)
        bgr = _bgr_expression(input_var, input_color)
        statements.extend(
            [
                _statement(f"binary = cv2.threshold({gray}, {threshold}, 255, cv2.THRESH_BINARY)[1]"),
                _statement("contours, _ = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)"),
                _statement("contour_items = []"),
                ast.parse(
                    f"""for contour in contours:
    area = float(cv2.contourArea(contour))
    perimeter = float(cv2.arcLength(contour, True))
    if area < {min_area!r} or ({max_area!r} > 0 and area > {max_area!r}):
        continue
    if perimeter < {min_perimeter!r} or ({max_perimeter!r} > 0 and perimeter > {max_perimeter!r}):
        continue
    x, y, w, h = cv2.boundingRect(contour)
    bbox_area = float(w * h)
    hull_area = float(cv2.contourArea(cv2.convexHull(contour)))
    item = {{
        'contour': contour,
        'area': area,
        'perimeter': perimeter,
        'bbox_width': float(w),
        'bbox_height': float(h),
        'bbox_area': bbox_area,
        'aspect_ratio': float(w / h) if h else 0.0,
        'extent': float(area / bbox_area) if bbox_area else 0.0,
        'solidity': float(area / hull_area) if hull_area else 0.0,
        'circularity': float((4.0 * np.pi * area) / (perimeter * perimeter)) if perimeter else 0.0,
        'center_x': float(x + w / 2.0),
        'center_y': float(y + h / 2.0),
    }}
    contour_items.append(item)"""
                ).body[0],
                _statement(f"reverse = {select_mode!r} not in {{'MIN', 'BOTTOM_K'}}"),
                _statement(f"contour_items = sorted(contour_items, key=lambda item: item.get({sort_by!r}, 0.0), reverse=reverse)"),
                _statement(f"selected = contour_items[:1] if {select_mode!r} in {{'MAX', 'MIN'}} else (contour_items[:{top_k}] if {select_mode!r} in {{'TOP_K', 'BOTTOM_K'}} else contour_items[{nth_index}:{nth_index}+1])"),
                _statement("canvas = " + bgr + ".copy()"),
                _statement("selected_contours = [item['contour'] for item in selected]"),
                ast.parse("""if selected_contours:
    cv2.drawContours(canvas, selected_contours, -1, (0, 255, 0), 2)
    x, y, w, h = cv2.boundingRect(np.vstack(selected_contours))
    cv2.rectangle(canvas, (x, y), (x + w, y + h), (0, 180, 255), 2)""").body[0],
                _statement("cv2.putText(canvas, f'selected: {len(selected_contours)}/{len(contour_items)}', (12, 28), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 220, 255), 2)"),
            ]
        )
        expression = "canvas"
        output_color = "BGR"
    else:
        raise ValueError(f"算子暂不支持导出为独立算法脚本：{node_type}")

    return statements, expression, output_color



def _compile_orb_feature_match_for_export(
    params: dict[str, Any],
    input_var: str,
    input_color: str,
    prefix: str,
) -> tuple[list[ast.stmt], dict[str, dict[str, str]]]:
    # 独立脚本只有一个命令行输入图，因此 ORB 节点导出时使用 template_path/mask_path 参数读取模板和模板 mask。
    template_path = str(params.get("template_path") or "").strip()
    if not template_path:
        raise ValueError("ORBFeatureMatch 导出脚本时需要在节点参数 template_path 中填写模板图片路径")

    n_features = max(50, _integer(params.get("n_features", 1000), 1000))
    scale_factor = max(1.01, _floating(params.get("scale_factor", 1.2), 1.2))
    n_levels = max(1, _integer(params.get("n_levels", 8), 8))
    fast_threshold = max(0, _integer(params.get("fast_threshold", 20), 20))
    ratio_test = min(0.99, max(0.05, _floating(params.get("ratio_test", 0.75), 0.75)))
    min_matches = max(4, _integer(params.get("min_matches", 8), 8))
    max_draw_matches = max(0, _integer(params.get("max_draw_matches", 40), 40))
    ransac_threshold = max(0.1, _floating(params.get("ransac_reproj_threshold", 5.0), 5.0))
    roi_mode = str(params.get("roi_mode", "FULL") or "FULL").strip().upper()
    if roi_mode not in {"FULL", "RECT", "MASK"}:
        roi_mode = "FULL"
    transform_model = str(params.get("transform_model", "HOMOGRAPHY") or "HOMOGRAPHY").strip().upper()
    if transform_model not in {"HOMOGRAPHY", "AFFINE", "AFFINE_PARTIAL"}:
        transform_model = "HOMOGRAPHY"
    output_mode = str(params.get("output_mode", "MASK") or "MASK").strip().upper()
    if output_mode not in {"MASK", "MASKED", "ROI", "ROI_MASK", "ANNOTATED"}:
        output_mode = "MASK"
    mask_threshold = max(0, min(255, _integer(params.get("mask_threshold", 1), 1)))
    roi_x = _integer(params.get("roi_x", 0), 0)
    roi_y = _integer(params.get("roi_y", 0), 0)
    roi_w = _integer(params.get("roi_w", 0), 0)
    roi_h = _integer(params.get("roi_h", 0), 0)
    mask_path = str(params.get("mask_path") or "").strip()
    crop_apply_mask = str(params.get("crop_apply_mask", "YES") or "YES").strip().upper() not in {"NO", "FALSE", "0", "OFF", "否"}

    image_gray = _gray_expression(input_var, input_color)
    image_bgr = _bgr_expression(input_var, input_color)
    source = f"""
{prefix}_template = read_image({template_path!r})
if {prefix}_template is None:
    raise ValueError("无法读取 ORB 模板图片：{template_path}")
{prefix}_image_gray = {image_gray}
{prefix}_image_bgr = {image_bgr}
{prefix}_template_gray = cv2.cvtColor({prefix}_template, cv2.COLOR_BGR2GRAY) if {prefix}_template.ndim != 2 else {prefix}_template
{prefix}_template_bgr = cv2.cvtColor({prefix}_template, cv2.COLOR_GRAY2BGR) if {prefix}_template.ndim == 2 else {prefix}_template
{prefix}_template_h, {prefix}_template_w = {prefix}_template_gray.shape[:2]
if {roi_mode!r} == "MASK":
    {prefix}_mask_image = read_image({mask_path!r}) if {bool(mask_path)!r} else None
    if {prefix}_mask_image is None:
        raise ValueError("ORBFeatureMatch 导出脚本使用 MASK ROI 时，需要填写可读取的 mask_path")
    {prefix}_template_roi_mask = cv2.cvtColor({prefix}_mask_image, cv2.COLOR_BGR2GRAY) if {prefix}_mask_image.ndim != 2 else {prefix}_mask_image
    if {prefix}_template_roi_mask.shape[:2] != ({prefix}_template_h, {prefix}_template_w):
        raise ValueError("模板 mask 尺寸必须与模板图一致")
    _, {prefix}_template_roi_mask = cv2.threshold({prefix}_template_roi_mask.astype(np.uint8), {mask_threshold}, 255, cv2.THRESH_BINARY)
elif {roi_mode!r} == "RECT":
    {prefix}_x = max(0, min({prefix}_template_w - 1, int({roi_x})))
    {prefix}_y = max(0, min({prefix}_template_h - 1, int({roi_y})))
    {prefix}_rw = int({roi_w}) if int({roi_w}) > 0 else {prefix}_template_w - {prefix}_x
    {prefix}_rh = int({roi_h}) if int({roi_h}) > 0 else {prefix}_template_h - {prefix}_y
    {prefix}_rw = max(1, min({prefix}_rw, {prefix}_template_w - {prefix}_x))
    {prefix}_rh = max(1, min({prefix}_rh, {prefix}_template_h - {prefix}_y))
    {prefix}_template_roi_mask = np.zeros(({prefix}_template_h, {prefix}_template_w), dtype=np.uint8)
    {prefix}_template_roi_mask[{prefix}_y:{prefix}_y + {prefix}_rh, {prefix}_x:{prefix}_x + {prefix}_rw] = 255
else:
    {prefix}_template_roi_mask = np.full(({prefix}_template_h, {prefix}_template_w), 255, dtype=np.uint8)
{prefix}_orb = cv2.ORB_create(nfeatures={n_features}, scaleFactor={scale_factor!r}, nlevels={n_levels}, fastThreshold={fast_threshold})
{prefix}_template_keypoints, {prefix}_template_descriptors = {prefix}_orb.detectAndCompute({prefix}_template_gray, None)
{prefix}_image_keypoints, {prefix}_image_descriptors = {prefix}_orb.detectAndCompute({prefix}_image_gray, None)
{prefix}_raw_match_count = 0
{prefix}_good_matches = []
if {prefix}_template_descriptors is not None and {prefix}_image_descriptors is not None and len({prefix}_template_keypoints) and len({prefix}_image_keypoints):
    {prefix}_matcher = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=False)
    {prefix}_knn_matches = {prefix}_matcher.knnMatch({prefix}_template_descriptors, {prefix}_image_descriptors, k=2)
    {prefix}_raw_match_count = len({prefix}_knn_matches)
    for {prefix}_pair in {prefix}_knn_matches:
        if len({prefix}_pair) < 2:
            continue
        {prefix}_first, {prefix}_second = {prefix}_pair
        if {prefix}_first.distance < {ratio_test!r} * {prefix}_second.distance:
            {prefix}_good_matches.append({prefix}_first)
{prefix}_good_matches.sort(key=lambda match: match.distance)
{prefix}_transform_matrix = None
{prefix}_homography = None
{prefix}_affine = None
{prefix}_homography_mask = []
{prefix}_corners = []
{prefix}_inlier_count = 0
{prefix}_transform_found = False
{prefix}_out_canvas = {prefix}_image_bgr.copy()
if len({prefix}_good_matches) >= {min_matches}:
    {prefix}_src_points = np.float32([{prefix}_template_keypoints[m.queryIdx].pt for m in {prefix}_good_matches]).reshape(-1, 1, 2)
    {prefix}_dst_points = np.float32([{prefix}_image_keypoints[m.trainIdx].pt for m in {prefix}_good_matches]).reshape(-1, 1, 2)
    if {transform_model!r} == "HOMOGRAPHY":
        {prefix}_homography, {prefix}_mask = cv2.findHomography({prefix}_src_points, {prefix}_dst_points, cv2.RANSAC, {ransac_threshold!r})
        if {prefix}_homography is not None and {prefix}_mask is not None:
            {prefix}_transform_matrix = {prefix}_homography
            {prefix}_homography_mask = {prefix}_mask.ravel().astype(int).tolist()
            {prefix}_inlier_count = int(sum({prefix}_homography_mask))
            {prefix}_transform_found = {prefix}_inlier_count >= max(4, {min_matches} // 2)
    else:
        {prefix}_estimator = cv2.estimateAffinePartial2D if {transform_model!r} == "AFFINE_PARTIAL" else cv2.estimateAffine2D
        {prefix}_affine, {prefix}_mask = {prefix}_estimator({prefix}_src_points, {prefix}_dst_points, method=cv2.RANSAC, ransacReprojThreshold={ransac_threshold!r})
        if {prefix}_affine is not None and {prefix}_mask is not None:
            {prefix}_transform_matrix = {prefix}_affine
            {prefix}_homography = np.vstack([{prefix}_affine, np.array([0.0, 0.0, 1.0], dtype=np.float64)])
            {prefix}_homography_mask = {prefix}_mask.ravel().astype(int).tolist()
            {prefix}_inlier_count = int(sum({prefix}_homography_mask))
            {prefix}_transform_found = {prefix}_inlier_count >= max(3, {min_matches} // 2)
{prefix}_template_corners = np.float32([[0, 0], [{prefix}_template_w - 1, 0], [{prefix}_template_w - 1, {prefix}_template_h - 1], [0, {prefix}_template_h - 1]]).reshape(-1, 1, 2)
if {prefix}_transform_matrix is not None:
    if {transform_model!r} == "HOMOGRAPHY":
        {prefix}_projected = cv2.perspectiveTransform({prefix}_template_corners, {prefix}_transform_matrix).reshape(-1, 2)
    else:
        {prefix}_projected = cv2.transform({prefix}_template_corners, {prefix}_transform_matrix).reshape(-1, 2)
    {prefix}_corners = [[round(float(x), 3), round(float(y), 3)] for x, y in {prefix}_projected]
    if {prefix}_transform_found:
        cv2.polylines({prefix}_out_canvas, [np.int32({prefix}_projected).reshape(-1, 1, 2)], True, (0, 255, 0), 3, cv2.LINE_AA)
{prefix}_target_h, {prefix}_target_w = {prefix}_image_gray.shape[:2]
if {prefix}_transform_found and {prefix}_transform_matrix is not None:
    if {transform_model!r} == "HOMOGRAPHY":
        {prefix}_target_mask = cv2.warpPerspective({prefix}_template_roi_mask, {prefix}_transform_matrix, ({prefix}_target_w, {prefix}_target_h), flags=cv2.INTER_NEAREST, borderMode=cv2.BORDER_CONSTANT, borderValue=0)
    else:
        {prefix}_target_mask = cv2.warpAffine({prefix}_template_roi_mask, {prefix}_transform_matrix, ({prefix}_target_w, {prefix}_target_h), flags=cv2.INTER_NEAREST, borderMode=cv2.BORDER_CONSTANT, borderValue=0)
    _, {prefix}_target_mask = cv2.threshold({prefix}_target_mask.astype(np.uint8), 1, 255, cv2.THRESH_BINARY)
else:
    {prefix}_target_mask = np.zeros(({prefix}_target_h, {prefix}_target_w), dtype=np.uint8)
{prefix}_contours, _ = cv2.findContours({prefix}_target_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
{prefix}_bbox = [0, 0, 0, 0]
{prefix}_roi_polygon = []
if {prefix}_contours:
    {prefix}_largest = max({prefix}_contours, key=cv2.contourArea)
    {prefix}_x, {prefix}_y, {prefix}_bw, {prefix}_bh = cv2.boundingRect({prefix}_largest)
    {prefix}_bbox = [int({prefix}_x), int({prefix}_y), int({prefix}_bw), int({prefix}_bh)]
    {prefix}_epsilon = max(1.0, 0.01 * cv2.arcLength({prefix}_largest, True))
    {prefix}_approx = cv2.approxPolyDP({prefix}_largest, {prefix}_epsilon, True).reshape(-1, 2)
    {prefix}_roi_polygon = [[round(float(px), 3), round(float(py), 3)] for px, py in {prefix}_approx[:200]]
    cv2.drawContours({prefix}_out_canvas, {prefix}_contours, -1, (255, 180, 0), 2, cv2.LINE_AA)
    cv2.rectangle({prefix}_out_canvas, ({prefix}_x, {prefix}_y), ({prefix}_x + {prefix}_bw, {prefix}_y + {prefix}_bh), (0, 180, 255), 2, cv2.LINE_AA)
{prefix}_masked = cv2.bitwise_and({prefix}_image_bgr, {prefix}_image_bgr, mask={prefix}_target_mask)
if {prefix}_bbox[2] > 0 and {prefix}_bbox[3] > 0:
    {prefix}_x, {prefix}_y, {prefix}_bw, {prefix}_bh = {prefix}_bbox
    {prefix}_roi = {prefix}_image_bgr[{prefix}_y:{prefix}_y + {prefix}_bh, {prefix}_x:{prefix}_x + {prefix}_bw].copy()
    {prefix}_roi_mask = {prefix}_target_mask[{prefix}_y:{prefix}_y + {prefix}_bh, {prefix}_x:{prefix}_x + {prefix}_bw].copy()
    if {crop_apply_mask!r}:
        {prefix}_roi = cv2.bitwise_and({prefix}_roi, {prefix}_roi, mask={prefix}_roi_mask)
else:
    {prefix}_roi = np.zeros((1, 1, 3), dtype=np.uint8)
    {prefix}_roi_mask = np.zeros((1, 1), dtype=np.uint8)
{prefix}_draw_matches = {prefix}_good_matches[:{max_draw_matches}] if {max_draw_matches} else []
for {prefix}_match in {prefix}_draw_matches:
    x, y = {prefix}_image_keypoints[{prefix}_match.trainIdx].pt
    cv2.circle({prefix}_out_canvas, (int(round(x)), int(round(y))), 3, (0, 180, 255), -1, cv2.LINE_AA)
if {prefix}_draw_matches:
    {prefix}_matches_canvas = cv2.drawMatches({prefix}_template_bgr, {prefix}_template_keypoints, {prefix}_image_bgr, {prefix}_image_keypoints, {prefix}_draw_matches, None, flags=cv2.DrawMatchesFlags_NOT_DRAW_SINGLE_POINTS)
else:
    {prefix}_left = {prefix}_template_bgr
    {prefix}_right = {prefix}_image_bgr
    {prefix}_join_height = max({prefix}_left.shape[0], {prefix}_right.shape[0])
    {prefix}_join_width = {prefix}_left.shape[1] + {prefix}_right.shape[1]
    {prefix}_matches_canvas = np.zeros(({prefix}_join_height, {prefix}_join_width, 3), dtype=np.uint8)
    {prefix}_matches_canvas[:{prefix}_left.shape[0], :{prefix}_left.shape[1]] = {prefix}_left
    {prefix}_matches_canvas[:{prefix}_right.shape[0], {prefix}_left.shape[1]:{prefix}_left.shape[1] + {prefix}_right.shape[1]] = {prefix}_right
if {prefix}_good_matches:
    {prefix}_avg_distance = float(np.mean([match.distance for match in {prefix}_good_matches[:max(1, min(len({prefix}_good_matches), {min_matches} * 2))]]))
    {prefix}_distance_score = max(0.0, min(1.0, 1.0 - {prefix}_avg_distance / 256.0))
else:
    {prefix}_distance_score = 0.0
{prefix}_count_score = max(0.0, min(1.0, len({prefix}_good_matches) / float(max(1, {min_matches}))))
{prefix}_inlier_score = max(0.0, min(1.0, {prefix}_inlier_count / float(max(1, len({prefix}_good_matches))))) if {prefix}_good_matches else 0.0
{prefix}_confidence = round(float({prefix}_distance_score * (0.45 + 0.35 * {prefix}_count_score + 0.20 * {prefix}_inlier_score)), 4)
if not {prefix}_transform_found:
    {prefix}_confidence = round({prefix}_confidence * 0.65, 4)
{prefix}_status_text = f"ORB {transform_model} good:{{len({prefix}_good_matches)}} inliers:{{{prefix}_inlier_count}} conf:{{{prefix}_confidence:.2f}}" if {prefix}_transform_found else f"ORB not found good:{{len({prefix}_good_matches)}} need:{{{min_matches}}}"
cv2.putText({prefix}_out_canvas, {prefix}_status_text, (12, 28), cv2.FONT_HERSHEY_SIMPLEX, 0.72, (0, 220, 255), 2, cv2.LINE_AA)
cv2.putText({prefix}_matches_canvas, {prefix}_status_text, (12, 28), cv2.FONT_HERSHEY_SIMPLEX, 0.72, (0, 220, 255), 2, cv2.LINE_AA)
{prefix}_homography_list = {prefix}_homography.round(6).tolist() if {prefix}_homography is not None else None
{prefix}_affine_list = {prefix}_affine.round(6).tolist() if {prefix}_affine is not None else None
if {output_mode!r} == "ROI":
    {prefix}_selected_out = {prefix}_roi
elif {output_mode!r} == "ROI_MASK":
    {prefix}_selected_out = {prefix}_roi_mask
elif {output_mode!r} == "MASKED":
    {prefix}_selected_out = {prefix}_masked
elif {output_mode!r} == "ANNOTATED":
    {prefix}_selected_out = {prefix}_out_canvas
else:
    {prefix}_selected_out = {prefix}_target_mask
"""
    statements = ast.parse(source).body
    out_color = "GRAY" if output_mode in {"MASK", "ROI_MASK"} else "BGR"
    return statements, {
        "out": {"expression": f"{prefix}_selected_out", "kind": "image", "color_space": out_color},
        "mask": {"expression": f"{prefix}_target_mask", "kind": "image", "color_space": "GRAY"},
        "roi": {"expression": f"{prefix}_roi", "kind": "image", "color_space": "BGR"},
        "roi_mask": {"expression": f"{prefix}_roi_mask", "kind": "image", "color_space": "GRAY"},
        "masked": {"expression": f"{prefix}_masked", "kind": "image", "color_space": "BGR"},
        "annotated": {"expression": f"{prefix}_out_canvas", "kind": "image", "color_space": "BGR"},
        "matches": {"expression": f"{prefix}_matches_canvas", "kind": "image", "color_space": "BGR"},
        "match_count": {"expression": f"{prefix}_raw_match_count", "kind": "value", "color_space": ""},
        "good_match_count": {"expression": f"len({prefix}_good_matches)", "kind": "value", "color_space": ""},
        "inlier_count": {"expression": f"{prefix}_inlier_count", "kind": "value", "color_space": ""},
        "confidence": {"expression": f"{prefix}_confidence", "kind": "value", "color_space": ""},
        "homography_found": {"expression": f"{prefix}_transform_found", "kind": "boolean", "color_space": ""},
        "transform_found": {"expression": f"{prefix}_transform_found", "kind": "boolean", "color_space": ""},
        "corners": {"expression": f"{prefix}_corners", "kind": "value", "color_space": ""},
        "roi_bbox": {"expression": f"{prefix}_bbox", "kind": "value", "color_space": ""},
        "roi_polygon": {"expression": f"{prefix}_roi_polygon", "kind": "value", "color_space": ""},
        "homography": {"expression": f"{prefix}_homography_list", "kind": "value", "color_space": ""},
        "affine": {"expression": f"{prefix}_affine_list", "kind": "value", "color_space": ""},
    }


def _invoke_script_compiler(compiler, input_var: str, input_color: str, params: dict[str, Any], prefix: str):
    """调用自定义脚本编译器，并兼容 3 参数和 4 参数两种签名。"""

    try:
        signature = inspect.signature(compiler)
        accepts_prefix = any(
            parameter.kind == inspect.Parameter.VAR_POSITIONAL
            for parameter in signature.parameters.values()
        ) or len(signature.parameters) >= 4
    except (TypeError, ValueError):
        accepts_prefix = False
    if accepts_prefix:
        return compiler(input_var, input_color, params, prefix)
    return compiler(input_var, input_color, params)


def _normalize_output_specs(raw_result: Any, default_color: str) -> tuple[list[str], dict[str, dict[str, str]]]:
    """把新旧自定义 script_compiler 返回值统一成按输出端口索引的表达式。

    旧协议：([statement_source], expression, color_space)，只描述 out 图像端口。
    新协议：([statement_source], {handle: expression 或 {expression, kind, color_space}})。
    kind 支持 image/value/boolean；未指定时 out 默认为 image，其余端口默认为 value。
    """

    if not isinstance(raw_result, tuple):
        raise ValueError("script_compiler 必须返回 tuple")
    if len(raw_result) == 3:
        statement_sources, expression, output_color = raw_result
        return list(statement_sources or []), {
            "out": {
                "expression": str(expression),
                "kind": "image",
                "color_space": str(output_color or default_color or "BGR"),
            }
        }
    if len(raw_result) != 2:
        raise ValueError("script_compiler 返回值必须是 2 项或 3 项 tuple")

    statement_sources, raw_outputs = raw_result
    if not isinstance(raw_outputs, dict) or not raw_outputs:
        raise ValueError("script_compiler 的多输出协议必须返回非空 outputs 字典")

    outputs: dict[str, dict[str, str]] = {}
    for handle, spec in raw_outputs.items():
        output_handle = str(handle or "out")
        if isinstance(spec, str):
            expression = spec
            kind = "image" if output_handle == "out" else "value"
            color_space = default_color if kind == "image" else ""
        elif isinstance(spec, dict):
            expression = str(spec.get("expression") or "")
            kind = str(spec.get("kind") or ("image" if output_handle == "out" else "value"))
            color_space = str(spec.get("color_space") or (default_color if kind == "image" else ""))
        else:
            raise ValueError(f"输出端口 {output_handle} 的编译描述必须是字符串或字典")
        if not expression:
            raise ValueError(f"输出端口 {output_handle} 缺少 expression")
        outputs[output_handle] = {
            "expression": expression,
            "kind": kind,
            "color_space": color_space,
        }
    return list(statement_sources or []), outputs



def _literal_constant(value: Any, value_type: str) -> Any:
    normalized = str(value_type or "NUMBER").upper()
    if normalized == "BOOLEAN":
        if isinstance(value, str):
            return value.strip().lower() not in {"", "0", "false", "no", "off", "否", "假"}
        return bool(value)
    if normalized == "TEXT":
        return str(value)
    return _floating(value, 0.0)


def _logic_compare_expression(left: str, right: str, operator: str) -> str:
    symbol = {
        "GT": ">", "GE": ">=", "LT": "<", "LE": "<=", "NE": "!=", "EQ": "==",
    }.get(str(operator or "EQ").upper(), "==")
    return f"({left} {symbol} {right})"


def _logic_update_expression(value: str, operation: str, step: Any) -> str:
    symbol = {
        "SUBTRACT": "-", "MULTIPLY": "*", "DIVIDE": "/", "ADD": "+",
    }.get(str(operation or "ADD").upper(), "+")
    numeric_step = _floating(step, 1.0)
    if symbol == "/" and numeric_step == 0:
        raise ValueError("循环更新的除数不能为 0")
    return f"({value} {symbol} {numeric_step!r})"


def _compile_python_snippet_for_export(
    params: dict[str, Any],
    input_vars: dict[str, str],
    prefix: str,
) -> tuple[list[ast.stmt], dict[str, dict[str, str]]]:
    code = str(params.get("code") or "").strip("\ufeff")
    if not code.strip():
        raise ValueError("Python代码片段为空，无法导出")
    from backend.algorithms.script.python_snippet import _validate_code, normalize_input_bindings

    _validate_code(code)
    bindings = normalize_input_bindings(params.get("input_bindings"), strict=True)
    runtime_params = {key: value for key, value in params.items() if key != "code"}
    runtime_params["input_bindings"] = bindings
    input_items = ", ".join(f"{handle!r}: {variable}" for handle, variable in sorted(input_vars.items()))
    named_items: list[str] = []
    input_meta: list[dict[str, Any]] = []
    for binding in bindings:
        handle = str(binding["handle"])
        name = str(binding["name"])
        if handle in input_vars:
            expression = input_vars[handle]
            connected = True
            used_default = False
        elif binding.get("default_enabled", False):
            expression = repr(binding.get("default"))
            connected = False
            used_default = True
        else:
            expression = "None"
            connected = False
            used_default = False
        named_items.append(f"{name!r}: {expression}")
        input_meta.append(
            {
                "handle": handle,
                "name": name,
                "label": str(binding.get("label") or name),
                "type": str(binding.get("type") or "any"),
                "required": bool(binding.get("required", False)),
                "connected": connected,
                "used_default": used_default,
            }
        )
    named_input_items = ", ".join(named_items)
    output_kind_param = str(params.get("output_kind", "AUTO") or "AUTO").upper()
    if output_kind_param == "VALUE":
        out_kind = "value"
    elif output_kind_param == "BOOLEAN":
        out_kind = "boolean"
    else:
        out_kind = "image"
    output_color = str(params.get("output_color_space") or "BGR").upper()
    if output_color not in {"BGR", "RGB", "GRAY"}:
        output_color = "BGR"

    source = f'''
{prefix}_ports = {{{input_items}}}
{prefix}_args = {{{named_input_items}}}
{prefix}_inputs = dict({prefix}_ports)
for {prefix}_name, {prefix}_value in {prefix}_args.items():
    {prefix}_inputs.setdefault({prefix}_name, {prefix}_value)
{prefix}_params = {runtime_params!r}
{prefix}_settings = {prefix}_params.get("custom_params") if isinstance({prefix}_params.get("custom_params"), dict) else {{}}
{prefix}_context = {{"exported": True}}
{prefix}_input_meta = {input_meta!r}
def {prefix}_get_input(name, default=None):
    value = {prefix}_inputs.get(name, default)
    return default if value is None else value
def {prefix}_emit(value=None, **outputs):
    if outputs:
        if value is not None and "out" not in outputs and "value" not in outputs:
            outputs["out"] = value
        return outputs
    return {{"out": value}}
{prefix}_namespace = {{
    "inputs": {prefix}_inputs,
    "ports": {prefix}_ports,
    "args": {prefix}_args,
    "params": {prefix}_params,
    "settings": {prefix}_settings,
    "context": {prefix}_context,
    "input_meta": {prefix}_input_meta,
    "np": np,
    "cv2": cv2,
    "math": math,
    "statistics": statistics,
    "json": json,
    "get_input": {prefix}_get_input,
    "emit": {prefix}_emit,
    "out": None,
    "metrics": {{}},
    "data": {{}},
}}
{prefix}_namespace.update({prefix}_args)
{prefix}_globals = {{
    "__builtins__": {{
        "abs": abs, "all": all, "any": any, "bool": bool, "bytes": bytes, "bytearray": bytearray,
        "dict": dict, "enumerate": enumerate, "filter": filter, "float": float, "int": int,
        "isinstance": isinstance, "len": len, "list": list, "map": map, "max": max, "min": min,
        "pow": pow, "print": print, "range": range, "reversed": reversed, "round": round,
        "set": set, "frozenset": frozenset, "slice": slice, "sorted": sorted, "str": str,
        "sum": sum, "tuple": tuple, "type": type, "iter": iter, "next": next, "repr": repr,
        "zip": zip, "Exception": Exception, "ValueError": ValueError, "TypeError": TypeError,
        "RuntimeError": RuntimeError,
    }},
    **{prefix}_namespace,
}}
exec(compile({code!r}, "<PythonSnippet>", "exec"), {prefix}_globals, {prefix}_namespace)
{prefix}_process = {prefix}_namespace.get("process") or {prefix}_globals.get("process")
if callable({prefix}_process):
    {prefix}_signature = inspect.signature({prefix}_process)
    {prefix}_special = {{
        "inputs": {prefix}_inputs, "ports": {prefix}_ports, "args": {prefix}_args,
        "params": {prefix}_params, "settings": {prefix}_settings,
        "context": {prefix}_context, "input_meta": {prefix}_input_meta,
    }}
    {prefix}_positional = []
    {prefix}_keyword = {{}}
    {prefix}_consumed = set()
    {prefix}_available = {{item["name"] for item in {prefix}_input_meta if item.get("connected") or item.get("used_default")}}
    {prefix}_var_kwargs = False
    for {prefix}_parameter in {prefix}_signature.parameters.values():
        if {prefix}_parameter.kind is inspect.Parameter.VAR_POSITIONAL:
            continue
        if {prefix}_parameter.kind is inspect.Parameter.VAR_KEYWORD:
            {prefix}_var_kwargs = True
            continue
        if {prefix}_parameter.name in {prefix}_args and ({prefix}_parameter.name in {prefix}_available or {prefix}_parameter.default is inspect.Parameter.empty):
            {prefix}_argument = {prefix}_args[{prefix}_parameter.name]
            {prefix}_consumed.add({prefix}_parameter.name)
        elif {prefix}_parameter.name in {prefix}_special:
            {prefix}_argument = {prefix}_special[{prefix}_parameter.name]
        elif {prefix}_parameter.default is not inspect.Parameter.empty:
            continue
        else:
            raise ValueError(f"process() 参数 {{{prefix}_parameter.name}} 没有对应输入")
        if {prefix}_parameter.kind is inspect.Parameter.POSITIONAL_ONLY:
            {prefix}_positional.append({prefix}_argument)
        else:
            {prefix}_keyword[{prefix}_parameter.name] = {prefix}_argument
    if {prefix}_var_kwargs:
        for {prefix}_name, {prefix}_value in {prefix}_args.items():
            if {prefix}_name not in {prefix}_consumed and {prefix}_name not in {prefix}_keyword:
                {prefix}_keyword[{prefix}_name] = {prefix}_value
    {prefix}_raw = {prefix}_process(*{prefix}_positional, **{prefix}_keyword)
elif "result" in {prefix}_namespace:
    {prefix}_raw = {prefix}_namespace["result"]
else:
    {prefix}_raw = {{key: {prefix}_namespace[key] for key in ("out", "image", "value", "metrics", "data") if key in {prefix}_namespace}}
{prefix}_contract_keys = {{"out", "image", "value", "metrics", "data", "result", "out_color_space", "image_color_space"}}
if isinstance({prefix}_raw, dict) and set({prefix}_raw).intersection({prefix}_contract_keys):
    {prefix}_result = dict({prefix}_raw)
elif isinstance({prefix}_raw, dict):
    {prefix}_result = {{"out": {prefix}_raw, "value": {prefix}_raw, "data": {{"result": {prefix}_raw}}}}
elif isinstance({prefix}_raw, np.ndarray):
    {prefix}_result = {{"out": {prefix}_raw, "image": {prefix}_raw}}
else:
    {prefix}_result = {{"out": {prefix}_raw, "value": {prefix}_raw}}
if "out" not in {prefix}_result:
    if isinstance({prefix}_result.get("image"), np.ndarray):
        {prefix}_result["out"] = {prefix}_result["image"]
    elif "value" in {prefix}_result:
        {prefix}_result["out"] = {prefix}_result["value"]
if "image" not in {prefix}_result and isinstance({prefix}_result.get("out"), np.ndarray):
    {prefix}_result["image"] = {prefix}_result["out"]
if "value" not in {prefix}_result and not isinstance({prefix}_result.get("out"), np.ndarray):
    {prefix}_result["value"] = {prefix}_result.get("out")
'''
    statements = ast.parse(textwrap.dedent(source)).body
    return statements, {
        "out": {"expression": f"{prefix}_result.get('out')", "kind": out_kind, "color_space": output_color if out_kind == "image" else ""},
        "image": {"expression": f"{prefix}_result.get('image', {prefix}_result.get('out'))", "kind": "image", "color_space": output_color},
        "value": {"expression": f"{prefix}_result.get('value', {prefix}_result.get('out'))", "kind": "value", "color_space": ""},
        "data": {"expression": f"{prefix}_result.get('data', {{}})", "kind": "value", "color_space": ""},
    }


def _compile_logic_operator(
    node_type: str,
    params: dict[str, Any],
    input_vars: dict[str, str],
    input_kinds: dict[str, str],
    input_colors: dict[str, str],
    prefix: str,
) -> tuple[list[ast.stmt], str, str, str]:
    statements: list[ast.stmt] = []
    output_kind = "value"
    output_color = ""

    if node_type == "LogicConstant":
        value = _literal_constant(params.get("value", 0), str(params.get("value_type", "NUMBER")))
        expression = repr(value)
        output_kind = "boolean" if isinstance(value, bool) else "value"
    elif node_type == "LogicCompare":
        expression = _logic_compare_expression(input_vars["a"], input_vars["b"], str(params.get("operator", "GT")))
        output_kind = "boolean"
    elif node_type == "LogicBoolean":
        left = f"bool({input_vars['a']})"
        right = f"bool({input_vars['b']})"
        operation = str(params.get("operation", "AND")).upper()
        expression = {
            "OR": f"({left} or {right})",
            "XOR": f"({left} != {right})",
            "NAND": f"(not ({left} and {right}))",
            "NOR": f"(not ({left} or {right}))",
        }.get(operation, f"({left} and {right})")
        output_kind = "boolean"
    elif node_type == "LogicNot":
        expression = f"(not bool({input_vars['in']}))"
        output_kind = "boolean"
    elif node_type == "LogicIfElse":
        condition = input_vars["condition"]
        true_var = input_vars["true_value"]
        false_var = input_vars["false_value"]
        true_kind = input_kinds.get("true_value", "value")
        false_kind = input_kinds.get("false_value", "value")
        if true_kind == false_kind == "image":
            true_color = input_colors.get("true_value", "BGR")
            false_color = input_colors.get("false_value", "BGR")
            if true_color != false_color:
                true_var = _bgr_expression(true_var, true_color)
                false_var = _bgr_expression(false_var, false_color)
                output_color = "BGR"
            else:
                output_color = true_color
            output_kind = "image"
        elif true_kind == false_kind:
            output_kind = true_kind
        expression = f"({true_var} if bool({condition}) else {false_var})"
    elif node_type == "LogicForLoop":
        initial = input_vars.get("in", repr(_floating(params.get("initial_value", 0), 0.0)))
        iterations = max(0, min(10000, _integer(params.get("iterations", 1), 1)))
        value_name = f"{prefix}_value"
        statements.append(_statement(f"{value_name} = {initial}"))
        update = _logic_update_expression(value_name, str(params.get("update_operation", "ADD")), params.get("step", 1))
        statements.append(ast.parse(f"for _ in range({iterations}):\n    {value_name} = {update}").body[0])
        expression = value_name
    elif node_type == "LogicWhileLoop":
        initial = input_vars.get("in", repr(_floating(params.get("initial_value", 0), 0.0)))
        value_name = f"{prefix}_value"
        count_name = f"{prefix}_iterations"
        compare_value = repr(_floating(params.get("compare_value", 10), 10.0))
        condition = _logic_compare_expression(value_name, compare_value, str(params.get("compare_operator", "LT")))
        update = _logic_update_expression(value_name, str(params.get("update_operation", "ADD")), params.get("step", 1))
        max_iterations = max(1, min(10000, _integer(params.get("max_iterations", 100), 100)))
        statements.extend([
            _statement(f"{value_name} = {initial}"),
            _statement(f"{count_name} = 0"),
            ast.parse(
                f"while {condition} and {count_name} < {max_iterations}:\n"
                f"    {value_name} = {update}\n"
                f"    {count_name} += 1"
            ).body[0],
        ])
        expression = value_name
    else:
        raise ValueError(f"逻辑节点暂不支持脚本导出：{node_type}")

    return statements, expression, output_kind, output_color

def _yes_flag(value: Any, default: bool = False) -> bool:
    if value is None:
        return default
    return str(value).strip().upper() in {"1", "TRUE", "YES", "Y", "是", "ON"}


def _batch_csv_fields(params: dict[str, Any]) -> dict[str, dict[str, Any]]:
    result: dict[str, dict[str, Any]] = {}
    raw_fields = params.get("csv_fields")
    if not isinstance(raw_fields, list):
        return result
    for item in raw_fields:
        if not isinstance(item, dict):
            continue
        handle = str(item.get("input") or "").strip()
        if not handle:
            continue
        result[handle] = {
            "enabled": item.get("enabled") is not False,
            "column": str(item.get("column") or "").strip(),
        }
    return result



def _standalone_yolo_runtime_nodes() -> list[ast.stmt]:
    """Embed the standalone-safe YOLO runtime without importing the platform backend."""

    from backend.services import standalone_yolo_runtime

    source = inspect.getsource(standalone_yolo_runtime)
    if "backend." in source or "from backend" in source or "import backend" in source:
        raise RuntimeError("独立YOLO运行时不能依赖平台backend包")
    parsed = ast.parse(source)
    return [
        item
        for item in parsed.body
        if not (
            isinstance(item, ast.ImportFrom)
            and item.module == "__future__"
        )
    ]


def _yolo_mask_output_count(params: dict[str, Any]) -> int:
    raw_indices = params.get("class_indices")
    indices: list[int] = []
    if isinstance(raw_indices, (list, tuple, set)):
        parts = list(raw_indices)
    else:
        text = str(raw_indices or "").strip()
        text = text.replace("，", ",").replace("；", ",").replace(";", ",").replace(" ", ",")
        for token in "[]()（）":
            text = text.replace(token, "")
        parts = [part for part in text.split(",") if part.strip()]
    for part in parts:
        try:
            value = int(str(part).strip())
        except (TypeError, ValueError):
            continue
        if value >= 0 and value not in indices:
            indices.append(value)
    return min(20, len(indices) if indices else max(1, _integer(params.get("top_k", 2), 2)))


def _compile_yolo_infer_for_export(
    node_id: str,
    params: dict[str, Any],
    input_var: str,
    input_color: str,
    prefix: str,
) -> tuple[list[ast.stmt], dict[str, dict[str, str]]]:
    source = f"{prefix}_result = run_yolo_infer_node({node_id!r}, {input_var}, {input_color!r}, {params!r})"
    statements = ast.parse(source).body
    return statements, {
        "out": {"expression": f"{prefix}_result['out']", "kind": "image", "color_space": "BGR"},
        "detections": {"expression": f"{prefix}_result.get('detections', [])", "kind": "value", "color_space": ""},
        "count": {"expression": f"{prefix}_result.get('count', 0)", "kind": "value", "color_space": ""},
        "top_class": {"expression": f"{prefix}_result.get('top_class', '')", "kind": "value", "color_space": ""},
        "top_confidence": {"expression": f"{prefix}_result.get('top_confidence', 0.0)", "kind": "value", "color_space": ""},
        "task": {"expression": f"{prefix}_result.get('task', '')", "kind": "value", "color_space": ""},
        "metrics": {"expression": f"{prefix}_result.get('metrics', {{}})", "kind": "value", "color_space": ""},
        "data": {"expression": f"{prefix}_result.get('data', {{}})", "kind": "value", "color_space": ""},
    }


def _compile_yolo_select_for_export(
    params: dict[str, Any],
    input_vars: dict[str, str],
    prefix: str,
) -> tuple[list[ast.stmt], dict[str, dict[str, str]]]:
    if "detections" not in input_vars:
        raise ValueError("YOLO目标筛选节点必须连接 detections 输入")
    image_expression = input_vars.get("image", "None")
    source = f"{prefix}_result = run_yolo_select_node({input_vars['detections']}, {image_expression}, {params!r})"
    statements = ast.parse(source).body
    outputs: dict[str, dict[str, str]] = {
        "out": {"expression": f"{prefix}_result.get('out')", "kind": "image", "color_space": "GRAY"},
        "mask": {"expression": f"{prefix}_result.get('mask')", "kind": "image", "color_space": "GRAY"},
        "selected": {"expression": f"{prefix}_result.get('selected', [])", "kind": "value", "color_space": ""},
        "count": {"expression": f"{prefix}_result.get('count', 0)", "kind": "value", "color_space": ""},
        "expected_count": {"expression": f"{prefix}_result.get('expected_count', 0)", "kind": "value", "color_space": ""},
        "missing_indices": {"expression": f"{prefix}_result.get('missing_indices', [])", "kind": "value", "color_space": ""},
        "first": {"expression": f"{prefix}_result.get('first')", "kind": "value", "color_space": ""},
        "second": {"expression": f"{prefix}_result.get('second')", "kind": "value", "color_space": ""},
        "centers": {"expression": f"{prefix}_result.get('centers', [])", "kind": "value", "color_space": ""},
        "metrics": {"expression": f"{prefix}_result.get('metrics', {{}})", "kind": "value", "color_space": ""},
        "data": {"expression": f"{prefix}_result.get('data', {{}})", "kind": "value", "color_space": ""},
    }
    for index in range(1, _yolo_mask_output_count(params) + 1):
        outputs[f"mask{index}"] = {
            "expression": f"{prefix}_result.get('mask{index}')",
            "kind": "image",
            "color_space": "GRAY",
        }
    return statements, outputs


def _compile_roi_pair_edge_distance_for_export(
    params: dict[str, Any],
    input_vars: dict[str, str],
    input_colors: dict[str, str],
    prefix: str,
) -> tuple[list[ast.stmt], dict[str, dict[str, str]]]:
    if "image" not in input_vars or "detections" not in input_vars:
        raise ValueError("ROI边缘距离节点必须同时连接 image 和 detections 输入")
    source = (
        f"{prefix}_result = run_roi_pair_edge_distance_node("
        f"{input_vars['image']}, {input_colors.get('image', 'BGR')!r}, {input_vars['detections']}, {params!r})"
    )
    statements = ast.parse(source).body
    return statements, {
        "out": {"expression": f"{prefix}_result['out']", "kind": "image", "color_space": "BGR"},
        "edge1": {"expression": f"{prefix}_result['edge1']", "kind": "image", "color_space": "GRAY"},
        "edge2": {"expression": f"{prefix}_result['edge2']", "kind": "image", "color_space": "GRAY"},
        "distance": {"expression": f"{prefix}_result.get('distance', 0.0)", "kind": "value", "color_space": ""},
        "center1": {"expression": f"{prefix}_result.get('center1', [])", "kind": "value", "color_space": ""},
        "center2": {"expression": f"{prefix}_result.get('center2', [])", "kind": "value", "color_space": ""},
        "metrics": {"expression": f"{prefix}_result.get('metrics', {{}})", "kind": "value", "color_space": ""},
        "data": {"expression": f"{prefix}_result.get('data', {{}})", "kind": "value", "color_space": ""},
    }

def _compile_point_line_distance_for_export(
    params: dict[str, Any],
    input_vars: dict[str, str],
    input_colors: dict[str, str],
    prefix: str,
) -> tuple[list[ast.stmt], dict[str, dict[str, str]]]:
    point_expr = input_vars.get("point") or input_vars.get("p") or input_vars.get("in")
    if not point_expr:
        point_expr = repr([
            _floating(params.get("point_x", 0), 0.0),
            _floating(params.get("point_y", 0), 0.0),
        ])
    line_expr = input_vars.get("line") or input_vars.get("l") or input_vars.get("value")
    if not line_expr:
        line_expr = repr({
            "p1": [_floating(params.get("x1", 0), 0.0), _floating(params.get("y1", 0), 0.0)],
            "p2": [_floating(params.get("x2", 100), 100.0), _floating(params.get("y2", 0), 0.0)],
        })
    image_expr = input_vars.get("image") or input_vars.get("img")
    point_order = str(params.get("point_order", "XY") or "XY").upper()
    image_color = input_colors.get("image") or input_colors.get("img") or "BGR"
    source = f"""
{prefix}_point_raw = {point_expr}
if isinstance({prefix}_point_raw, dict):
    if "point" in {prefix}_point_raw:
        {prefix}_point_raw = {prefix}_point_raw["point"]
    elif "x" in {prefix}_point_raw and "y" in {prefix}_point_raw:
        {prefix}_point_raw = [{prefix}_point_raw["x"], {prefix}_point_raw["y"]]
{prefix}_point = list({prefix}_point_raw)
if len({prefix}_point) < 2:
    raise ValueError("点到直线距离节点的 point 输入至少需要两个坐标")
{prefix}_x0 = float({prefix}_point[0])
{prefix}_y0 = float({prefix}_point[1])
if {point_order!r} == "YX":
    {prefix}_x0, {prefix}_y0 = {prefix}_y0, {prefix}_x0
{prefix}_line_raw = {line_expr}
if isinstance({prefix}_line_raw, dict) and "line" in {prefix}_line_raw:
    {prefix}_line_raw = {prefix}_line_raw["line"]
if isinstance({prefix}_line_raw, dict) and "abc" in {prefix}_line_raw:
    {prefix}_a, {prefix}_b, {prefix}_c = [float(v) for v in {prefix}_line_raw["abc"]]
    {prefix}_p1 = {prefix}_line_raw.get("p1")
    {prefix}_p2 = {prefix}_line_raw.get("p2")
elif isinstance({prefix}_line_raw, dict) and "p1" in {prefix}_line_raw and "p2" in {prefix}_line_raw:
    {prefix}_p1 = list({prefix}_line_raw["p1"])
    {prefix}_p2 = list({prefix}_line_raw["p2"])
    {prefix}_dx = float({prefix}_p2[0]) - float({prefix}_p1[0])
    {prefix}_dy = float({prefix}_p2[1]) - float({prefix}_p1[1])
    {prefix}_a = -{prefix}_dy
    {prefix}_b = {prefix}_dx
    {prefix}_c = {prefix}_dy * float({prefix}_p1[0]) - {prefix}_dx * float({prefix}_p1[1])
else:
    {prefix}_line_points = list({prefix}_line_raw)
    if len({prefix}_line_points) != 2:
        raise ValueError("点到直线距离节点的 line 输入需要 abc 或两个端点")
    {prefix}_p1 = list({prefix}_line_points[0])
    {prefix}_p2 = list({prefix}_line_points[1])
    {prefix}_dx = float({prefix}_p2[0]) - float({prefix}_p1[0])
    {prefix}_dy = float({prefix}_p2[1]) - float({prefix}_p1[1])
    {prefix}_a = -{prefix}_dy
    {prefix}_b = {prefix}_dx
    {prefix}_c = {prefix}_dy * float({prefix}_p1[0]) - {prefix}_dx * float({prefix}_p1[1])
{prefix}_denom = float(np.hypot({prefix}_a, {prefix}_b))
if {prefix}_denom <= 1e-12:
    raise ValueError("直线参数无效：a 和 b 不能同时为 0")
{prefix}_signed = ({prefix}_a * {prefix}_x0 + {prefix}_b * {prefix}_y0 + {prefix}_c) / {prefix}_denom
{prefix}_distance = abs({prefix}_signed)
{prefix}_foot_x = {prefix}_x0 - {prefix}_a * ({prefix}_a * {prefix}_x0 + {prefix}_b * {prefix}_y0 + {prefix}_c) / ({prefix}_denom * {prefix}_denom)
{prefix}_foot_y = {prefix}_y0 - {prefix}_b * ({prefix}_a * {prefix}_x0 + {prefix}_b * {prefix}_y0 + {prefix}_c) / ({prefix}_denom * {prefix}_denom)
{prefix}_foot = [round(float({prefix}_foot_x), 6), round(float({prefix}_foot_y), 6)]
"""
    if image_expr:
        source += f"""
{prefix}_canvas_source = {image_expr}
if {prefix}_canvas_source.ndim == 2:
    {prefix}_canvas = cv2.cvtColor({prefix}_canvas_source, cv2.COLOR_GRAY2BGR)
elif {image_color!r} == "RGB":
    {prefix}_canvas = cv2.cvtColor({prefix}_canvas_source, cv2.COLOR_RGB2BGR)
else:
    {prefix}_canvas = {prefix}_canvas_source.copy()
"""
    else:
        source += f"""
{prefix}_coords_x = [{prefix}_x0, {prefix}_foot_x]
{prefix}_coords_y = [{prefix}_y0, {prefix}_foot_y]
if {prefix}_p1 and {prefix}_p2:
    {prefix}_coords_x.extend([float({prefix}_p1[0]), float({prefix}_p2[0])])
    {prefix}_coords_y.extend([float({prefix}_p1[1]), float({prefix}_p2[1])])
{prefix}_canvas = np.zeros((max(160, int(np.ceil(max({prefix}_coords_y) + 40))), max(200, int(np.ceil(max({prefix}_coords_x) + 40))), 3), dtype=np.uint8)
"""
    source += f"""
{prefix}_h, {prefix}_w = {prefix}_canvas.shape[:2]
{prefix}_candidates = []
if abs({prefix}_b) > 1e-12:
    {prefix}_candidates.extend([(0.0, -{prefix}_c / {prefix}_b), (float({prefix}_w - 1), -({prefix}_a * ({prefix}_w - 1) + {prefix}_c) / {prefix}_b)])
if abs({prefix}_a) > 1e-12:
    {prefix}_candidates.extend([(-{prefix}_c / {prefix}_a, 0.0), (-({prefix}_b * ({prefix}_h - 1) + {prefix}_c) / {prefix}_a, float({prefix}_h - 1))])
{prefix}_inside = [(x, y) for x, y in {prefix}_candidates if -1 <= x <= {prefix}_w and -1 <= y <= {prefix}_h]
{prefix}_draw_points = {prefix}_inside[:2] if len({prefix}_inside) >= 2 else {prefix}_candidates[:2]
if len({prefix}_draw_points) >= 2:
    {prefix}_d1 = tuple(int(round(v)) for v in {prefix}_draw_points[0])
    {prefix}_d2 = tuple(int(round(v)) for v in {prefix}_draw_points[1])
    cv2.line({prefix}_canvas, {prefix}_d1, {prefix}_d2, (60, 170, 60), 1, cv2.LINE_AA)
{prefix}_point_px = (int(round({prefix}_x0)), int(round({prefix}_y0)))
{prefix}_foot_px = (int(round({prefix}_foot_x)), int(round({prefix}_foot_y)))
cv2.circle({prefix}_canvas, {prefix}_point_px, 5, (0, 0, 255), -1, cv2.LINE_AA)
cv2.line({prefix}_canvas, {prefix}_point_px, {prefix}_foot_px, (0, 180, 255), 1, cv2.LINE_AA)
cv2.drawMarker({prefix}_canvas, {prefix}_foot_px, (255, 180, 0), markerType=cv2.MARKER_TILTED_CROSS, markerSize=12, thickness=2, line_type=cv2.LINE_AA)
"""
    statements = ast.parse(textwrap.dedent(source)).body
    return statements, {
        "out": {"expression": f"{prefix}_canvas", "kind": "image", "color_space": "BGR"},
        "distance": {"expression": f"round(float({prefix}_distance), 9)", "kind": "value", "color_space": ""},
        "signed_distance": {"expression": f"round(float({prefix}_signed), 9)", "kind": "value", "color_space": ""},
        "foot_point": {"expression": f"{prefix}_foot", "kind": "value", "color_space": ""},
        "value": {"expression": f"round(float({prefix}_distance), 9)", "kind": "value", "color_space": ""},
    }


def generate_algorithm_script(workflow: WorkflowRequest) -> str:
    if not workflow.nodes:
        raise ValueError("流程为空，无法导出算法脚本")

    order = topological_sort(workflow.nodes, workflow.edges)
    nodes = {node.id: node for node in workflow.nodes}
    incoming: dict[str, list[Any]] = defaultdict(list)
    outgoing: dict[str, list[Any]] = defaultdict(list)
    for edge in workflow.edges:
        incoming[edge.target].append(edge)
        outgoing[edge.source].append(edge)

    batch_readers = [node for node in workflow.nodes if node.type == "BatchReadImages"]
    batch_savers = [node for node in workflow.nodes if node.type == "SaveBatchResults"]
    single_readers = [node for node in workflow.nodes if node.type == "ReadImage"]
    is_batch = bool(batch_readers or batch_savers)
    yolo_related_types = {"YoloInfer", "YoloSelectTopDetections", "RoiPairEdgeDistance"}
    yolo_node_ids = [node.id for node in workflow.nodes if node.type == "YoloInfer"]
    has_yolo_runtime = any(node.type in yolo_related_types for node in workflow.nodes)
    if is_batch:
        if len(batch_readers) != 1 or len(batch_savers) != 1:
            raise ValueError("批量脚本导出要求流程中恰好包含一个“批量读取图片”和一个“保存批量结果”节点")
        if single_readers:
            raise ValueError("批量脚本导出不能同时包含“读取图像”节点")
        if outgoing[batch_savers[0].id]:
            raise ValueError("保存批量结果节点必须是流程末端节点")
        image_edges = [edge for edge in incoming[batch_savers[0].id] if (edge.targetHandle or "in") == "in"]
        if len(image_edges) != 1:
            raise ValueError("保存批量结果节点的“结果图”端口必须连接且只能连接一个上游图像节点")
        read_nodes = batch_readers
    else:
        read_nodes = single_readers
        if len(read_nodes) != 1:
            raise ValueError("纯算法脚本要求流程中恰好包含一个读取图像节点")

    module_body: list[ast.stmt] = [
        ast.Expr(value=ast.Constant(value="由工业视觉流程编辑器生成的独立算法脚本。")),
        ast.Import(names=[ast.alias(name="argparse")]),
        ast.Import(names=[ast.alias(name="csv")]),
        ast.Import(names=[ast.alias(name="json")]),
        ast.Import(names=[ast.alias(name="inspect")]),
        ast.Import(names=[ast.alias(name="math")]),
        ast.Import(names=[ast.alias(name="statistics")]),
        ast.ImportFrom(module="pathlib", names=[ast.alias(name="Path")], level=0),
        ast.Import(names=[ast.alias(name="cv2")]),
        ast.Import(names=[ast.alias(name="numpy", asname="np")]),
    ]
    if has_yolo_runtime:
        module_body.extend(_standalone_yolo_runtime_nodes())
        module_body.append(
            ast.Assign(
                targets=[ast.Name(id="_YOLO_NODE_IDS", ctx=ast.Store())],
                value=ast.List(elts=[ast.Constant(value=node_id) for node_id in yolo_node_ids], ctx=ast.Load()),
            )
        )

    function_body: list[ast.stmt] = [
        ast.If(
            test=ast.Compare(left=ast.Name(id="input_image", ctx=ast.Load()), ops=[ast.Is()], comparators=[ast.Constant(value=None)]),
            body=[ast.Raise(exc=ast.Call(func=ast.Name(id="ValueError", ctx=ast.Load()), args=[ast.Constant(value="输入图像不能为空")], keywords=[]), cause=None)],
            orelse=[],
        )
    ]
    variables: dict[tuple[str, str], str] = {}
    kinds: dict[tuple[str, str], str] = {}
    color_spaces: dict[tuple[str, str], str] = {}
    logic_types = {
        "LogicConstant", "LogicCompare", "LogicBoolean", "LogicNot",
        "LogicIfElse", "LogicForLoop", "LogicWhileLoop",
    }

    def source_key(edge: Any) -> tuple[str, str]:
        return edge.source, edge.sourceHandle or "out"

    def assign_outputs(node_id: str, base_variable: str, output_specs: dict[str, dict[str, str]]) -> None:
        for handle, spec in output_specs.items():
            output_variable = base_variable if handle == "out" else f"{base_variable}_{_safe_identifier(handle).lower()}"
            function_body.append(ast.Assign(targets=[ast.Name(id=output_variable, ctx=ast.Store())], value=_expression(spec["expression"])))
            key = (node_id, handle)
            variables[key] = output_variable
            kinds[key] = spec.get("kind", "value")
            color_spaces[key] = spec.get("color_space", "")

    def primary_output_key(node_id: str) -> tuple[str, str]:
        if (node_id, "out") in variables:
            return node_id, "out"
        handles = sorted(handle for item_node_id, handle in variables if item_node_id == node_id)
        if not handles:
            raise ValueError(f"节点 {node_id} 没有可返回的输出端口")
        return node_id, handles[0]

    for index, node_id in enumerate(order, start=1):
        raw_node = nodes[node_id]
        raw_type = raw_node.type
        node_type, params = _normalize_type(raw_type, raw_node.params)
        variable = f"step_{index:02d}_{_safe_identifier(node_type).lower()}"
        if raw_type in {"ReadImage", "BatchReadImages"}:
            function_body.append(_statement(f"{variable} = input_image"))
            variables[(node_id, "out")] = variable
            kinds[(node_id, "out")] = "image"
            color_spaces[(node_id, "out")] = "BGR"
            continue

        input_vars: dict[str, str] = {}
        input_kinds: dict[str, str] = {}
        input_colors: dict[str, str] = {}
        for edge in incoming[node_id]:
            handle = edge.targetHandle or "in"
            key = source_key(edge)
            if key not in variables:
                raise ValueError(f"上游节点 {edge.source} 不存在可导出的输出端口：{key[1]}")
            input_vars[handle] = variables[key]
            input_kinds[handle] = kinds.get(key, "value")
            input_colors[handle] = color_spaces.get(key, "")

        if raw_type == "SaveBatchResults":
            if "in" not in input_vars or input_kinds.get("in") != "image":
                raise ValueError("保存批量结果节点必须连接有效的结果图")
            function_body.append(_statement(f"{variable} = {input_vars['in']}"))
            variables[(node_id, "out")] = variable
            kinds[(node_id, "out")] = "image"
            color_spaces[(node_id, "out")] = input_colors.get("in", "BGR")
            continue

        if node_type in logic_types:
            statements, expression, output_kind, output_color = _compile_logic_operator(node_type, params, input_vars, input_kinds, input_colors, variable)
            function_body.extend(statements)
            function_body.append(ast.Assign(targets=[ast.Name(id=variable, ctx=ast.Store())], value=_expression(expression)))
            variables[(node_id, "out")] = variable
            kinds[(node_id, "out")] = output_kind
            color_spaces[(node_id, "out")] = output_color
            continue

        if node_type == "PythonSnippet":
            extra_statements, output_specs = _compile_python_snippet_for_export(params, input_vars, variable)
            function_body.extend(extra_statements)
            assign_outputs(node_id, variable, output_specs)
            continue

        if node_type == "PointLineDistance":
            extra_statements, output_specs = _compile_point_line_distance_for_export(params, input_vars, input_colors, variable)
            function_body.extend(extra_statements)
            assign_outputs(node_id, variable, output_specs)
            continue

        if node_type == "YoloInfer":
            if set(input_vars) != {"in"} or input_kinds.get("in") != "image":
                raise ValueError(f"YOLO推理节点 {node_id} 必须连接一个有效的 in 图像输入")
            extra_statements, output_specs = _compile_yolo_infer_for_export(
                node_id, params, input_vars["in"], input_colors.get("in", "BGR"), variable
            )
            function_body.extend(extra_statements)
            assign_outputs(node_id, variable, output_specs)
            continue

        if node_type == "YoloSelectTopDetections":
            unexpected = set(input_vars) - {"detections", "image"}
            if unexpected:
                raise ValueError(f"YOLO目标筛选节点 {node_id} 包含不支持的输入端口：{sorted(unexpected)}")
            if input_kinds.get("detections") == "image":
                raise ValueError(f"YOLO目标筛选节点 {node_id} 的 detections 输入不能是图像")
            if "image" in input_vars and input_kinds.get("image") != "image":
                raise ValueError(f"YOLO目标筛选节点 {node_id} 的 image 输入必须是图像")
            extra_statements, output_specs = _compile_yolo_select_for_export(params, input_vars, variable)
            function_body.extend(extra_statements)
            assign_outputs(node_id, variable, output_specs)
            continue

        if node_type == "RoiPairEdgeDistance":
            if set(input_vars) != {"image", "detections"}:
                raise ValueError(f"ROI边缘距离节点 {node_id} 必须连接 image 和 detections 输入")
            if input_kinds.get("image") != "image" or input_kinds.get("detections") == "image":
                raise ValueError(f"ROI边缘距离节点 {node_id} 的输入类型无效")
            extra_statements, output_specs = _compile_roi_pair_edge_distance_for_export(
                params, input_vars, input_colors, variable
            )
            function_body.extend(extra_statements)
            assign_outputs(node_id, variable, output_specs)
            continue

        if node_type == "ORBFeatureMatch":
            if "template" in input_vars or "mask" in input_vars:
                raise ValueError("ORBFeatureMatch 导出脚本暂不支持 template/mask 输入端口；请改用节点参数 template_path/mask_path 指定模板与模板Mask")
            if set(input_vars) != {"in"}:
                raise ValueError(f"图像节点 {node_id} 必须连接 in 输入端口")
            if input_kinds.get("in") != "image":
                raise ValueError(f"图像节点 {node_id} 的输入不是图像")
            extra_statements, output_specs = _compile_orb_feature_match_for_export(params, input_vars["in"], input_colors.get("in", "BGR"), variable)
            function_body.extend(extra_statements)
            assign_outputs(node_id, variable, output_specs)
            continue

        if set(input_vars) != {"in"}:
            raise ValueError(f"节点 {node_id}（{raw_type}）的输入结构暂不支持独立脚本导出：需要单一 in 图像输入，实际为 {sorted(input_vars)}")
        input_var = input_vars["in"]
        if input_kinds.get("in") != "image":
            raise ValueError(f"图像节点 {node_id} 的输入不是图像")
        input_color = input_colors.get("in", "BGR")
        compiler = CUSTOM_SCRIPT_COMPILERS.get(node_type)
        if compiler is not None:
            raw_result = _invoke_script_compiler(compiler, input_var, input_color, params, variable)
            statement_sources, output_specs = _normalize_output_specs(raw_result, input_color)
            function_body.extend(_statement(source) for source in statement_sources)
            assign_outputs(node_id, variable, output_specs)
        else:
            extra_statements, expression, output_color = _compile_operator(node_type, params, input_var, input_color)
            function_body.extend(extra_statements)
            function_body.append(ast.Assign(targets=[ast.Name(id=variable, ctx=ast.Store())], value=_expression(expression)))
            variables[(node_id, "out")] = variable
            kinds[(node_id, "out")] = "image"
            color_spaces[(node_id, "out")] = output_color

    if is_batch:
        saver = batch_savers[0]
        image_key = (saver.id, "out")
        csv_keys: list[ast.expr] = []
        csv_values: list[ast.expr] = []
        mode = str(saver.params.get("csv_export_mode") or "AUTO_ALL").strip().upper()
        fields = _batch_csv_fields(saver.params)
        if mode == "SELECTED_INPUTS":
            for edge in incoming[saver.id]:
                target_handle = edge.targetHandle or "in"
                if target_handle == "in" or not target_handle.startswith("result"):
                    continue
                field = fields.get(target_handle, {})
                if field.get("enabled") is False:
                    continue
                key = source_key(edge)
                if key not in variables:
                    raise ValueError(f"CSV变量 {target_handle} 的源端口无法导出：{edge.source}.{key[1]}")
                if kinds.get(key) == "image":
                    raise ValueError(f"CSV变量 {target_handle} 连接了图像端口：{edge.source}.{key[1]}")
                column = str(field.get("column") or f"{edge.source}.{key[1]}")
                csv_keys.append(ast.Constant(value=column))
                csv_values.append(ast.Name(id=variables[key], ctx=ast.Load()))
        else:
            for (item_node_id, handle), value_variable in variables.items():
                if item_node_id in {read_nodes[0].id, saver.id} or kinds.get((item_node_id, handle)) == "image":
                    continue
                if handle in {"out", "image"}:
                    continue
                csv_keys.append(ast.Constant(value=f"{item_node_id}.{handle}"))
                csv_values.append(ast.Name(id=value_variable, ctx=ast.Load()))
        function_body.append(ast.Return(value=ast.Dict(
            keys=[ast.Constant(value="image"), ast.Constant(value="color_space"), ast.Constant(value="csv")],
            values=[ast.Name(id=variables[image_key], ctx=ast.Load()), ast.Constant(value=color_spaces.get(image_key, "BGR")), ast.Dict(keys=csv_keys, values=csv_values)],
        )))
    else:
        sink_ids = [node_id for node_id in order if not outgoing[node_id]]
        if not sink_ids:
            raise ValueError("流程没有终点节点")
        if len(sink_ids) == 1:
            key = primary_output_key(sink_ids[0])
            function_body.append(ast.Return(value=ast.Name(id=variables[key], ctx=ast.Load())))
        else:
            return_keys = []
            return_values = []
            for node_id in sink_ids:
                key = primary_output_key(node_id)
                return_keys.append(ast.Constant(value=node_id))
                return_values.append(ast.Name(id=variables[key], ctx=ast.Load()))
            function_body.append(ast.Return(value=ast.Dict(keys=return_keys, values=return_values)))

    run_function = ast.FunctionDef(
        name="run_algorithm",
        args=ast.arguments(posonlyargs=[], args=[ast.arg(arg="input_image")], kwonlyargs=[], kw_defaults=[], defaults=[]),
        body=function_body,
        decorator_list=[],
    )
    module_body.append(run_function)

    if is_batch:
        reader_params = batch_readers[0].params
        saver_params = batch_savers[0].params
        configured_input = str(reader_params.get("folder_path") or "")
        configured_output = str(saver_params.get("output_dir") or "batch_outputs")
        recursive = _yes_flag(reader_params.get("recursive"), True)
        continue_on_error = _yes_flag(reader_params.get("continue_on_error"), True)
        max_images = max(0, _integer(reader_params.get("max_images"), 0))
        extensions = str(reader_params.get("extensions") or ".jpg,.jpeg,.png,.bmp,.tif,.tiff,.webp")
        save_images = _yes_flag(saver_params.get("save_images"), True)
        preserve_structure = _yes_flag(saver_params.get("preserve_structure"), True)
        write_csv = _yes_flag(saver_params.get("write_csv"), True)
        image_format = str(saver_params.get("image_format") or "SOURCE").upper()
        filename_suffix = str(saver_params.get("filename_suffix") or "")
        csv_filename = str(saver_params.get("csv_filename") or "results.csv")
        helpers_source = f'''
def read_image(path):
    data = np.fromfile(str(path), dtype=np.uint8)
    image = cv2.imdecode(data, cv2.IMREAD_COLOR)
    if image is None:
        raise ValueError(f"无法读取图片：{{path}}")
    return image


def save_image(path, image, color_space="BGR"):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    encoded = image
    if isinstance(image, np.ndarray) and image.ndim == 3 and str(color_space).upper() == "RGB":
        encoded = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
    extension = path.suffix or ".png"
    if not path.suffix:
        path = path.with_suffix(extension)
    ok, buffer = cv2.imencode(extension, encoded)
    if not ok:
        raise ValueError(f"无法编码结果图：{{path}}")
    buffer.tofile(str(path))
    return path


def parse_extensions(value):
    result = set()
    for item in str(value or "").replace(";", ",").split(","):
        suffix = item.strip().lower()
        if suffix:
            result.add(suffix if suffix.startswith(".") else "." + suffix)
    return result


def list_images(root, extensions, recursive=True, limit=0):
    root = Path(root)
    iterator = root.rglob("*") if recursive else root.glob("*")
    paths = sorted(path for path in iterator if path.is_file() and path.suffix.lower() in extensions)
    return paths[:limit] if limit > 0 else paths


def output_suffix(source_path, mode):
    normalized = str(mode or "SOURCE").upper()
    if normalized == "PNG":
        return ".png"
    if normalized == "JPG":
        return ".jpg"
    if normalized == "WEBP":
        return ".webp"
    return source_path.suffix or ".png"


def csv_safe(value):
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, np.ndarray):
        raise ValueError("CSV字段不能是图像/数组")
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, dict):
        return {{str(key): csv_safe(child) for key, child in value.items()}}
    if isinstance(value, (list, tuple, set)):
        return [csv_safe(child) for child in value]
    return str(value)


def flatten_csv(prefix, value):
    prefix = str(prefix or "value")
    if isinstance(value, dict):
        result = {{}}
        for key, child in value.items():
            nested = flatten_csv(f"{{prefix}}.{{key}}", child)
            for name, item in nested.items():
                if name in result:
                    raise ValueError(f"CSV列名冲突：{{name}}")
                result[name] = item
        if not value:
            result[prefix] = "{{}}"
        return result
    if isinstance(value, np.ndarray):
        raise ValueError(f"CSV字段 {{prefix}} 是图像/数组")
    if isinstance(value, (list, tuple, set)):
        return {{prefix: json.dumps(csv_safe(value), ensure_ascii=False)}}
    return {{prefix: csv_safe(value)}}


def write_csv(path, rows):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = []
    seen = set()
    for row in rows:
        for key in row:
            if key not in seen:
                seen.add(key)
                fields.append(key)
    with path.open("w", newline="", encoding="utf-8-sig") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)
    return path


def run_batch(input_dir, output_dir, *, recursive={recursive!r}, extensions={extensions!r}, max_images={max_images}, continue_on_error={continue_on_error!r}):
    source_root = Path(input_dir).expanduser().resolve()
    if not source_root.is_dir():
        raise ValueError(f"批量图片文件夹不存在：{{source_root}}")
    output_root = Path(output_dir).expanduser().resolve()
    output_root.mkdir(parents=True, exist_ok=True)
    images = list_images(source_root, parse_extensions(extensions), recursive=recursive, limit=max_images)
    if not images:
        raise ValueError(f"文件夹中没有找到符合扩展名的图片：{{source_root}}")
    rows = []
    succeeded = 0
    failed = 0
    for index, source_path in enumerate(images, start=1):
        relative = source_path.relative_to(source_root)
        row = {{"source_path": str(source_path), "source_name": source_path.name, "relative_path": str(relative), "output_path": "", "status": "success", "error": ""}}
        try:
            result = run_algorithm(read_image(source_path))
            if not isinstance(result, dict) or not isinstance(result.get("image"), np.ndarray):
                raise ValueError("算法没有返回有效的批量结果图")
            if {save_images!r}:
                relative_parent = relative.parent if {preserve_structure!r} else Path()
                suffix = output_suffix(source_path, {image_format!r})
                destination = output_root / relative_parent / f"{{source_path.stem}}{filename_suffix}{{suffix}}"
                if not {preserve_structure!r} and destination.exists():
                    destination = output_root / f"{{source_path.stem}}{filename_suffix}_{{index:05d}}{{suffix}}"
                save_image(destination, result["image"], result.get("color_space", "BGR"))
                row["output_path"] = str(destination)
            for name, value in (result.get("csv") or {{}}).items():
                for column, item in flatten_csv(name, value).items():
                    if column in row:
                        raise ValueError(f"CSV列名冲突：{{column}}")
                    row[column] = item
            succeeded += 1
            print(f"[{{index}}/{{len(images)}}] 成功：{{source_path.name}}")
        except Exception as exc:
            failed += 1
            row["status"] = "error"
            row["error"] = str(exc)
            print(f"[{{index}}/{{len(images)}}] 失败：{{source_path.name}} · {{exc}}")
            if not continue_on_error:
                rows.append(row)
                if {write_csv!r}:
                    write_csv(output_root / {csv_filename!r}, rows)
                raise
        rows.append(row)
    csv_path = write_csv(output_root / {csv_filename!r}, rows) if {write_csv!r} else None
    summary = {{"total": len(images), "succeeded": succeeded, "failed": failed, "output_dir": str(output_root), "csv_path": str(csv_path) if csv_path else ""}}
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return summary


def main():
    parser = argparse.ArgumentParser(description="运行导出的批量工业视觉算法")
    parser.add_argument("--input", default={configured_input!r}, help="输入图片文件夹")
    parser.add_argument("--output", default={configured_output!r}, help="结果输出文件夹")
    parser.add_argument("--extensions", default={extensions!r}, help="图片扩展名，逗号分隔")
    parser.add_argument("--max-images", type=int, default={max_images}, help="最大处理图片数，0为不限")
    parser.add_argument("--recursive", action=argparse.BooleanOptionalAction, default={recursive!r}, help="是否递归读取子目录")
    parser.add_argument("--continue-on-error", action=argparse.BooleanOptionalAction, default={continue_on_error!r}, help="单张失败后是否继续")
    # __YOLO_CLI_ARGUMENTS__
    args = parser.parse_args()
    # __YOLO_CLI_CONFIGURE__
    if not args.input:
        parser.error("请通过 --input 指定图片文件夹，或在批量读取图片节点中配置 folder_path")
    run_batch(args.input, args.output, recursive=args.recursive, extensions=args.extensions, max_images=max(0, args.max_images), continue_on_error=args.continue_on_error)


if __name__ == "__main__":
    main()
'''
    else:
        helpers_source = '''
def read_image(path):
    data = np.fromfile(str(path), dtype=np.uint8)
    image = cv2.imdecode(data, cv2.IMREAD_COLOR)
    if image is None:
        raise ValueError(f"无法读取图片：{path}")
    return image


def save_image(path, image):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    extension = path.suffix or ".png"
    if not path.suffix:
        path = path.with_suffix(extension)
    ok, buffer = cv2.imencode(extension, image)
    if not ok:
        raise ValueError(f"无法编码结果图：{path}")
    buffer.tofile(str(path))
    return path


def save_result(path, result):
    if isinstance(result, np.ndarray):
        return save_image(path, result)
    path = Path(path)
    if path.suffix.lower() not in {".json", ".txt"}:
        path = path.with_suffix(".json")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(result, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    return path


def main():
    parser = argparse.ArgumentParser(description="运行导出的 OpenCV 算法")
    parser.add_argument("--input", required=True, help="输入图片路径")
    parser.add_argument("--output", default="result.png", help="输出路径；多结果时作为输出目录")
    # __YOLO_CLI_ARGUMENTS__
    args = parser.parse_args()
    # __YOLO_CLI_CONFIGURE__
    result = run_algorithm(read_image(args.input))
    if isinstance(result, dict):
        output_dir = Path(args.output)
        output_dir.mkdir(parents=True, exist_ok=True)
        for name, value in result.items():
            suffix = ".png" if isinstance(value, np.ndarray) else ".json"
            save_result(output_dir / f"{name}{suffix}", value)
    else:
        save_result(args.output, result)


if __name__ == "__main__":
    main()
'''
    yolo_cli_arguments = (
        'parser.add_argument("--model", action="append", default=[], help="覆盖YOLO模型；单节点填PATH，多节点填节点ID=PATH，可重复")\n'
        '    parser.add_argument("--device", default="", help="覆盖所有YOLO节点设备，例如cpu、0、0,1")'
        if yolo_node_ids
        else ""
    )
    yolo_cli_configure = "configure_yolo_cli(args.model, args.device)" if yolo_node_ids else ""
    helpers_source = helpers_source.replace("# __YOLO_CLI_ARGUMENTS__", yolo_cli_arguments)
    helpers_source = helpers_source.replace("# __YOLO_CLI_CONFIGURE__", yolo_cli_configure)
    module_body.extend(ast.parse(textwrap.dedent(helpers_source)).body)

    module = ast.Module(body=module_body, type_ignores=[])
    ast.fix_missing_locations(module)
    header = "#!/usr/bin/env python3\n# -*- coding: utf-8 -*-\n"
    if yolo_node_ids:
        header += (
            "# YOLO依赖：pip install 'ultralytics>=8.3,<9.0'\n"
            "# 模型覆盖：单YOLO节点使用 --model PATH；多节点使用 --model NODE_ID=PATH（可重复）\n"
        )
    source = header + ast.unparse(module) + "\n"
    compile(source, "vision_algorithm.py", "exec")
    forbidden = ("WORKFLOW", "topological_sort", "OPERATORS", '"nodes"', '"edges"', "from backend", "import backend")
    if any(token in source for token in forbidden):
        raise RuntimeError("生成脚本意外包含平台工作流运行时结构")
    return source


# 保留旧路由导入名，生成内容已经是纯顺序算法代码。
def generate_standalone_script(workflow: WorkflowRequest) -> str:
    return generate_algorithm_script(workflow)
