from __future__ import annotations

from pathlib import Path

from fastapi.testclient import TestClient

from backend.infrastructure.state_backend import FileJsonStateBackend
from backend.main import app
from backend.models.workflow import WorkflowRequest
from backend.services.dataset_store import DatasetStore
from backend.services.image_store import ImageStore
from backend.services.project_store import ProjectStore
from backend.services.run_history_store import RunHistoryStore
from backend.services.workflow_debugger import DebugSessionError, WorkflowDebugManager
from backend.services.workflow_engine import run_workflow
from tests.auth_utils import auth_headers


def _store(tmp_path: Path) -> ImageStore:
    return ImageStore(tmp_path / "images", {".png", ".jpg"})


def _workflow() -> WorkflowRequest:
    return WorkflowRequest.model_validate(
        {
            "nodes": [
                {"id": "start", "type": "LogicConstant", "params": {"value_type": "NUMBER", "value": "2"}},
                {"id": "loop", "type": "LogicForLoop", "params": {"iterations": 2, "update_operation": "ADD", "step": 1}},
                {"id": "not", "type": "LogicNot"},
            ],
            "edges": [
                {"source": "start", "target": "loop", "targetHandle": "in"},
                {"source": "loop", "target": "not", "targetHandle": "in"},
            ],
        }
    )


def test_full_and_debug_modes_share_node_execution_semantics(tmp_path: Path) -> None:
    workflow = _workflow()
    image_store = _store(tmp_path)
    full = run_workflow(workflow, image_store)

    manager = WorkflowDebugManager()
    debug = manager.run(
        workflow,
        image_store,
        action="run_to_node",
        target_node_id="not",
        session_id=None,
        user_id="u",
        workspace_id="w",
        model_manager=None,
        event_callback=None,
    )

    assert debug["executed_order"] == full["order"]
    assert debug["data"] == full["data"]
    assert [item["node_id"] for item in debug["previews"]] == [item["node_id"] for item in full["previews"]]


def test_debug_releases_consumed_outputs_but_keeps_execution_progress(tmp_path: Path) -> None:
    manager = WorkflowDebugManager()
    result = manager.run(
        _workflow(),
        _store(tmp_path),
        action="run_to_node",
        target_node_id="not",
        session_id=None,
        user_id="u",
        workspace_id="w",
        model_manager=None,
        event_callback=None,
    )
    assert result["completed"] is True
    assert result["retained_output_nodes"] == ["not"]
    assert set(result["released_output_nodes"]) == {"start", "loop"}
    assert result["executed_order"] == ["start", "loop", "not"]


def test_debug_status_and_cancel_endpoints() -> None:
    client = TestClient(app)
    _, headers = auth_headers(client, "debug-status-cancel")
    response = client.post(
        "/api/debug/run-stream",
        headers=headers,
        json={"workflow": _workflow().model_dump(), "action": "step"},
    )
    result_line = [line for line in response.text.splitlines() if '"kind":"result"' in line][-1]
    import json

    result = json.loads(result_line)["data"]
    session_id = result["debug_session_id"]

    status = client.post("/api/debug/status", headers=headers, json={"session_id": session_id})
    assert status.status_code == 200
    assert status.json()["next_node_id"] == "loop"

    cancelled = client.post("/api/debug/cancel", headers=headers, json={"session_id": session_id})
    assert cancelled.status_code == 200
    assert cancelled.json()["cancelled"] is True

    retry = client.post(
        "/api/debug/run-stream",
        headers=headers,
        json={"workflow": _workflow().model_dump(), "session_id": session_id, "action": "step"},
    )
    assert "重新开始调试" in retry.text


def test_file_state_backend_drives_project_dataset_and_history(tmp_path: Path) -> None:
    backend = FileJsonStateBackend(tmp_path / "state")
    projects = ProjectStore(tmp_path / "projects", state_backend=backend)
    datasets = DatasetStore(tmp_path / "datasets", state_backend=backend)
    history = RunHistoryStore(tmp_path / "runs", state_backend=backend)

    project = projects.save_project(workflow=_workflow(), owner_id="ws", name="P")
    assert projects.get_project(project["project_id"], "ws")["name"] == "P"
    assert len(projects.list_versions(project["project_id"], "ws")) == 1

    dataset = datasets.create_dataset(owner_id="ws", name="D", samples=[{"image_path": "a.png"}])
    assert datasets.get_dataset(owner_id="ws", dataset_id=dataset["dataset_id"])["samples"][0]["image_path"] == "a.png"

    run = history.record_run(owner_id="ws", workflow=_workflow().model_dump(), result={"success": True})
    assert history.get_run(owner_id="ws", run_id=run["run_id"])["status"] == "success"


def test_health_ready_metrics_and_frontend_modules() -> None:
    client = TestClient(app)
    assert client.get("/api/health/live").json() == {"status": "ok"}
    ready = client.get("/api/health/ready")
    assert ready.status_code == 200
    assert ready.json()["status"] == "ready"
    metrics = client.get("/api/metrics")
    assert metrics.status_code == 200
    assert "vision_http_requests_total" in metrics.text

    html = client.get("/").text
    assert "/assets/js/app/edge_router.js" in html
    assert "/assets/js/app/run_controller.js" in html
    assert "/assets/js/app/execution_state.js" in html
    assert 'id="debugCancelButton"' in html


def test_operator_contracts_are_valid() -> None:
    from backend.algorithms.contract_validation import validate_operator_contracts
    from backend.algorithms.registry import OPERATORS, OPERATOR_META

    report = validate_operator_contracts(OPERATORS, OPERATOR_META)
    assert report.valid is True
    assert report.operator_count == len(OPERATORS) == len(OPERATOR_META)


def test_auth_workspace_and_presence_can_use_shared_state_backend(tmp_path: Path) -> None:
    from backend.services.auth_store import AuthStore
    from backend.services.team_store import WorkspaceStore

    state = FileJsonStateBackend(tmp_path / "shared-state")
    sessions = FileJsonStateBackend(tmp_path / "shared-sessions")
    auth = AuthStore(tmp_path / "legacy-auth", user_backend=state, session_backend=sessions)
    public = auth.register(email="shared@example.com", password="password123", display_name="Shared")
    login = auth.authenticate(email="shared@example.com", password="password123")

    reloaded = AuthStore(tmp_path / "second-auth", user_backend=state, session_backend=sessions)
    assert reloaded.get_user_by_token(login["token"], touch=False)["user_id"] == public["user_id"]

    workspaces = WorkspaceStore(tmp_path / "legacy-workspaces", state_backend=state, presence_backend=sessions)
    workspace = workspaces.ensure_personal_workspace(public["user_id"])
    workspaces.touch_presence(workspace_id=workspace["workspace_id"], user=public)
    assert workspaces.list_presence(workspace["workspace_id"], public["user_id"])[0]["user_id"] == public["user_id"]


def test_job_queue_persists_and_marks_interrupted_jobs_on_restart(tmp_path: Path) -> None:
    from backend.services.job_queue import JobQueue

    state = FileJsonStateBackend(tmp_path / "job-state")
    state.put(
        "jobs",
        "queued-job",
        {
            "job_id": "queued-job",
            "kind": "workflow",
            "owner_id": "ws",
            "status": "queued",
            "created_at": "2026-01-01T00:00:00Z",
            "progress": {"current": 0, "total": 1, "message": "排队中"},
        },
    )
    queue = JobQueue(max_workers=1, state_backend=state)
    try:
        restored = queue.get("queued-job", owner_id="ws")
        assert restored["status"] == "failed"
        assert "服务重启" in restored["error"]
    finally:
        queue.shutdown()


def test_file_artifact_store_and_workflow_cancellation(tmp_path: Path) -> None:
    from backend.infrastructure.artifact_store import FileArtifactStore
    from backend.services.node_executor import ExecutionCancelledError

    source = tmp_path / "result.csv"
    source.write_text("a,b\n1,2\n", encoding="utf-8")
    artifacts = FileArtifactStore(tmp_path / "artifacts")
    stored = artifacts.put_file("ws/runs/run-1/result.csv", source)
    assert Path(stored["path"]).read_text(encoding="utf-8") == source.read_text(encoding="utf-8")

    try:
        run_workflow(_workflow(), _store(tmp_path), cancel_check=lambda: True)
    except ExecutionCancelledError as exc:
        assert "取消" in str(exc)
    else:
        raise AssertionError("cancelled workflow should raise ExecutionCancelledError")


def test_frontend_uses_abort_controller_for_full_and_debug_runs() -> None:
    root = Path(__file__).resolve().parents[1]
    controller = (root / "frontend/assets/js/app/run_controller.js").read_text(encoding="utf-8")
    api = (root / "frontend/assets/js/api.js").read_text(encoding="utf-8")
    assert "new AbortController()" in controller
    assert "activeExecutionAbortController?.abort()" in controller
    assert "signal: options.signal" in api
