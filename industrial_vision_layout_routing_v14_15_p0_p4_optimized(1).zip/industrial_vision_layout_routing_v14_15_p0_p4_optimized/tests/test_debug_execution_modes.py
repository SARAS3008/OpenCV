from __future__ import annotations

import json
from pathlib import Path

from fastapi.testclient import TestClient

from backend.main import app
from backend.models.workflow import WorkflowRequest
from backend.services.image_store import ImageStore
from backend.services.workflow_debugger import WorkflowDebugManager
from tests.auth_utils import auth_headers


def make_store(tmp_path: Path) -> ImageStore:
    return ImageStore(tmp_path, {".png", ".jpg", ".jpeg"})


def chain_workflow() -> WorkflowRequest:
    return WorkflowRequest.model_validate(
        {
            "nodes": [
                {"id": "start", "type": "LogicConstant", "params": {"value_type": "NUMBER", "value": "2"}},
                {"id": "loop", "type": "LogicForLoop", "params": {"iterations": 2, "update_operation": "ADD", "step": 1}},
                {"id": "not", "type": "LogicNot"},
            ],
            "edges": [
                {"source": "start", "target": "loop", "targetHandle": "in"},
                {"source": "loop", "target": "not", "targetHandle": "in"},
            ],
        }
    )


def test_single_step_reuses_completed_outputs(tmp_path: Path) -> None:
    manager = WorkflowDebugManager()
    workflow = chain_workflow()
    store = make_store(tmp_path)

    first = manager.run(
        workflow,
        store,
        action="step",
        target_node_id=None,
        session_id=None,
        user_id="user",
        workspace_id="workspace",
        model_manager=None,
        event_callback=None,
    )
    assert first["newly_executed"] == ["start"]
    assert first["executed_order"] == ["start"]
    assert first["next_node_id"] == "loop"

    second = manager.run(
        workflow,
        store,
        action="step",
        target_node_id=None,
        session_id=first["debug_session_id"],
        user_id="user",
        workspace_id="workspace",
        model_manager=None,
        event_callback=None,
    )
    assert second["newly_executed"] == ["loop"]
    assert second["executed_order"] == ["start", "loop"]
    assert second["next_node_id"] == "not"

    third = manager.run(
        workflow,
        store,
        action="step",
        target_node_id=None,
        session_id=first["debug_session_id"],
        user_id="user",
        workspace_id="workspace",
        model_manager=None,
        event_callback=None,
    )
    assert third["newly_executed"] == ["not"]
    assert third["completed"] is True
    assert third["executed_order"] == ["start", "loop", "not"]


def test_run_to_node_then_continue_step(tmp_path: Path) -> None:
    manager = WorkflowDebugManager()
    workflow = chain_workflow()
    store = make_store(tmp_path)

    paused = manager.run(
        workflow,
        store,
        action="run_to_node",
        target_node_id="loop",
        session_id=None,
        user_id="user",
        workspace_id="workspace",
        model_manager=None,
        event_callback=None,
    )
    assert paused["newly_executed"] == ["start", "loop"]
    assert paused["current_node_id"] == "loop"
    assert paused["next_node_id"] == "not"
    assert paused["completed"] is False

    completed = manager.run(
        workflow,
        store,
        action="step",
        target_node_id=None,
        session_id=paused["debug_session_id"],
        user_id="user",
        workspace_id="workspace",
        model_manager=None,
        event_callback=None,
    )
    assert completed["newly_executed"] == ["not"]
    assert completed["completed"] is True


def test_debugger_respects_lazy_if_else_branch(tmp_path: Path) -> None:
    manager = WorkflowDebugManager()
    workflow = WorkflowRequest.model_validate(
        {
            "nodes": [
                {"id": "condition", "type": "LogicConstant", "params": {"value_type": "BOOLEAN", "value": "false"}},
                {"id": "true_value", "type": "LogicConstant", "params": {"value_type": "TEXT", "value": "T"}},
                {"id": "false_value", "type": "LogicConstant", "params": {"value_type": "TEXT", "value": "F"}},
                {"id": "choose", "type": "LogicIfElse"},
            ],
            "edges": [
                {"source": "condition", "target": "choose", "targetHandle": "condition"},
                {"source": "true_value", "target": "choose", "targetHandle": "true_value"},
                {"source": "false_value", "target": "choose", "targetHandle": "false_value"},
            ],
        }
    )
    result = manager.run(
        workflow,
        make_store(tmp_path),
        action="run_to_node",
        target_node_id="choose",
        session_id=None,
        user_id="user",
        workspace_id="workspace",
        model_manager=None,
        event_callback=None,
    )

    assert result["executed_order"] == ["condition", "false_value", "choose"]
    assert result["completed"] is True
    assert result["skipped_nodes"] == ["true_value"]


def test_debug_stream_endpoint_supports_step_and_run_to_node() -> None:
    client = TestClient(app)
    _, headers = auth_headers(client, "debug-modes")
    workflow = chain_workflow().model_dump()

    response = client.post(
        "/api/debug/run-stream",
        headers=headers,
        json={"workflow": workflow, "action": "run_to_node", "target_node_id": "loop"},
    )
    assert response.status_code == 200
    messages = [json.loads(line) for line in response.text.splitlines() if line.strip()]
    result = messages[-1]["data"]
    assert messages[-1]["kind"] == "result"
    assert result["executed_order"] == ["start", "loop"]
    assert result["next_node_id"] == "not"

    response = client.post(
        "/api/debug/run-stream",
        headers=headers,
        json={
            "workflow": workflow,
            "session_id": result["debug_session_id"],
            "action": "step",
        },
    )
    messages = [json.loads(line) for line in response.text.splitlines() if line.strip()]
    completed = messages[-1]["data"]
    assert completed["completed"] is True
    assert completed["newly_executed"] == ["not"]


def test_debug_session_rejects_changed_execution_graph(tmp_path: Path) -> None:
    manager = WorkflowDebugManager()
    workflow = chain_workflow()
    store = make_store(tmp_path)
    first = manager.run(
        workflow,
        store,
        action="step",
        target_node_id=None,
        session_id=None,
        user_id="user",
        workspace_id="workspace",
        model_manager=None,
        event_callback=None,
    )
    changed = workflow.model_copy(deep=True)
    changed.nodes[1].params["step"] = 5

    try:
        manager.run(
            changed,
            store,
            action="step",
            target_node_id=None,
            session_id=first["debug_session_id"],
            user_id="user",
            workspace_id="workspace",
            model_manager=None,
            event_callback=None,
        )
    except Exception as exc:
        assert "重新开始调试" in str(exc)
        assert getattr(exc, "restart_required", False) is True
    else:
        raise AssertionError("changed workflow should invalidate debug session")


def test_batch_debug_uses_first_image_without_writing_results(tmp_path: Path) -> None:
    import cv2
    import numpy as np

    source_dir = tmp_path / "batch"
    source_dir.mkdir()
    for name, value in [("a.png", 30), ("b.png", 220)]:
        assert cv2.imwrite(str(source_dir / name), np.full((12, 16, 3), value, dtype=np.uint8))

    workflow = WorkflowRequest.model_validate(
        {
            "nodes": [
                {"id": "read", "type": "BatchReadImages", "params": {"folder_path": str(source_dir)}},
                {"id": "gray", "type": "Gray"},
                {"id": "save", "type": "SaveBatchResults", "params": {"output_dir": str(tmp_path / "should_not_exist")}},
            ],
            "edges": [
                {"source": "read", "target": "gray"},
                {"source": "gray", "target": "save"},
            ],
        }
    )
    manager = WorkflowDebugManager()
    result = manager.run(
        workflow,
        make_store(tmp_path / "uploads"),
        action="step",
        target_node_id=None,
        session_id=None,
        user_id="user",
        workspace_id="workspace",
        model_manager=None,
        event_callback=None,
    )

    assert result["newly_executed"] == ["read"]
    assert result["debug_sample"]["source_name"] == "a.png"
    assert result["debug_sample"]["writes_disabled"] is True
    assert not (tmp_path / "should_not_exist").exists()


def test_frontend_exposes_three_run_modes_and_debug_highlights() -> None:
    client = TestClient(app)
    html = client.get("/").text
    api_js = client.get("/assets/js/api.js").text
    actions_js = client.get("/assets/js/app/actions.js").text
    canvas_js = client.get("/assets/js/app/canvas.js").text
    css = client.get("/assets/css/styles.css").text

    assert 'id="runModeSelect"' in html
    assert '<option value="full">整体运行</option>' in html
    assert '<option value="step">单步运行</option>' in html
    assert '<option value="run_to_node">运行到节点</option>' in html
    assert 'onclick="runSelectedMode()"' in html
    assert 'onclick="resetDebugSession()"' in html
    assert "executeDebugStream" in api_js
    assert 'fetch(`${API_BASE}/debug/run-stream`' in api_js
    assert "function executeDebugAction(" in actions_js
    assert "function workflowExecutionSignatureForDebug(" in actions_js
    assert "debugExecutedNodeIds.has(node.id)" in canvas_js
    assert ".node.debug-current" in css
    assert ".node.debug-next" in css


def test_debug_failure_keeps_session_id_for_retry() -> None:
    client = TestClient(app)
    _, headers = auth_headers(client, "debug-failure-session")
    workflow = {
        "nodes": [
            {"id": "start", "type": "LogicConstant", "params": {"value_type": "NUMBER", "value": "8"}},
            {"id": "broken", "type": "LogicForLoop", "params": {"iterations": 1, "update_operation": "DIVIDE", "step": 0}},
        ],
        "edges": [{"source": "start", "target": "broken", "targetHandle": "in"}],
    }
    response = client.post(
        "/api/debug/run-stream",
        headers=headers,
        json={"workflow": workflow, "action": "run_to_node", "target_node_id": "broken"},
    )
    messages = [json.loads(line) for line in response.text.splitlines() if line.strip()]
    error = messages[-1]
    assert error["kind"] == "error"
    assert error["data"]["debug_session_id"]
    assert error["data"]["executed_order"] == ["start"]
    assert error["data"]["next_node_id"] == "broken"
