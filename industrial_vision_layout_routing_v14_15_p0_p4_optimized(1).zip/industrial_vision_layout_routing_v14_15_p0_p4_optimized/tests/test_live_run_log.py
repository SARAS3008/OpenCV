from __future__ import annotations

import json
from pathlib import Path

from fastapi.testclient import TestClient

from backend.main import app
from backend.models.workflow import WorkflowRequest
from backend.services.image_store import ImageStore
from backend.services.workflow_engine import WorkflowExecutionError, run_workflow
from tests.auth_utils import auth_headers


client = TestClient(app)
_, AUTH_HEADERS = auth_headers(client, "live-log")


def make_store(tmp_path: Path) -> ImageStore:
    return ImageStore(tmp_path, {".png", ".jpg", ".jpeg"})


def test_workflow_event_callback_reports_node_lifecycle(tmp_path: Path) -> None:
    events: list[dict] = []
    workflow = WorkflowRequest.model_validate(
        {
            "nodes": [
                {"id": "value", "type": "LogicConstant", "params": {"value_type": "NUMBER", "value": "7"}},
            ],
            "edges": [],
        }
    )

    result = run_workflow(workflow, make_store(tmp_path), event_callback=events.append)

    assert result["success"] is True
    assert [event["event"] for event in events] == [
        "workflow_started",
        "node_started",
        "node_completed",
        "workflow_completed",
    ]
    assert events[1]["node_id"] == "value"
    assert events[2]["level"] == "success"
    assert events[2]["duration_ms"] >= 0
    assert events[0]["timestamp"]


def test_workflow_event_callback_reports_failure(tmp_path: Path) -> None:
    events: list[dict] = []
    workflow = WorkflowRequest.model_validate(
        {
            "nodes": [
                {"id": "value", "type": "LogicConstant", "params": {"value_type": "NUMBER", "value": "7"}},
                {
                    "id": "broken",
                    "type": "LogicForLoop",
                    "params": {"iterations": 1, "update_operation": "DIVIDE", "step": 0},
                },
            ],
            "edges": [{"source": "value", "target": "broken", "targetHandle": "in"}],
        }
    )

    try:
        run_workflow(workflow, make_store(tmp_path), event_callback=events.append)
    except WorkflowExecutionError:
        pass
    else:
        raise AssertionError("expected workflow failure")

    event_names = [event["event"] for event in events]
    assert "node_failed" in event_names
    assert event_names[-1] == "workflow_failed"
    failed_event = next(event for event in events if event["event"] == "node_failed")
    assert failed_event["node_id"] == "broken"
    assert failed_event["level"] == "error"


def test_run_stream_endpoint_sends_ndjson_logs_and_result() -> None:
    response = client.post(
        "/api/run-stream",
        headers=AUTH_HEADERS,
        json={
            "nodes": [
                {"id": "value", "type": "LogicConstant", "params": {"value_type": "TEXT", "value": "ok"}},
            ],
            "edges": [],
        },
    )

    assert response.status_code == 200
    assert response.headers["content-type"].startswith("application/x-ndjson")
    messages = [json.loads(line) for line in response.text.splitlines() if line.strip()]
    assert messages[-1]["kind"] == "result"
    assert messages[-1]["data"]["success"] is True
    log_events = [message["data"]["event"] for message in messages if message["kind"] == "log"]
    assert log_events == ["workflow_started", "node_started", "node_completed", "workflow_completed"]


def test_right_panel_is_live_log_instead_of_duplicate_preview() -> None:
    html = client.get("/").text
    api_js = client.get("/assets/js/api.js").text
    actions_js = client.get("/assets/js/app/actions.js").text
    css = client.get("/assets/css/styles.css").text

    assert "实时运行日志" in html
    assert "运行预览" not in html
    assert 'onclick="clearRunLog()"' in html
    assert "executeWorkflowStream" in api_js
    assert 'fetch(`${API_BASE}/run-stream`' in api_js
    assert "function appendRunLog(" in actions_js
    assert "previewPanel.appendChild(card)" not in actions_js
    assert ".run-log-entry" in css
