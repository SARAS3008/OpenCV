from __future__ import annotations

import sys
import types
from pathlib import Path

import pytest

from backend.algorithms.contract_validation import validate_operator_contracts
from backend.infrastructure.artifact_store import FileArtifactStore, S3ArtifactStore
from backend.infrastructure.observability import ApplicationMetrics, JsonLogFormatter
from backend.infrastructure.state_backend import FileJsonStateBackend, RedisJsonStateBackend, create_state_backend
from backend.services.dataset_store import DatasetStore


def test_file_state_backend_crud_prefix_health_and_factory(tmp_path: Path) -> None:
    backend = FileJsonStateBackend(tmp_path / "state")
    backend.put("projects", "ws/a", {"value": 1})
    backend.put("projects", "ws/b", {"value": 2})
    backend.put("projects", "other/c", {"value": 3})

    assert backend.get("projects", "ws/a") == {"value": 1}
    assert {record.key for record in backend.list("projects", "ws/")} == {"ws/a", "ws/b"}
    assert backend.health()["ready"] is True
    assert backend.delete("projects", "ws/a") is True
    assert backend.delete("projects", "ws/a") is False
    assert backend.get("projects", "ws/a") is None
    assert create_state_backend("file", root_dir=tmp_path / "factory").kind == "file"
    with pytest.raises(ValueError, match="不支持"):
        create_state_backend("unknown", root_dir=tmp_path / "bad")


def test_redis_state_backend_with_driver_boundary(monkeypatch: pytest.MonkeyPatch) -> None:
    class FakeClient:
        def __init__(self) -> None:
            self.values: dict[str, str] = {}
            self.closed = False

        def set(self, key: str, value: str, ex: int | None = None) -> None:
            self.values[key] = value

        def get(self, key: str) -> str | None:
            return self.values.get(key)

        def delete(self, key: str) -> int:
            return int(self.values.pop(key, None) is not None)

        def scan_iter(self, match: str, count: int = 200):
            prefix = match[:-1]
            return iter(key for key in sorted(self.values) if key.startswith(prefix))

        def ping(self) -> bool:
            return True

        def close(self) -> None:
            self.closed = True

    fake_client = FakeClient()

    class FakeRedis:
        @staticmethod
        def from_url(url: str, decode_responses: bool = True) -> FakeClient:
            assert url == "redis://example"
            assert decode_responses is True
            return fake_client

    monkeypatch.setitem(sys.modules, "redis", types.SimpleNamespace(Redis=FakeRedis))
    backend = RedisJsonStateBackend("redis://example", prefix="test")
    backend.put("sessions", "token-a", {"user_id": "u"}, ttl_seconds=30)
    backend.put("sessions", "token-b", {"user_id": "v"})
    assert backend.get("sessions", "token-a") == {"user_id": "u"}
    assert {record.key for record in backend.list("sessions", "token-")} == {"token-a", "token-b"}
    assert backend.health() == {"kind": "redis", "ready": True}
    assert backend.delete("sessions", "token-a") is True
    backend.close()
    assert fake_client.closed is True


def test_artifact_stores_and_s3_driver_boundary(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    source = tmp_path / "source.txt"
    source.write_text("result", encoding="utf-8")
    local = FileArtifactStore(tmp_path / "artifacts")
    record = local.put_file("ws/run/source.txt", source)
    assert Path(record["path"]).read_text(encoding="utf-8") == "result"
    assert local.health()["ready"] is True
    with pytest.raises(ValueError, match="越界"):
        local.put_file("../escape.txt", source)

    class FakeMinio:
        def __init__(self, endpoint: str, **kwargs) -> None:
            self.endpoint = endpoint
            self.uploads: list[tuple[str, str, str]] = []

        def fput_object(self, bucket: str, key: str, path: str) -> None:
            self.uploads.append((bucket, key, path))

        def bucket_exists(self, bucket: str) -> bool:
            return bucket == "bucket"

    monkeypatch.setitem(sys.modules, "minio", types.SimpleNamespace(Minio=FakeMinio))
    remote = S3ArtifactStore(endpoint="minio:9000", bucket="bucket", access_key="a", secret_key="b", secure=False)
    remote_record = remote.put_file("ws/source.txt", source)
    assert remote_record == {"backend": "s3", "bucket": "bucket", "key": "ws/source.txt"}
    assert remote.health()["ready"] is True


def test_dataset_state_backend_update_add_list_and_delete(tmp_path: Path) -> None:
    state = FileJsonStateBackend(tmp_path / "state")
    store = DatasetStore(tmp_path / "legacy", state_backend=state)
    created = store.create_dataset(owner_id="ws", name="D", samples=[{"image_path": "a.png"}])
    dataset_id = created["dataset_id"]
    updated = store.update_dataset(owner_id="ws", dataset_id=dataset_id, payload={"name": "D2", "tags": ["ok"]})
    assert updated["name"] == "D2"
    added = store.add_samples(owner_id="ws", dataset_id=dataset_id, samples=[{"image_path": "b.png"}])
    assert len(added["samples"]) == 2
    assert store.list_datasets(owner_id="ws")[0]["sample_count"] == 2
    deleted = store.delete_dataset(owner_id="ws", dataset_id=dataset_id)
    assert deleted["dataset_id"] == dataset_id
    with pytest.raises(ValueError, match="不存在"):
        store.get_dataset(owner_id="ws", dataset_id=dataset_id)


def test_contract_validation_errors_and_metrics_formatting() -> None:
    report = validate_operator_contracts(
        {"Broken": object(), "NoMeta": lambda *_args: {}},
        {
            "Broken": {
                "label": "",
                "inputs": [{"handle": "in"}, {"handle": "in"}],
                "outputs": "bad",
                "params": {"mode": "missing"},
                "param_schema": {
                    "mode": {"type": "select", "options": [{"value": "ok"}]},
                    "manual": {"fallback_for": "unknown"},
                },
            },
            "NoImplementation": {"label": "x", "params": {}},
        },
    )
    assert report.valid is False
    assert any("缺少算子元数据" in item for item in report.errors)
    assert any("缺少算子实现" in item for item in report.errors)
    assert any("handle 重复" in item for item in report.errors)
    with pytest.raises(RuntimeError, match="算子契约校验失败"):
        report.raise_for_errors()

    metrics = ApplicationMetrics()
    metrics.begin_request()
    metrics.end_request(method="GET", path="/api/projects/1234567890abcdef", status=200, duration_seconds=0.25)
    snapshot = metrics.snapshot()
    assert snapshot["request_count"] == 1
    text = metrics.prometheus(job_stats={"by_status": {"success": 2}}, debug_sessions=1)
    assert 'vision_jobs_total{status="success"} 2' in text
    assert "vision_debug_sessions 1" in text
    assert JsonLogFormatter().format(__import__("logging").LogRecord("x", 20, "", 1, "hello", (), None))
