import cv2
import numpy as np

from backend.algorithms.image.contours import op_filter_contours
from backend.algorithms.registry import OPERATORS, OPERATOR_META


def _binary_with_three_rectangles() -> np.ndarray:
    image = np.zeros((120, 160), dtype=np.uint8)
    cv2.rectangle(image, (10, 10), (30, 30), 255, -1)    # small: ~400
    cv2.rectangle(image, (55, 10), (105, 50), 255, -1)   # large: ~2000
    cv2.rectangle(image, (20, 70), (55, 95), 255, -1)    # middle: ~875
    return image


def test_filter_contours_selects_largest_area() -> None:
    image = _binary_with_three_rectangles()
    result = op_filter_contours(
        {"in": image, "in_color_space": "GRAY"},
        {"binary_mode": "INPUT_BINARY", "sort_by": "area", "select_mode": "MAX"},
        {},
    )

    assert result["out"].shape == (120, 160, 3)
    assert result["mask"].shape == (120, 160)
    assert result["roi"].ndim == 3
    assert result["roi_mask"].ndim == 2
    assert result["metrics"]["selected_count"] == 1
    assert result["metrics"]["contour_filtered"] == 3
    assert result["bbox"] == [55, 10, 51, 41]
    assert result["contour_infos"][0]["area"] >= 1900
    assert np.count_nonzero(result["mask"]) > 0


def test_filter_contours_selects_smallest_area() -> None:
    image = _binary_with_three_rectangles()
    result = op_filter_contours(
        {"in": image, "in_color_space": "GRAY"},
        {"binary_mode": "INPUT_BINARY", "sort_by": "area", "select_mode": "MIN"},
        {},
    )

    assert result["metrics"]["selected_count"] == 1
    assert result["bbox"] == [10, 10, 21, 21]
    assert 350 <= result["metrics"]["primary_area"] <= 450


def test_filter_contours_top_k_by_perimeter_and_min_area() -> None:
    image = _binary_with_three_rectangles()
    result = op_filter_contours(
        {"in": image, "in_color_space": "GRAY"},
        {
            "binary_mode": "INPUT_BINARY",
            "sort_by": "perimeter",
            "select_mode": "TOP_K",
            "top_k": 2,
            "min_area": 500,
        },
        {},
    )

    assert result["metrics"]["contour_filtered"] == 2
    assert result["metrics"]["selected_count"] == 2
    assert len(result["contours"]) == 2
    assert result["bbox"] == [20, 10, 86, 86]


def test_filter_contours_is_registered_and_has_metadata() -> None:
    assert "FilterContours" in OPERATORS
    meta = OPERATOR_META["FilterContours"]
    assert meta["label"] == "轮廓筛选"
    assert meta["outputs"][1]["handle"] == "mask"
    assert any(option["value"] == "circularity" for option in meta["param_schema"]["sort_by"]["options"])

from backend.models.workflow import WorkflowRequest
from backend.services.script_exporter import generate_algorithm_script


def test_filter_contours_can_be_exported_to_algorithm_script() -> None:
    workflow = WorkflowRequest.model_validate(
        {
            "nodes": [
                {"id": "read", "type": "ReadImage"},
                {
                    "id": "filter",
                    "type": "FilterContours",
                    "params": {"threshold": 127, "sort_by": "area", "select_mode": "MAX", "min_area": 10},
                },
            ],
            "edges": [{"source": "read", "target": "filter"}],
        }
    )
    source = generate_algorithm_script(workflow)
    assert "FilterContours" not in source
    assert "cv2.findContours" in source
    assert "selected_contours" in source
