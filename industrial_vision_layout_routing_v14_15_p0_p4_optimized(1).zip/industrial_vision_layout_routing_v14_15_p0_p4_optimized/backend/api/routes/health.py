from __future__ import annotations

from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse, PlainTextResponse

from backend.services.workflow_debugger import workflow_debug_manager

router = APIRouter()


@router.get("/health/live", include_in_schema=False)
def live() -> dict:
    return {"status": "ok"}


@router.get("/health/ready", include_in_schema=False)
def ready(request: Request):
    checks = {
        "state_backend": request.app.state.state_backend.health(),
        "session_backend": request.app.state.session_backend.health(),
        "artifact_backend": request.app.state.artifact_store.health(),
        "operator_contracts": request.app.state.operator_contract_report.as_dict(),
    }
    ready_value = all(
        item.get("ready", item.get("valid", False)) for item in checks.values()
    )
    payload = {"status": "ready" if ready_value else "not_ready", "checks": checks}
    return payload if ready_value else JSONResponse(status_code=503, content=payload)


@router.get("/metrics", include_in_schema=False)
def metrics(request: Request) -> PlainTextResponse:
    text = request.app.state.metrics.prometheus(
        job_stats=request.app.state.job_queue.stats(),
        debug_sessions=workflow_debug_manager.session_count(),
    )
    return PlainTextResponse(text, media_type="text/plain; version=0.0.4; charset=utf-8")
