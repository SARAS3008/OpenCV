from __future__ import annotations

import json
import logging
import threading
import time
import uuid
from collections import Counter
from typing import Any

from fastapi import Request, Response


class ApplicationMetrics:
    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._requests: Counter[tuple[str, str]] = Counter()
        self._status: Counter[int] = Counter()
        self._duration_seconds = 0.0
        self._active_requests = 0
        self._started_at = time.time()

    def begin_request(self) -> None:
        with self._lock:
            self._active_requests += 1

    def end_request(self, *, method: str, path: str, status: int, duration_seconds: float) -> None:
        route = self._normalize_path(path)
        with self._lock:
            self._active_requests = max(0, self._active_requests - 1)
            self._requests[(method, route)] += 1
            self._status[status] += 1
            self._duration_seconds += duration_seconds

    @staticmethod
    def _normalize_path(path: str) -> str:
        parts = []
        for part in str(path or "/").split("/"):
            if len(part) >= 16 and all(ch.isalnum() or ch in "-_" for ch in part):
                parts.append(":id")
            else:
                parts.append(part)
        return "/".join(parts) or "/"

    def snapshot(self) -> dict[str, Any]:
        with self._lock:
            return {
                "uptime_seconds": round(time.time() - self._started_at, 3),
                "active_requests": self._active_requests,
                "request_count": sum(self._requests.values()),
                "status_counts": dict(self._status),
                "request_duration_seconds_sum": round(self._duration_seconds, 6),
            }

    def prometheus(self, *, job_stats: dict[str, Any] | None = None, debug_sessions: int = 0) -> str:
        snapshot = self.snapshot()
        lines = [
            "# HELP vision_uptime_seconds Process uptime.",
            "# TYPE vision_uptime_seconds gauge",
            f"vision_uptime_seconds {snapshot['uptime_seconds']}",
            "# HELP vision_active_requests Active HTTP requests.",
            "# TYPE vision_active_requests gauge",
            f"vision_active_requests {snapshot['active_requests']}",
            "# HELP vision_http_requests_total Total HTTP requests.",
            "# TYPE vision_http_requests_total counter",
            f"vision_http_requests_total {snapshot['request_count']}",
            "# HELP vision_http_request_duration_seconds_sum Cumulative HTTP request duration.",
            "# TYPE vision_http_request_duration_seconds_sum counter",
            f"vision_http_request_duration_seconds_sum {snapshot['request_duration_seconds_sum']}",
            "# HELP vision_debug_sessions Active in-process debug sessions.",
            "# TYPE vision_debug_sessions gauge",
            f"vision_debug_sessions {debug_sessions}",
        ]
        for status, count in sorted(snapshot["status_counts"].items()):
            lines.append(f'vision_http_responses_total{{status="{status}"}} {count}')
        for status, count in sorted((job_stats or {}).get("by_status", {}).items()):
            lines.append(f'vision_jobs_total{{status="{status}"}} {count}')
        return "\n".join(lines) + "\n"


class JsonLogFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        payload = {
            "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(record.created)),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }
        for key in ("request_id", "method", "path", "status", "duration_ms"):
            value = getattr(record, key, None)
            if value is not None:
                payload[key] = value
        if record.exc_info:
            payload["exception"] = self.formatException(record.exc_info)
        return json.dumps(payload, ensure_ascii=False, separators=(",", ":"))


def configure_logging(level: str = "INFO") -> None:
    root = logging.getLogger()
    root.setLevel(getattr(logging, str(level).upper(), logging.INFO))
    if not any(isinstance(handler.formatter, JsonLogFormatter) for handler in root.handlers):
        handler = logging.StreamHandler()
        handler.setFormatter(JsonLogFormatter())
        root.handlers[:] = [handler]


async def request_observability_middleware(request: Request, call_next):
    metrics: ApplicationMetrics = request.app.state.metrics
    request_id = request.headers.get("X-Request-Id") or uuid.uuid4().hex
    started = time.perf_counter()
    metrics.begin_request()
    status = 500
    try:
        response: Response = await call_next(request)
        status = response.status_code
        response.headers["X-Request-Id"] = request_id
        return response
    finally:
        duration = time.perf_counter() - started
        metrics.end_request(method=request.method, path=request.url.path, status=status, duration_seconds=duration)
        logging.getLogger("vision.http").info(
            "request_completed",
            extra={
                "request_id": request_id,
                "method": request.method,
                "path": request.url.path,
                "status": status,
                "duration_ms": round(duration * 1000, 2),
            },
        )
