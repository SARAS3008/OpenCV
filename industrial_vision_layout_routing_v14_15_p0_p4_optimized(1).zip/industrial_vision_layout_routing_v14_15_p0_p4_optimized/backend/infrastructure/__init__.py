"""Production infrastructure adapters with file-backed defaults."""
