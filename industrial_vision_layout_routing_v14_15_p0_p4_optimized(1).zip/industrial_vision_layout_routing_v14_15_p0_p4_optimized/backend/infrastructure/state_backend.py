from __future__ import annotations

import json
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Protocol

from backend.services.file_io import atomic_write_json


@dataclass(frozen=True, slots=True)
class StateRecord:
    namespace: str
    key: str
    payload: dict[str, Any]
    updated_at: float


class JsonStateBackend(Protocol):
    kind: str

    def put(self, namespace: str, key: str, payload: dict[str, Any], *, ttl_seconds: int | None = None) -> None: ...
    def get(self, namespace: str, key: str) -> dict[str, Any] | None: ...
    def delete(self, namespace: str, key: str) -> bool: ...
    def list(self, namespace: str, prefix: str = "") -> list[StateRecord]: ...
    def health(self) -> dict[str, Any]: ...
    def close(self) -> None: ...


def _safe_part(value: str) -> str:
    text = str(value or "").strip().replace("\\", "/")
    parts = [part for part in text.split("/") if part not in {"", ".", ".."}]
    if not parts:
        raise ValueError("状态键不能为空")
    return "/".join(parts)


class FileJsonStateBackend:
    kind = "file"

    def __init__(self, root_dir: Path) -> None:
        self.root_dir = root_dir.resolve()
        self.root_dir.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()

    def _path(self, namespace: str, key: str) -> Path:
        namespace_part = _safe_part(namespace)
        key_part = _safe_part(key)
        path = (self.root_dir / namespace_part / f"{key_part}.json").resolve()
        if self.root_dir not in path.parents:
            raise ValueError("状态键越界")
        return path

    def put(self, namespace: str, key: str, payload: dict[str, Any], *, ttl_seconds: int | None = None) -> None:
        with self._lock:
            atomic_write_json(self._path(namespace, key), payload)

    def get(self, namespace: str, key: str) -> dict[str, Any] | None:
        path = self._path(namespace, key)
        if not path.is_file():
            return None
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return None
        return payload if isinstance(payload, dict) else None

    def delete(self, namespace: str, key: str) -> bool:
        path = self._path(namespace, key)
        existed = path.exists()
        path.unlink(missing_ok=True)
        return existed

    def list(self, namespace: str, prefix: str = "") -> list[StateRecord]:
        base = (self.root_dir / _safe_part(namespace)).resolve()
        if not base.exists():
            return []
        prefix_part = str(prefix or "").strip().replace("\\", "/")
        records: list[StateRecord] = []
        for path in base.rglob("*.json"):
            relative = path.relative_to(base).as_posix()
            key = relative[:-5]
            if prefix_part and not key.startswith(prefix_part):
                continue
            try:
                payload = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                continue
            if isinstance(payload, dict):
                records.append(StateRecord(namespace, key, payload, path.stat().st_mtime))
        return sorted(records, key=lambda item: item.updated_at, reverse=True)

    def health(self) -> dict[str, Any]:
        probe = self.root_dir / ".health-probe"
        try:
            probe.write_text(str(time.time()), encoding="utf-8")
            probe.unlink(missing_ok=True)
            return {"kind": self.kind, "ready": True, "root": str(self.root_dir)}
        except OSError as exc:
            return {"kind": self.kind, "ready": False, "error": str(exc)}

    def close(self) -> None:
        return None


class RedisJsonStateBackend:
    kind = "redis"

    def __init__(self, url: str, *, prefix: str = "vision") -> None:
        if not url:
            raise ValueError("VISION_REDIS_URL 未配置")
        try:
            import redis
        except ImportError as exc:
            raise RuntimeError("Redis 后端需要安装 requirements-production.txt 中的 redis") from exc
        self._client = redis.Redis.from_url(url, decode_responses=True)
        self.prefix = prefix.strip(":") or "vision"

    def _key(self, namespace: str, key: str) -> str:
        return f"{self.prefix}:{_safe_part(namespace)}:{_safe_part(key)}"

    def put(self, namespace: str, key: str, payload: dict[str, Any], *, ttl_seconds: int | None = None) -> None:
        self._client.set(self._key(namespace, key), json.dumps(payload, ensure_ascii=False, separators=(",", ":")), ex=ttl_seconds)

    def get(self, namespace: str, key: str) -> dict[str, Any] | None:
        raw = self._client.get(self._key(namespace, key))
        if raw is None:
            return None
        payload = json.loads(raw)
        return payload if isinstance(payload, dict) else None

    def delete(self, namespace: str, key: str) -> bool:
        return bool(self._client.delete(self._key(namespace, key)))

    def list(self, namespace: str, prefix: str = "") -> list[StateRecord]:
        ns = _safe_part(namespace)
        raw_prefix = _safe_part(prefix) if prefix else ""
        pattern = f"{self.prefix}:{ns}:{raw_prefix}*"
        records: list[StateRecord] = []
        key_prefix = f"{self.prefix}:{ns}:"
        for redis_key in self._client.scan_iter(match=pattern, count=200):
            raw = self._client.get(redis_key)
            if not raw:
                continue
            payload = json.loads(raw)
            if isinstance(payload, dict):
                records.append(StateRecord(ns, str(redis_key)[len(key_prefix):], payload, 0.0))
        return records

    def health(self) -> dict[str, Any]:
        try:
            return {"kind": self.kind, "ready": bool(self._client.ping())}
        except Exception as exc:  # external service boundary
            return {"kind": self.kind, "ready": False, "error": str(exc)}

    def close(self) -> None:
        try:
            self._client.close()
        except Exception:
            return None


class PostgresJsonStateBackend:
    kind = "postgres"

    def __init__(self, url: str, *, table: str = "vision_state") -> None:
        if not url:
            raise ValueError("VISION_DATABASE_URL 未配置")
        try:
            import psycopg
        except ImportError as exc:
            raise RuntimeError("PostgreSQL 后端需要安装 requirements-production.txt 中的 psycopg") from exc
        self._psycopg = psycopg
        self.url = url
        self.table = "".join(ch for ch in table if ch.isalnum() or ch == "_") or "vision_state"
        self._initialize()

    def _connect(self):
        return self._psycopg.connect(self.url)

    def _initialize(self) -> None:
        with self._connect() as conn, conn.cursor() as cur:
            cur.execute(
                f'''CREATE TABLE IF NOT EXISTS {self.table} (\n                    namespace TEXT NOT NULL,\n                    state_key TEXT NOT NULL,\n                    payload JSONB NOT NULL,\n                    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),\n                    PRIMARY KEY(namespace, state_key)\n                )'''
            )

    def put(self, namespace: str, key: str, payload: dict[str, Any], *, ttl_seconds: int | None = None) -> None:
        with self._connect() as conn, conn.cursor() as cur:
            cur.execute(
                f'''INSERT INTO {self.table}(namespace, state_key, payload, updated_at)\n                    VALUES (%s, %s, %s::jsonb, NOW())\n                    ON CONFLICT(namespace, state_key) DO UPDATE\n                    SET payload=EXCLUDED.payload, updated_at=NOW()''',
                (_safe_part(namespace), _safe_part(key), json.dumps(payload, ensure_ascii=False)),
            )

    def get(self, namespace: str, key: str) -> dict[str, Any] | None:
        with self._connect() as conn, conn.cursor() as cur:
            cur.execute(
                f"SELECT payload FROM {self.table} WHERE namespace=%s AND state_key=%s",
                (_safe_part(namespace), _safe_part(key)),
            )
            row = cur.fetchone()
        return dict(row[0]) if row else None

    def delete(self, namespace: str, key: str) -> bool:
        with self._connect() as conn, conn.cursor() as cur:
            cur.execute(
                f"DELETE FROM {self.table} WHERE namespace=%s AND state_key=%s",
                (_safe_part(namespace), _safe_part(key)),
            )
            return cur.rowcount > 0

    def list(self, namespace: str, prefix: str = "") -> list[StateRecord]:
        ns = _safe_part(namespace)
        with self._connect() as conn, conn.cursor() as cur:
            cur.execute(
                f'''SELECT state_key, payload, EXTRACT(EPOCH FROM updated_at)\n                    FROM {self.table}\n                    WHERE namespace=%s AND state_key LIKE %s\n                    ORDER BY updated_at DESC''',
                (ns, f"{prefix}%"),
            )
            rows = cur.fetchall()
        return [StateRecord(ns, row[0], dict(row[1]), float(row[2])) for row in rows]

    def health(self) -> dict[str, Any]:
        try:
            with self._connect() as conn, conn.cursor() as cur:
                cur.execute("SELECT 1")
                cur.fetchone()
            return {"kind": self.kind, "ready": True}
        except Exception as exc:
            return {"kind": self.kind, "ready": False, "error": str(exc)}

    def close(self) -> None:
        return None


def create_state_backend(kind: str, *, root_dir: Path, database_url: str = "", redis_url: str = "") -> JsonStateBackend:
    normalized = str(kind or "file").strip().lower()
    if normalized in {"file", "filesystem", "local"}:
        return FileJsonStateBackend(root_dir)
    if normalized in {"postgres", "postgresql"}:
        return PostgresJsonStateBackend(database_url)
    if normalized == "redis":
        return RedisJsonStateBackend(redis_url)
    raise ValueError(f"不支持的状态后端：{kind}")
