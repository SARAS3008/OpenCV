from __future__ import annotations

from pathlib import Path
from typing import Any, Protocol


class ArtifactStore(Protocol):
    kind: str
    def put_file(self, key: str, source: Path) -> dict[str, Any]: ...
    def health(self) -> dict[str, Any]: ...
    def close(self) -> None: ...


class FileArtifactStore:
    kind = "file"

    def __init__(self, root_dir: Path) -> None:
        self.root_dir = root_dir.resolve()
        self.root_dir.mkdir(parents=True, exist_ok=True)

    def put_file(self, key: str, source: Path) -> dict[str, Any]:
        import shutil
        destination = (self.root_dir / key).resolve()
        if self.root_dir not in destination.parents:
            raise ValueError("产物路径越界")
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)
        return {"backend": self.kind, "key": key, "path": str(destination)}

    def health(self) -> dict[str, Any]:
        return {"kind": self.kind, "ready": self.root_dir.is_dir(), "root": str(self.root_dir)}

    def close(self) -> None:
        return None


class S3ArtifactStore:
    kind = "s3"

    def __init__(self, *, endpoint: str, bucket: str, access_key: str, secret_key: str, secure: bool = True) -> None:
        try:
            from minio import Minio
        except ImportError as exc:
            raise RuntimeError("S3/MinIO 产物后端需要安装 requirements-production.txt 中的 minio") from exc
        if not endpoint or not access_key or not secret_key:
            raise ValueError("S3/MinIO 后端配置不完整")
        self.bucket = bucket
        self._client = Minio(endpoint, access_key=access_key, secret_key=secret_key, secure=secure)

    def put_file(self, key: str, source: Path) -> dict[str, Any]:
        self._client.fput_object(self.bucket, key, str(source))
        return {"backend": self.kind, "bucket": self.bucket, "key": key}

    def health(self) -> dict[str, Any]:
        try:
            ready = self._client.bucket_exists(self.bucket)
            return {"kind": self.kind, "ready": bool(ready), "bucket": self.bucket}
        except Exception as exc:
            return {"kind": self.kind, "ready": False, "error": str(exc), "bucket": self.bucket}

    def close(self) -> None:
        return None
