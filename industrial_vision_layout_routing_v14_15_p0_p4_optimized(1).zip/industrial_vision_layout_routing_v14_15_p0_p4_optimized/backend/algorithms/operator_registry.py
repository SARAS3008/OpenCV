from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from backend.algorithms.plugin_loader import ScriptCompiler
from backend.algorithms.types import Operator


@dataclass(frozen=True)
class OperatorDefinition:
    """运行函数、元数据、目录归属和导出编译器的统一注册单元。"""

    type_name: str
    operator: Operator
    metadata: dict[str, Any]
    category: str
    group: str
    script_compiler: ScriptCompiler | None = None
    builtin: bool = True


class OperatorRegistry:
    def __init__(self) -> None:
        self.definitions: dict[str, OperatorDefinition] = {}
        self.operators: dict[str, Operator] = {}
        self.metadata: dict[str, dict[str, Any]] = {}
        self.catalog: dict[str, list[dict[str, Any]]] = {}
        self.script_compilers: dict[str, ScriptCompiler] = {}

    def register(self, definition: OperatorDefinition) -> None:
        type_name = str(definition.type_name).strip()
        if not type_name:
            raise ValueError("算子 type_name 不能为空")
        if type_name in self.definitions:
            raise ValueError(f"算子名称重复：{type_name}")

        metadata = dict(definition.metadata)
        metadata.setdefault("label", type_name)
        metadata.setdefault("category", definition.category)
        metadata.setdefault("group", definition.group)
        metadata.setdefault("params", {})

        normalized = OperatorDefinition(
            type_name=type_name,
            operator=definition.operator,
            metadata=metadata,
            category=str(metadata.get("category") or definition.category),
            group=str(metadata.get("group") or definition.group),
            script_compiler=definition.script_compiler,
            builtin=definition.builtin,
        )
        self.definitions[type_name] = normalized
        self.operators[type_name] = normalized.operator
        self.metadata[type_name] = normalized.metadata
        self._append_catalog_item(normalized.category, normalized.group, type_name)
        if normalized.script_compiler is not None:
            self.script_compilers[type_name] = normalized.script_compiler

    def _append_catalog_item(self, category: str, group: str, type_name: str) -> None:
        groups = self.catalog.setdefault(category, [])
        target = next((item for item in groups if item.get("group") == group), None)
        if target is None:
            target = {"group": group, "items": []}
            groups.append(target)
        if type_name not in target["items"]:
            target["items"].append(type_name)

    def register_many(
        self,
        operator_map: dict[str, Operator],
        metadata_map: dict[str, dict[str, Any]],
        catalog: dict[str, list[dict[str, Any]]],
    ) -> None:
        group_lookup: dict[str, tuple[str, str]] = {}
        for category, groups in catalog.items():
            for group_metadata in groups:
                group_name = str(group_metadata.get("group") or "未分类")
                for type_name in group_metadata.get("items", []):
                    group_lookup[str(type_name)] = (str(category), group_name)

        for type_name, operator in operator_map.items():
            metadata = dict(metadata_map.get(type_name, {}))
            category, group_name = group_lookup.get(
                type_name,
                (str(metadata.get("category") or "图像"), str(metadata.get("group") or "未分类")),
            )
            self.register(
                OperatorDefinition(
                    type_name=type_name,
                    operator=operator,
                    metadata=metadata,
                    category=category,
                    group=group_name,
                    builtin=True,
                )
            )


__all__ = ["OperatorDefinition", "OperatorRegistry"]
