from __future__ import annotations

from typing import Any

import cv2
import numpy as np

from backend.algorithms.helpers import ensure_bgr, to_float, to_int
from backend.algorithms.image.common import gray_input
from backend.algorithms.types import ExecutionContext, OperatorInputs, OperatorParams, OperatorResult


def op_find_contours(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    img = inputs["in"]
    gray = gray_input({"in": img, "in_color_space": inputs.get("in_color_space", "BGR")})
    threshold = to_int(params.get("threshold", 127), 127)
    min_area = to_float(params.get("min_area", 20), 20.0)
    _, binary = cv2.threshold(gray, threshold, 255, cv2.THRESH_BINARY)
    contours, _ = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    canvas = ensure_bgr(img).copy()
    count = 0
    for contour in contours:
        if cv2.contourArea(contour) < min_area:
            continue
        cv2.drawContours(canvas, [contour], -1, (0, 255, 0), 2)
        x, y, w, h = cv2.boundingRect(contour)
        cv2.rectangle(canvas, (x, y), (x + w, y + h), (0, 180, 255), 1)
        count += 1
    areas = [float(cv2.contourArea(contour)) for contour in contours if cv2.contourArea(contour) >= min_area]
    cv2.putText(canvas, f"contours: {count}", (12, 28), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 220, 255), 2)
    return {
        "out": canvas,
        "out_color_space": "BGR",
        "metrics": {
            "contour_count": count,
            "contour_area_total": round(sum(areas), 4),
            "contour_area_max": round(max(areas, default=0.0), 4),
        },
    }


_RETRIEVAL_MODES = {
    "EXTERNAL": cv2.RETR_EXTERNAL,
    "LIST": cv2.RETR_LIST,
    "CCOMP": cv2.RETR_CCOMP,
    "TREE": cv2.RETR_TREE,
}

_APPROX_MODES = {
    "SIMPLE": cv2.CHAIN_APPROX_SIMPLE,
    "NONE": cv2.CHAIN_APPROX_NONE,
}

_SORT_FIELDS = {
    "area",
    "perimeter",
    "bbox_width",
    "bbox_height",
    "bbox_area",
    "aspect_ratio",
    "circularity",
    "solidity",
    "extent",
    "center_x",
    "center_y",
}


def _upper(value: Any, default: str) -> str:
    text = str(value if value is not None else default).strip().upper()
    return text or default


def _positive_int(value: Any, default: int, *, minimum: int = 1) -> int:
    return max(minimum, to_int(value, default))


def _binary_from_input(img: np.ndarray, inputs: OperatorInputs, params: OperatorParams) -> np.ndarray:
    gray = gray_input({"in": img, "in_color_space": inputs.get("in_color_space", "BGR")})
    mode = _upper(params.get("binary_mode", "AUTO"), "AUTO")
    threshold = to_int(params.get("threshold", 127), 127)

    if mode == "INPUT_BINARY":
        return ((gray > 0).astype(np.uint8)) * 255
    if mode == "THRESH_BINARY_INV":
        return cv2.threshold(gray, threshold, 255, cv2.THRESH_BINARY_INV)[1]
    if mode == "OTSU":
        return cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)[1]
    if mode == "OTSU_INV":
        return cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV | cv2.THRESH_OTSU)[1]
    if mode == "THRESH_BINARY":
        return cv2.threshold(gray, threshold, 255, cv2.THRESH_BINARY)[1]

    # AUTO：如果输入基本已经是二值图，直接按非零像素作为前景；否则按阈值二值化。
    unique = np.unique(gray)
    if unique.size <= 4 and set(int(v) for v in unique.tolist()).issubset({0, 1, 255}):
        return ((gray > 0).astype(np.uint8)) * 255
    return cv2.threshold(gray, threshold, 255, cv2.THRESH_BINARY)[1]


def _contour_info(contour: np.ndarray, index: int) -> dict[str, Any]:
    area = float(cv2.contourArea(contour))
    perimeter = float(cv2.arcLength(contour, True))
    x, y, w, h = cv2.boundingRect(contour)
    bbox_area = float(w * h)
    aspect_ratio = float(w / h) if h else 0.0
    extent = float(area / bbox_area) if bbox_area else 0.0
    hull = cv2.convexHull(contour)
    hull_area = float(cv2.contourArea(hull))
    solidity = float(area / hull_area) if hull_area else 0.0
    circularity = float((4.0 * np.pi * area) / (perimeter * perimeter)) if perimeter else 0.0
    moments = cv2.moments(contour)
    if abs(moments.get("m00", 0.0)) > 1e-9:
        center_x = float(moments["m10"] / moments["m00"])
        center_y = float(moments["m01"] / moments["m00"])
    else:
        center_x = float(x + w / 2.0)
        center_y = float(y + h / 2.0)
    return {
        "index": int(index),
        "area": area,
        "perimeter": perimeter,
        "bbox": [int(x), int(y), int(w), int(h)],
        "bbox_width": int(w),
        "bbox_height": int(h),
        "bbox_area": bbox_area,
        "aspect_ratio": aspect_ratio,
        "extent": extent,
        "solidity": solidity,
        "circularity": circularity,
        "center": [center_x, center_y],
        "center_x": center_x,
        "center_y": center_y,
    }


def _passes_range(value: float, minimum: float, maximum: float) -> bool:
    if value < minimum:
        return False
    if maximum > 0 and value > maximum:
        return False
    return True


def _filter_by_measure_ranges(items: list[tuple[np.ndarray, dict[str, Any]]], params: OperatorParams) -> list[tuple[np.ndarray, dict[str, Any]]]:
    min_area = to_float(params.get("min_area", 0), 0.0)
    max_area = to_float(params.get("max_area", 0), 0.0)
    min_perimeter = to_float(params.get("min_perimeter", 0), 0.0)
    max_perimeter = to_float(params.get("max_perimeter", 0), 0.0)
    min_width = to_float(params.get("min_width", 0), 0.0)
    max_width = to_float(params.get("max_width", 0), 0.0)
    min_height = to_float(params.get("min_height", 0), 0.0)
    max_height = to_float(params.get("max_height", 0), 0.0)

    filtered: list[tuple[np.ndarray, dict[str, Any]]] = []
    for contour, info in items:
        if not _passes_range(float(info["area"]), min_area, max_area):
            continue
        if not _passes_range(float(info["perimeter"]), min_perimeter, max_perimeter):
            continue
        if not _passes_range(float(info["bbox_width"]), min_width, max_width):
            continue
        if not _passes_range(float(info["bbox_height"]), min_height, max_height):
            continue
        filtered.append((contour, info))
    return filtered


def _sort_and_select(items: list[tuple[np.ndarray, dict[str, Any]]], params: OperatorParams) -> list[tuple[np.ndarray, dict[str, Any]]]:
    sort_by = str(params.get("sort_by", "area") or "area").strip()
    if sort_by not in _SORT_FIELDS:
        sort_by = "area"

    select_mode = _upper(params.get("select_mode", "MAX"), "MAX")
    if select_mode in {"MIN", "BOTTOM_K"}:
        descending = False
    elif select_mode in {"MAX", "TOP_K"}:
        descending = True
    else:
        order = _upper(params.get("sort_order", "DESC"), "DESC")
        descending = order != "ASC"

    sorted_items = sorted(items, key=lambda item: float(item[1].get(sort_by, 0.0)), reverse=descending)

    if select_mode in {"MAX", "MIN"}:
        return sorted_items[:1]
    if select_mode in {"TOP_K", "BOTTOM_K"}:
        return sorted_items[: _positive_int(params.get("top_k", 1), 1)]
    if select_mode == "NTH":
        index = max(0, to_int(params.get("nth_index", 0), 0))
        return sorted_items[index : index + 1]
    if select_mode == "ALL_SORTED":
        return sorted_items
    return sorted_items[:1]


def _json_contour(contour: np.ndarray, max_points: int) -> list[list[int]]:
    points = contour.reshape(-1, 2)
    if max_points > 0 and len(points) > max_points:
        step = max(1, int(np.ceil(len(points) / float(max_points))))
        points = points[::step][:max_points]
    return [[int(x), int(y)] for x, y in points]


def _selected_bbox(infos: list[dict[str, Any]], shape: tuple[int, ...]) -> list[int]:
    if not infos:
        return [0, 0, 0, 0]
    height, width = shape[:2]
    x1 = min(int(info["bbox"][0]) for info in infos)
    y1 = min(int(info["bbox"][1]) for info in infos)
    x2 = max(int(info["bbox"][0]) + int(info["bbox"][2]) for info in infos)
    y2 = max(int(info["bbox"][1]) + int(info["bbox"][3]) for info in infos)
    x1 = int(np.clip(x1, 0, width))
    y1 = int(np.clip(y1, 0, height))
    x2 = int(np.clip(x2, 0, width))
    y2 = int(np.clip(y2, 0, height))
    return [x1, y1, max(0, x2 - x1), max(0, y2 - y1)]


def op_filter_contours(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    """筛选轮廓。

    输入可以是二值图，也可以是灰度/彩色图。算子先获取轮廓，再按面积、周长、外接框、
    圆度等指标排序，最后输出选中的轮廓 mask / ROI / 统计信息。
    """

    img = inputs["in"]
    binary = _binary_from_input(img, inputs, params)
    retrieval_name = _upper(params.get("retrieval_mode", "EXTERNAL"), "EXTERNAL")
    approx_name = _upper(params.get("approx_mode", "SIMPLE"), "SIMPLE")
    contours, _ = cv2.findContours(
        binary,
        _RETRIEVAL_MODES.get(retrieval_name, cv2.RETR_EXTERNAL),
        _APPROX_MODES.get(approx_name, cv2.CHAIN_APPROX_SIMPLE),
    )

    all_items = [(contour, _contour_info(contour, index)) for index, contour in enumerate(contours)]
    filtered_items = _filter_by_measure_ranges(all_items, params)
    selected_items = _sort_and_select(filtered_items, params)
    selected_contours = [contour for contour, _ in selected_items]
    selected_infos = [info for _, info in selected_items]

    selected_mask = np.zeros(binary.shape[:2], dtype=np.uint8)
    if selected_contours:
        cv2.drawContours(selected_mask, selected_contours, -1, 255, thickness=cv2.FILLED)

    bbox = _selected_bbox(selected_infos, selected_mask.shape)
    x, y, w, h = bbox
    roi = ensure_bgr(img)[y : y + h, x : x + w].copy() if w > 0 and h > 0 else np.zeros((0, 0, 3), dtype=np.uint8)
    roi_mask = selected_mask[y : y + h, x : x + w].copy() if w > 0 and h > 0 else np.zeros((0, 0), dtype=np.uint8)

    canvas = ensure_bgr(img).copy()
    draw_all = _upper(params.get("draw_all", "YES"), "YES") in {"1", "TRUE", "YES", "Y", "是", "ON"}
    if draw_all and filtered_items:
        cv2.drawContours(canvas, [item[0] for item in filtered_items], -1, (120, 120, 120), 1)
    if selected_contours:
        cv2.drawContours(canvas, selected_contours, -1, (0, 255, 0), 2)
        if w > 0 and h > 0:
            cv2.rectangle(canvas, (x, y), (x + w, y + h), (0, 180, 255), 2)
        for rank, info in enumerate(selected_infos, start=1):
            cx, cy = info["center"]
            cv2.circle(canvas, (int(round(cx)), int(round(cy))), 3, (0, 0, 255), -1)
            cv2.putText(
                canvas,
                f"#{rank}",
                (int(info["bbox"][0]), max(16, int(info["bbox"][1]) - 4)),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.5,
                (0, 220, 255),
                1,
                cv2.LINE_AA,
            )

    sort_by = str(params.get("sort_by", "area") or "area").strip()
    select_mode = _upper(params.get("select_mode", "MAX"), "MAX")
    cv2.putText(
        canvas,
        f"selected: {len(selected_infos)}/{len(filtered_items)} by {sort_by}",
        (12, 28),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.7,
        (0, 220, 255),
        2,
        cv2.LINE_AA,
    )

    max_points = max(0, to_int(params.get("max_points", 200), 200))
    selected_points = [_json_contour(contour, max_points) for contour in selected_contours]
    all_areas = [float(info["area"]) for _, info in filtered_items]
    selected_areas = [float(info["area"]) for info in selected_infos]

    primary_info = dict(selected_infos[0]) if selected_infos else {}
    primary_contour = selected_points[0] if selected_points else []
    selected_infos_rounded: list[dict[str, Any]] = []
    for info in selected_infos:
        rounded = dict(info)
        for key in ("area", "perimeter", "bbox_area", "aspect_ratio", "extent", "solidity", "circularity", "center_x", "center_y"):
            if key in rounded:
                rounded[key] = round(float(rounded[key]), 6)
        rounded["center"] = [round(float(v), 6) for v in rounded.get("center", [])]
        selected_infos_rounded.append(rounded)

    metrics = {
        "contour_total": len(all_items),
        "contour_filtered": len(filtered_items),
        "selected_count": len(selected_items),
        "selected_area_total": round(sum(selected_areas), 4),
        "selected_area_max": round(max(selected_areas, default=0.0), 4),
        "selected_area_min": round(min(selected_areas, default=0.0), 4),
        "selected_bbox_x": bbox[0],
        "selected_bbox_y": bbox[1],
        "selected_bbox_w": bbox[2],
        "selected_bbox_h": bbox[3],
        "sort_by": sort_by,
        "select_mode": select_mode,
    }
    if primary_info:
        metrics.update(
            {
                "primary_area": round(float(primary_info.get("area", 0.0)), 4),
                "primary_perimeter": round(float(primary_info.get("perimeter", 0.0)), 4),
                "primary_circularity": round(float(primary_info.get("circularity", 0.0)), 6),
                "primary_solidity": round(float(primary_info.get("solidity", 0.0)), 6),
            }
        )

    return {
        "out": canvas,
        "out_color_space": "BGR",
        "mask": selected_mask,
        "mask_color_space": "GRAY",
        "roi": roi,
        "roi_color_space": "BGR",
        "roi_mask": roi_mask,
        "roi_mask_color_space": "GRAY",
        "bbox": bbox,
        "contour": primary_contour,
        "contours": selected_points,
        "contour_infos": selected_infos_rounded,
        "data": {
            "bbox": bbox,
            "contour": primary_contour,
            "contours": selected_points,
            "contour_infos": selected_infos_rounded,
            "selected_count": len(selected_items),
            "filtered_count": len(filtered_items),
            "total_count": len(all_items),
            "areas": [round(value, 4) for value in all_areas],
        },
        "metrics": metrics,
    }
