from __future__ import annotations

from typing import Any

import cv2
import numpy as np

from backend.algorithms.helpers import ensure_bgr, to_float, to_int
from backend.algorithms.image.common import gray_input
from backend.algorithms.image.mask import mask_to_binary
from backend.algorithms.types import ExecutionContext, OperatorInputs, OperatorParams, OperatorResult


def _upper(value: Any, default: str) -> str:
    text = str(value if value is not None else default).strip().upper()
    return text or default


def _yes(value: Any, default: bool = False) -> bool:
    if value is None:
        return default
    return str(value).strip().upper() in {"1", "TRUE", "YES", "Y", "是", "ON"}


def _round_point(point: tuple[float, float] | list[float] | np.ndarray, digits: int = 3) -> list[float]:
    return [round(float(point[0]), digits), round(float(point[1]), digits)]


def _round_point_int(point: tuple[float, float] | list[float] | np.ndarray) -> list[int]:
    """返回与诊断图绘制完全一致的像素坐标。

    MaskMinAreaRect 的诊断图最终使用 int(round(x/y)) 绘制角点。早期版本
    独立输出端口返回的是浮点坐标，用户在后续测量/查看时容易认为
    “图上标注位置”和“端口输出位置”不一致。因此普通点端口统一输出
    像素整数坐标；rect.raw_points 中仍保留浮点坐标供高精度场景使用。
    """
    return [int(round(float(point[0]))), int(round(float(point[1])))]


def _order_box_points(points: np.ndarray) -> np.ndarray:
    """把四点按 TL, TR, BR, BL 排序。

    这里的 TL/TR/BR/BL 是屏幕/图像坐标语义：x 向右、y 向下。普通连线
    或下游几何测量往往需要的是“视觉上的左上/右上/右下/左下”，而不是
    OpenCV boxPoints 的原始顺序。

    旧版使用 sum/diff 规则，遇到部分旋转角度或接近竖直的矩形时，可能在
    端口值中把角点语义交换；同时诊断图只是画出同一组点，容易造成“图像
    看起来对，但点值语义不对”。新版改为先按 y 分成上边两个点/下边两个点，
    再分别按 x 排列，语义更稳定。
    """
    pts = np.asarray(points, dtype=np.float32).reshape(4, 2)
    by_y = pts[np.lexsort((pts[:, 0], pts[:, 1]))]
    top = by_y[:2]
    bottom = by_y[2:]
    top = top[np.argsort(top[:, 0])]
    bottom = bottom[np.argsort(bottom[:, 0])]
    tl, tr = top[0], top[1]
    bl, br = bottom[0], bottom[1]
    return np.array([tl, tr, br, bl], dtype=np.float32)


def _points_to_rect_dict(points: np.ndarray, angle: float | None = None) -> dict[str, Any]:
    ordered = _order_box_points(points)
    tl, tr, br, bl = ordered
    top_len = float(np.linalg.norm(tr - tl))
    bottom_len = float(np.linalg.norm(br - bl))
    left_len = float(np.linalg.norm(bl - tl))
    right_len = float(np.linalg.norm(br - tr))
    width = float((top_len + bottom_len) / 2.0)
    height = float((left_len + right_len) / 2.0)
    center = ordered.mean(axis=0)
    visual_angle = float(np.degrees(np.arctan2((tr - tl)[1], (tr - tl)[0])))
    opencv_angle = float(angle) if angle is not None else visual_angle

    raw_points = [_round_point(point) for point in ordered]
    # 端口输出使用与图上标注一致的整数像素点。
    points_list = [_round_point_int(point) for point in ordered]
    center_point = _round_point(center)
    center_pixel = _round_point_int(center)
    lines = {
        "top": [points_list[0], points_list[1]],
        "right": [points_list[1], points_list[2]],
        "bottom": [points_list[3], points_list[2]],
        "left": [points_list[0], points_list[3]],
    }
    raw_lines = {
        "top": [raw_points[0], raw_points[1]],
        "right": [raw_points[1], raw_points[2]],
        "bottom": [raw_points[3], raw_points[2]],
        "left": [raw_points[0], raw_points[3]],
    }
    return {
        "center": center_point,
        "center_pixel": center_pixel,
        "size": [round(width, 3), round(height, 3)],
        "width": round(width, 3),
        "height": round(height, 3),
        "angle": round(visual_angle, 6),
        "opencv_angle": round(opencv_angle, 6),
        "points": points_list,
        "raw_points": raw_points,
        "top_left": points_list[0],
        "top_right": points_list[1],
        "bottom_right": points_list[2],
        "bottom_left": points_list[3],
        "raw_top_left": raw_points[0],
        "raw_top_right": raw_points[1],
        "raw_bottom_right": raw_points[2],
        "raw_bottom_left": raw_points[3],
        "lines": lines,
        "raw_lines": raw_lines,
    }


def _rect_points_from_params(params: OperatorParams) -> np.ndarray:
    cx = to_float(params.get("center_x", 0), 0.0)
    cy = to_float(params.get("center_y", 0), 0.0)
    width = max(0.0, to_float(params.get("width", 0), 0.0))
    height = max(0.0, to_float(params.get("height", 0), 0.0))
    angle = to_float(params.get("angle", 0), 0.0)
    if width <= 0 or height <= 0:
        raise ValueError("未连接 rect 输入时，需要填写 width 和 height 参数")
    return cv2.boxPoints(((cx, cy), (width, height), angle)).astype(np.float32)


def _parse_rect(value: Any, params: OperatorParams | None = None) -> dict[str, Any]:
    params = params or {}
    if isinstance(value, dict):
        if "rect" in value and isinstance(value["rect"], dict):
            return _parse_rect(value["rect"], params)
        if "points" in value:
            points = np.asarray(value["points"], dtype=np.float32).reshape(-1, 2)
            if len(points) >= 4:
                return _points_to_rect_dict(points[:4], value.get("angle"))
        if {"center", "size", "angle"}.issubset(value):
            center = value.get("center") or [0, 0]
            size = value.get("size") or [0, 0]
            rect = ((float(center[0]), float(center[1])), (float(size[0]), float(size[1])), float(value.get("angle", 0.0)))
            return _points_to_rect_dict(cv2.boxPoints(rect), float(value.get("angle", 0.0)))
        if {"center_x", "center_y", "width", "height", "angle"}.issubset(value):
            rect = ((float(value["center_x"]), float(value["center_y"])), (float(value["width"]), float(value["height"])), float(value["angle"]))
            return _points_to_rect_dict(cv2.boxPoints(rect), float(value["angle"]))
    if isinstance(value, (list, tuple, np.ndarray)):
        arr = np.asarray(value, dtype=np.float32)
        if arr.size >= 8:
            return _points_to_rect_dict(arr.reshape(-1, 2)[:4])
    return _points_to_rect_dict(_rect_points_from_params(params), to_float(params.get("angle", 0), 0.0))


def _line_from_points(p1: list[float], p2: list[float]) -> dict[str, Any]:
    x1, y1 = float(p1[0]), float(p1[1])
    x2, y2 = float(p2[0]), float(p2[1])
    dx, dy = x2 - x1, y2 - y1
    length = float(np.hypot(dx, dy))
    # 一般式 ax + by + c = 0
    a = y1 - y2
    b = x2 - x1
    c = x1 * y2 - x2 * y1
    return {
        "p1": [round(x1, 3), round(y1, 3)],
        "p2": [round(x2, 3), round(y2, 3)],
        "length": round(length, 6),
        "abc": [round(float(a), 9), round(float(b), 9), round(float(c), 9)],
    }


def _parse_point(value: Any, params: OperatorParams | None = None) -> list[float]:
    params = params or {}
    if isinstance(value, dict):
        for key in ("point", "center", "top_left", "top_right", "bottom_left", "bottom_right"):
            if key in value:
                return _parse_point(value[key], params)
        if {"x", "y"}.issubset(value):
            return [float(value["x"]), float(value["y"])]
    if isinstance(value, (list, tuple, np.ndarray)):
        arr = np.asarray(value, dtype=np.float64).reshape(-1)
        if arr.size >= 2:
            return [float(arr[0]), float(arr[1])]
    return [to_float(params.get("point_x", 0), 0.0), to_float(params.get("point_y", 0), 0.0)]


def _parse_line(value: Any, params: OperatorParams | None = None) -> dict[str, Any]:
    params = params or {}
    if isinstance(value, dict):
        if "line" in value:
            return _parse_line(value["line"], params)
        if "p1" in value and "p2" in value:
            return _line_from_points(_parse_point(value["p1"]), _parse_point(value["p2"]))
        if "abc" in value:
            abc = np.asarray(value["abc"], dtype=np.float64).reshape(-1)
            if abc.size >= 3:
                return {"abc": [float(abc[0]), float(abc[1]), float(abc[2])], "p1": value.get("p1"), "p2": value.get("p2")}
        if {"vx", "vy", "x0", "y0"}.issubset(value):
            vx, vy, x0, y0 = float(value["vx"]), float(value["vy"]), float(value["x0"]), float(value["y0"])
            a, b, c = -vy, vx, vy * x0 - vx * y0
            return {"abc": [a, b, c], "p1": value.get("p1"), "p2": value.get("p2"), "vx": vx, "vy": vy, "x0": x0, "y0": y0}
    if isinstance(value, (list, tuple, np.ndarray)):
        arr = np.asarray(value, dtype=np.float64)
        if arr.size >= 4:
            flat = arr.reshape(-1)
            return _line_from_points([flat[0], flat[1]], [flat[2], flat[3]])
        if arr.size == 3:
            flat = arr.reshape(-1)
            return {"abc": [float(flat[0]), float(flat[1]), float(flat[2])]}
    p1 = [to_float(params.get("x1", 0), 0.0), to_float(params.get("y1", 0), 0.0)]
    p2 = [to_float(params.get("x2", 100), 100.0), to_float(params.get("y2", 0), 0.0)]
    return _line_from_points(p1, p2)


def _normalize_point_order(point: list[float], params: OperatorParams | None = None) -> tuple[list[float], str]:
    """返回点的 x/y 坐标。

    平台几何节点的标准点格式是 [x, y]。少数来自 numpy 坐标的自定义
    代码可能输出 [row, col] / [y, x]，因此 PointLineDistance 提供
    point_order 参数用于显式切换，避免用户误以为上游端口被取错。
    """
    order = _upper((params or {}).get("point_order", "XY"), "XY")
    if order in {"YX", "ROW_COL", "RC"}:
        return [float(point[1]), float(point[0])], "YX"
    return [float(point[0]), float(point[1])], "XY"


def _extract_image_shape_from_data(value: Any) -> list[int] | None:
    if not isinstance(value, dict):
        return None
    candidates = [
        value.get("image_shape"),
        value.get("source_shape"),
        value.get("input_shape"),
    ]
    rect = value.get("rect")
    if isinstance(rect, dict):
        candidates.extend([rect.get("image_shape"), rect.get("source_shape")])
    line = value.get("line")
    if isinstance(line, dict):
        candidates.extend([line.get("image_shape"), line.get("source_shape")])
    for candidate in candidates:
        if isinstance(candidate, (list, tuple)) and len(candidate) >= 2:
            try:
                return [int(candidate[0]), int(candidate[1])]
            except Exception:
                continue
    return None


def _canvas_shape_from_inputs(inputs: OperatorInputs, x_values: list[float], y_values: list[float]) -> tuple[int, int, str]:
    for key in ("image", "img"):
        image = inputs.get(key)
        if isinstance(image, np.ndarray) and image.ndim >= 2:
            h, w = image.shape[:2]
            return int(h), int(w), f"{key}输入图"
    for key in ("point_data", "line_data", "data"):
        shape = _extract_image_shape_from_data(inputs.get(key))
        if shape:
            return int(shape[0]), int(shape[1]), key
    w = max(200, int(max(x_values + [100.0]) + 60))
    h = max(160, int(max(y_values + [80.0]) + 60))
    return h, w, "自动画布"


def _line_endpoints_from_abc(a: float, b: float, c: float, width: int, height: int) -> tuple[list[int], list[int]]:
    candidates: list[tuple[float, float]] = []
    if abs(b) > 1e-12:
        candidates.append((0.0, -c / b))
        candidates.append((float(width - 1), -(a * (width - 1) + c) / b))
    if abs(a) > 1e-12:
        candidates.append((-c / a, 0.0))
        candidates.append((-(b * (height - 1) + c) / a, float(height - 1)))
    in_bounds = [(x, y) for x, y in candidates if -1 <= x <= width and -1 <= y <= height]
    if len(in_bounds) >= 2:
        p1, p2 = in_bounds[0], in_bounds[1]
    elif len(candidates) >= 2:
        p1, p2 = candidates[0], candidates[1]
    else:
        p1, p2 = (0.0, 0.0), (float(width - 1), 0.0)
    return [int(round(np.clip(p1[0], 0, width - 1))), int(round(np.clip(p1[1], 0, height - 1)))], [int(round(np.clip(p2[0], 0, width - 1))), int(round(np.clip(p2[1], 0, height - 1)))]


def op_mask_min_area_rect(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    """获取 mask 区域的带角度最小外接矩形。"""
    mask_image = inputs["in"]
    threshold = to_int(params.get("threshold", 1), 1)
    invert = _yes(params.get("invert_mask", "NO"), False)
    select_mode = _upper(params.get("select_mode", "UNION"), "UNION")
    binary = mask_to_binary(mask_image, threshold, invert=invert, color_space=inputs.get("in_color_space", "BGR"))
    contours, _ = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        canvas = ensure_bgr(mask_image).copy()
        return {
            "out": canvas,
            "out_color_space": "BGR",
            "rect": {},
            "points": [],
            "top_left": [],
            "top_right": [],
            "bottom_left": [],
            "bottom_right": [],
            "lines": {},
            "angle": 0.0,
            "center": [],
            "size": [],
            "data": {"found": False},
            "metrics": {"found": False, "area": 0.0},
        }

    if select_mode == "LARGEST":
        points = max(contours, key=cv2.contourArea).reshape(-1, 2).astype(np.float32)
    else:
        points = np.vstack(contours).reshape(-1, 2).astype(np.float32)
    rect_tuple = cv2.minAreaRect(points)
    box = cv2.boxPoints(rect_tuple)
    rect = _points_to_rect_dict(box, float(rect_tuple[2]))
    image_shape = [int(binary.shape[0]), int(binary.shape[1])]
    rect["image_shape"] = image_shape
    rect["coordinate_order"] = "XY"
    area = float(rect_tuple[1][0] * rect_tuple[1][1])

    canvas = ensure_bgr(mask_image).copy()
    cv2.polylines(canvas, [np.int32(np.asarray(rect["points"]).reshape(-1, 1, 2))], True, (0, 255, 0), 2, cv2.LINE_AA)
    for label, point in (("TL", rect["top_left"]), ("TR", rect["top_right"]), ("BR", rect["bottom_right"]), ("BL", rect["bottom_left"])):
        cv2.circle(canvas, (int(round(point[0])), int(round(point[1]))), 4, (0, 0, 255), -1, cv2.LINE_AA)
        cv2.putText(canvas, label, (int(point[0]) + 4, int(point[1]) - 4), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0, 220, 255), 1, cv2.LINE_AA)

    point_outputs = {
        "points": rect["points"],
        "top_left": rect["top_left"],
        "top_right": rect["top_right"],
        "bottom_left": rect["bottom_left"],
        "bottom_right": rect["bottom_right"],
        "lines": rect["lines"],
        "angle": rect["angle"],
        "center": rect["center"],
        "size": rect["size"],
    }
    return {
        "out": canvas,
        "out_color_space": "BGR",
        "rect": rect,
        **point_outputs,
        "data": {"found": True, "rect": rect, "image_shape": image_shape, "coordinate_order": "XY", **point_outputs},
        "metrics": {
            "found": True,
            "area": round(area, 4),
            "top_left_x": rect["top_left"][0],
            "top_left_y": rect["top_left"][1],
            "top_right_x": rect["top_right"][0],
            "top_right_y": rect["top_right"][1],
            "bottom_left_x": rect["bottom_left"][0],
            "bottom_left_y": rect["bottom_left"][1],
            "bottom_right_x": rect["bottom_right"][0],
            "bottom_right_y": rect["bottom_right"][1],
            "center_x": rect["center"][0],
            "center_y": rect["center"][1],
            "width": rect["width"],
            "height": rect["height"],
            "angle": rect["angle"],
            "opencv_angle": rect.get("opencv_angle", rect["angle"]),
        },
    }


def op_rotated_rect_feature(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    """从带角度矩形中取指定角点或边线。"""
    rect_value = inputs.get("rect")
    if rect_value is None:
        rect_value = inputs.get("in")
    if rect_value is None:
        rect_value = inputs.get("value")
    rect = _parse_rect(rect_value, params)
    feature_type = _upper(params.get("feature_type", "POINT"), "POINT")
    point_name = _upper(params.get("point", "TOP_LEFT"), "TOP_LEFT")
    line_name = _upper(params.get("line", "TOP"), "TOP")

    point_map = {
        "TOP_LEFT": rect["top_left"],
        "TOP_RIGHT": rect["top_right"],
        "BOTTOM_LEFT": rect["bottom_left"],
        "BOTTOM_RIGHT": rect["bottom_right"],
        "LEFT_TOP": rect["top_left"],
        "RIGHT_TOP": rect["top_right"],
        "LEFT_BOTTOM": rect["bottom_left"],
        "RIGHT_BOTTOM": rect["bottom_right"],
    }
    line_map = {
        "TOP": rect["lines"]["top"],
        "RIGHT": rect["lines"]["right"],
        "BOTTOM": rect["lines"]["bottom"],
        "LEFT": rect["lines"]["left"],
    }
    selected_point = point_map.get(point_name, rect["top_left"])
    selected_line_points = line_map.get(line_name, rect["lines"]["top"])
    selected_line = _line_from_points(selected_line_points[0], selected_line_points[1])
    selected = selected_point if feature_type == "POINT" else selected_line

    image = inputs.get("image")
    if image is None:
        image = inputs.get("img")
    if isinstance(image, np.ndarray):
        canvas = ensure_bgr(image).copy()
    else:
        pts = np.asarray(rect["points"], dtype=np.float32)
        max_x = max(200, int(np.ceil(np.max(pts[:, 0]) + 40)))
        max_y = max(160, int(np.ceil(np.max(pts[:, 1]) + 40)))
        canvas = np.zeros((max_y, max_x, 3), dtype=np.uint8)
    cv2.polylines(canvas, [np.int32(np.asarray(rect["points"]).reshape(-1, 1, 2))], True, (80, 180, 255), 1, cv2.LINE_AA)
    if feature_type == "POINT":
        cv2.circle(canvas, (int(round(selected_point[0])), int(round(selected_point[1]))), 5, (0, 0, 255), -1, cv2.LINE_AA)
    else:
        p1, p2 = selected_line["p1"], selected_line["p2"]
        cv2.line(canvas, (int(round(p1[0])), int(round(p1[1]))), (int(round(p2[0])), int(round(p2[1]))), (0, 255, 0), 2, cv2.LINE_AA)

    return {
        "out": canvas,
        "out_color_space": "BGR",
        "selected": selected,
        "point": selected_point,
        "line": selected_line,
        "points": rect["points"],
        "lines": {name: _line_from_points(line[0], line[1]) for name, line in rect["lines"].items()},
        "rect": rect,
        "data": {"selected": selected, "point": selected_point, "line": selected_line, "rect": rect, "image_shape": rect.get("image_shape"), "coordinate_order": "XY"},
        "metrics": {"feature_type": feature_type, "point": point_name, "line": line_name},
    }


def op_fit_line_from_edges(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    """对 Canny 等边缘图中的非零点拟合直线。"""
    edge_image = inputs["in"]
    gray = gray_input({"in": edge_image, "in_color_space": inputs.get("in_color_space", "GRAY")})
    threshold = to_int(params.get("threshold", 1), 1)
    max_points = max(0, to_int(params.get("max_points", 5000), 5000))
    min_points = max(2, to_int(params.get("min_points", 20), 20))
    draw_points = _yes(params.get("draw_points", "NO"), False)
    binary = cv2.threshold(gray.astype(np.uint8), threshold, 255, cv2.THRESH_BINARY)[1]
    ys, xs = np.nonzero(binary)
    if len(xs) < min_points:
        canvas = ensure_bgr(edge_image).copy()
        return {"out": canvas, "out_color_space": "BGR", "line": {}, "distance_model": {}, "data": {"found": False}, "metrics": {"found": False, "point_count": int(len(xs))}}
    points = np.column_stack([xs, ys]).astype(np.float32)
    if max_points and len(points) > max_points:
        step = max(1, int(np.ceil(len(points) / float(max_points))))
        points = points[::step][:max_points]
    dist_mode_name = _upper(params.get("distance_type", "L2"), "L2")
    dist_type = {"L1": cv2.DIST_L1, "L2": cv2.DIST_L2, "L12": cv2.DIST_L12, "FAIR": cv2.DIST_FAIR, "WELSCH": cv2.DIST_WELSCH, "HUBER": cv2.DIST_HUBER}.get(dist_mode_name, cv2.DIST_L2)
    vx, vy, x0, y0 = [float(v) for v in cv2.fitLine(points, dist_type, 0, 0.01, 0.01).reshape(-1)]
    a, b, c = -vy, vx, vy * x0 - vx * y0
    h, w = gray.shape[:2]
    p1, p2 = _line_endpoints_from_abc(a, b, c, w, h)
    image_shape = [int(h), int(w)]
    line = {
        "p1": p1,
        "p2": p2,
        "abc": [round(a, 9), round(b, 9), round(c, 9)],
        "image_shape": image_shape,
        "coordinate_order": "XY",
        "vx": round(vx, 9),
        "vy": round(vy, 9),
        "x0": round(x0, 6),
        "y0": round(y0, 6),
        "angle": round(float(np.degrees(np.arctan2(vy, vx))), 6),
    }
    canvas = ensure_bgr(edge_image).copy()
    if draw_points:
        canvas[binary > 0] = (80, 80, 80)
    cv2.line(canvas, tuple(p1), tuple(p2), (0, 255, 0), 2, cv2.LINE_AA)
    cv2.circle(canvas, (int(round(x0)), int(round(y0))), 4, (0, 0, 255), -1, cv2.LINE_AA)
    return {
        "out": canvas,
        "out_color_space": "BGR",
        "line": line,
        "p1": p1,
        "p2": p2,
        "abc": line["abc"],
        "angle": line["angle"],
        "data": {"found": True, "line": line, "point_count": int(len(points)), "image_shape": image_shape, "coordinate_order": "XY"},
        "metrics": {"found": True, "point_count": int(len(points)), "angle": line["angle"], "vx": line["vx"], "vy": line["vy"]},
    }


def op_point_line_distance(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    """计算点到直线的垂直距离。

    坐标约定：平台内置几何节点统一使用图像坐标 [x, y]。
    当 point_order=YX 时，才会把输入点按 [y, x] 交换为 [x, y]。
    """
    point_value = inputs.get("point")
    if point_value is None:
        point_value = inputs.get("p")
    if point_value is None:
        point_value = inputs.get("in")
    line_value = inputs.get("line")
    if line_value is None:
        line_value = inputs.get("l")
    if line_value is None:
        line_value = inputs.get("value")

    raw_point = _parse_point(point_value, params)
    point, point_order = _normalize_point_order(raw_point, params)
    line = _parse_line(line_value, params)
    a, b, c = [float(v) for v in line.get("abc", [0.0, 1.0, 0.0])]
    denom = float(np.hypot(a, b))
    if denom <= 1e-12:
        raise ValueError("直线参数无效：a 和 b 不能同时为 0")
    x0, y0 = float(point[0]), float(point[1])
    signed_distance = (a * x0 + b * y0 + c) / denom
    distance = abs(signed_distance)
    foot_x = x0 - a * (a * x0 + b * y0 + c) / (denom * denom)
    foot_y = y0 - b * (a * x0 + b * y0 + c) / (denom * denom)
    foot = [round(float(foot_x), 6), round(float(foot_y), 6)]

    image = inputs.get("image")
    if image is None:
        image = inputs.get("img")
    if isinstance(image, np.ndarray):
        canvas = ensure_bgr(image).copy()
        h, w = canvas.shape[:2]
        canvas_source = "image输入图"
    else:
        h, w, canvas_source = _canvas_shape_from_inputs(inputs, [x0, foot_x], [y0, foot_y])
        canvas = np.zeros((h, w, 3), dtype=np.uint8)

    lp1, lp2 = line.get("p1"), line.get("p2")
    if not lp1 or not lp2:
        lp1, lp2 = _line_endpoints_from_abc(a, b, c, w, h)
    cv2.line(canvas, (int(round(lp1[0])), int(round(lp1[1]))), (int(round(lp2[0])), int(round(lp2[1]))), (0, 255, 0), 2, cv2.LINE_AA)
    cv2.circle(canvas, (int(round(x0)), int(round(y0))), 5, (0, 0, 255), -1, cv2.LINE_AA)
    cv2.circle(canvas, (int(round(foot_x)), int(round(foot_y))), 4, (255, 180, 0), -1, cv2.LINE_AA)
    cv2.line(canvas, (int(round(x0)), int(round(y0))), (int(round(foot_x)), int(round(foot_y))), (0, 180, 255), 1, cv2.LINE_AA)
    cv2.putText(canvas, f"P=({x0:.1f},{y0:.1f})", (12, 24), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 220, 255), 1, cv2.LINE_AA)
    cv2.putText(canvas, f"d={distance:.3f}", (12, 48), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 220, 255), 1, cv2.LINE_AA)

    point_shape = _extract_image_shape_from_data(inputs.get("point_data"))
    line_shape = _extract_image_shape_from_data(inputs.get("line_data"))
    warnings: list[str] = []
    if point_shape and line_shape and point_shape != line_shape:
        warnings.append(f"point来源图尺寸{point_shape}与line来源图尺寸{line_shape}不同，可能存在全图坐标/ROI局部坐标混用。")
    if point_order == "YX":
        warnings.append("已按 point_order=YX 将输入点从 [y,x] 转换为 [x,y]。")

    resolved_point = [round(x0, 6), round(y0, 6)]
    resolved_line = {**line, "p1": lp1, "p2": lp2}
    data = {
        "distance": round(float(distance), 9),
        "signed_distance": round(float(signed_distance), 9),
        "foot_point": foot,
        "point": resolved_point,
        "raw_point": [round(float(raw_point[0]), 6), round(float(raw_point[1]), 6)],
        "point_order": point_order,
        "line": resolved_line,
        "canvas_source": canvas_source,
        "canvas_shape": [int(h), int(w)],
        "point_source_shape": point_shape,
        "line_source_shape": line_shape,
        "warnings": warnings,
    }

    return {
        "out": canvas,
        "out_color_space": "BGR",
        "distance": round(float(distance), 9),
        "signed_distance": round(float(signed_distance), 9),
        "foot_point": foot,
        "point": resolved_point,
        "line": resolved_line,
        "value": round(float(distance), 9),
        "data": data,
        "metrics": {
            "distance": round(float(distance), 6),
            "signed_distance": round(float(signed_distance), 6),
            "point_x": round(x0, 6),
            "point_y": round(y0, 6),
            "raw_point_x": round(float(raw_point[0]), 6),
            "raw_point_y": round(float(raw_point[1]), 6),
            "foot_x": foot[0],
            "foot_y": foot[1],
            "point_order": point_order,
            "canvas_source": canvas_source,
            "warning": "; ".join(warnings),
        },
    }

