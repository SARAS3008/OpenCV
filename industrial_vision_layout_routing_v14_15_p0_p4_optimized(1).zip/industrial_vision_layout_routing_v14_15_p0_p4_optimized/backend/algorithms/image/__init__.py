from __future__ import annotations

from backend.algorithms.image.common import bgr_input, gray_input
from backend.algorithms.image.io import op_batch_read_images, op_display, op_read_image, op_save_batch_results
from backend.algorithms.image.color import (
    op_bgr_to_rgb,
    op_clahe,
    op_color_convert,
    op_equalize_hist,
    op_gray,
    op_invert,
    op_normalize,
)
from backend.algorithms.image.filters import (
    op_bilateral_filter,
    op_gaussian_blur,
    op_mean_blur,
    op_median_blur,
    op_sharpen,
)
from backend.algorithms.image.thresholding import op_adaptive_threshold, op_otsu_threshold, op_threshold
from backend.algorithms.image.edges import op_canny, op_laplacian, op_sobel
from backend.algorithms.image.morphology import (
    op_dilate,
    op_erode,
    op_morph_close,
    op_morph_gradient,
    op_morph_open,
)
from backend.algorithms.image.geometry import op_flip, op_resize, op_rotate90
from backend.algorithms.image.contours import op_filter_contours, op_find_contours
from backend.algorithms.image.mask import op_apply_mask
from backend.algorithms.image.measurement import (
    op_fit_line_from_edges,
    op_mask_min_area_rect,
    op_point_line_distance,
    op_rotated_rect_feature,
)
from backend.algorithms.image.template_matching import op_orb_feature_match

__all__ = [
    "gray_input",
    "bgr_input",
    "op_read_image",
    "op_batch_read_images",
    "op_save_batch_results",
    "op_display",
    "op_color_convert",
    "op_gray",
    "op_bgr_to_rgb",
    "op_invert",
    "op_normalize",
    "op_equalize_hist",
    "op_clahe",
    "op_mean_blur",
    "op_gaussian_blur",
    "op_median_blur",
    "op_bilateral_filter",
    "op_sharpen",
    "op_threshold",
    "op_otsu_threshold",
    "op_adaptive_threshold",
    "op_canny",
    "op_sobel",
    "op_laplacian",
    "op_erode",
    "op_dilate",
    "op_morph_open",
    "op_morph_close",
    "op_morph_gradient",
    "op_resize",
    "op_flip",
    "op_rotate90",
    "op_find_contours",
    "op_filter_contours",
    "op_mask_min_area_rect",
    "op_rotated_rect_feature",
    "op_apply_mask",
    "op_fit_line_from_edges",
    "op_point_line_distance",
    "op_orb_feature_match",
]
