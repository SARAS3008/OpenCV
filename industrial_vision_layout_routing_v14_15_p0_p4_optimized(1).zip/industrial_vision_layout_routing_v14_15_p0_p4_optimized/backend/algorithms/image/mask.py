from __future__ import annotations

from typing import Any

import cv2
import numpy as np

from backend.algorithms.helpers import ensure_bgr, to_int
from backend.algorithms.image.common import gray_input
from backend.algorithms.types import ExecutionContext, OperatorInputs, OperatorParams, OperatorResult


def _yes(value: Any, default: bool = False) -> bool:
    if value is None:
        return default
    return str(value).strip().upper() in {"1", "TRUE", "YES", "Y", "是", "ON"}


def _upper(value: Any, default: str) -> str:
    text = str(value if value is not None else default).strip().upper()
    return text or default


def mask_to_binary(mask_image: np.ndarray, threshold: int = 1, *, invert: bool = False, color_space: str = "BGR") -> np.ndarray:
    """把任意灰度/彩色 mask 转为 0/255 二值 mask。"""
    gray = gray_input({"in": mask_image, "in_color_space": color_space})
    threshold = int(np.clip(threshold, 0, 255))
    binary = cv2.threshold(gray.astype(np.uint8), threshold, 255, cv2.THRESH_BINARY)[1]
    if invert:
        binary = cv2.bitwise_not(binary)
    return binary


def selected_mask_bbox(binary_mask: np.ndarray, *, mode: str = "UNION") -> list[int]:
    """返回 mask 前景区域外接框 [x, y, w, h]。"""
    contours, _ = cv2.findContours(binary_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return [0, 0, 0, 0]
    mode = _upper(mode, "UNION")
    if mode == "LARGEST":
        x, y, w, h = cv2.boundingRect(max(contours, key=cv2.contourArea))
        return [int(x), int(y), int(w), int(h)]
    x, y, w, h = cv2.boundingRect(np.vstack(contours))
    return [int(x), int(y), int(w), int(h)]


def op_apply_mask(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    """原图与 mask 相交抠图。

    输入：
    - in：原图
    - mask：二值/灰度/彩色 mask

    输出：
    - out：根据 output_mode 输出 masked / roi / roi_mask / mask
    - masked：全图抠图
    - roi：外接框裁剪后的抠图 ROI
    - roi_mask：局部 mask
    - mask：全图二值 mask
    - bbox：外接框 [x, y, w, h]
    """

    image = inputs["in"]
    mask_image = inputs["mask"]
    image_bgr = ensure_bgr(image)
    threshold = to_int(params.get("threshold", 1), 1)
    invert_mask = _yes(params.get("invert_mask", "NO"), False)
    output_mode = _upper(params.get("output_mode", "MASKED"), "MASKED")
    bbox_mode = _upper(params.get("bbox_mode", "UNION"), "UNION")
    background = _upper(params.get("background", "BLACK"), "BLACK")

    binary = mask_to_binary(mask_image, threshold, invert=invert_mask, color_space=inputs.get("mask_color_space", "BGR"))
    if binary.shape[:2] != image_bgr.shape[:2]:
        resize_mode = _upper(params.get("resize_mask", "NO"), "NO")
        if resize_mode in {"YES", "TRUE", "1", "ON", "是"}:
            binary = cv2.resize(binary, (image_bgr.shape[1], image_bgr.shape[0]), interpolation=cv2.INTER_NEAREST)
        else:
            raise ValueError(f"mask 尺寸 {binary.shape[:2]} 与原图尺寸 {image_bgr.shape[:2]} 不一致；可开启 resize_mask")

    if background == "WHITE":
        masked = np.full_like(image_bgr, 255)
        masked[binary > 0] = image_bgr[binary > 0]
    else:
        masked = cv2.bitwise_and(image_bgr, image_bgr, mask=binary)

    bbox = selected_mask_bbox(binary, mode=bbox_mode)
    x, y, w, h = bbox
    if w > 0 and h > 0:
        roi = masked[y : y + h, x : x + w].copy()
        roi_mask = binary[y : y + h, x : x + w].copy()
    else:
        roi = np.zeros((0, 0, 3), dtype=np.uint8)
        roi_mask = np.zeros((0, 0), dtype=np.uint8)

    if output_mode == "ROI":
        out = roi
        out_color = "BGR"
    elif output_mode == "ROI_MASK":
        out = roi_mask
        out_color = "GRAY"
    elif output_mode == "MASK":
        out = binary
        out_color = "GRAY"
    else:
        out = masked
        out_color = "BGR"

    mask_pixels = int(np.count_nonzero(binary))
    total_pixels = int(binary.size)
    return {
        "out": out,
        "out_color_space": out_color,
        "masked": masked,
        "masked_color_space": "BGR",
        "mask": binary,
        "mask_color_space": "GRAY",
        "roi": roi,
        "roi_color_space": "BGR",
        "roi_mask": roi_mask,
        "roi_mask_color_space": "GRAY",
        "bbox": bbox,
        "data": {"bbox": bbox, "mask_pixels": mask_pixels, "mask_ratio": mask_pixels / float(total_pixels or 1)},
        "metrics": {
            "mask_pixels": mask_pixels,
            "mask_ratio": round(mask_pixels / float(total_pixels or 1), 6),
            "bbox_x": bbox[0],
            "bbox_y": bbox[1],
            "bbox_w": bbox[2],
            "bbox_h": bbox[3],
        },
    }
