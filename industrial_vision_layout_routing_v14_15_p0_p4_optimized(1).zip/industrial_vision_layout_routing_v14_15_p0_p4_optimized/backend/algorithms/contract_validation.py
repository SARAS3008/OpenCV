from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping


@dataclass
class OperatorContractReport:
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    operator_count: int = 0

    @property
    def valid(self) -> bool:
        return not self.errors

    def as_dict(self) -> dict[str, Any]:
        return {
            "valid": self.valid,
            "operator_count": self.operator_count,
            "errors": list(self.errors),
            "warnings": list(self.warnings),
        }

    def raise_for_errors(self) -> None:
        if self.errors:
            raise RuntimeError("算子契约校验失败：" + "；".join(self.errors))


def _handles(value: Any, *, operator_type: str, field_name: str, report: OperatorContractReport) -> set[str]:
    if value is None:
        return set()
    if not isinstance(value, list):
        report.errors.append(f"{operator_type}.{field_name} 必须是列表")
        return set()
    handles: list[str] = []
    for index, item in enumerate(value):
        if not isinstance(item, Mapping):
            report.errors.append(f"{operator_type}.{field_name}[{index}] 必须是对象")
            continue
        handle = str(item.get("handle") or "").strip()
        if not handle:
            report.errors.append(f"{operator_type}.{field_name}[{index}] 缺少 handle")
            continue
        handles.append(handle)
    duplicates = sorted({handle for handle in handles if handles.count(handle) > 1})
    if duplicates:
        report.errors.append(f"{operator_type}.{field_name} handle 重复：{', '.join(duplicates)}")
    return set(handles)


def validate_operator_contracts(
    operators: Mapping[str, Any],
    metadata: Mapping[str, Mapping[str, Any]],
) -> OperatorContractReport:
    """Validate executable operators and UI metadata as one deploy-time contract."""

    report = OperatorContractReport(operator_count=len(operators))
    missing_metadata = sorted(set(operators) - set(metadata))
    missing_implementations = sorted(set(metadata) - set(operators))
    if missing_metadata:
        report.errors.append("缺少算子元数据：" + ", ".join(missing_metadata))
    if missing_implementations:
        report.errors.append("缺少算子实现：" + ", ".join(missing_implementations))

    for operator_type in sorted(set(operators) & set(metadata)):
        operator = operators[operator_type]
        meta = metadata[operator_type]
        if not callable(operator):
            report.errors.append(f"{operator_type} 实现不可调用")
        if not isinstance(meta, Mapping):
            report.errors.append(f"{operator_type} 元数据必须是对象")
            continue
        if not str(meta.get("label") or "").strip():
            report.warnings.append(f"{operator_type} 缺少用户可见 label")

        input_handles = _handles(meta.get("inputs"), operator_type=operator_type, field_name="inputs", report=report)
        _handles(meta.get("outputs"), operator_type=operator_type, field_name="outputs", report=report)

        params = meta.get("params") or {}
        schema = meta.get("param_schema") or {}
        if not isinstance(params, Mapping):
            report.errors.append(f"{operator_type}.params 必须是对象")
            continue
        if not isinstance(schema, Mapping):
            report.errors.append(f"{operator_type}.param_schema 必须是对象")
            continue

        for param_name, definition in schema.items():
            if not isinstance(definition, Mapping):
                report.errors.append(f"{operator_type}.param_schema.{param_name} 必须是对象")
                continue
            fallback_for = definition.get("fallback_for")
            if fallback_for and str(fallback_for) not in input_handles:
                report.errors.append(
                    f"{operator_type}.{param_name}.fallback_for 指向不存在的输入端口：{fallback_for}"
                )
            if definition.get("type") == "select":
                options = definition.get("options") or []
                if not isinstance(options, list) or not options:
                    report.errors.append(f"{operator_type}.{param_name} 的 select options 不能为空")
                    continue
                option_values = {
                    item.get("value") for item in options if isinstance(item, Mapping) and "value" in item
                }
                if param_name in params and params[param_name] not in option_values:
                    report.errors.append(
                        f"{operator_type}.{param_name} 默认值 {params[param_name]!r} 不在 select options 中"
                    )

        undeclared_defaults = sorted(set(params) - set(schema))
        if undeclared_defaults:
            report.warnings.append(
                f"{operator_type} 参数缺少表单 schema：{', '.join(undeclared_defaults)}"
            )

    return report


__all__ = ["OperatorContractReport", "validate_operator_contracts"]
