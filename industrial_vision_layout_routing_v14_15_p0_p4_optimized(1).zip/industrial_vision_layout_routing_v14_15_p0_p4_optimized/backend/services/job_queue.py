from __future__ import annotations

import threading
import time
import traceback
import uuid
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from typing import Any, Callable

from backend.infrastructure.state_backend import JsonStateBackend


def _now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


@dataclass
class JobRecord:
    job_id: str
    kind: str
    owner_id: str
    status: str = "queued"
    created_at: str = field(default_factory=_now_iso)
    started_at: str | None = None
    finished_at: str | None = None
    progress: dict[str, Any] = field(default_factory=lambda: {"current": 0, "total": 1, "message": "排队中"})
    result: dict[str, Any] | None = None
    error: str | None = None


class JobQueue:
    """进程内异步任务队列。

    用于把长耗时工作流/数据集回归任务从同步 HTTP 请求中剥离出来。
    生产部署时可以替换为 Celery/RQ/Dramatiq + Redis，不影响 API 语义。
    """

    def __init__(self, max_workers: int = 2, *, state_backend: JsonStateBackend | None = None) -> None:
        self._executor = ThreadPoolExecutor(max_workers=max(1, int(max_workers)), thread_name_prefix="vision-job")
        self._jobs: dict[str, JobRecord] = {}
        self._lock = threading.RLock()
        self._state_backend = state_backend
        self._closed = False
        self._restore_jobs()

    def _restore_jobs(self) -> None:
        if self._state_backend is None:
            return
        for item in self._state_backend.list("jobs"):
            payload = item.payload
            try:
                record = JobRecord(
                    job_id=str(payload["job_id"]),
                    kind=str(payload.get("kind") or "job"),
                    owner_id=str(payload.get("owner_id") or "default"),
                    status=str(payload.get("status") or "failed"),
                    created_at=str(payload.get("created_at") or _now_iso()),
                    started_at=payload.get("started_at"),
                    finished_at=payload.get("finished_at"),
                    progress=dict(payload.get("progress") or {}),
                    result=payload.get("result"),
                    error=payload.get("error"),
                )
            except Exception:
                continue
            if record.status in {"queued", "running"}:
                record.status = "failed"
                record.error = "服务重启导致任务中断"
                record.finished_at = _now_iso()
                record.progress = {"current": 1, "total": 1, "message": "已中断"}
            self._jobs[record.job_id] = record
            self._persist(record)

    def _persist(self, record: JobRecord) -> None:
        if self._state_backend is not None:
            self._state_backend.put("jobs", record.job_id, self._to_dict(record, include_result=True))

    def submit(self, *, owner_id: str, kind: str, fn: Callable[[Callable[[int, int, str], None]], dict[str, Any]]) -> dict[str, Any]:
        job_id = uuid.uuid4().hex
        record = JobRecord(job_id=job_id, kind=kind, owner_id=owner_id)
        with self._lock:
            if self._closed:
                raise RuntimeError("任务队列已关闭")
            self._jobs[job_id] = record
            self._persist(record)

        def progress(current: int, total: int = 1, message: str = "") -> None:
            with self._lock:
                active = self._jobs.get(job_id)
                if active:
                    active.progress = {"current": int(current), "total": max(1, int(total)), "message": message}
                    self._persist(active)

        def runner() -> None:
            with self._lock:
                record.status = "running"
                record.started_at = _now_iso()
                record.progress = {"current": 0, "total": 1, "message": "运行中"}
                self._persist(record)
            try:
                result = fn(progress)
                with self._lock:
                    record.status = "success" if result.get("success", True) else "failed"
                    record.result = result
                    record.error = result.get("error")
                    record.progress = {"current": 1, "total": 1, "message": "完成"}
                    self._persist(record)
            except Exception as exc:  # noqa: BLE001 - 任务边界需要兜底保存错误
                with self._lock:
                    record.status = "failed"
                    record.error = f"{type(exc).__name__}: {exc}"
                    record.result = {"success": False, "error": str(exc), "traceback": traceback.format_exc(limit=12)}
                    record.progress = {"current": 1, "total": 1, "message": "失败"}
                    self._persist(record)
            finally:
                with self._lock:
                    record.finished_at = _now_iso()
                    self._persist(record)

        self._executor.submit(runner)
        return self.get(job_id, owner_id=owner_id)

    def list_jobs(self, *, owner_id: str | None = None, limit: int = 50) -> list[dict[str, Any]]:
        with self._lock:
            records = sorted(self._jobs.values(), key=lambda item: item.created_at, reverse=True)
            if owner_id is not None:
                records = [item for item in records if item.owner_id == owner_id]
            return [self._to_dict(item, include_result=False) for item in records[:limit]]

    def get(self, job_id: str, *, owner_id: str | None = None) -> dict[str, Any]:
        with self._lock:
            record = self._jobs.get(job_id)
            if record is None or (owner_id is not None and record.owner_id != owner_id):
                raise ValueError("任务不存在")
            return self._to_dict(record, include_result=True)


    def stats(self) -> dict[str, Any]:
        with self._lock:
            counts: dict[str, int] = {}
            for record in self._jobs.values():
                counts[record.status] = counts.get(record.status, 0) + 1
            return {"total": len(self._jobs), "by_status": counts, "closed": self._closed}

    def shutdown(self, *, wait: bool = True, cancel_futures: bool = False) -> None:
        with self._lock:
            self._closed = True
        self._executor.shutdown(wait=wait, cancel_futures=cancel_futures)

    def _to_dict(self, record: JobRecord, *, include_result: bool) -> dict[str, Any]:
        payload = {
            "job_id": record.job_id,
            "kind": record.kind,
            "owner_id": record.owner_id,
            "status": record.status,
            "created_at": record.created_at,
            "started_at": record.started_at,
            "finished_at": record.finished_at,
            "progress": record.progress,
            "error": record.error,
        }
        if include_result:
            payload["result"] = record.result
        return payload
