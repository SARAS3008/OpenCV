from __future__ import annotations

import base64
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Mapping, MutableMapping, Sequence

import cv2
import numpy as np

from backend.algorithms.registry import OPERATORS, OPERATOR_META
from backend.algorithms.types import ExecutionContext
from backend.models.workflow import WorkflowEdge, WorkflowNode

CancelCheck = Callable[[], bool]


def estimate_value_bytes(value: Any, seen: set[int] | None = None) -> int:
    """Estimate retained memory without traversing the same object twice."""

    visited = seen if seen is not None else set()
    object_id = id(value)
    if object_id in visited:
        return 0
    visited.add(object_id)
    if isinstance(value, np.ndarray):
        return int(value.nbytes) + sys.getsizeof(value)
    if isinstance(value, dict):
        return sys.getsizeof(value) + sum(
            estimate_value_bytes(key, visited) + estimate_value_bytes(child, visited)
            for key, child in value.items()
        )
    if isinstance(value, (list, tuple, set, frozenset)):
        return sys.getsizeof(value) + sum(estimate_value_bytes(child, visited) for child in value)
    return sys.getsizeof(value)


def image_to_data_url(image: np.ndarray, color_space: str = "BGR") -> str:
    if image is None:
        return ""
    if image.dtype != np.uint8:
        image = np.clip(image, 0, 255).astype(np.uint8)
    encode_image = image
    if image.ndim == 3 and str(color_space).upper() == "RGB":
        encode_image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
    ok, buffer = cv2.imencode(".png", encode_image)
    if not ok:
        raise ValueError("图像编码失败")
    encoded = base64.b64encode(buffer.tobytes()).decode("utf-8")
    return f"data:image/png;base64,{encoded}"


def json_safe_value(value: Any, path: str = "result") -> Any:
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, np.ndarray):
        raise ValueError(
            f"{path} 包含图像/数组数据，不能作为数值结果返回；"
            "请把图像放在 out 输出端口，把统计值放在 metrics 或独立数值输出端口"
        )
    if isinstance(value, Path):
        return str(value)
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, dict):
        return {str(key): json_safe_value(child, f"{path}.{key}") for key, child in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [json_safe_value(child, f"{path}[{index}]") for index, child in enumerate(value)]
    raise ValueError(f"{path} 包含无法序列化的结果类型：{type(value).__name__}")


def merge_data(target: dict[str, Any], source: Any) -> None:
    if isinstance(source, dict):
        target.update(source)


def parameter_fallback_handles(metadata: Mapping[str, Any]) -> set[str]:
    schema = metadata.get("param_schema")
    if not isinstance(schema, dict):
        return set()
    handles: set[str] = set()
    for definition in schema.values():
        if not isinstance(definition, dict):
            continue
        raw = definition.get("fallback_for")
        if isinstance(raw, str) and raw.strip():
            handles.add(raw.strip())
        elif isinstance(raw, (list, tuple, set)):
            handles.update(str(item).strip() for item in raw if str(item).strip())
    return handles


class ExecutionCancelledError(RuntimeError):
    pass


@dataclass(slots=True)
class NodeExecutionOutcome:
    result: dict[str, Any]
    preview: dict[str, Any] | None
    own_metrics: dict[str, Any]
    result_kind: str
    input_bytes: int
    output_bytes: int


class NodeExecutor:
    """Single source of truth for executing one already-runnable workflow node.

    Scheduling (topological traversal, lazy branches, stepping) stays outside this
    class. Input assembly, port validation, operator invocation, output
    normalization and preview construction are shared by every execution mode.
    """

    def __init__(
        self,
        *,
        context: ExecutionContext,
        outputs: MutableMapping[str, dict[str, Any]],
        collect_preview: bool,
        cancel_check: CancelCheck | None = None,
        max_input_bytes: int | None = None,
        max_output_bytes: int | None = None,
        max_image_pixels: int | None = None,
        preview_max_side: int | None = None,
    ) -> None:
        self.context = context
        self.outputs = outputs
        self.collect_preview = collect_preview
        self.cancel_check = cancel_check
        self.max_input_bytes = max_input_bytes
        self.max_output_bytes = max_output_bytes
        self.max_image_pixels = max_image_pixels
        self.preview_max_side = preview_max_side

    def _check_cancelled(self) -> None:
        if self.cancel_check and self.cancel_check():
            raise ExecutionCancelledError("运行已取消")

    def _validate_images(self, value: Any, *, path: str) -> None:
        if isinstance(value, np.ndarray):
            if self.max_image_pixels and value.ndim >= 2:
                pixels = int(value.shape[0]) * int(value.shape[1])
                if pixels > self.max_image_pixels:
                    raise ValueError(
                        f"{path} 图像像素数超过限制：{pixels} > {self.max_image_pixels}；"
                        "请缩小输入图像或调整 VISION_NODE_MAX_IMAGE_PIXELS"
                    )
            return
        if isinstance(value, dict):
            for key, child in value.items():
                self._validate_images(child, path=f"{path}.{key}")
        elif isinstance(value, (list, tuple)):
            for index, child in enumerate(value):
                self._validate_images(child, path=f"{path}[{index}]")

    def _assemble_inputs(self, input_edges: Sequence[WorkflowEdge]) -> tuple[dict[str, Any], dict[str, Any]]:
        inputs: dict[str, Any] = {}
        inherited_data: dict[str, Any] = {}
        for edge in input_edges:
            source_output = self.outputs.get(edge.source)
            if source_output is None:
                raise ValueError(f"上游节点 {edge.source} 尚未执行或中间结果已释放")
            source_handle = edge.sourceHandle or "out"
            if source_handle not in source_output:
                raise ValueError(f"上游节点 {edge.source} 不存在输出端口：{source_handle}")
            target_handle = edge.targetHandle or "in"
            inputs[target_handle] = source_output[source_handle]
            source_color_key = f"{source_handle}_color_space"
            if source_color_key in source_output:
                inputs[f"{target_handle}_color_space"] = source_output[source_color_key]
            source_data = source_output.get("data")
            if isinstance(source_data, dict):
                inputs[f"{target_handle}_data"] = source_data
            merge_data(inherited_data, source_data)
        return inputs, inherited_data

    @staticmethod
    def _validate_ports(
        node: WorkflowNode,
        metadata: Mapping[str, Any],
        inputs: Mapping[str, Any],
        input_edges: Sequence[WorkflowEdge],
        selected_if_handle: str | None,
    ) -> None:
        configured_inputs = metadata.get("inputs")
        if node.type == "LogicIfElse" and selected_if_handle:
            required_handles = ["condition", selected_if_handle]
            missing = [handle for handle in required_handles if handle not in inputs]
            if missing:
                raise ValueError(f"缺少输入端口：{'、'.join(missing)}")
            return
        if isinstance(configured_inputs, list):
            fallback_handles = parameter_fallback_handles(metadata)
            required_handles = [
                str(port.get("handle", "in"))
                for port in configured_inputs
                if port.get("required", True)
                and str(port.get("handle", "in")) not in fallback_handles
            ]
            missing = [handle for handle in required_handles if handle not in inputs]
            if missing:
                raise ValueError(f"缺少输入端口：{'、'.join(missing)}")
            if not configured_inputs and input_edges:
                raise ValueError("输入节点不应存在输入连线")
            return
        if metadata.get("has_input", True) and "in" not in inputs:
            raise ValueError("缺少输入连线")
        if not metadata.get("has_input", True) and input_edges:
            raise ValueError("输入节点不应存在输入连线")

    @staticmethod
    def _result_kind(out_image: Any, metrics: Mapping[str, Any]) -> str:
        if isinstance(out_image, np.ndarray) and metrics:
            return "图像与数值"
        if isinstance(out_image, np.ndarray):
            return "图像"
        if metrics:
            return "数值"
        return "数据"

    def execute(
        self,
        node: WorkflowNode,
        input_edges: Sequence[WorkflowEdge],
        *,
        selected_if_handle: str | None = None,
    ) -> NodeExecutionOutcome:
        self._check_cancelled()
        metadata = OPERATOR_META.get(node.type, {})
        node_label = str(metadata.get("label", node.type))
        operator = OPERATORS.get(node.type)
        if operator is None:
            raise ValueError(f"未知算子或尚未实现：{node.type}")

        inputs, inherited_data = self._assemble_inputs(input_edges)
        self._validate_ports(node, metadata, inputs, input_edges, selected_if_handle)
        self._validate_images(inputs, path=f"节点 {node.id}.inputs")
        input_bytes = estimate_value_bytes(inputs)
        if self.max_input_bytes and input_bytes > self.max_input_bytes:
            raise ValueError(
                f"节点 {node.id} 输入超过内存预算：{input_bytes} > {self.max_input_bytes} 字节"
            )

        self._check_cancelled()
        raw_result = operator(inputs, node.params, self.context)
        self._check_cancelled()
        if not isinstance(raw_result, dict):
            raise ValueError("算子返回值必须是字典")
        result = dict(raw_result)

        out_image = result.get("out")
        self._validate_images(result, path=f"节点 {node.id}.outputs")
        if isinstance(out_image, np.ndarray) and "out_color_space" not in result:
            result["out_color_space"] = "GRAY" if out_image.ndim == 2 else inputs.get("in_color_space", "BGR")

        explicit_data = result.get("data")
        if explicit_data is not None:
            if not isinstance(explicit_data, dict):
                raise ValueError("data 必须是字典")
            explicit_data = json_safe_value(explicit_data, f"节点 {node.id}.data")
        merge_data(inherited_data, explicit_data)

        metrics = result.pop("metrics", None)
        own_metrics: dict[str, Any] = {}
        if metrics is not None:
            if not isinstance(metrics, dict):
                raise ValueError("metrics 必须是字典")
            own_metrics = json_safe_value(metrics, f"节点 {node.id}.metrics")
            inherited_data[f"{node.id}_{node_label}"] = own_metrics
        if inherited_data:
            result["data"] = json_safe_value(inherited_data, f"节点 {node.id}.data")

        output_bytes = estimate_value_bytes(result)
        if self.max_output_bytes and output_bytes > self.max_output_bytes:
            raise ValueError(
                f"节点 {node.id} 输出超过内存预算：{output_bytes} > {self.max_output_bytes} 字节"
            )

        preview: dict[str, Any] | None = None
        if self.collect_preview and (isinstance(out_image, np.ndarray) or own_metrics):
            configured_result_type = str(metadata.get("result_type", "")).strip().lower()
            if configured_result_type == "metrics" and own_metrics:
                result_type = "metrics"
            elif isinstance(out_image, np.ndarray):
                result_type = "image"
            else:
                result_type = "metrics"
            preview = {
                "node_id": node.id,
                "type": node.type,
                "label": node_label,
                "result_type": result_type,
                "status": "success",
                "metrics": own_metrics,
                "data": result.get("data", {}),
            }
            if result_type == "image" and isinstance(out_image, np.ndarray):
                preview_image = out_image
                if self.preview_max_side and preview_image.ndim >= 2:
                    height, width = preview_image.shape[:2]
                    longest = max(height, width)
                    if longest > self.preview_max_side:
                        scale = self.preview_max_side / float(longest)
                        preview_image = cv2.resize(
                            preview_image,
                            (max(1, round(width * scale)), max(1, round(height * scale))),
                            interpolation=cv2.INTER_AREA,
                        )
                        preview["preview_scaled"] = True
                        preview["source_shape"] = [int(height), int(width)]
                preview["image"] = image_to_data_url(preview_image, result.get("out_color_space", "BGR"))

        self.outputs[node.id] = result
        return NodeExecutionOutcome(
            result=result,
            preview=preview,
            own_metrics=own_metrics,
            result_kind=self._result_kind(out_image, own_metrics),
            input_bytes=input_bytes,
            output_bytes=output_bytes,
        )
