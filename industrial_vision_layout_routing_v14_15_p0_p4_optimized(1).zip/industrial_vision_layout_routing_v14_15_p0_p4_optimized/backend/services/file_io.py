from __future__ import annotations

import json
import os
import threading
import uuid
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterator


@contextmanager
def exclusive_file_lock(lock_path: Path) -> Iterator[None]:
    """Cross-process exclusive lock for POSIX and Windows file-backed stores."""

    lock_path = lock_path.resolve()
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    stream = lock_path.open("a+b")
    lock_backend = "none"
    try:
        try:
            import fcntl

            fcntl.flock(stream.fileno(), fcntl.LOCK_EX)
            lock_backend = "fcntl"
        except ImportError:
            try:
                import msvcrt

                stream.seek(0, os.SEEK_END)
                if stream.tell() == 0:
                    stream.write(b"\0")
                    stream.flush()
                stream.seek(0)
                getattr(msvcrt, "locking")(stream.fileno(), getattr(msvcrt, "LK_LOCK"), 1)
                lock_backend = "msvcrt"
            except ImportError:
                # Unknown platform: in-process store locks still prevent thread races.
                lock_backend = "none"
        yield
    finally:
        try:
            if lock_backend == "fcntl":
                import fcntl

                fcntl.flock(stream.fileno(), fcntl.LOCK_UN)
            elif lock_backend == "msvcrt":
                import msvcrt

                stream.seek(0)
                getattr(msvcrt, "locking")(stream.fileno(), getattr(msvcrt, "LK_UNLCK"), 1)
        finally:
            stream.close()


def atomic_write_json(path: Path, payload: Any, *, indent: int = 2) -> None:
    """Durably write JSON without exposing a partially written destination file."""

    path = path.resolve()
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(
        f".{path.name}.{os.getpid()}.{threading.get_ident()}.{uuid.uuid4().hex}.tmp"
    )
    try:
        with temporary.open("x", encoding="utf-8") as stream:
            json.dump(payload, stream, ensure_ascii=False, indent=indent)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
        try:
            directory_fd = os.open(path.parent, os.O_RDONLY)
        except OSError:
            return
        try:
            os.fsync(directory_fd)
        finally:
            os.close(directory_fd)
    finally:
        temporary.unlink(missing_ok=True)
