import os
from pathlib import Path


def _env_bool(name: str, default: bool = False) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}

PROJECT_ROOT = Path(__file__).resolve().parents[1]
FRONTEND_DIR = PROJECT_ROOT / "frontend"
UPLOAD_DIR = PROJECT_ROOT / "uploads"
MODEL_DIR = PROJECT_ROOT / "models" / "uploads"
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
MODEL_DIR.mkdir(parents=True, exist_ok=True)

ALLOWED_IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff", ".webp"}
ALLOWED_MODEL_EXTENSIONS = {".pt", ".onnx", ".engine", ".torchscript", ".mlmodel", ".tflite", ".pb", ".xml", ".bin", ".yaml", ".yml"}
MAX_UPLOAD_BYTES = 20 * 1024 * 1024
MAX_MODEL_UPLOAD_BYTES = 512 * 1024 * 1024

PROJECTS_DIR = PROJECT_ROOT / "projects"
MODEL_METADATA_PATH = MODEL_DIR / "models.json"
MODEL_CACHE_MAX_ITEMS = 4
MODEL_CACHE_TTL_SECONDS = 30 * 60
PROJECTS_DIR.mkdir(parents=True, exist_ok=True)

# PythonSnippet 不是完整安全沙箱。服务端强制使用独立进程，只有在明确了解
# 风险并设置环境变量时才允许退回主进程执行。
PYTHON_SNIPPET_ALLOW_INLINE = _env_bool("VISION_ALLOW_INLINE_PYTHON_SNIPPET", False)
PYTHON_SNIPPET_START_METHOD = os.getenv("VISION_PYTHON_SNIPPET_START_METHOD", "forkserver").strip().lower() or "forkserver"
PYTHON_SNIPPET_CPU_LIMIT_SECONDS = max(1, int(os.getenv("VISION_PYTHON_SNIPPET_CPU_LIMIT_SECONDS", "5")))
PYTHON_SNIPPET_STARTUP_GRACE_SECONDS = max(0.0, float(os.getenv("VISION_PYTHON_SNIPPET_STARTUP_GRACE_SECONDS", "2.0")))


# 统一节点执行内核的资源预算。默认值兼顾 4K/8K 工业图像与单机稳定性。
NODE_MAX_INPUT_BYTES = max(16 * 1024 * 1024, int(os.getenv("VISION_NODE_MAX_INPUT_BYTES", str(512 * 1024 * 1024))))
NODE_MAX_OUTPUT_BYTES = max(16 * 1024 * 1024, int(os.getenv("VISION_NODE_MAX_OUTPUT_BYTES", str(512 * 1024 * 1024))))
NODE_MAX_IMAGE_PIXELS = max(1_000_000, int(os.getenv("VISION_NODE_MAX_IMAGE_PIXELS", "100000000")))
PREVIEW_MAX_SIDE = max(256, int(os.getenv("VISION_PREVIEW_MAX_SIDE", "1600")))
DEBUG_PREVIEW_MAX_SIDE = max(128, int(os.getenv("VISION_DEBUG_PREVIEW_MAX_SIDE", "1024")))

# 节点调试会话保存在当前服务进程内，需要限制生命周期和内存占用。
DEBUG_SESSION_TTL_SECONDS = max(60, int(os.getenv("VISION_DEBUG_SESSION_TTL_SECONDS", "1800")))
DEBUG_SESSION_MAX_ITEMS = max(1, int(os.getenv("VISION_DEBUG_SESSION_MAX_ITEMS", "8")))
DEBUG_SESSION_MAX_PER_WORKSPACE = max(1, int(os.getenv("VISION_DEBUG_SESSION_MAX_PER_WORKSPACE", "2")))
DEBUG_SESSION_MAX_MEMORY_BYTES = max(64 * 1024 * 1024, int(os.getenv("VISION_DEBUG_SESSION_MAX_MEMORY_BYTES", str(512 * 1024 * 1024))))
DEBUG_RELEASE_UNUSED_OUTPUTS = _env_bool("VISION_DEBUG_RELEASE_UNUSED_OUTPUTS", True)

# 可渐进迁移的生产基础设施设置；file/inmemory 保持开箱即用。
STATE_BACKEND = os.getenv("VISION_STATE_BACKEND", "file").strip().lower() or "file"
SESSION_BACKEND = os.getenv("VISION_SESSION_BACKEND", "file").strip().lower() or "file"
ARTIFACT_BACKEND = os.getenv("VISION_ARTIFACT_BACKEND", "file").strip().lower() or "file"
DATABASE_URL = os.getenv("VISION_DATABASE_URL", "").strip()
REDIS_URL = os.getenv("VISION_REDIS_URL", "").strip()
OBJECT_STORAGE_ENDPOINT = os.getenv("VISION_OBJECT_STORAGE_ENDPOINT", "").strip()
OBJECT_STORAGE_BUCKET = os.getenv("VISION_OBJECT_STORAGE_BUCKET", "vision-artifacts").strip() or "vision-artifacts"
OBJECT_STORAGE_ACCESS_KEY = os.getenv("VISION_OBJECT_STORAGE_ACCESS_KEY", "").strip()
OBJECT_STORAGE_SECRET_KEY = os.getenv("VISION_OBJECT_STORAGE_SECRET_KEY", "").strip()
OBJECT_STORAGE_SECURE = _env_bool("VISION_OBJECT_STORAGE_SECURE", True)
JOB_WORKERS = max(1, int(os.getenv("VISION_JOB_WORKERS", "2")))
LOG_LEVEL = os.getenv("VISION_LOG_LEVEL", "INFO").strip().upper() or "INFO"


# 团队级功能：这些仍是文件系统实现，后续可替换为数据库/对象存储。
WORKSPACES_DIR = PROJECT_ROOT / "workspaces"
DATASETS_DIR = PROJECT_ROOT / "datasets"
RUN_HISTORY_DIR = PROJECT_ROOT / "run_history"
JOBS_DIR = PROJECT_ROOT / "jobs"
AUTH_DIR = PROJECT_ROOT / "auth"
STATE_DIR = PROJECT_ROOT / "state"
ARTIFACTS_DIR = PROJECT_ROOT / "artifacts"
for _directory in (WORKSPACES_DIR, DATASETS_DIR, RUN_HISTORY_DIR, JOBS_DIR, AUTH_DIR, STATE_DIR, ARTIFACTS_DIR):
    _directory.mkdir(parents=True, exist_ok=True)
