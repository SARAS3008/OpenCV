// 画布连线路由：快速拖拽路径、完整避障、SVG 定义与边渲染。
// 独立后可单独压测和替换路由算法，不再放大 canvas.js 的维护成本。

function getRouteNodeRect(node, padding = 28){
  const size = measureNodeForLayout(node);
  return {
    id:node.id,
    left:node.position.x - padding,
    top:node.position.y - padding,
    right:node.position.x + size.width + padding,
    bottom:node.position.y + size.height + padding,
  };
}
function normalizeSegmentRange(a, b){ return a <= b ? [a, b] : [b, a]; }
function segmentIntersectsRect(a, b, rect){
  const epsilon = 0.001;
  if(Math.abs(a.x - b.x) <= epsilon){
    const [y1, y2] = normalizeSegmentRange(a.y, b.y);
    return a.x >= rect.left && a.x <= rect.right && y2 >= rect.top && y1 <= rect.bottom;
  }
  if(Math.abs(a.y - b.y) <= epsilon){
    const [x1, x2] = normalizeSegmentRange(a.x, b.x);
    return a.y >= rect.top && a.y <= rect.bottom && x2 >= rect.left && x1 <= rect.right;
  }
  return false;
}
function polylineCollidesWithRects(points, rects){
  for(let index = 1; index < points.length; index += 1){
    const a = points[index - 1];
    const b = points[index];
    if(Math.abs(a.x - b.x) < 0.001 && Math.abs(a.y - b.y) < 0.001) continue;
    if(rects.some(rect => segmentIntersectsRect(a, b, rect))) return true;
  }
  return false;
}
function compactPolylinePoints(points){
  const rounded = points
    .map(point => ({ x:Math.round(point.x), y:Math.round(point.y) }))
    .filter((point, index, list) => index === 0 || point.x !== list[index - 1].x || point.y !== list[index - 1].y);
  const compacted = [];
  rounded.forEach(point => {
    compacted.push(point);
    while(compacted.length >= 3){
      const a = compacted[compacted.length - 3];
      const b = compacted[compacted.length - 2];
      const c = compacted[compacted.length - 1];
      const sameHorizontal = a.y === b.y && b.y === c.y;
      const sameVertical = a.x === b.x && b.x === c.x;
      if(!sameHorizontal && !sameVertical) break;
      compacted.splice(compacted.length - 2, 1);
    }
  });
  return compacted;
}
function roundedOrthogonalPath(points){
  const compacted = compactPolylinePoints(points);
  if(compacted.length <= 1) return "";
  if(compacted.length === 2) return `M ${compacted[0].x} ${compacted[0].y} L ${compacted[1].x} ${compacted[1].y}`;
  const parts = [`M ${compacted[0].x} ${compacted[0].y}`];
  for(let index = 1; index < compacted.length - 1; index += 1){
    const prev = compacted[index - 1];
    const current = compacted[index];
    const next = compacted[index + 1];
    const inDx = current.x - prev.x;
    const inDy = current.y - prev.y;
    const outDx = next.x - current.x;
    const outDy = next.y - current.y;
    const radius = Math.min(18, Math.abs(inDx || inDy) / 2, Math.abs(outDx || outDy) / 2);
    if(radius < 1){
      parts.push(`L ${current.x} ${current.y}`);
      continue;
    }
    const before = {
      x:current.x - Math.sign(inDx) * radius,
      y:current.y - Math.sign(inDy) * radius,
    };
    const after = {
      x:current.x + Math.sign(outDx) * radius,
      y:current.y + Math.sign(outDy) * radius,
    };
    parts.push(`L ${Math.round(before.x)} ${Math.round(before.y)}`);
    parts.push(`Q ${current.x} ${current.y} ${Math.round(after.x)} ${Math.round(after.y)}`);
  }
  const last = compacted[compacted.length - 1];
  parts.push(`L ${last.x} ${last.y}`);
  return parts.join(" ");
}
function routeScore(points){
  let length = 0;
  let bends = Math.max(0, points.length - 2);
  for(let index = 1; index < points.length; index += 1){
    length += Math.abs(points[index].x - points[index - 1].x) + Math.abs(points[index].y - points[index - 1].y);
  }
  return length + bends * 45;
}
function getEdgeRoutingBounds(rects, start, end){
  const allXs = [start.x, end.x];
  const allYs = [start.y, end.y];
  rects.forEach(rect => {
    allXs.push(rect.left, rect.right);
    allYs.push(rect.top, rect.bottom);
  });
  return {
    left:Math.min(...allXs),
    right:Math.max(...allXs),
    top:Math.min(...allYs),
    bottom:Math.max(...allYs),
  };
}
function candidateVerticalLanes(start, end, bounds){
  const dx = end.x - start.x;
  const minX = Math.min(start.x, end.x);
  const maxX = Math.max(start.x, end.x);
  const midX = Math.round(start.x + dx / 2);
  return [...new Set([
    midX,
    start.x + 72,
    start.x + 120,
    end.x - 72,
    end.x - 120,
    minX - 90,
    maxX + 90,
    bounds.left - 90,
    bounds.right + 90,
  ].map(value => Math.round(value)))]
    .filter(value => end.x - start.x >= 140 && value >= start.x + 40 && value <= end.x - 40);
}
function candidateBusLanes(start, end, bounds, edgeIndex = 0){
  const centerY = (start.y + end.y) / 2;
  const step = 34;
  const offset = (edgeIndex % 6) * step;
  const lanes = [
    bounds.top - 84 - offset,
    bounds.bottom + 84 + offset,
    Math.min(start.y, end.y) - 96 - offset,
    Math.max(start.y, end.y) + 96 + offset,
    centerY - 130 - offset,
    centerY + 130 + offset,
  ].map(value => Math.round(value));
  return [...new Set(lanes)].sort((a, b) => Math.abs(a - centerY) - Math.abs(b - centerY));
}
function buildBusRoute(start, end, clearXStart, clearXEnd, busY){
  return [start, { x:clearXStart, y:start.y }, { x:clearXStart, y:busY }, { x:clearXEnd, y:busY }, { x:clearXEnd, y:end.y }, end];
}
function calculateFastEdgeWaypoints(start, end, edgeIndex = 0){
  const clearXStart = Math.round(start.x + 56);
  const clearXEnd = Math.round(end.x - 56);
  if(clearXEnd >= clearXStart + 32){
    const laneX = Math.round((clearXStart + clearXEnd) / 2);
    return compactPolylinePoints([start, { x:clearXStart, y:start.y }, { x:laneX, y:start.y }, { x:laneX, y:end.y }, { x:clearXEnd, y:end.y }, end]);
  }
  const laneOffset = 76 + (edgeIndex % 6) * 22;
  const busY = Math.round(Math.min(start.y, end.y) - laneOffset);
  return compactPolylinePoints(buildBusRoute(start, end, clearXStart, clearXEnd, busY));
}
function calculateEdgeWaypoints(start, end, edge = null, edgeIndex = 0, options = {}){
  if(options.fast) return calculateFastEdgeWaypoints(start, end, edgeIndex);
  const ignored = new Set(edge ? [edge.source, edge.target] : []);
  const allRects = Array.isArray(options.routingRects) ? options.routingRects : nodes.map(node => getRouteNodeRect(node, 30));
  const rects = allRects.filter(rect => !ignored.has(rect.id));
  const bounds = getEdgeRoutingBounds(rects, start, end);
  const candidates = [];

  candidateVerticalLanes(start, end, bounds).forEach(laneX => {
    candidates.push([start, { x:laneX, y:start.y }, { x:laneX, y:end.y }, end]);
  });

  // 输出端始终先向右离开源节点，输入端始终从左侧进入目标节点。
  // 这可以避免反向连线从端口向左穿过源节点本体。
  const startClearCandidates = [56, 86, 124].map(value => Math.round(start.x + value));
  const endClearCandidates = [56, 86, 124].map(value => Math.round(end.x - value));
  candidateBusLanes(start, end, bounds, edgeIndex).forEach(busY => {
    startClearCandidates.forEach(clearXStart => {
      endClearCandidates.forEach(clearXEnd => {
        candidates.push(buildBusRoute(start, end, clearXStart, clearXEnd, busY));
      });
    });
  });

  const fallbackTop = Math.round(bounds.top - 150 - (edgeIndex % 8) * 28);
  const fallbackBottom = Math.round(bounds.bottom + 150 + (edgeIndex % 8) * 28);
  const leftOutside = Math.round(bounds.left - 130);
  const rightOutside = Math.round(bounds.right + 130);
  [fallbackTop, fallbackBottom].forEach(busY => {
    candidates.push(buildBusRoute(start, end, rightOutside, rightOutside, busY));
    candidates.push(buildBusRoute(start, end, leftOutside, leftOutside, busY));
  });

  const cleanCandidates = candidates
    .map(compactPolylinePoints)
    .filter(points => points.length >= 2)
    .filter(points => !polylineCollidesWithRects(points, rects));
  if(cleanCandidates.length){
    cleanCandidates.sort((a, b) => routeScore(a) - routeScore(b));
    return cleanCandidates[0];
  }

  return compactPolylinePoints([start, { x:Math.round((start.x + end.x) / 2), y:start.y }, { x:Math.round((start.x + end.x) / 2), y:end.y }, end]);
}
function makeEdgePath(start, end, edge = null, edgeIndex = 0, options = {}){
  return roundedOrthogonalPath(calculateEdgeWaypoints(start, end, edge, edgeIndex, options));
}
function drawTempEdge(clientX, clientY){
  clearTempEdge();
  const source = nodes.find(node => node.id === connectingSourceId);
  if(!source) return;
  const start = getPortPoint(source, "out", connectingSourceHandle);
  const end = screenToWorld(clientX, clientY);
  const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
  path.id = "tempEdge";
  path.setAttribute("class", "edge-temp");
  path.setAttribute("d", makeEdgePath(start, end, null, 0, { fast:true }));
  edgeLayer.appendChild(path);
}
function clearTempEdge(){
  const temporary = document.getElementById("tempEdge");
  if(temporary) temporary.remove();
}
function renderEdgeDefinitions(){
  const defs = document.createElementNS("http://www.w3.org/2000/svg", "defs");
  defs.innerHTML = `<marker id="edgeArrow" viewBox="0 0 10 10" refX="8.5" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
    <path d="M 0 0 L 10 5 L 0 10 z" class="edge-arrow-shape"></path>
  </marker>
  <marker id="edgeArrowSelected" viewBox="0 0 10 10" refX="8.5" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
    <path d="M 0 0 L 10 5 L 0 10 z" class="edge-arrow-shape selected"></path>
  </marker>`;
  edgeLayer.appendChild(defs);
}
function renderEdges(options = {}){
  edgeLayer.innerHTML = "";
  edgeLayer.setAttribute("overflow", "visible");
  renderEdgeDefinitions();
  const collapsedByNodeId = collapsedModuleMapByNodeId();
  const nodeById = new Map(nodes.map(node => [node.id, node]));
  const routingRects = options.fast ? null : nodes.map(node => getRouteNodeRect(node, 30));
  edges.forEach((edge, edgeIndex) => {
    const source = nodeById.get(edge.source);
    const target = nodeById.get(edge.target);
    if(!source || !target) return;

    const sourceModule = collapsedByNodeId.get(edge.source) || null;
    const targetModule = collapsedByNodeId.get(edge.target) || null;
    if(sourceModule && targetModule && sourceModule.id === targetModule.id) return;

    const rawStart = getPortPoint(source, "out", edge.sourceHandle || "out");
    const rawEnd = getPortPoint(target, "in", edge.targetHandle || "in");
    const start = sourceModule ? moduleEdgePortPoint(sourceModule, "out", rawEnd, rawStart.y) : rawStart;
    const end = targetModule ? moduleEdgePortPoint(targetModule, "in", rawStart, rawEnd.y) : rawEnd;
    if(!start || !end) return;

    const isModuleEdge = Boolean(sourceModule || targetModule);
    const pathData = makeEdgePath(start, end, edge, edgeIndex, { fast:Boolean(options.fast), routingRects });
    const hit = document.createElementNS("http://www.w3.org/2000/svg", "path");
    hit.setAttribute("d", pathData);
    hit.setAttribute("class", `edge-hit ${isModuleEdge ? "module-edge" : ""}`);
    hit.dataset.id = edge.id;
    const fromLabel = sourceModule ? `模块「${sourceModule.name || sourceModule.id}」` : `${edge.source}.${edge.sourceHandle || "out"}`;
    const toLabel = targetModule ? `模块「${targetModule.name || targetModule.id}」` : `${edge.target}.${edge.targetHandle || "in"}`;
    hit.setAttribute("aria-label", `${fromLabel} → ${toLabel}`);
    hit.addEventListener("mousedown", event => event.stopPropagation());
    hit.addEventListener("click", event => { event.stopPropagation(); selectEdge(edge.id); });
    hit.addEventListener("dblclick", event => { event.stopPropagation(); deleteEdge(edge.id); });
    hit.addEventListener("contextmenu", event => { event.preventDefault(); event.stopPropagation(); deleteEdge(edge.id); });
    const visible = document.createElementNS("http://www.w3.org/2000/svg", "path");
    visible.setAttribute("d", pathData);
    visible.setAttribute("class", `edge-visible ${isModuleEdge ? "module-edge" : ""} ${selectedEdgeId === edge.id ? "selected" : ""}`);
    visible.setAttribute("marker-end", selectedEdgeId === edge.id ? "url(#edgeArrowSelected)" : "url(#edgeArrow)");
    edgeLayer.append(hit, visible);
  });
}
