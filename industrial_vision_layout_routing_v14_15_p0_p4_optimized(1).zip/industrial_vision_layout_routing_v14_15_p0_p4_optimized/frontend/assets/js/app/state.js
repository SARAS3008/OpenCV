// 拆分自 app.bundle.legacy.js：第 1-351 行。
let OPERATOR_META = {};
let OPERATOR_CATALOG = {};
let nodes = [];
let edges = [];
let nodeSeq = 1;
let workflowModules = [];
let moduleSeq = 1;
let selectedModuleId = null;
let moduleEditorState = null;
let moduleSelectionRect = null;
let isSpacePanning = false;
let workflowExplorerVisible = false;
let activeSidePanel = "nodes";
let selectedNodeId = null;
let selectedEdgeId = null;
let connectingSourceId = null;
let connectingSourceHandle = "out";
let connectDrag = null;
let pan = { x: -260, y: -120 };
let zoom = 0.82;
let previewCollapsed = false;
let nodeLibraryVisible = true;
let previewActionNodeId = null;
let colorPaletteNodeId = null;
let lightboxNodeId = null;
let workflowDocuments = [];
let activeWorkflowId = null;
let suppressDocumentSync = false;
let debugSessionId = null;
let debugWorkflowExecutionSignature = "";
let debugCurrentNodeId = null;
let debugNextNodeId = null;
let debugTargetNodeId = null;
let debugRunBusy = false;
const debugExecutedNodeIds = new Set();
let minimapTransform = null;
const collapsedOperatorGroups = new Set();
const collapsedLogicOperatorGroups = new Set();

const WORKSPACE_STORAGE_KEY = VisionWorkspaceStore.WORKSPACE_STORAGE_KEY;
const fallbackStorage = new Map();
const nodePreviews = new Map();
const DEFAULT_NODE_COLOR = "#8d9298";
const NODE_COLORS = [
  "#8d9298", "#8a4b4d", "#8e5845", "#3f7149", "#4b4b7d",
  "#526b75", "#3d7374", "#70476c", "#8b6c37", "#151719",
];
const ICONS = { io:"⎋", color:"◐", filter:"≋", segment:"⌁", morph:"⬡", geo:"⟲", measure:"▤", custom:"✦", logic:"◇" };
const NODE_WIDTH = 340;

const viewport = document.getElementById("viewport");
const world = document.getElementById("world");
const nodeLayer = document.getElementById("nodeLayer");
const edgeLayer = document.getElementById("edgeLayer");
const statusEl = document.getElementById("status");
const paramPanel = document.getElementById("paramPanel");
const previewPanel = document.getElementById("previewPanel");
const previewWrap = document.getElementById("previewWrap");
const previewToggleText = document.getElementById("previewToggleText");

function storageGet(key){ return VisionWorkspaceStore.storageGet(key); }
function storageSet(key, value){ return VisionWorkspaceStore.storageSet(key, value); }
function cloneData(value){ return VisionWorkspaceStore.cloneData(value); }
function createWorkflowId(){ return VisionWorkspaceStore.createWorkflowId(); }
function emptyWorkflow(){
  return { version:"2.3", nodes:[], edges:[], modules:[] };
}
function demoWorkflowDefinition(){
  return {
    version:"2.1",
    nodes:[
      { id:"n1", type:"ReadImage", position:{ x:380, y:250 }, params:{ image_path:"" }, collapsed:false, color:DEFAULT_NODE_COLOR },
      { id:"n2", type:"ColorConvert", position:{ x:790, y:250 }, params:{ mode:"GRAY" }, collapsed:false, color:DEFAULT_NODE_COLOR },
      { id:"n3", type:"GaussianBlur", position:{ x:1200, y:250 }, params:{ ksize:5, sigma:0 }, collapsed:false, color:DEFAULT_NODE_COLOR },
      { id:"n4", type:"Canny", position:{ x:1610, y:250 }, params:{ threshold1:50, threshold2:150 }, collapsed:false, color:DEFAULT_NODE_COLOR },
      { id:"n5", type:"Display", position:{ x:2020, y:250 }, params:{}, collapsed:false, color:DEFAULT_NODE_COLOR },
    ],
    edges:[
      { id:"e1", source:"n1", sourceHandle:"out", target:"n2", targetHandle:"in" },
      { id:"e2", source:"n2", sourceHandle:"out", target:"n3", targetHandle:"in" },
      { id:"e3", source:"n3", sourceHandle:"out", target:"n4", targetHandle:"in" },
      { id:"e4", source:"n4", sourceHandle:"out", target:"n5", targetHandle:"in" },
    ],
    modules:[
      { id:"m1", name:"边缘检测预处理", node_ids:["n2", "n3", "n4"], description:"颜色转换、平滑和边缘提取", color:"#526b75", collapsed:false },
    ],
  };
}
function workflowSignature(workflow){ return VisionWorkspaceStore.signature(workflow || emptyWorkflow()); }
function getActiveWorkflowDocument(){
  return workflowDocuments.find(documentInfo => documentInfo.id === activeWorkflowId) || null;
}
function nextWorkflowName(){
  const used = new Set(workflowDocuments.map(documentInfo => documentInfo.name));
  if(!used.has("Vision Workflow")) return "Vision Workflow";
  let index = 2;
  while(used.has(`Vision Workflow ${index}`)) index += 1;
  return `Vision Workflow ${index}`;
}
function createWorkflowDocument(workflow = emptyWorkflow(), options = {}){
  const name = options.name || nextWorkflowName();
  const normalizedWorkflow = cloneData(workflow);
  const saved = Boolean(options.saved);
  return {
    id:options.id || createWorkflowId(),
    projectId:options.projectId || options.project_id || null,
    name,
    workflow:normalizedWorkflow,
    savedSnapshot:saved ? workflowSignature(normalizedWorkflow) : (options.savedSnapshot || null),
    savedName:saved ? name : (options.savedName || null),
    dirty:!saved,
    view:options.view || { pan:{ x:-260, y:-120 }, zoom:.82, previewCollapsed:false, nodeLibraryVisible:true, activeSidePanel:"nodes" },
    selectedNodeId:options.selectedNodeId || null,
    runtimePreviews:[],
  };
}
function recomputeDocumentDirty(documentInfo){
  if(!documentInfo) return;
  documentInfo.dirty = !documentInfo.savedSnapshot
    || documentInfo.savedSnapshot !== workflowSignature(documentInfo.workflow)
    || documentInfo.savedName !== documentInfo.name;
}
function persistWorkspace(){
  try{
    const payload = {
      version:1,
      activeWorkflowId,
      documents:workflowDocuments.map(documentInfo => ({
        id:documentInfo.id,
        projectId:documentInfo.projectId || null,
        name:documentInfo.name,
        workflow:documentInfo.workflow,
        savedSnapshot:documentInfo.savedSnapshot,
        savedName:documentInfo.savedName,
        view:documentInfo.view,
        selectedNodeId:documentInfo.selectedNodeId,
      })),
    };
    VisionWorkspaceStore.saveLocalWorkspace(payload);
  }catch(error){
    console.warn("无法保存工作区状态", error);
  }
}
function captureActiveWorkflowDocument(recalculateDirty = true){
  if(suppressDocumentSync) return;
  const documentInfo = getActiveWorkflowDocument();
  if(!documentInfo) return;
  documentInfo.workflow = buildWorkflow();
  documentInfo.view = {
    pan:{ ...pan },
    zoom,
    previewCollapsed,
    nodeLibraryVisible,
    activeSidePanel,
  };
  documentInfo.selectedNodeId = selectedNodeId;
  documentInfo.runtimePreviews = Array.from(nodePreviews.values());
  if(recalculateDirty) recomputeDocumentDirty(documentInfo);
}
function commitActiveWorkflowChange(){
  captureActiveWorkflowDocument(true);
  if(typeof invalidateDebugSessionIfWorkflowChanged === "function") invalidateDebugSessionIfWorkflowChanged();
  renderWorkflowTabs();
  persistWorkspace();
}
function persistActiveWorkflowView(){
  captureActiveWorkflowDocument(false);
  persistWorkspace();
}
function renderWorkflowTabs(){
  const container = document.getElementById("workflowTabs");
  if(!container) return;
  container.innerHTML = "";
  workflowDocuments.forEach(documentInfo => {
    const tab = document.createElement("div");
    tab.className = `workflow-tab ${documentInfo.id === activeWorkflowId ? "active" : ""}`;
    tab.setAttribute("role", "tab");
    tab.setAttribute("aria-selected", String(documentInfo.id === activeWorkflowId));
    tab.dataset.workflowId = documentInfo.id;

    const main = document.createElement("button");
    main.type = "button";
    main.className = "workflow-tab-main";
    main.title = `${documentInfo.name} · ${documentInfo.dirty ? "未保存" : "已保存"}（双击重命名）`;
    const name = document.createElement("span");
    name.className = "workflow-tab-name";
    name.textContent = documentInfo.name;
    const dot = document.createElement("span");
    dot.className = `save-state-dot ${documentInfo.dirty ? "dirty" : "saved"}`;
    dot.title = documentInfo.dirty ? "有未保存修改" : "已保存";
    main.append(name, dot);
    main.addEventListener("click", () => switchWorkflow(documentInfo.id));
    main.addEventListener("dblclick", event => {
      event.preventDefault();
      renameWorkflow(documentInfo.id);
    });

    const close = document.createElement("button");
    close.type = "button";
    close.className = "workflow-tab-close";
    close.textContent = "×";
    close.title = "关闭工作流";
    close.setAttribute("aria-label", `关闭 ${documentInfo.name}`);
    close.addEventListener("click", event => {
      event.stopPropagation();
      closeWorkflow(documentInfo.id);
    });
    tab.append(main, close);
    container.appendChild(tab);
  });
  window.requestAnimationFrame(() => {
    container.querySelector(".workflow-tab.active")?.scrollIntoView({ block:"nearest", inline:"nearest" });
  });
}
function restoreWorkflowDocument(documentInfo){
  if(!documentInfo) return;
  if(typeof resetLocalDebugState === "function") resetLocalDebugState({ preserveLogs:true });
  suppressDocumentSync = true;
  try{
    closeImageLightbox();
    applyWorkflow(cloneData(documentInfo.workflow), { silent:true });
    pan = { ...(documentInfo.view?.pan || { x:-260, y:-120 }) };
    zoom = Number(documentInfo.view?.zoom) || .82;
    applyTransform();
    setSidePanelMode(documentInfo.view?.activeSidePanel ?? (documentInfo.view?.nodeLibraryVisible === false ? null : "nodes"));
    togglePreviewPanel(Boolean(documentInfo.view?.previewCollapsed));
    selectedNodeId = nodes.some(node => node.id === documentInfo.selectedNodeId) ? documentInfo.selectedNodeId : (nodes[0]?.id || null);
    selectedEdgeId = null;
    nodePreviews.clear();
    (documentInfo.runtimePreviews || []).forEach(item => nodePreviews.set(item.node_id, item));
    if(documentInfo.runtimePreviews?.length) renderPreviews(documentInfo.runtimePreviews);
    else{
      clearRunLog("工作流已切换，运行后显示实时日志。");
      render();
    }
    setStatus(`当前工作流：${documentInfo.name}${documentInfo.dirty ? "（未保存）" : "（已保存）"}`);
  }finally{
    suppressDocumentSync = false;
  }
}
function switchWorkflow(workflowId){
  if(workflowId === activeWorkflowId) return;
  const target = workflowDocuments.find(documentInfo => documentInfo.id === workflowId);
  if(!target) return;
  captureActiveWorkflowDocument(true);
  activeWorkflowId = workflowId;
  restoreWorkflowDocument(target);
  renderWorkflowTabs();
  persistWorkspace();
}
function newWorkflow(){
  captureActiveWorkflowDocument(true);
  const documentInfo = createWorkflowDocument(emptyWorkflow());
  workflowDocuments.push(documentInfo);
  activeWorkflowId = documentInfo.id;
  restoreWorkflowDocument(documentInfo);
  renderWorkflowTabs();
  persistWorkspace();
  toast("已新建工作流", documentInfo.name, true);
}
function closeWorkflow(workflowId){
  const index = workflowDocuments.findIndex(documentInfo => documentInfo.id === workflowId);
  if(index < 0) return;
  const documentInfo = workflowDocuments[index];
  if(documentInfo.dirty && !window.confirm(`“${documentInfo.name}”存在未保存修改，确定关闭吗？`)) return;
  const wasActive = workflowId === activeWorkflowId;
  workflowDocuments.splice(index, 1);
  if(!workflowDocuments.length){
    const replacement = createWorkflowDocument(emptyWorkflow());
    workflowDocuments.push(replacement);
    activeWorkflowId = replacement.id;
    restoreWorkflowDocument(replacement);
  }else if(wasActive){
    const replacement = workflowDocuments[Math.min(index, workflowDocuments.length - 1)];
    activeWorkflowId = replacement.id;
    restoreWorkflowDocument(replacement);
  }
  renderWorkflowTabs();
  persistWorkspace();
}
function renameWorkflow(workflowId){
  const documentInfo = workflowDocuments.find(item => item.id === workflowId);
  if(!documentInfo) return;
  const nextName = window.prompt("请输入工作流名称", documentInfo.name);
  if(nextName === null) return;
  const trimmed = nextName.trim();
  if(!trimmed || trimmed === documentInfo.name) return;
  documentInfo.name = trimmed;
  recomputeDocumentDirty(documentInfo);
  renderWorkflowTabs();
  persistWorkspace();
  setStatus(`工作流已重命名为：${trimmed}`);
}
async function initializeWorkspace(){
  let restored = false;

  try{
    const serverProjects = await VisionWorkspaceStore.loadServerProjects();
    if(serverProjects.length){
      const documentInfo = await VisionWorkspaceStore.openServerProject(serverProjects[0].project_id);
      workflowDocuments = [documentInfo];
      activeWorkflowId = documentInfo.id;
      restored = true;
      setStatus(`已从服务端项目库打开：${documentInfo.name}`);
    }
  }catch(error){
    console.warn("服务端项目恢复失败，将使用本地兜底缓存", error);
  }

  if(!restored){
    try{
      const payload = VisionWorkspaceStore.loadLocalWorkspace();
      if(payload){
        workflowDocuments = (payload.documents || []).map(rawDocument => {
          const documentInfo = createWorkflowDocument(rawDocument.workflow || emptyWorkflow(), {
            id:rawDocument.id,
            projectId:rawDocument.projectId || rawDocument.project_id || null,
            name:rawDocument.name || "Vision Workflow",
            savedSnapshot:rawDocument.savedSnapshot || null,
            savedName:rawDocument.savedName || null,
            view:rawDocument.view,
            selectedNodeId:rawDocument.selectedNodeId,
          });
          recomputeDocumentDirty(documentInfo);
          return documentInfo;
        });
        if(workflowDocuments.length){
          activeWorkflowId = workflowDocuments.some(item => item.id === payload.activeWorkflowId)
            ? payload.activeWorkflowId
            : workflowDocuments[0].id;
          restored = true;
        }
      }
    }catch(error){
      console.warn("工作区恢复失败", error);
    }
  }

  if(!restored){
    const firstDocument = createWorkflowDocument(demoWorkflowDefinition(), { name:"Vision Workflow" });
    workflowDocuments = [firstDocument];
    activeWorkflowId = firstDocument.id;
  }
  restoreWorkflowDocument(getActiveWorkflowDocument());
  renderWorkflowTabs();
  persistWorkspace();
}

async function initOperators(){
  if(!VisionApi.getAuthToken()){
    setStatus("请先登录后再加载节点库、创建或运行工作流。");
    return;
  }
  try{
    const data = await VisionApi.getOperators();
    OPERATOR_META = data.operators || {};
    OPERATOR_CATALOG = data.catalog || {};
    const pluginErrors = Array.isArray(data.plugin_errors) ? data.plugin_errors : [];
    renderOperatorPanel();
    applyTransform();
    await initializeWorkspace();
    if(pluginErrors.length){
      const first = pluginErrors[0];
      toast("部分自定义算子加载失败", `${pluginErrors.length} 个插件未注册：${first.module || "未知插件"}`, false);
      setStatus(`部分自定义算子加载失败：${pluginErrors.length} 个。请查看 /api/operators 的 plugin_errors 字段。`);
    }
  }catch(error){
    toast("初始化失败", error.message || String(error));
    setStatus(`初始化失败：${error.message || error}`);
  }
}

