// 统一运行状态机：整体运行、调试运行、取消和会话状态只维护一份状态。
const VisionExecutionStore = (() => {
  const initial = () => ({
    phase:"idle",
    busy:false,
    mode:"full",
    sessionId:null,
    workflowSignature:"",
    currentNodeId:null,
    nextNodeId:null,
    targetNodeId:null,
    executedNodeIds:[],
    cancelled:false,
    lastError:null,
  });
  let state = initial();
  const listeners = new Set();
  const notify = () => listeners.forEach(listener => {
    try{ listener({ ...state, executedNodeIds:[...state.executedNodeIds] }); }catch(error){ console.warn(error); }
  });
  return {
    get(){ return { ...state, executedNodeIds:[...state.executedNodeIds] }; },
    patch(patch){ state = { ...state, ...(patch || {}) }; notify(); return this.get(); },
    begin(mode, targetNodeId = null){
      return this.patch({ phase:"running", busy:true, mode, targetNodeId, cancelled:false, lastError:null });
    },
    applyDebug(data, workflowSignature){
      return this.patch({
        phase:data?.completed ? "completed" : "paused",
        busy:false,
        mode:data?.debug_action || state.mode,
        sessionId:data?.debug_session_id || state.sessionId,
        workflowSignature:workflowSignature || state.workflowSignature,
        currentNodeId:data?.current_node_id || null,
        nextNodeId:data?.next_node_id || null,
        targetNodeId:data?.target_node_id || null,
        executedNodeIds:[...(data?.executed_order || [])],
        cancelled:Boolean(data?.cancelled),
      });
    },
    fail(error){ return this.patch({ phase:"failed", busy:false, lastError:String(error || "运行失败") }); },
    cancel(){ return this.patch({ phase:"cancelled", busy:false, cancelled:true }); },
    reset(){ state = initial(); notify(); return this.get(); },
    subscribe(listener){ listeners.add(listener); return () => listeners.delete(listener); },
  };
})();
