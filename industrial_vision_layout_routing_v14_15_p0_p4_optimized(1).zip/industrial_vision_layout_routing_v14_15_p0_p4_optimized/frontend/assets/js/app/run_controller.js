// 运行控制器：整体运行、单步、运行到节点、实时日志与调试状态。
// 与画布渲染解耦，所有运行模式共享同一前端状态转换入口。

let activeExecutionAbortController = null;

function syncExecutionStateToLegacy(){
  const state = VisionExecutionStore.get();
  debugSessionId = state.sessionId;
  debugWorkflowExecutionSignature = state.workflowSignature;
  debugCurrentNodeId = state.currentNodeId;
  debugNextNodeId = state.nextNodeId;
  debugTargetNodeId = state.targetNodeId;
  debugRunBusy = state.busy;
  debugExecutedNodeIds.clear();
  (state.executedNodeIds || []).forEach(nodeId => debugExecutedNodeIds.add(nodeId));
}

function formatRunLogTimestamp(value){
  const date = value ? new Date(value) : new Date();
  const safeDate = Number.isNaN(date.getTime()) ? new Date() : date;
  const pad = number => String(number).padStart(2, "0");
  return `${safeDate.getFullYear()}-${pad(safeDate.getMonth() + 1)}-${pad(safeDate.getDate())} ${pad(safeDate.getHours())}:${pad(safeDate.getMinutes())}:${pad(safeDate.getSeconds())}`;
}

function clearRunLog(message = "等待运行工作流..."){
  if(!previewPanel) return;
  previewPanel.replaceChildren();
  if(message){
    const empty = document.createElement("div");
    empty.className = "run-log-empty";
    empty.textContent = message;
    previewPanel.appendChild(empty);
  }
}

function appendRunLog(level, message, details = "", timestamp = null, eventName = ""){
  if(!previewPanel) return;
  previewPanel.querySelector(".run-log-empty")?.remove();
  const normalizedLevel = ["success", "warning", "error", "debug"].includes(level) ? level : "info";
  const row = document.createElement("div");
  row.className = `run-log-entry ${normalizedLevel}`;
  if(eventName) row.dataset.event = eventName;

  const time = document.createElement("time");
  time.className = "run-log-time";
  time.dateTime = timestamp || new Date().toISOString();
  time.textContent = formatRunLogTimestamp(timestamp);

  const badge = document.createElement("span");
  badge.className = "run-log-level";
  badge.textContent = ({ success:"成功", warning:"警告", error:"错误", debug:"调试", info:"信息" })[normalizedLevel];

  const content = document.createElement("div");
  content.className = "run-log-content";
  const messageElement = document.createElement("div");
  messageElement.className = "run-log-message";
  messageElement.textContent = String(message || "运行事件");
  content.appendChild(messageElement);
  if(details){
    const detailElement = document.createElement("div");
    detailElement.className = "run-log-details";
    detailElement.textContent = String(details);
    content.appendChild(detailElement);
  }

  row.append(time, badge, content);
  previewPanel.appendChild(row);
  while(previewPanel.querySelectorAll(".run-log-entry").length > RUN_LOG_LIMIT){
    previewPanel.querySelector(".run-log-entry")?.remove();
  }
  const scroll = document.getElementById("previewScroll");
  if(scroll) scroll.scrollTop = scroll.scrollHeight;
}

function workflowLogDetails(event){
  if(event.node_id){
    const progress = event.node_total ? `${event.node_index || "-"}/${event.node_total}` : "";
    return [progress, event.node_type || "", event.duration_ms != null ? `${Number(event.duration_ms).toFixed(2)} ms` : ""].filter(Boolean).join(" · ");
  }
  if(event.source_name){
    return [`${event.index || "-"}/${event.total || "-"}`, event.source_name, event.duration_ms != null ? `${Number(event.duration_ms).toFixed(2)} ms` : ""].filter(Boolean).join(" · ");
  }
  if(event.output_dir || event.csv_path){
    return [event.output_dir ? `结果目录：${event.output_dir}` : "", event.csv_path ? `CSV：${event.csv_path}` : ""].filter(Boolean).join(" · ");
  }
  return "";
}

function handleWorkflowLogEvent(event){
  appendRunLog(event.level || "info", event.message || event.event || "运行事件", workflowLogDetails(event), event.timestamp, event.event || "");
}

function workflowExecutionSignatureForDebug(workflow = buildWorkflow()){
  return JSON.stringify({
    image_id:workflow.image_id || null,
    nodes:(workflow.nodes || []).map(node => ({ id:node.id, type:node.type, params:node.params || {} })),
    edges:(workflow.edges || []).map(edge => ({
      source:edge.source,
      target:edge.target,
      sourceHandle:edge.sourceHandle || "out",
      targetHandle:edge.targetHandle || "in",
    })),
  });
}

function resetLocalDebugState(options = {}){
  VisionExecutionStore.reset();
  syncExecutionStateToLegacy();
  updateRunModeUi();
  if(!options.preserveRender){
    renderNodes();
    updateMinimap();
  }
  if(!options.preserveLogs && previewPanel){
    appendRunLog("debug", "调试会话已重置");
  }
}

async function resetDebugSession(options = {}){
  const sessionId = debugSessionId;
  resetLocalDebugState({
    preserveLogs:Boolean(options.preserveLogs || options.silent),
    preserveRender:Boolean(options.preserveRender),
  });
  if(sessionId){
    try{ await VisionApi.resetDebugSession(sessionId); }
    catch(error){ if(!options.silent) console.warn("调试会话重置失败", error); }
  }
  if(!options.silent){
    setStatus("调试会话已结束；可重新选择运行模式。");
    toast("调试已重置", "已清除执行进度，节点结果预览仍保留", true);
  }
}

function invalidateDebugSessionIfWorkflowChanged(){
  if(!debugSessionId || debugRunBusy) return;
  const currentSignature = workflowExecutionSignatureForDebug();
  if(currentSignature === debugWorkflowExecutionSignature) return;
  const oldSessionId = debugSessionId;
  resetLocalDebugState({ preserveLogs:true });
  VisionApi.resetDebugSession(oldSessionId).catch(() => {});
  appendRunLog("warning", "工作流参数或连线已修改，原调试会话已失效", "移动节点和折叠节点不会触发重置；执行参数与连线变化会重新开始调试");
  setStatus("工作流已修改，请重新开始单步调试。");
}

function updateRunModeUi(){
  const select = document.getElementById("runModeSelect");
  const button = document.getElementById("runModeButton");
  const resetButton = document.getElementById("debugResetButton");
  const cancelButton = document.getElementById("debugCancelButton");
  const controls = document.querySelector(".run-mode-controls");
  if(!select || !button) return;
  const mode = select.value || "full";
  const labels = {
    full:"▶ 整体运行",
    step:debugSessionId ? "⏭ 继续单步" : "⏭ 单步运行",
    run_to_node:"⏯ 运行到节点",
  };
  button.textContent = labels[mode] || labels.full;
  button.disabled = debugRunBusy;
  select.disabled = debugRunBusy;
  if(resetButton){
    resetButton.hidden = !debugSessionId;
    resetButton.disabled = debugRunBusy;
  }
  if(cancelButton){
    cancelButton.hidden = !debugRunBusy;
    cancelButton.disabled = !debugRunBusy;
    cancelButton.title = mode === "full" ? "取消当前整体运行" : "取消当前调试执行";
  }
  controls?.classList.toggle("busy", debugRunBusy);
  if(mode === "run_to_node"){
    button.title = selectedNodeId ? `执行到当前选中的节点 ${selectedNodeId}` : "请先在画布中选择目标节点";
  }else if(mode === "step"){
    button.title = debugNextNodeId ? `下一步将执行 ${debugNextNodeId}` : "每次只执行一个新的节点";
  }else{
    button.title = "按当前方式运行整个工作流";
  }
}

function runSelectedMode(){
  const mode = document.getElementById("runModeSelect")?.value || "full";
  if(mode === "full") return runWorkflow();
  if(mode === "run_to_node") return executeDebugAction("run_to_node");
  return executeDebugAction("step");
}

function applyDebugResult(data){
  VisionExecutionStore.applyDebug(data, workflowExecutionSignatureForDebug());
  syncExecutionStateToLegacy();
  if(debugCurrentNodeId){
    selectedNodeId = debugCurrentNodeId;
    selectedEdgeId = null;
  }
  renderPreviews(data.previews || []);
  updateRunModeUi();
}


async function executeDebugAction(action){
  if(debugRunBusy) return;
  const workflow = buildWorkflow();
  if(!workflow.nodes.length){
    toast("无法调试", "流程为空，请先添加节点");
    return;
  }
  const targetNodeId = action === "run_to_node" ? selectedNodeId : null;
  if(action === "run_to_node" && !targetNodeId){
    setStatus("请先在画布中选择要运行到的节点。");
    toast("请选择目标节点", "选中节点后再使用“运行到节点”模式");
    return;
  }
  const signature = workflowExecutionSignatureForDebug(workflow);
  if(debugSessionId && debugWorkflowExecutionSignature && signature !== debugWorkflowExecutionSignature){
    await resetDebugSession({ silent:true, preserveLogs:true, preserveRender:true });
  }

  VisionExecutionStore.begin(action, targetNodeId);
  if(debugSessionId) VisionExecutionStore.patch({ sessionId:debugSessionId, workflowSignature:debugWorkflowExecutionSignature });
  syncExecutionStateToLegacy();
  updateRunModeUi();
  document.getElementById("taskCount").textContent = "1";
  if(previewCollapsed) togglePreviewPanel(false);
  if(!debugSessionId){
    clearRunLog("");
    appendRunLog("debug", "正在建立调试会话...", `${workflow.nodes.length} 个节点 · ${workflow.edges.length} 条连线`);
  }else{
    appendRunLog("debug", action === "step" ? "继续执行下一步" : `继续执行到节点 ${targetNodeId}`, debugNextNodeId ? `当前下一节点：${debugNextNodeId}` : "");
  }
  setStatus(action === "step" ? "单步执行中..." : `正在执行到节点 ${targetNodeId}...`);

  const controller = new AbortController();
  activeExecutionAbortController = controller;
  try{
    const data = await VisionApi.executeDebugStream({
      workflow,
      session_id:debugSessionId || null,
      action,
      target_node_id:targetNodeId,
    }, handleWorkflowLogEvent, { signal:controller.signal });
    applyDebugResult(data);

    if(data.completed){
      const skippedText = (data.skipped_nodes || []).length ? `；跳过未选分支：${data.skipped_nodes.join("、")}` : "";
      setStatus(`调试执行完成。执行顺序：${(data.executed_order || []).join(" → ")}${skippedText}`);
      toast("调试完成", `共执行 ${(data.executed_order || []).length} 个节点`, true);
    }else if(action === "run_to_node"){
      setStatus(`已执行到节点 ${targetNodeId}。下一步：${data.next_node_id || "无"}。运行模式已切换为单步。`);
      const select = document.getElementById("runModeSelect");
      if(select) select.value = "step";
      updateRunModeUi();
      toast("已暂停到指定节点", `${targetNodeId}；可继续单步执行`, true);
    }else{
      setStatus(`单步完成：${(data.newly_executed || []).join("、") || "无新节点"}。下一步：${data.next_node_id || "无"}`);
      toast("单步执行完成", data.current_node_id || "工作流已完成", true);
    }
  }catch(error){
    if(error?.name === "AbortError"){
      VisionExecutionStore.cancel();
      syncExecutionStateToLegacy();
      appendRunLog("warning", "调试运行已取消", "当前算子返回后，后端不会继续调度后续节点");
      setStatus("调试运行已取消。");
      return;
    }
    const message = error?.message || String(error);
    const payload = error?.payload || null;
    if(payload && Array.isArray(payload.previews)){
      if(payload.debug_session_id){
        VisionExecutionStore.applyDebug({
          ...payload,
          current_node_id:payload.current_node_id || payload.failed_node?.node_id || null,
          next_node_id:payload.next_node_id || payload.failed_node?.node_id || null,
          completed:false,
        }, workflowExecutionSignatureForDebug());
        syncExecutionStateToLegacy();
        if(debugCurrentNodeId){
          selectedNodeId = debugCurrentNodeId;
          selectedEdgeId = null;
        }
      }
      renderPreviews(payload.previews || []);
      renderExecutionFailureSummary(payload);
    }else{
      appendRunLog("error", `调试执行失败：${message}`);
    }
    if(payload?.restart_required || error?.httpStatus === 409){
      resetLocalDebugState({ preserveLogs:true });
      appendRunLog("warning", "调试会话需要重新开始", "服务可能已重启、会话已过期，或工作流执行参数发生变化");
    }
    setStatus(`调试失败：${message}`);
    toast("调试执行失败", message);
  }finally{
    if(activeExecutionAbortController === controller) activeExecutionAbortController = null;
    VisionExecutionStore.patch({ busy:false });
    syncExecutionStateToLegacy();
    document.getElementById("taskCount").textContent = "0";
    updateRunModeUi();
  }
}

async function cancelActiveDebugRun(){
  if(!debugRunBusy) return;
  const mode = VisionExecutionStore.get().mode || document.getElementById("runModeSelect")?.value || "full";
  appendRunLog("warning", mode === "full" ? "正在取消整体运行..." : "正在请求取消调试运行...", debugSessionId ? `会话：${debugSessionId}` : "连接断开后服务端将停止后续调度");
  if(debugSessionId){
    try{ await VisionApi.cancelDebugSession(debugSessionId); }
    catch(error){ appendRunLog("error", `调试取消请求失败：${error?.message || error}`); }
  }
  activeExecutionAbortController?.abort();
  VisionExecutionStore.cancel();
  syncExecutionStateToLegacy();
  setStatus("运行已取消；当前算子返回后会停止继续调度。");
  updateRunModeUi();
}


async function runWorkflow(){
  if(debugRunBusy) return;
  const previousDebugSession = debugSessionId;
  if(previousDebugSession){
    resetLocalDebugState({ preserveLogs:true, preserveRender:true });
    VisionApi.resetDebugSession(previousDebugSession).catch(() => {});
  }
  const workflow = buildWorkflow();
  VisionExecutionStore.begin("full");
  syncExecutionStateToLegacy();
  updateRunModeUi();
  setStatus("运行中...");
  document.getElementById("taskCount").textContent = "1";
  if(previewCollapsed) togglePreviewPanel(false);
  clearRunLog("");
  appendRunLog("info", "正在建立实时运行通道...", `${workflow.nodes.length} 个节点 · ${workflow.edges.length} 条连线`);
  const controller = new AbortController();
  activeExecutionAbortController = controller;
  try{
    const data = await VisionApi.executeWorkflowStream(workflow, handleWorkflowLogEvent, { signal:controller.signal });
    renderPreviews(data.previews || [], data.batch || null);
    appendRunLog("success", "运行结果已同步到各节点下方", `共更新 ${(data.previews || []).length} 个节点结果`);
    if(data.mode === "batch" && data.batch){
      const batch = data.batch;
      setStatus(`批量运行完成：共 ${batch.total} 张，成功 ${batch.succeeded} 张，失败 ${batch.failed} 张。结果目录：${batch.output_dir}`);
      toast("批量处理完成", `成功 ${batch.succeeded} / ${batch.total}，失败 ${batch.failed}`, batch.failed === 0);
    }else{
      setStatus(`运行成功。执行顺序：${(data.order || []).join(" → ")}`);
      toast("运行成功", `已生成 ${(data.previews || []).length} 个节点结果`, true);
    }
  }catch(error){
    if(error?.name === "AbortError"){
      appendRunLog("warning", "整体运行已取消", "服务端将在当前算子返回后停止继续调度");
      setStatus("整体运行已取消。");
      return;
    }
    const message = error && error.message ? error.message : String(error);
    const payload = error?.payload || null;
    if(payload && Array.isArray(payload.previews)){
      renderPreviews(payload.previews || [], payload.batch || null);
      renderExecutionFailureSummary(payload);
      const failed = payload.failed_node;
      const executedText = (payload.executed_order || []).join(" → ") || "无";
      setStatus(`运行到节点 ${failed?.node_id || "未知"} 时失败。已完成：${executedText}。错误：${message}`);
      if(failed?.node_id){
        selectedNodeId = failed.node_id;
        selectedEdgeId = null;
        render();
      }
      toast("节点执行失败", `${failed?.node_id || "未知节点"}：${failed?.error || message}`);
    }else{
      setStatus(`运行失败：${message}`);
      appendRunLog("error", `运行失败：${message}`);
      toast("运行失败", message);
    }
  }finally{
    if(activeExecutionAbortController === controller) activeExecutionAbortController = null;
    VisionExecutionStore.patch({ busy:false, phase:"idle" });
    syncExecutionStateToLegacy();
    updateRunModeUi();
    document.getElementById("taskCount").textContent = "0";
  }
}

VisionExecutionStore.subscribe(() => updateRunModeUi());
