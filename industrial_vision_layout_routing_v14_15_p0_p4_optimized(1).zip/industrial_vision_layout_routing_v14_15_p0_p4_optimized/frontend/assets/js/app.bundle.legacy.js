let OPERATOR_META = {};
let OPERATOR_CATALOG = {};
let nodes = [];
let edges = [];
let nodeSeq = 1;
let selectedNodeId = null;
let selectedEdgeId = null;
let connectingSourceId = null;
let connectingSourceHandle = "out";
let connectDrag = null;
let pan = { x: -260, y: -120 };
let zoom = 0.82;
let previewCollapsed = false;
let nodeLibraryVisible = true;
let previewActionNodeId = null;
let colorPaletteNodeId = null;
let lightboxNodeId = null;
let workflowDocuments = [];
let activeWorkflowId = null;
let suppressDocumentSync = false;
let minimapTransform = null;
const collapsedOperatorGroups = new Set();
const collapsedLogicOperatorGroups = new Set();

const WORKSPACE_STORAGE_KEY = "vision_python_mvp_workspace_v1";
const fallbackStorage = new Map();
const nodePreviews = new Map();
const DEFAULT_NODE_COLOR = "#8d9298";
const NODE_COLORS = [
  "#8d9298", "#8a4b4d", "#8e5845", "#3f7149", "#4b4b7d",
  "#526b75", "#3d7374", "#70476c", "#8b6c37", "#151719",
];
const ICONS = { io:"⎋", color:"◐", filter:"≋", segment:"⌁", morph:"⬡", geo:"⟲", measure:"▤", custom:"✦", logic:"◇" };
const NODE_WIDTH = 340;

const viewport = document.getElementById("viewport");
const world = document.getElementById("world");
const nodeLayer = document.getElementById("nodeLayer");
const edgeLayer = document.getElementById("edgeLayer");
const statusEl = document.getElementById("status");
const paramPanel = document.getElementById("paramPanel");
const previewPanel = document.getElementById("previewPanel");
const previewWrap = document.getElementById("previewWrap");
const previewToggleText = document.getElementById("previewToggleText");

function storageGet(key){
  try{ return window.localStorage.getItem(key); }
  catch(error){ return fallbackStorage.has(key) ? fallbackStorage.get(key) : null; }
}
function storageSet(key, value){
  const serialized = String(value);
  try{ window.localStorage.setItem(key, serialized); }
  catch(error){ fallbackStorage.set(key, serialized); }
}
function cloneData(value){
  return JSON.parse(JSON.stringify(value));
}
function createWorkflowId(){
  if(window.crypto && typeof window.crypto.randomUUID === "function") return `wf_${window.crypto.randomUUID()}`;
  return `wf_${Date.now()}_${Math.random().toString(16).slice(2)}`;
}
function emptyWorkflow(){
  return { version:"2.1", nodes:[], edges:[] };
}
function demoWorkflowDefinition(){
  return {
    version:"2.1",
    nodes:[
      { id:"n1", type:"ReadImage", position:{ x:380, y:250 }, params:{ image_path:"" }, collapsed:false, color:DEFAULT_NODE_COLOR },
      { id:"n2", type:"ColorConvert", position:{ x:790, y:250 }, params:{ mode:"GRAY" }, collapsed:false, color:DEFAULT_NODE_COLOR },
      { id:"n3", type:"GaussianBlur", position:{ x:1200, y:250 }, params:{ ksize:5, sigma:0 }, collapsed:false, color:DEFAULT_NODE_COLOR },
      { id:"n4", type:"Canny", position:{ x:1610, y:250 }, params:{ threshold1:50, threshold2:150 }, collapsed:false, color:DEFAULT_NODE_COLOR },
      { id:"n5", type:"Display", position:{ x:2020, y:250 }, params:{}, collapsed:false, color:DEFAULT_NODE_COLOR },
    ],
    edges:[
      { id:"e1", source:"n1", sourceHandle:"out", target:"n2", targetHandle:"in" },
      { id:"e2", source:"n2", sourceHandle:"out", target:"n3", targetHandle:"in" },
      { id:"e3", source:"n3", sourceHandle:"out", target:"n4", targetHandle:"in" },
      { id:"e4", source:"n4", sourceHandle:"out", target:"n5", targetHandle:"in" },
    ],
  };
}
function workflowSignature(workflow){
  return JSON.stringify(workflow || emptyWorkflow());
}
function getActiveWorkflowDocument(){
  return workflowDocuments.find(documentInfo => documentInfo.id === activeWorkflowId) || null;
}
function nextWorkflowName(){
  const used = new Set(workflowDocuments.map(documentInfo => documentInfo.name));
  if(!used.has("Vision Workflow")) return "Vision Workflow";
  let index = 2;
  while(used.has(`Vision Workflow ${index}`)) index += 1;
  return `Vision Workflow ${index}`;
}
function createWorkflowDocument(workflow = emptyWorkflow(), options = {}){
  const name = options.name || nextWorkflowName();
  const normalizedWorkflow = cloneData(workflow);
  const saved = Boolean(options.saved);
  return {
    id:options.id || createWorkflowId(),
    name,
    workflow:normalizedWorkflow,
    savedSnapshot:saved ? workflowSignature(normalizedWorkflow) : (options.savedSnapshot || null),
    savedName:saved ? name : (options.savedName || null),
    dirty:!saved,
    view:options.view || { pan:{ x:-260, y:-120 }, zoom:.82, previewCollapsed:false, nodeLibraryVisible:true },
    selectedNodeId:options.selectedNodeId || null,
    runtimePreviews:[],
  };
}
function recomputeDocumentDirty(documentInfo){
  if(!documentInfo) return;
  documentInfo.dirty = !documentInfo.savedSnapshot
    || documentInfo.savedSnapshot !== workflowSignature(documentInfo.workflow)
    || documentInfo.savedName !== documentInfo.name;
}
function persistWorkspace(){
  try{
    const payload = {
      version:1,
      activeWorkflowId,
      documents:workflowDocuments.map(documentInfo => ({
        id:documentInfo.id,
        name:documentInfo.name,
        workflow:documentInfo.workflow,
        savedSnapshot:documentInfo.savedSnapshot,
        savedName:documentInfo.savedName,
        view:documentInfo.view,
        selectedNodeId:documentInfo.selectedNodeId,
      })),
    };
    storageSet(WORKSPACE_STORAGE_KEY, JSON.stringify(payload));
  }catch(error){
    console.warn("无法保存工作区状态", error);
  }
}
function captureActiveWorkflowDocument(recalculateDirty = true){
  if(suppressDocumentSync) return;
  const documentInfo = getActiveWorkflowDocument();
  if(!documentInfo) return;
  documentInfo.workflow = buildWorkflow();
  documentInfo.view = {
    pan:{ ...pan },
    zoom,
    previewCollapsed,
    nodeLibraryVisible,
  };
  documentInfo.selectedNodeId = selectedNodeId;
  documentInfo.runtimePreviews = Array.from(nodePreviews.values());
  if(recalculateDirty) recomputeDocumentDirty(documentInfo);
}
function commitActiveWorkflowChange(){
  captureActiveWorkflowDocument(true);
  renderWorkflowTabs();
  persistWorkspace();
}
function persistActiveWorkflowView(){
  captureActiveWorkflowDocument(false);
  persistWorkspace();
}
function renderWorkflowTabs(){
  const container = document.getElementById("workflowTabs");
  if(!container) return;
  container.innerHTML = "";
  workflowDocuments.forEach(documentInfo => {
    const tab = document.createElement("div");
    tab.className = `workflow-tab ${documentInfo.id === activeWorkflowId ? "active" : ""}`;
    tab.setAttribute("role", "tab");
    tab.setAttribute("aria-selected", String(documentInfo.id === activeWorkflowId));
    tab.dataset.workflowId = documentInfo.id;

    const main = document.createElement("button");
    main.type = "button";
    main.className = "workflow-tab-main";
    main.title = `${documentInfo.name} · ${documentInfo.dirty ? "未保存" : "已保存"}（双击重命名）`;
    const name = document.createElement("span");
    name.className = "workflow-tab-name";
    name.textContent = documentInfo.name;
    const dot = document.createElement("span");
    dot.className = `save-state-dot ${documentInfo.dirty ? "dirty" : "saved"}`;
    dot.title = documentInfo.dirty ? "有未保存修改" : "已保存";
    main.append(name, dot);
    main.addEventListener("click", () => switchWorkflow(documentInfo.id));
    main.addEventListener("dblclick", event => {
      event.preventDefault();
      renameWorkflow(documentInfo.id);
    });

    const close = document.createElement("button");
    close.type = "button";
    close.className = "workflow-tab-close";
    close.textContent = "×";
    close.title = "关闭工作流";
    close.setAttribute("aria-label", `关闭 ${documentInfo.name}`);
    close.addEventListener("click", event => {
      event.stopPropagation();
      closeWorkflow(documentInfo.id);
    });
    tab.append(main, close);
    container.appendChild(tab);
  });
  window.requestAnimationFrame(() => {
    container.querySelector(".workflow-tab.active")?.scrollIntoView({ block:"nearest", inline:"nearest" });
  });
}
function restoreWorkflowDocument(documentInfo){
  if(!documentInfo) return;
  suppressDocumentSync = true;
  try{
    closeImageLightbox();
    applyWorkflow(cloneData(documentInfo.workflow), { silent:true });
    pan = { ...(documentInfo.view?.pan || { x:-260, y:-120 }) };
    zoom = Number(documentInfo.view?.zoom) || .82;
    applyTransform();
    setNodeLibraryVisible(documentInfo.view?.nodeLibraryVisible !== false);
    togglePreviewPanel(Boolean(documentInfo.view?.previewCollapsed));
    selectedNodeId = nodes.some(node => node.id === documentInfo.selectedNodeId) ? documentInfo.selectedNodeId : (nodes[0]?.id || null);
    selectedEdgeId = null;
    nodePreviews.clear();
    (documentInfo.runtimePreviews || []).forEach(item => nodePreviews.set(item.node_id, item));
    if(documentInfo.runtimePreviews?.length) renderPreviews(documentInfo.runtimePreviews);
    else{
      previewPanel.innerHTML = '<div class="empty-preview">运行工作流后显示实时执行日志</div>';
      render();
    }
    setStatus(`当前工作流：${documentInfo.name}${documentInfo.dirty ? "（未保存）" : "（已保存）"}`);
  }finally{
    suppressDocumentSync = false;
  }
}
function switchWorkflow(workflowId){
  if(workflowId === activeWorkflowId) return;
  const target = workflowDocuments.find(documentInfo => documentInfo.id === workflowId);
  if(!target) return;
  captureActiveWorkflowDocument(true);
  activeWorkflowId = workflowId;
  restoreWorkflowDocument(target);
  renderWorkflowTabs();
  persistWorkspace();
}
function newWorkflow(){
  captureActiveWorkflowDocument(true);
  const documentInfo = createWorkflowDocument(emptyWorkflow());
  workflowDocuments.push(documentInfo);
  activeWorkflowId = documentInfo.id;
  restoreWorkflowDocument(documentInfo);
  renderWorkflowTabs();
  persistWorkspace();
  toast("已新建工作流", documentInfo.name, true);
}
function closeWorkflow(workflowId){
  const index = workflowDocuments.findIndex(documentInfo => documentInfo.id === workflowId);
  if(index < 0) return;
  const documentInfo = workflowDocuments[index];
  if(documentInfo.dirty && !window.confirm(`“${documentInfo.name}”存在未保存修改，确定关闭吗？`)) return;
  const wasActive = workflowId === activeWorkflowId;
  workflowDocuments.splice(index, 1);
  if(!workflowDocuments.length){
    const replacement = createWorkflowDocument(emptyWorkflow());
    workflowDocuments.push(replacement);
    activeWorkflowId = replacement.id;
    restoreWorkflowDocument(replacement);
  }else if(wasActive){
    const replacement = workflowDocuments[Math.min(index, workflowDocuments.length - 1)];
    activeWorkflowId = replacement.id;
    restoreWorkflowDocument(replacement);
  }
  renderWorkflowTabs();
  persistWorkspace();
}
function renameWorkflow(workflowId){
  const documentInfo = workflowDocuments.find(item => item.id === workflowId);
  if(!documentInfo) return;
  const nextName = window.prompt("请输入工作流名称", documentInfo.name);
  if(nextName === null) return;
  const trimmed = nextName.trim();
  if(!trimmed || trimmed === documentInfo.name) return;
  documentInfo.name = trimmed;
  recomputeDocumentDirty(documentInfo);
  renderWorkflowTabs();
  persistWorkspace();
  setStatus(`工作流已重命名为：${trimmed}`);
}
function initializeWorkspace(){
  let restored = false;
  try{
    const raw = storageGet(WORKSPACE_STORAGE_KEY);
    if(raw){
      const payload = JSON.parse(raw);
      workflowDocuments = (payload.documents || []).map(rawDocument => {
        const documentInfo = createWorkflowDocument(rawDocument.workflow || emptyWorkflow(), {
          id:rawDocument.id,
          name:rawDocument.name || "Vision Workflow",
          savedSnapshot:rawDocument.savedSnapshot || null,
          savedName:rawDocument.savedName || null,
          view:rawDocument.view,
          selectedNodeId:rawDocument.selectedNodeId,
        });
        recomputeDocumentDirty(documentInfo);
        return documentInfo;
      });
      if(workflowDocuments.length){
        activeWorkflowId = workflowDocuments.some(item => item.id === payload.activeWorkflowId)
          ? payload.activeWorkflowId
          : workflowDocuments[0].id;
        restored = true;
      }
    }
  }catch(error){
    console.warn("工作区恢复失败", error);
  }

  if(!restored){
    const legacyRaw = storageGet("vision_python_mvp_workflow_v3") || storageGet("vision_python_mvp_workflow_v2");
    if(legacyRaw){
      try{
        const legacyDocument = createWorkflowDocument(JSON.parse(legacyRaw), { name:"Vision Workflow", saved:true });
        workflowDocuments = [legacyDocument];
        activeWorkflowId = legacyDocument.id;
        restored = true;
      }catch(error){
        console.warn("旧版流程恢复失败", error);
      }
    }
  }

  if(!restored){
    const firstDocument = createWorkflowDocument(demoWorkflowDefinition(), { name:"Vision Workflow" });
    workflowDocuments = [firstDocument];
    activeWorkflowId = firstDocument.id;
  }
  restoreWorkflowDocument(getActiveWorkflowDocument());
  renderWorkflowTabs();
  persistWorkspace();
}

async function initOperators(){
  try{
    const data = await VisionApi.getOperators();
    OPERATOR_META = data.operators || {};
    OPERATOR_CATALOG = data.catalog || {};
    renderOperatorPanel();
    applyTransform();
    initializeWorkspace();
  }catch(error){
    toast("初始化失败", error.message || String(error));
    setStatus(`初始化失败：${error.message || error}`);
  }
}

function renderOperatorPanel(){
  renderCategoryOperatorPanel({
    category:"图像",
    panelId:"operatorPanel",
    searchId:"opSearch",
    collapsedGroups:collapsedOperatorGroups,
  });
  renderCategoryOperatorPanel({
    category:"逻辑",
    panelId:"logicOperatorPanel",
    searchId:"logicSearch",
    collapsedGroups:collapsedLogicOperatorGroups,
  });
}

function renderCategoryOperatorPanel({ category, panelId, searchId, collapsedGroups }){
  const panel = document.getElementById(panelId);
  if(!panel) return;
  panel.innerHTML = "";
  const search = document.getElementById(searchId);
  const query = (search?.value || "").trim().toLowerCase();
  const groups = OPERATOR_CATALOG[category] || [];
  groups.forEach(groupInfo => {
    const matched = groupInfo.items.filter(type => {
      const meta = OPERATOR_META[type] || {};
      if(meta.hidden) return false;
      const haystack = `${type} ${meta.label || ""} ${meta.description || ""} ${groupInfo.group}`.toLowerCase();
      return !query || haystack.includes(query);
    });
    if(!matched.length) return;

    const groupKey = `${category}:${groupInfo.group}`;
    const group = document.createElement("div");
    group.className = `op-group${collapsedGroups.has(groupKey) ? " closed" : ""}`;
    const title = document.createElement("div");
    title.className = "group-title";
    title.setAttribute("role", "button");
    title.setAttribute("tabindex", "0");
    title.setAttribute("aria-expanded", String(!collapsedGroups.has(groupKey)));
    title.innerHTML = `<span class="chev">▾</span>${escapeHtml(groupInfo.group)}<span style="color:#707b8d;font-weight:700">${matched.length}</span>`;
    const toggleGroup = () => {
      if(collapsedGroups.has(groupKey)) collapsedGroups.delete(groupKey);
      else collapsedGroups.add(groupKey);
      group.classList.toggle("closed", collapsedGroups.has(groupKey));
      title.setAttribute("aria-expanded", String(!collapsedGroups.has(groupKey)));
    };
    title.onclick = toggleGroup;
    title.onkeydown = event => {
      if(event.key === "Enter" || event.key === " "){
        event.preventDefault();
        toggleGroup();
      }
    };

    const ops = document.createElement("div");
    ops.className = "ops";
    matched.forEach(type => {
      const meta = OPERATOR_META[type];
      const op = document.createElement("div");
      op.className = `op ${category === "逻辑" ? "logic-op" : ""}`;
      op.draggable = true;
      op.dataset.type = type;
      op.innerHTML = `<div class="op-icon" style="background:${kindColor(meta.kind)}">${ICONS[meta.kind] || "□"}</div><div><div class="op-name">${escapeHtml(meta.label)}</div><div class="op-desc">${escapeHtml(meta.description || type)}</div></div><div class="op-type">${escapeHtml(type)}</div>`;
      op.ondragstart = event => event.dataTransfer.setData("operator/type", type);
      op.ondblclick = () => addNode(type, 460 + nodes.length * 28, 240 + nodes.length * 22);
      ops.appendChild(op);
    });
    group.append(title, ops);
    panel.appendChild(group);
  });
}

function kindColor(kind){
  return { io:"#6c7177", color:"#555987", filter:"#406c88", segment:"#80604a", morph:"#47705f", geo:"#72547f", measure:"#7a4c59", custom:"#576b7a", logic:"#6b5c91" }[kind] || "#555a61";
}

function setNodeLibraryVisible(visible){
  nodeLibraryVisible = Boolean(visible);
  const main = document.querySelector(".main");
  const library = document.getElementById("nodeLibrary");
  const toggle = document.getElementById("nodeLibraryToggle");
  main.classList.toggle("nodes-panel-hidden", !nodeLibraryVisible);
  library.setAttribute("aria-hidden", String(!nodeLibraryVisible));
  toggle.classList.toggle("active", nodeLibraryVisible);
  toggle.setAttribute("aria-expanded", String(nodeLibraryVisible));
  toggle.title = nodeLibraryVisible ? "隐藏节点库" : "显示节点库";
  window.requestAnimationFrame(updateMinimap);
  if(!suppressDocumentSync) persistActiveWorkflowView();
}
function toggleNodeLibrary(){ setNodeLibraryVisible(!nodeLibraryVisible); }

function collapseAllOperatorGroups(){
  (OPERATOR_CATALOG["图像"] || []).forEach(groupInfo => collapsedOperatorGroups.add(`图像:${groupInfo.group}`));
  renderOperatorPanel();
  setStatus("已按类别折叠图像节点库");
}
function expandAllOperatorGroups(){
  collapsedOperatorGroups.clear();
  renderOperatorPanel();
  setStatus("已展开图像节点库中的全部类别");
}
function collapseAllLogicOperatorGroups(){
  (OPERATOR_CATALOG["逻辑"] || []).forEach(groupInfo => collapsedLogicOperatorGroups.add(`逻辑:${groupInfo.group}`));
  renderOperatorPanel();
  setStatus("已按类别折叠逻辑节点库");
}
function expandAllLogicOperatorGroups(){
  collapsedLogicOperatorGroups.clear();
  renderOperatorPanel();
  setStatus("已展开逻辑节点库中的全部类别");
}

function defaultParams(type){
  return JSON.parse(JSON.stringify((OPERATOR_META[type] && OPERATOR_META[type].params) || {}));
}

function normalizeNodeType(type, params = {}){
  if(type === "Gray") return { type:"ColorConvert", params:{ ...params, mode:"GRAY" } };
  if(type === "BGR2RGB") return { type:"ColorConvert", params:{ ...params, mode:"RGB" } };
  return { type, params };
}

function addNode(type, x, y){
  const normalized = normalizeNodeType(type, defaultParams(type));
  if(!OPERATOR_META[normalized.type]){
    toast("不能添加节点", `${type} 尚未实现`);
    return;
  }
  const id = `n${nodeSeq++}`;
  nodes.push({
    id,
    type:normalized.type,
    position:{ x:Math.round(x), y:Math.round(y) },
    params:Object.keys(normalized.params).length ? normalized.params : defaultParams(normalized.type),
    collapsed:false,
    color:DEFAULT_NODE_COLOR,
  });
  selectedNodeId = id;
  selectedEdgeId = null;
  colorPaletteNodeId = null;
  render();
  commitActiveWorkflowChange();
  setStatus(`已添加节点：${id} · ${OPERATOR_META[normalized.type].label}`);
}

function clampZoom(value){ return Math.min(2.6, Math.max(0.18, value)); }
function applyTransform(){
  world.style.transform = `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`;
  document.getElementById("zoomLabel").textContent = `${Math.round(zoom * 100)}%`;
  const small = 20 * zoom;
  const large = 100 * zoom;
  viewport.style.backgroundSize = `${small}px ${small}px, ${small}px ${small}px, ${large}px ${large}px, ${large}px ${large}px`;
  viewport.style.backgroundPosition = `${pan.x}px ${pan.y}px, ${pan.x}px ${pan.y}px, ${pan.x}px ${pan.y}px, ${pan.x}px ${pan.y}px`;
  updateMinimap();
}
function screenToWorld(clientX, clientY){
  const rect = viewport.getBoundingClientRect();
  return { x:(clientX - rect.left - pan.x) / zoom, y:(clientY - rect.top - pan.y) / zoom, sx:clientX - rect.left, sy:clientY - rect.top };
}
function setZoom(value, center){
  const next = clampZoom(value);
  if(center){
    pan.x = center.sx - center.x * next;
    pan.y = center.sy - center.y * next;
  }
  zoom = next;
  applyTransform();
  persistActiveWorkflowView();
}
function zoomBy(delta, clientX, clientY){
  const center = screenToWorld(clientX, clientY);
  setZoom(zoom * (delta > 0 ? 1.1 : 1 / 1.1), center);
}
function isCanvasEmptyTarget(target){
  if(!target) return false;
  if(target.closest && target.closest(".node,.port,.canvas-toolbar,.bottom-controls,.toast,button,input,label,textarea,select")) return false;
  return target === viewport || target === world || target === nodeLayer || target === edgeLayer || target.tagName === "svg" || target.tagName === "path";
}

viewport.addEventListener("wheel", event => {
  event.preventDefault();
  zoomBy(event.deltaY < 0 ? 1 : -1, event.clientX, event.clientY);
}, { passive:false });
viewport.addEventListener("dragover", event => event.preventDefault());
viewport.addEventListener("drop", event => {
  event.preventDefault();
  const type = event.dataTransfer.getData("operator/type");
  if(!type) return;
  const point = screenToWorld(event.clientX, event.clientY);
  addNode(type, point.x, point.y);
});
viewport.addEventListener("mousedown", event => {
  if(event.button !== 0 || !isCanvasEmptyTarget(event.target)) return;
  event.preventDefault();
  selectedNodeId = null;
  selectedEdgeId = null;
  previewActionNodeId = null;
  colorPaletteNodeId = null;
  render();
  const startX = event.clientX;
  const startY = event.clientY;
  const start = { ...pan };
  viewport.classList.add("panning");
  function move(moveEvent){
    pan.x = start.x + moveEvent.clientX - startX;
    pan.y = start.y + moveEvent.clientY - startY;
    applyTransform();
  }
  function up(){
    viewport.classList.remove("panning");
    window.removeEventListener("mousemove", move);
    window.removeEventListener("mouseup", up);
    persistActiveWorkflowView();
  }
  window.addEventListener("mousemove", move);
  window.addEventListener("mouseup", up);
});

function render(){
  renderNodes();
  renderEdges();
  renderParams();
  updateMinimap();
}

function nodeInputPorts(meta){
  if(Array.isArray(meta?.inputs)) return meta.inputs.map((port, index) => ({
    handle:String(port.handle || `in${index + 1}`),
    label:String(port.label || port.handle || "输入"),
    type:String(port.type || "any"),
    required:port.required !== false,
  }));
  return meta?.has_input ? [{ handle:"in", label:"图像", type:"image", required:true }] : [];
}
function nodeOutputPorts(meta){
  if(Array.isArray(meta?.outputs)) return meta.outputs.map((port, index) => ({
    handle:String(port.handle || `out${index + 1}`),
    label:String(port.label || port.handle || "输出"),
    type:String(port.type || "any"),
  }));
  return meta?.has_output ? [{ handle:"out", label:"图像", type:"image" }] : [];
}
function portTypeClass(type){
  const normalized = String(type || "any").toLowerCase();
  return ["image", "number", "boolean", "text", "list", "any"].includes(normalized) ? normalized : "any";
}
function portRows(meta){ return Math.max(1, nodeInputPorts(meta).length, nodeOutputPorts(meta).length); }
function portTop(index){ return 70 + index * 31; }
function renderNodePortsHtml(meta){
  const inputs = nodeInputPorts(meta);
  const outputs = nodeOutputPorts(meta);
  const rows = Math.max(inputs.length, outputs.length, 1);
  const bodyRows = [];
  const ports = [];
  for(let index = 0; index < rows; index += 1){
    const input = inputs[index];
    const output = outputs[index];
    bodyRows.push(`<div class="node-port-row"><span>${input ? escapeHtml(input.label) : ""}</span><span>${output ? escapeHtml(output.label) : ""}</span></div>`);
    if(input){
      ports.push(`<div class="port in ${portTypeClass(input.type)}" data-handle="${escapeHtml(input.handle)}" data-port-index="${index}" data-port-type="${escapeHtml(input.type)}" style="top:${portTop(index)}px" title="输入：${escapeHtml(input.label)}${input.required ? "" : "（可选）"}"></div>`);
    }
    if(output){
      ports.push(`<div class="port out ${portTypeClass(output.type)}" data-handle="${escapeHtml(output.handle)}" data-port-index="${index}" data-port-type="${escapeHtml(output.type)}" style="top:${portTop(index)}px" title="输出：${escapeHtml(output.label)}"></div>`);
    }
  }
  return { rowsHtml:`<div class="node-port-list">${bodyRows.join("")}</div>`, portsHtml:ports.join("") };
}
function nodeHeight(node){
  if(node.collapsed) return 58;
  const meta = OPERATOR_META[node.type] || { params:{} };
  const count = Object.keys(meta.params || {}).length;
  return 170 + portRows(meta) * 31 + Math.max(1, count) * 48 + 206;
}

function renderNodes(){
  nodeLayer.innerHTML = "";
  nodes.forEach(node => {
    const meta = OPERATOR_META[node.type] || { label:node.type, params:{}, has_input:true, has_output:true };
    const selected = selectedNodeId === node.id;
    const preview = nodePreviews.get(node.id);
    const accent = safeColor(node.color || DEFAULT_NODE_COLOR);
    const portMarkup = renderNodePortsHtml(meta);
    const element = document.createElement("div");
    const executionClass = preview?.status === "error" ? "execution-error" : preview?.status === "success" ? "execution-success" : "";
    element.className = `node ${selected ? "selected" : ""} ${node.collapsed ? "collapsed" : ""} ${executionClass}`;
    element.dataset.id = node.id;
    element.style.left = `${node.position.x}px`;
    element.style.top = `${node.position.y}px`;
    element.style.setProperty("--node-accent", accent);

    element.innerHTML = `
      ${renderNodeToolbarHtml(node)}
      ${selected && colorPaletteNodeId === node.id ? renderColorPaletteHtml(node) : ""}
      <div class="node-head">
        <div class="node-title"><button class="fold-btn" type="button" title="折叠/展开">▾</button><span>${escapeHtml(meta.label)}</span></div>
        <div class="node-badge">${escapeHtml(node.id)}</div>
      </div>
      ${portMarkup.portsHtml}
      <div class="node-body">
        ${portMarkup.rowsHtml}
        <div class="node-param-list"></div>
        <div class="node-effect ${nodeResultType(node, preview)}-result">
          <div class="node-effect-title"><span>${resultTypeLabel(nodeResultType(node, preview), node)}</span><span class="${preview ? (preview.status === "error" ? "result-error" : "result-ready") : ""}">${preview ? (preview.status === "error" ? "失败" : "已生成") : "等待运行"}</span></div>
          ${renderNodePreviewHtml(node, preview)}
        </div>
      </div>`;

    attachNodeEvents(element, node, meta);
    renderNodeParameterControls(element.querySelector(".node-param-list"), node, meta);
    nodeLayer.appendChild(element);
  });
}

function renderNodeToolbarHtml(node){
  return `<div class="node-toolbar" data-stop-node-drag>
    <button type="button" data-node-action="delete" title="删除节点" aria-label="删除节点">🗑</button>
    <span class="divider"></span>
    <button type="button" data-node-action="info" title="查看节点信息">ⓘ</button>
    <button type="button" class="node-color-button" data-node-action="color" title="更改节点配色">●</button>
    <button type="button" data-node-action="duplicate" title="复制节点">⧉</button>
    <button type="button" data-node-action="collapse" title="${node.collapsed ? "展开节点" : "折叠节点"}">↕</button>
  </div>`;
}

function renderColorPaletteHtml(node){
  const current = safeColor(node.color || DEFAULT_NODE_COLOR);
  return `<div class="node-color-palette" data-stop-node-drag>${NODE_COLORS.map(color => `<button type="button" class="node-color-swatch ${color === current ? "active" : ""}" style="background:${color}" data-node-color="${color}" title="使用 ${color}"></button>`).join("")}</div>`;
}

function previewMetricEntries(preview){
  if(!preview || !preview.metrics || typeof preview.metrics !== "object" || Array.isArray(preview.metrics)) return [];
  return Object.entries(preview.metrics);
}

function nodeResultType(node, preview){
  if(preview?.result_type === "error" || preview?.status === "error") return "error";
  const hasImage = Boolean(preview?.image);
  const hasMetrics = previewMetricEntries(preview).length > 0;
  if(hasImage && hasMetrics) return "combined";
  if(hasMetrics || preview?.result_type === "metrics") return "metrics";
  if(hasImage || preview?.result_type === "image") return "image";
  const meta = OPERATOR_META[node.type] || {};
  return meta.result_type === "metrics" || meta.kind === "logic" ? "metrics" : "image";
}

function resultTypeLabel(resultType, node = null){
  const meta = node ? (OPERATOR_META[node.type] || {}) : {};
  if(resultType === "error") return "执行错误";
  if(resultType === "combined") return meta.kind === "logic" ? "图像与逻辑结果" : "图像与数值结果";
  if(resultType === "metrics") return meta.kind === "logic" ? "逻辑结果" : "数值结果";
  return "图像结果";
}

function renderNodeErrorHtml(preview){
  const message = preview?.error || "节点执行失败";
  return `<div class="node-error-frame"><div class="node-error-title">该节点执行失败</div><div class="node-error-message">${escapeHtml(message)}</div></div>`;
}

function humanizeMetricName(name){
  const labels = {
    mean_brightness:"平均亮度",
    brightness_std:"亮度标准差",
    contour_count:"轮廓数量",
    contour_area_total:"轮廓总面积",
    contour_area_max:"最大轮廓面积",
  };
  return labels[name] || String(name).replace(/[_-]+/g, " ");
}

function formatMetricValue(value){
  if(typeof value === "number"){
    if(!Number.isFinite(value)) return String(value);
    return Number.isInteger(value) ? String(value) : value.toFixed(4).replace(/0+$/, "").replace(/\.$/, "");
  }
  if(typeof value === "boolean") return value ? "是" : "否";
  if(value === null || value === undefined) return "—";
  if(typeof value === "object") return JSON.stringify(value);
  return String(value);
}

function renderMetricResultHtml(preview, compact = false){
  const entries = previewMetricEntries(preview);
  const frameClass = compact ? "preview-metric-frame" : "node-metric-frame";
  if(!entries.length){
    return `<div class="${frameClass}"><div class="node-effect-empty">运行流程后，这里会显示数值结果</div></div>`;
  }
  const rows = entries.map(([key, value]) => `<div class="metric-row"><span>${escapeHtml(humanizeMetricName(key))}</span><strong>${escapeHtml(formatMetricValue(value))}</strong></div>`).join("");
  return `<div class="${frameClass}"><div class="metric-list">${rows}</div></div>`;
}

function renderImageResultHtml(node, preview){
  if(!preview || !preview.image){
    return `<div class="node-effect-frame" data-preview-node="${escapeHtml(node.id)}"><div class="node-effect-empty">运行流程后，这里会显示当前节点的完整缩略图</div></div>`;
  }
  const showActions = previewActionNodeId === node.id;
  return `<div class="node-effect-frame" data-preview-node="${escapeHtml(node.id)}" title="点击显示图片操作">
    <img src="${preview.image}" alt="${escapeHtml(preview.label || node.id)} 的处理结果" />
    <span class="node-effect-hint">点击显示下载和放大按钮</span>
    ${showActions ? `<div class="node-effect-actions" data-stop-node-drag>
      <button type="button" data-preview-action="download">⇩ 下载</button>
      <button type="button" class="primary" data-preview-action="zoom">⛶ 放大</button>
    </div>` : ""}
  </div>`;
}

function renderNodePreviewHtml(node, preview){
  const resultType = nodeResultType(node, preview);
  if(resultType === "error") return renderNodeErrorHtml(preview);
  if(resultType === "combined"){
    return `<div class="node-combined-result">${renderImageResultHtml(node, preview)}${renderMetricResultHtml(preview)}</div>`;
  }
  if(resultType === "metrics") return renderMetricResultHtml(preview);
  return renderImageResultHtml(node, preview);
}

function attachNodeEvents(element, node, meta){
  element.addEventListener("mousedown", event => {
    if(event.target.closest("input,select,button,.node-effect-frame,.node-color-palette")) return;
    if(selectedNodeId !== node.id){
      selectedNodeId = node.id;
      selectedEdgeId = null;
      colorPaletteNodeId = null;
      render();
    }
  });

  const head = element.querySelector(".node-head");
  head.addEventListener("mousedown", event => startDragNode(event, node.id));
  element.querySelector(".fold-btn").addEventListener("click", event => {
    event.stopPropagation();
    node.collapsed = !node.collapsed;
    render();
    commitActiveWorkflowChange();
  });

  element.querySelectorAll("[data-node-action]").forEach(button => {
    button.addEventListener("mousedown", event => event.stopPropagation());
    button.addEventListener("click", event => {
      event.stopPropagation();
      const action = button.dataset.nodeAction;
      if(action === "delete") deleteNode(node.id);
      else if(action === "info"){
        setStatus(`${node.id} · ${meta.label}：${meta.description || "暂无说明"}`);
        toast("节点说明", meta.description || meta.label, true);
      }else if(action === "color"){
        colorPaletteNodeId = colorPaletteNodeId === node.id ? null : node.id;
        renderNodes();
      }else if(action === "duplicate") duplicateNode(node.id);
      else if(action === "collapse"){
        node.collapsed = !node.collapsed;
        render();
        commitActiveWorkflowChange();
      }
    });
  });

  element.querySelectorAll("[data-node-color]").forEach(button => {
    button.addEventListener("mousedown", event => event.stopPropagation());
    button.addEventListener("click", event => {
      event.stopPropagation();
      node.color = safeColor(button.dataset.nodeColor);
      colorPaletteNodeId = null;
      renderNodes();
      commitActiveWorkflowChange();
      setStatus(`已更新 ${node.id} 的节点配色`);
    });
  });

  const previewFrame = element.querySelector(".node-effect-frame");
  if(previewFrame){
    previewFrame.addEventListener("mousedown", event => event.stopPropagation());
    previewFrame.addEventListener("click", event => {
      event.stopPropagation();
      selectedNodeId = node.id;
      selectedEdgeId = null;
      if(!nodePreviews.has(node.id)){
        render();
        return;
      }
      previewActionNodeId = previewActionNodeId === node.id ? null : node.id;
      renderNodes();
      renderParams();
    });
  }
  const downloadButton = element.querySelector('[data-preview-action="download"]');
  if(downloadButton){
    downloadButton.addEventListener("click", event => {
      event.stopPropagation();
      downloadNodePreview(node.id);
    });
  }
  const zoomButton = element.querySelector('[data-preview-action="zoom"]');
  if(zoomButton){
    zoomButton.addEventListener("click", event => {
      event.stopPropagation();
      openImageLightbox(node.id);
    });
  }

  element.querySelectorAll(".port.out").forEach(outPort => {
    const handle = outPort.dataset.handle || "out";
    outPort.onclick = event => { event.stopPropagation(); startConnect(node.id, handle); };
    outPort.addEventListener("mousedown", event => startConnectDrag(event, node.id, handle));
  });
  element.querySelectorAll(".port.in").forEach(inPort => {
    const handle = inPort.dataset.handle || "in";
    inPort.onclick = event => {
      event.stopPropagation();
      if(connectingSourceId) finishConnect(node.id, handle);
      else selectIncomingEdge(node.id, handle);
    };
    inPort.addEventListener("mousedown", event => {
      if(connectingSourceId){
        event.stopPropagation();
        finishConnect(node.id, handle);
      }
    });
  });
}

function renderNodeParameterControls(container, node, meta){
  const keys = Object.keys(meta.params || {});
  if(!keys.length){
    const empty = document.createElement("div");
    empty.className = "node-no-params";
    empty.textContent = "该节点没有可调参数";
    container.appendChild(empty);
    return;
  }

  keys.forEach(key => {
    const schema = (meta.param_schema || {})[key] || {};
    const value = node.params[key] ?? meta.params[key];
    const row = document.createElement("div");
    row.className = "node-param-row";
    const label = document.createElement("div");
    label.className = "node-param-label";
    label.textContent = schema.label || humanizeParam(key);
    label.title = schema.label || key;
    const control = document.createElement("div");
    control.className = "node-param-control";

    if(schema.type === "select"){
      const select = document.createElement("select");
      select.className = "node-param-select";
      (schema.options || []).forEach(optionInfo => {
        const option = document.createElement("option");
        option.value = optionInfo.value;
        option.textContent = optionInfo.label;
        option.selected = String(optionInfo.value) === String(value);
        select.appendChild(option);
      });
      select.addEventListener("mousedown", event => selectNodeWithoutRerender(node.id, event));
      select.onchange = () => updateNodeParam(node.id, key, select.value);
      control.appendChild(select);
    }else if(schema.type === "text" || typeof value === "string"){
      const input = document.createElement("input");
      input.className = "node-param-input";
      input.type = "text";
      input.value = value ?? "";
      input.placeholder = schema.placeholder || "";
      input.addEventListener("mousedown", event => selectNodeWithoutRerender(node.id, event));
      input.onchange = () => updateNodeParam(node.id, key, input.value);
      control.appendChild(input);
    }else{
      const stepper = document.createElement("div");
      stepper.className = "node-param-stepper";
      const minus = document.createElement("button");
      minus.type = "button";
      minus.textContent = "−";
      const input = document.createElement("input");
      input.type = "number";
      input.value = value;
      input.step = numericStep(value, key);
      const plus = document.createElement("button");
      plus.type = "button";
      plus.textContent = "+";
      [minus, input, plus].forEach(item => item.addEventListener("mousedown", event => selectNodeWithoutRerender(node.id, event)));
      minus.onclick = event => {
        event.stopPropagation();
        const step = Number(input.step) || 1;
        updateNodeParam(node.id, key, numberValue(value) - step);
      };
      plus.onclick = event => {
        event.stopPropagation();
        const step = Number(input.step) || 1;
        updateNodeParam(node.id, key, numberValue(value) + step);
      };
      input.onchange = () => updateNodeParam(node.id, key, Number(input.value));
      stepper.append(minus, input, plus);
      control.appendChild(stepper);
    }

    row.append(label, control);
    if(schema.help){
      const help = document.createElement("div");
      help.className = "node-param-help";
      help.textContent = schema.help;
      row.appendChild(help);
    }
    container.appendChild(row);
  });
}

function selectNodeWithoutRerender(nodeId, event){
  event.stopPropagation();
  selectedNodeId = nodeId;
  selectedEdgeId = null;
  colorPaletteNodeId = null;
  document.querySelectorAll(".node").forEach(element => element.classList.toggle("selected", element.dataset.id === nodeId));
  renderParams();
}

function humanizeParam(key){
  const names = {
    image_path:"图片路径", mode:"转换模式", ksize:"核尺寸", sigma:"Sigma", clip_limit:"裁剪限制",
    tile_grid:"网格大小", d:"邻域直径", sigma_color:"颜色 Sigma", sigma_space:"空间 Sigma",
    amount:"锐化强度", threshold:"阈值", max_value:"最大值", block_size:"块大小", c:"常数 C",
    threshold1:"低阈值", threshold2:"高阈值", dx:"X 阶数", dy:"Y 阶数", iterations:"迭代次数",
    scale_percent:"缩放百分比", flip_code:"翻转模式", direction:"旋转方向", min_area:"最小面积",
  };
  return names[key] || key;
}
function numericStep(value, key){
  if(["sigma", "clip_limit", "amount", "min_area"].includes(key) || !Number.isInteger(Number(value))) return "0.1";
  return "1";
}
function numberValue(value){
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : 0;
}
function updateNodeParam(nodeId, key, value){
  const node = nodes.find(item => item.id === nodeId);
  if(!node) return;
  node.params[key] = value;
  invalidateNodeAndDownstreamPreviews(nodeId);
  selectedNodeId = nodeId;
  selectedEdgeId = null;
  render();
  commitActiveWorkflowChange();
  setStatus(`已更新参数：${node.id}.${key} = ${value}；请重新运行流程`);
}
function invalidateNodeAndDownstreamPreviews(nodeId){
  const pending = [nodeId];
  const affected = new Set();
  while(pending.length){
    const current = pending.shift();
    if(affected.has(current)) continue;
    affected.add(current);
    edges.filter(edge => edge.source === current).forEach(edge => pending.push(edge.target));
  }
  affected.forEach(id => nodePreviews.delete(id));
  if(affected.has(previewActionNodeId)) previewActionNodeId = null;
  if(affected.has(lightboxNodeId)) closeImageLightbox();
}

function findPortDefinition(nodeId, direction, handle){
  const node = nodes.find(item => item.id === nodeId);
  const meta = OPERATOR_META[node?.type] || {};
  const ports = direction === "out" ? nodeOutputPorts(meta) : nodeInputPorts(meta);
  return ports.find(port => port.handle === handle) || null;
}
function portsAreCompatible(sourceType, targetType){
  const source = String(sourceType || "any").toLowerCase();
  const target = String(targetType || "any").toLowerCase();
  if(source === "any" || target === "any") return true;
  if(source === target) return true;
  return source === "number" && target === "boolean";
}
function startConnect(id, handle = "out"){
  const sourcePort = findPortDefinition(id, "out", handle);
  if(!sourcePort){ toast("连线失败", `源节点不存在输出端口：${handle}`); return; }
  connectingSourceId = id;
  connectingSourceHandle = handle;
  selectedEdgeId = null;
  renderEdges();
  setStatus(`请选择目标节点输入端口：${id}.${handle} → ?`);
}
function startConnectDrag(event, id, handle = "out"){
  if(event.button !== 0) return;
  event.stopPropagation();
  event.preventDefault();
  startConnect(id, handle);
  connectDrag = { source:id, sourceHandle:handle };
  drawTempEdge(event.clientX, event.clientY);
  function move(moveEvent){ drawTempEdge(moveEvent.clientX, moveEvent.clientY); }
  function up(upEvent){
    window.removeEventListener("mousemove", move);
    window.removeEventListener("mouseup", up);
    clearTempEdge();
    const target = document.elementFromPoint(upEvent.clientX, upEvent.clientY);
    const port = target && target.closest ? target.closest(".port.in") : null;
    const nodeElement = port && port.closest ? port.closest(".node") : null;
    const targetId = nodeElement ? nodeElement.dataset.id : null;
    const targetHandle = port?.dataset.handle || "in";
    if(targetId) finishConnect(targetId, targetHandle);
    else setStatus(`已选择源端口：${id}.${handle}，请点击目标节点输入端口`);
    connectDrag = null;
  }
  window.addEventListener("mousemove", move);
  window.addEventListener("mouseup", up);
}
function finishConnect(targetId, targetHandle = "in"){
  if(!connectingSourceId || connectingSourceId === targetId) return;
  const sourcePort = findPortDefinition(connectingSourceId, "out", connectingSourceHandle);
  const targetPort = findPortDefinition(targetId, "in", targetHandle);
  if(!sourcePort){ toast("连线失败", "源输出端口不存在"); connectingSourceId = null; return; }
  if(!targetPort){ toast("连线失败", "目标输入端口不存在"); connectingSourceId = null; return; }
  if(!portsAreCompatible(sourcePort.type, targetPort.type)){
    toast("端口类型不兼容", `${sourcePort.label}（${sourcePort.type}）不能连接到 ${targetPort.label}（${targetPort.type}）`);
    connectingSourceId = null;
    connectingSourceHandle = "out";
    clearTempEdge();
    return;
  }
  edges = edges.filter(edge => !(edge.target === targetId && edge.targetHandle === targetHandle));
  const edgeId = `e${Date.now()}_${Math.random().toString(16).slice(2, 7)}`;
  edges.push({
    id:edgeId,
    source:connectingSourceId,
    sourceHandle:connectingSourceHandle,
    target:targetId,
    targetHandle,
  });
  const message = `${connectingSourceId}.${connectingSourceHandle} → ${targetId}.${targetHandle}`;
  invalidateNodeAndDownstreamPreviews(targetId);
  connectingSourceId = null;
  connectingSourceHandle = "out";
  selectedEdgeId = edgeId;
  selectedNodeId = null;
  render();
  commitActiveWorkflowChange();
  setStatus(`已创建连线：${message}`);
  toast("已创建连线", message, true);
}

function startDragNode(event, nodeId){
  if(event.button !== 0 || event.target.closest("button,input,select")) return;
  event.stopPropagation();
  selectedNodeId = nodeId;
  selectedEdgeId = null;
  colorPaletteNodeId = null;
  document.querySelectorAll(".node").forEach(element => element.classList.toggle("selected", element.dataset.id === nodeId));
  renderParams();
  const node = nodes.find(item => item.id === nodeId);
  const startX = event.clientX;
  const startY = event.clientY;
  const start = { ...node.position };
  function move(moveEvent){
    node.position.x = Math.round(start.x + (moveEvent.clientX - startX) / zoom);
    node.position.y = Math.round(start.y + (moveEvent.clientY - startY) / zoom);
    renderNodes();
    renderEdges();
    updateMinimap();
  }
  function up(){
    window.removeEventListener("mousemove", move);
    window.removeEventListener("mouseup", up);
    renderParams();
    if(node.position.x !== start.x || node.position.y !== start.y) commitActiveWorkflowChange();
  }
  window.addEventListener("mousemove", move);
  window.addEventListener("mouseup", up);
}
function getPortPoint(node, kind, handle){
  const meta = OPERATOR_META[node.type] || {};
  const ports = kind === "out" ? nodeOutputPorts(meta) : nodeInputPorts(meta);
  const index = Math.max(0, ports.findIndex(port => port.handle === handle));
  const y = node.position.y + (node.collapsed ? 27 : portTop(index) + 8);
  return { x:node.position.x + (kind === "out" ? NODE_WIDTH : 0), y };
}
function makeEdgePath(start, end){
  const control1 = start.x + 105;
  const control2 = end.x - 105;
  return `M ${start.x} ${start.y} C ${control1} ${start.y}, ${control2} ${end.y}, ${end.x} ${end.y}`;
}
function drawTempEdge(clientX, clientY){
  clearTempEdge();
  const source = nodes.find(node => node.id === connectingSourceId);
  if(!source) return;
  const start = getPortPoint(source, "out", connectingSourceHandle);
  const end = screenToWorld(clientX, clientY);
  const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
  path.id = "tempEdge";
  path.setAttribute("class", "edge-temp");
  path.setAttribute("d", makeEdgePath(start, end));
  edgeLayer.appendChild(path);
}
function clearTempEdge(){
  const temporary = document.getElementById("tempEdge");
  if(temporary) temporary.remove();
}
function renderEdges(){
  edgeLayer.innerHTML = "";
  edges.forEach(edge => {
    const source = nodes.find(node => node.id === edge.source);
    const target = nodes.find(node => node.id === edge.target);
    if(!source || !target) return;
    const pathData = makeEdgePath(getPortPoint(source, "out", edge.sourceHandle || "out"), getPortPoint(target, "in", edge.targetHandle || "in"));
    const hit = document.createElementNS("http://www.w3.org/2000/svg", "path");
    hit.setAttribute("d", pathData);
    hit.setAttribute("class", "edge-hit");
    hit.dataset.id = edge.id;
    hit.addEventListener("mousedown", event => event.stopPropagation());
    hit.addEventListener("click", event => { event.stopPropagation(); selectEdge(edge.id); });
    hit.addEventListener("dblclick", event => { event.stopPropagation(); deleteEdge(edge.id); });
    hit.addEventListener("contextmenu", event => { event.preventDefault(); event.stopPropagation(); deleteEdge(edge.id); });
    const visible = document.createElementNS("http://www.w3.org/2000/svg", "path");
    visible.setAttribute("d", pathData);
    visible.setAttribute("class", `edge-visible ${selectedEdgeId === edge.id ? "selected" : ""}`);
    edgeLayer.append(hit, visible);
  });
}
function selectIncomingEdge(targetId, targetHandle = "in"){
  const edge = edges.find(item => item.target === targetId && (item.targetHandle || "in") === targetHandle);
  if(edge) selectEdge(edge.id);
}
function selectEdge(edgeId){
  selectedEdgeId = edgeId;
  selectedNodeId = null;
  connectingSourceId = null;
  connectingSourceHandle = "out";
  previewActionNodeId = null;
  colorPaletteNodeId = null;
  render();
  const edge = edges.find(item => item.id === edgeId);
  if(edge) setStatus(`已选择连线：${edge.source}.${edge.sourceHandle || "out"} → ${edge.target}.${edge.targetHandle || "in"}，按 Delete/Backspace 删除`);
}
function deleteEdge(edgeId){
  const edge = edges.find(item => item.id === edgeId);
  if(!edge) return;
  edges = edges.filter(item => item.id !== edgeId);
  if(selectedEdgeId === edgeId) selectedEdgeId = null;
  invalidateNodeAndDownstreamPreviews(edge.target);
  render();
  commitActiveWorkflowChange();
  toast("已删除连线", `${edge.source}.${edge.sourceHandle || "out"} → ${edge.target}.${edge.targetHandle || "in"}`, true);
}
function deleteSelectedEdge(){ if(selectedEdgeId) deleteEdge(selectedEdgeId); }

function renderParams(){
  if(selectedEdgeId && !selectedNodeId){
    const edge = edges.find(item => item.id === selectedEdgeId);
    if(edge){
      paramPanel.className = "param-card";
      paramPanel.innerHTML = `<h3>连线 · ${escapeHtml(edge.source)}.${escapeHtml(edge.sourceHandle || "out")} → ${escapeHtml(edge.target)}.${escapeHtml(edge.targetHandle || "in")}</h3><div class="hint">双击、右键或按 Delete 可以删除这条连线。</div><div class="row-actions"><button class="btn red" onclick="deleteSelectedEdge()">删除连线</button></div>`;
      return;
    }
  }
  const node = nodes.find(item => item.id === selectedNodeId);
  if(!node){
    paramPanel.className = "param-card hint";
    paramPanel.innerHTML = "请选择一个节点或连线";
    return;
  }
  const meta = OPERATOR_META[node.type] || { label:node.type };
  const previewState = nodePreviews.has(node.id) ? "已生成节点效果预览" : "尚未生成节点效果预览";
  paramPanel.className = "param-card";
  paramPanel.innerHTML = `<h3>${escapeHtml(node.id)} · ${escapeHtml(meta.label)}</h3><div class="hint">类型：${escapeHtml(node.type)}<br>${escapeHtml(meta.description || "")}<br>${previewState}<br><br>所有可调参数都在节点卡片内编辑。</div><div class="row-actions"><button class="btn ghost" onclick="duplicateNode('${escapeHtml(node.id)}')">复制节点</button><button class="btn red" onclick="deleteNode('${escapeHtml(node.id)}')">删除节点</button></div>`;
}
function toggleSelectedCollapse(){
  const node = nodes.find(item => item.id === selectedNodeId);
  if(!node) return;
  node.collapsed = !node.collapsed;
  render();
  commitActiveWorkflowChange();
}
// 兼容旧页面调用；现在这两个操作只控制左侧节点库分类，不再改变画布节点。
function collapseAllNodes(){ collapseAllOperatorGroups(); }
function expandAllNodes(){ expandAllOperatorGroups(); }
function duplicateNode(id){
  const source = nodes.find(item => item.id === id);
  if(!source) return;
  const newId = `n${nodeSeq++}`;
  nodes.push({
    id:newId,
    type:source.type,
    position:{ x:source.position.x + 42, y:source.position.y + 42 },
    params:JSON.parse(JSON.stringify(source.params || {})),
    collapsed:source.collapsed,
    color:source.color || DEFAULT_NODE_COLOR,
  });
  selectedNodeId = newId;
  selectedEdgeId = null;
  colorPaletteNodeId = null;
  render();
  commitActiveWorkflowChange();
}
function deleteNode(id){
  if(!nodes.some(node => node.id === id)) return;
  nodes = nodes.filter(node => node.id !== id);
  edges = edges.filter(edge => edge.source !== id && edge.target !== id);
  nodePreviews.delete(id);
  if(selectedNodeId === id) selectedNodeId = null;
  if(previewActionNodeId === id) previewActionNodeId = null;
  if(colorPaletteNodeId === id) colorPaletteNodeId = null;
  if(lightboxNodeId === id) closeImageLightbox();
  render();
  commitActiveWorkflowChange();
  toast("已删除节点", id, true);
}
function deleteSelectedNode(){ if(selectedNodeId) deleteNode(selectedNodeId); }

function buildWorkflow(){
  return {
    version:"2.1",
    nodes:nodes.map(node => ({
      id:node.id,
      type:node.type,
      position:node.position,
      params:{ ...(node.params || {}) },
      collapsed:Boolean(node.collapsed),
      color:node.color || DEFAULT_NODE_COLOR,
    })),
    edges:edges.map(edge => ({ ...edge })),
  };
}

async function runWorkflow(){
  const workflow = buildWorkflow();
  setStatus("运行中...");
  document.getElementById("taskCount").textContent = "1";
  if(previewCollapsed) togglePreviewPanel(false);
  previewPanel.innerHTML = '<div class="empty-preview">正在运行 OpenCV 流程...</div>';
  try{
    const data = await VisionApi.executeWorkflow(workflow);
    renderPreviews(data.previews || [], data.batch || null);
    if(data.mode === "batch" && data.batch){
      const batch = data.batch;
      setStatus(`批量运行完成：共 ${batch.total} 张，成功 ${batch.succeeded} 张，失败 ${batch.failed} 张。结果目录：${batch.output_dir}`);
      toast("批量处理完成", `成功 ${batch.succeeded} / ${batch.total}，失败 ${batch.failed}`, batch.failed === 0);
    }else{
      setStatus(`运行成功。执行顺序：${(data.order || []).join(" → ")}`);
      toast("运行成功", `已生成 ${(data.previews || []).length} 个节点结果`, true);
    }
  }catch(error){
    const message = error && error.message ? error.message : String(error);
    const payload = error?.payload || null;
    if(payload && Array.isArray(payload.previews)){
      renderPreviews(payload.previews || [], payload.batch || null);
      renderExecutionFailureSummary(payload);
      const failed = payload.failed_node;
      const executedText = (payload.executed_order || []).join(" → ") || "无";
      setStatus(`运行到节点 ${failed?.node_id || "未知"} 时失败。已完成：${executedText}。错误：${message}`);
      if(failed?.node_id){
        selectedNodeId = failed.node_id;
        selectedEdgeId = null;
        render();
      }
      toast("节点执行失败", `${failed?.node_id || "未知节点"}：${failed?.error || message}`);
    }else{
      setStatus(`运行失败：${message}`);
      previewPanel.innerHTML = `<div class="empty-preview">运行失败：${escapeHtml(message)}</div>`;
      toast("运行失败", message);
    }
  }finally{
    document.getElementById("taskCount").textContent = "0";
  }
}

function renderExecutionFailureSummary(payload){
  const failed = payload.failed_node || {};
  const card = document.createElement("div");
  card.className = "execution-error-summary";
  const executed = payload.executed_order || [];
  const pending = payload.pending_nodes || [];
  card.innerHTML = `<div class="execution-error-summary-title"><span>工作流执行中断</span><span class="tag">ERROR</span></div>
    <div class="execution-error-node"><strong>失败节点：</strong>${escapeHtml(failed.node_id || "未知")} · ${escapeHtml(failed.label || failed.type || "未知节点")}</div>
    <div class="execution-error-message">${escapeHtml(failed.error || payload.error || "未知错误")}</div>
    <div class="execution-error-progress"><strong>已完成：</strong>${escapeHtml(executed.join(" → ") || "无")}</div>
    <div class="execution-error-progress"><strong>未执行：</strong>${escapeHtml(pending.join("、") || "无")}</div>`;
  previewPanel.prepend(card);
}

function togglePreviewPanel(force){
  previewCollapsed = typeof force === "boolean" ? force : !previewCollapsed;
  previewWrap.classList.toggle("collapsed", previewCollapsed);
  previewToggleText.textContent = previewCollapsed ? "展开" : "折叠";
  if(!suppressDocumentSync) persistActiveWorkflowView();
}

function renderPreviews(previews, batchSummary = null){
  nodePreviews.clear();
  previews.forEach(item => nodePreviews.set(item.node_id, item));
  previewActionNodeId = null;
  renderNodes();
  updateMinimap();

  previewPanel.innerHTML = "";
  if(batchSummary) renderBatchSummary(batchSummary);
  if(!previews.length){
    if(!batchSummary) previewPanel.innerHTML = '<div class="empty-preview">没有生成预览结果</div>';
    return;
  }
  previews.forEach((item, index) => {
    const card = document.createElement("div");
    if(item.status === "error" || item.result_type === "error"){
      card.className = "preview-card error-preview-card";
      const title = `${index + 1}. ${item.node_id} · ${item.label}`;
      card.innerHTML = `<div class="preview-meta"><b title="${escapeHtml(title)}">${escapeHtml(title)}</b><span class="tag">ERROR</span></div>${renderNodeErrorHtml(item)}`;
      previewPanel.appendChild(card);
      return;
    }
    const hasImage = Boolean(item.image);
    const hasMetrics = previewMetricEntries(item).length > 0;
    const previewKind = hasImage && hasMetrics ? "combined" : hasMetrics ? "metrics" : "image";
    card.className = `preview-card ${previewKind}-preview-card`;
    const title = `${index + 1}. ${item.node_id} · ${item.label}`;
    const content = `${hasImage ? `<img src="${item.image}" alt="${escapeHtml(title)}" title="点击查看原图" />` : ""}${hasMetrics ? renderMetricResultHtml(item, true) : ""}`;
    const itemMeta = OPERATOR_META[item.type] || {};
    const tagLabel = previewKind === "combined"
      ? (itemMeta.kind === "logic" ? "图像 + 逻辑" : "图像 + 数值")
      : previewKind === "metrics"
        ? (itemMeta.kind === "logic" ? "逻辑" : "数值")
        : escapeHtml(item.type || "");
    card.innerHTML = `<div class="preview-meta"><b title="${escapeHtml(title)}">${escapeHtml(title)}</b><span class="tag">${tagLabel}</span></div>${content}`;
    const image = card.querySelector("img");
    if(image) image.addEventListener("click", () => openImageLightbox(item.node_id));
    previewPanel.appendChild(card);
  });
  if(!suppressDocumentSync) captureActiveWorkflowDocument(false);
}

function renderBatchSummary(batch){
  const card = document.createElement("div");
  card.className = "batch-summary";
  const failedRows = (batch.rows || []).filter(row => row.status === "error").slice(0, 5);
  const csvLine = batch.csv_path
    ? `<div class="batch-summary-path"><strong>CSV：</strong>${escapeHtml(batch.csv_path)}</div>`
    : "";
  const errors = failedRows.length
    ? `<div class="batch-summary-errors"><strong>前 ${failedRows.length} 个失败：</strong><br>${failedRows.map(row => `${escapeHtml(row.source_name || row.source_path)}：${escapeHtml(row.error || "未知错误")}`).join("<br>")}</div>`
    : "";
  card.innerHTML = `<div class="batch-summary-title"><span>批量处理汇总</span><span class="tag">BATCH</span></div>
    <div class="batch-summary-grid">
      <div class="batch-summary-stat"><b>${Number(batch.total || 0)}</b><span>总图片</span></div>
      <div class="batch-summary-stat"><b>${Number(batch.succeeded || 0)}</b><span>成功</span></div>
      <div class="batch-summary-stat"><b>${Number(batch.failed || 0)}</b><span>失败</span></div>
    </div>
    <div class="batch-summary-path"><strong>结果目录：</strong>${escapeHtml(batch.output_dir || "")}</div>
    ${csvLine}${errors}`;
  previewPanel.appendChild(card);
}

function downloadNodePreview(nodeId){
  const preview = nodePreviews.get(nodeId);
  if(!preview || !preview.image){
    toast("下载失败", "该节点还没有可下载的结果图");
    return;
  }
  const anchor = document.createElement("a");
  anchor.href = preview.image;
  anchor.download = `${safeFilename(nodeId)}_${safeFilename(preview.label || preview.type || "result")}.png`;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  toast("开始下载", anchor.download, true);
}

function openImageLightbox(nodeId){
  const preview = nodePreviews.get(nodeId);
  if(!preview || !preview.image){
    toast("无法放大", "该节点还没有结果图");
    return;
  }
  lightboxNodeId = nodeId;
  const lightbox = document.getElementById("imageLightbox");
  const image = document.getElementById("lightboxImage");
  document.getElementById("lightboxTitle").textContent = `${nodeId} · ${preview.label || preview.type || "节点结果"}`;
  document.getElementById("lightboxMeta").textContent = "原始分辨率 · 可滚动查看";
  image.src = preview.image;
  image.alt = `${preview.label || nodeId} 的原图`;
  document.getElementById("lightboxDownload").onclick = event => {
    event.stopPropagation();
    downloadNodePreview(nodeId);
  };
  document.getElementById("lightboxRestore").onclick = event => {
    event.stopPropagation();
    closeImageLightbox();
  };
  lightbox.classList.add("open");
  lightbox.setAttribute("aria-hidden", "false");
  document.body.classList.add("lightbox-open");
}
function closeImageLightbox(){
  const lightbox = document.getElementById("imageLightbox");
  lightbox.classList.remove("open");
  lightbox.setAttribute("aria-hidden", "true");
  document.getElementById("lightboxImage").removeAttribute("src");
  lightboxNodeId = null;
  document.body.classList.remove("lightbox-open");
}

async function exportAlgorithmScript(){
  if(!nodes.length){ toast("导出失败", "请先编排工作流"); return; }
  setStatus("正在生成独立算法脚本...");
  try{
    const result = await VisionApi.exportScript(buildWorkflow());
    const url = URL.createObjectURL(result.blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = result.filename || "vision_algorithm.py";
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    URL.revokeObjectURL(url);
    setStatus("独立算法脚本已导出");
    toast("脚本已导出", anchor.download, true);
  }catch(error){
    setStatus(`脚本导出失败：${error.message}`);
    toast("脚本导出失败", error.message);
  }
}

function saveWorkflowLocal(){
  const documentInfo = getActiveWorkflowDocument();
  if(!documentInfo) return;
  captureActiveWorkflowDocument(false);
  documentInfo.savedSnapshot = workflowSignature(documentInfo.workflow);
  documentInfo.savedName = documentInfo.name;
  documentInfo.dirty = false;
  storageSet("vision_python_mvp_workflow_v3", JSON.stringify(documentInfo.workflow, null, 2));
  renderWorkflowTabs();
  persistWorkspace();
  toast("工作流已保存", documentInfo.name, true);
  setStatus(`${documentInfo.name} 已保存（Ctrl+S）`);
}
function loadWorkflowLocal(){
  const documentInfo = getActiveWorkflowDocument();
  if(!documentInfo) return;
  let workflow = null;
  if(documentInfo.savedSnapshot){
    try{ workflow = JSON.parse(documentInfo.savedSnapshot); }catch(error){ console.warn(error); }
  }
  if(!workflow){
    const raw = storageGet("vision_python_mvp_workflow_v3") || storageGet("vision_python_mvp_workflow_v2");
    if(raw){
      try{ workflow = JSON.parse(raw); }catch(error){ toast("加载失败", error.message || String(error)); return; }
    }
  }
  if(!workflow){ toast("加载失败", "当前工作流还没有保存版本"); return; }
  suppressDocumentSync = true;
  try{ applyWorkflow(workflow, { silent:true }); }finally{ suppressDocumentSync = false; }
  documentInfo.workflow = buildWorkflow();
  documentInfo.savedSnapshot = workflowSignature(documentInfo.workflow);
  documentInfo.name = documentInfo.savedName || documentInfo.name;
  documentInfo.savedName = documentInfo.name;
  documentInfo.dirty = false;
  documentInfo.runtimePreviews = [];
  renderWorkflowTabs();
  persistWorkspace();
  toast("已恢复保存版本", documentInfo.name, true);
  setStatus(`${documentInfo.name} 已恢复到最近保存状态`);
}
function downloadWorkflowJson(){
  const documentInfo = getActiveWorkflowDocument();
  const blob = new Blob([JSON.stringify(buildWorkflow(), null, 2)], { type:"application/json" });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = `${safeFilename(documentInfo?.name || "vision_workflow")}.json`;
  anchor.click();
  URL.revokeObjectURL(url);
}
function resetView(){ pan = { x:-260, y:-120 }; zoom = .82; applyTransform(); persistActiveWorkflowView(); setStatus("已重置画布视图"); }

function applyWorkflow(workflow, options = {}){
  nodePreviews.clear();
  previewActionNodeId = null;
  colorPaletteNodeId = null;
  closeImageLightbox();
  nodes = (workflow.nodes || []).map(rawNode => {
    const normalized = normalizeNodeType(rawNode.type, rawNode.params || {});
    if(!OPERATOR_META[normalized.type]) return null;
    return {
      id:rawNode.id,
      type:normalized.type,
      position:rawNode.position || { x:100, y:100 },
      params:{ ...defaultParams(normalized.type), ...normalized.params },
      collapsed:Boolean(rawNode.collapsed),
      color:safeColor(rawNode.color || DEFAULT_NODE_COLOR),
    };
  }).filter(Boolean);
  edges = (workflow.edges || [])
    .filter(edge => nodes.some(node => node.id === edge.source) && nodes.some(node => node.id === edge.target))
    .map(edge => ({ ...edge, sourceHandle:edge.sourceHandle || "out", targetHandle:edge.targetHandle || "in" }));
  connectingSourceId = null;
  connectingSourceHandle = "out";
  const maxSequence = nodes.reduce((maxValue, node) => Math.max(maxValue, Number(String(node.id).replace(/^n/, "")) || 0), 0);
  nodeSeq = maxSequence + 1;
  selectedNodeId = nodes[0]?.id || null;
  selectedEdgeId = null;
  previewPanel.innerHTML = '<div class="empty-preview">运行工作流后显示实时执行日志</div>';
  render();
  if(!options.silent) setStatus("工作流已加载；旧版 Gray/BGR2RGB 节点已自动迁移为颜色转换节点");
}

function createDemoWorkflow(){
  applyWorkflow(demoWorkflowDefinition(), { silent:true });
  pan = { x:-260, y:-120 };
  zoom = .82;
  applyTransform();
  commitActiveWorkflowChange();
  setStatus("示例流程已生成。请在读取图像节点内填写服务器图片路径，然后运行。");
  toast("示例流程已生成", "请先填写 ReadImage 的图片路径", true);
}

function clearWorkflow(){
  applyWorkflow(emptyWorkflow(), { silent:true });
  commitActiveWorkflowChange();
  setStatus("流程已清空");
}

function toast(title, text, ok){
  const element = document.getElementById("toast");
  document.getElementById("toastTitle").textContent = title;
  document.getElementById("toastText").textContent = text || "";
  element.className = `toast show${ok ? " ok" : ""}`;
  clearTimeout(window.__toastTimer);
  window.__toastTimer = setTimeout(() => element.className = "toast", 3200);
}
function setStatus(text){ statusEl.textContent = text; }
function escapeHtml(value){
  return String(value).replace(/[&<>"']/g, character => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" })[character]);
}
function safeFilename(value){ return String(value).replace(/[\\/:*?"<>|\s]+/g, "_").replace(/^_+|_+$/g, "") || "result"; }
function safeColor(value){ return /^#[0-9a-fA-F]{6}$/.test(String(value)) ? String(value) : DEFAULT_NODE_COLOR; }

function currentViewportWorldRect(){
  const rect = viewport.getBoundingClientRect();
  return {
    x:-pan.x / zoom,
    y:-pan.y / zoom,
    width:rect.width / zoom,
    height:rect.height / zoom,
  };
}

function renderedNodeHeight(node){
  const element = Array.from(nodeLayer.children).find(item => item.dataset.id === node.id);
  return element ? element.getBoundingClientRect().height / zoom : nodeHeight(node);
}

function computeMinimapTransform(){
  const minimap = document.querySelector(".minimap");
  const header = minimap.querySelector(".minimap-head");
  const viewRect = currentViewportWorldRect();
  const rectangles = [viewRect, ...nodes.map(node => ({
    x:node.position.x,
    y:node.position.y,
    width:NODE_WIDTH,
    height:renderedNodeHeight(node),
  }))];

  let minX = Math.min(...rectangles.map(rect => rect.x));
  let minY = Math.min(...rectangles.map(rect => rect.y));
  let maxX = Math.max(...rectangles.map(rect => rect.x + rect.width));
  let maxY = Math.max(...rectangles.map(rect => rect.y + rect.height));
  const worldWidth = Math.max(1, maxX - minX);
  const worldHeight = Math.max(1, maxY - minY);
  const worldPadding = Math.max(100, Math.min(420, Math.max(worldWidth, worldHeight) * .08));
  minX -= worldPadding;
  minY -= worldPadding;
  maxX += worldPadding;
  maxY += worldPadding;

  const headerHeight = header.offsetHeight || 22;
  const pixelPadding = 8;
  const availableWidth = Math.max(1, minimap.clientWidth - pixelPadding * 2);
  const availableHeight = Math.max(1, minimap.clientHeight - headerHeight - pixelPadding * 2);
  const boundsWidth = Math.max(1, maxX - minX);
  const boundsHeight = Math.max(1, maxY - minY);
  const scale = Math.min(availableWidth / boundsWidth, availableHeight / boundsHeight);
  const drawnWidth = boundsWidth * scale;
  const drawnHeight = boundsHeight * scale;
  const offsetX = pixelPadding + (availableWidth - drawnWidth) / 2 - minX * scale;
  const offsetY = headerHeight + pixelPadding + (availableHeight - drawnHeight) / 2 - minY * scale;

  return { minX, minY, maxX, maxY, scale, offsetX, offsetY, headerHeight };
}

function minimapWorldToScreen(x, y){
  if(!minimapTransform) return { x:0, y:0 };
  return {
    x:x * minimapTransform.scale + minimapTransform.offsetX,
    y:y * minimapTransform.scale + minimapTransform.offsetY,
  };
}

function updateMinimap(){
  const mini = document.getElementById("miniNodes");
  const view = document.getElementById("miniView");
  mini.innerHTML = "";
  minimapTransform = computeMinimapTransform();

  nodes.forEach(node => {
    const marker = document.createElement("div");
    const point = minimapWorldToScreen(node.position.x, node.position.y);
    marker.className = "mini-node";
    marker.dataset.nodeId = node.id;
    marker.style.left = `${point.x}px`;
    marker.style.top = `${point.y}px`;
    marker.style.width = `${Math.max(4, NODE_WIDTH * minimapTransform.scale)}px`;
    marker.style.height = `${Math.max(4, renderedNodeHeight(node) * minimapTransform.scale)}px`;
    marker.style.background = safeColor(node.color || DEFAULT_NODE_COLOR);
    marker.title = `${node.id} · ${(OPERATOR_META[node.type] || {}).label || node.type}`;
    mini.appendChild(marker);
  });

  const viewportWorld = currentViewportWorldRect();
  const viewPoint = minimapWorldToScreen(viewportWorld.x, viewportWorld.y);
  view.style.left = `${viewPoint.x}px`;
  view.style.top = `${viewPoint.y}px`;
  view.style.width = `${Math.max(2, viewportWorld.width * minimapTransform.scale)}px`;
  view.style.height = `${Math.max(2, viewportWorld.height * minimapTransform.scale)}px`;
}

function navigateFromMinimap(event){
  if(!minimapTransform) return;
  const minimap = document.querySelector(".minimap");
  const rect = minimap.getBoundingClientRect();
  const localX = event.clientX - rect.left;
  const localY = event.clientY - rect.top;
  if(localY <= minimapTransform.headerHeight) return;

  const worldX = (localX - minimapTransform.offsetX) / minimapTransform.scale;
  const worldY = (localY - minimapTransform.offsetY) / minimapTransform.scale;
  const viewportRect = viewport.getBoundingClientRect();
  pan.x = viewportRect.width / 2 - worldX * zoom;
  pan.y = viewportRect.height / 2 - worldY * zoom;
  applyTransform();
  persistActiveWorkflowView();
  setStatus(`已通过导航视图定位到画布坐标：${Math.round(worldX)}, ${Math.round(worldY)}`);
}


document.addEventListener("keydown", event => {
  if((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "s"){
    event.preventDefault();
    saveWorkflowLocal();
    return;
  }
  if(event.key === "Escape"){
    if(lightboxNodeId){ closeImageLightbox(); return; }
    connectingSourceId = null;
    connectingSourceHandle = "out";
    clearTempEdge();
    previewActionNodeId = null;
    colorPaletteNodeId = null;
    renderNodes();
    setStatus("已取消当前操作");
  }
  if((event.key === "Delete" || event.key === "Backspace") && selectedEdgeId && !event.target.matches("input,textarea,select")){
    event.preventDefault();
    deleteSelectedEdge();
  }
});
window.addEventListener("resize", updateMinimap);
document.querySelector(".minimap").addEventListener("click", navigateFromMinimap);
document.getElementById("nodeLibraryToggle").addEventListener("click", toggleNodeLibrary);
document.getElementById("newWorkflowButton").addEventListener("click", newWorkflow);
document.getElementById("exportScriptButton").addEventListener("click", exportAlgorithmScript);
document.getElementById("workflowInput").addEventListener("change", async event => {
  const file = event.target.files[0];
  if(!file) return;
  try{
    applyWorkflow(JSON.parse(await file.text()), { silent:true });
    const documentInfo = getActiveWorkflowDocument();
    if(documentInfo){
      documentInfo.name = file.name.replace(/\.json$/i, "") || documentInfo.name;
    }
    commitActiveWorkflowChange();
    toast("JSON 流程已导入", file.name, true);
    setStatus(`已导入到当前工作流：${documentInfo?.name || file.name}`);
  }catch(error){
    toast("导入失败", error.message || String(error));
  }finally{
    event.target.value = "";
  }
});
setNodeLibraryVisible(true);
initOperators();
