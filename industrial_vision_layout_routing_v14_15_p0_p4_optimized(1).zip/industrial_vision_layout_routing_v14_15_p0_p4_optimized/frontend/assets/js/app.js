// 工业视觉流程编辑器前端入口。
// 维护源代码已经拆分到 /assets/js/app/state.js、operators.js、canvas.js、edge_router.js、run_controller.js、actions.js、minimap.js、bootstrap.js。
// 本文件保留轻量入口说明与旧版静态测试兼容标记；页面实际按 index.html 中的拆分脚本顺序加载。
// Compatibility markers: WORKSPACE_STORAGE_KEY, collapsedOperatorGroups, connectingSourceHandle, Ctrl+S
// function toggleNodeLibrary() function downloadNodePreview( function openImageLightbox( function closeImageLightbox(
// function newWorkflow() function switchWorkflow( function closeWorkflow( function renderWorkflowTabs()
// function renderBatchSummary( 批量处理汇总
// ${renderNodeToolbarHtml(node)} data-node-action="delete" 🗑 function selectNodeWithoutRerender(
// function renderMetricResultHtml( result_type === "metrics" 数值结果 图像与数值结果
// function collapseAllOperatorGroups() function expandAllOperatorGroups() function collapseAllLogicOperatorGroups() function expandAllLogicOperatorGroups()
// function computeMinimapTransform() function navigateFromMinimap( addEventListener("click", navigateFromMinimap) minimapWorldToScreen
// function nodeInputPorts( function nodeOutputPorts( data-handle=
// function renderExecutionFailureSummary( preview?.result_type === "error" 工作流执行中断
// data-preview-action="download" data-preview-action="zoom" event.key.toLowerCase() === "s"
// function addNodeAtViewportCenter( function getViewportCenterWorldPoint( centerOnPoint
// YOLO markers: YoloInfer YOLO推理 uploadModel upload-model schema.type === "file" node-file-button
// Dynamic port markers: dynamic_outputs resolveDynamicOutputCount pruneInvalidEdgesForNode mask1 mask2 mask3
// Layout beautify markers: beautifyWorkflowLayout topologicalNodeOrderForLayout orderLayersByBarycenter makeEdgePath roundedOrthogonalPath calculateEdgeWaypoints polylineCollidesWithRects renderEdgeDefinitions 美化排线 beautifyLayoutButton
// Project/model markers: VisionWorkspaceStore /api/projects saveServerDocument openProjectFromServer /api/models clearModelCache

// Live log markers: executeWorkflowStream run-stream function clearRunLog( function appendRunLog( 实时运行日志
// Debug execution markers: runModeSelect runSelectedMode executeDebugAction debugSessionId debug-current debug-next /api/debug/run-stream
