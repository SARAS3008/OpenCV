"""Migrate legacy JSON files into PostgreSQL/Redis state adapters.

Examples:
    python scripts/migrate_file_state.py --dry-run
    VISION_DATABASE_URL=... VISION_REDIS_URL=... \
      python scripts/migrate_file_state.py --state-backend postgres --session-backend redis

The command is idempotent because every record is written with a deterministic namespace/key.
It never deletes source files.
"""
from __future__ import annotations

import argparse
import json
import os
import time
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterator

PROJECT_ROOT_HINT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT_HINT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT_HINT))

from backend.config import AUTH_DIR, DATASETS_DIR, JOBS_DIR, PROJECTS_DIR, PROJECT_ROOT, RUN_HISTORY_DIR, STATE_DIR, WORKSPACES_DIR
from backend.infrastructure.state_backend import JsonStateBackend, create_state_backend


@dataclass(frozen=True)
class MigrationRecord:
    target: str
    namespace: str
    key: str
    payload: dict[str, Any]
    ttl_seconds: int | None = None


def _read_json(path: Path) -> dict[str, Any] | None:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    return payload if isinstance(payload, dict) else None


def collect_records() -> Iterator[MigrationRecord]:
    users = _read_json(AUTH_DIR / "users.json") or {}
    for user in users.get("users") or []:
        if isinstance(user, dict) and user.get("user_id"):
            yield MigrationRecord("state", "auth_users", str(user["user_id"]), user)

    sessions = _read_json(AUTH_DIR / "sessions.json") or {}
    now = int(time.time())
    for session in sessions.get("sessions") or []:
        if not isinstance(session, dict) or not session.get("token"):
            continue
        expires_at = int(session.get("expires_at") or 0)
        ttl = max(1, expires_at - now) if expires_at else None
        yield MigrationRecord("session", "auth_sessions", str(session["token"]), session, ttl)

    for path in sorted(WORKSPACES_DIR.glob("*.json")):
        payload = _read_json(path)
        if payload:
            yield MigrationRecord("state", "workspaces", str(payload.get("workspace_id") or path.stem), payload)

    for owner_dir in sorted(path for path in PROJECTS_DIR.iterdir() if path.is_dir()):
        owner = owner_dir.name
        for path in sorted(owner_dir.glob("*.json")):
            payload = _read_json(path)
            if payload:
                yield MigrationRecord("state", "projects", f"{owner}/{path.stem}", payload)
        versions_root = owner_dir / "_versions"
        if versions_root.is_dir():
            for path in sorted(versions_root.glob("*/*.json")):
                payload = _read_json(path)
                if payload:
                    project_id = path.parent.name
                    yield MigrationRecord("state", "project_versions", f"{owner}/{project_id}/{path.stem}", payload)

    for owner_dir in sorted(path for path in DATASETS_DIR.iterdir() if path.is_dir()):
        for path in sorted(owner_dir.glob("*.json")):
            payload = _read_json(path)
            if payload:
                yield MigrationRecord("state", "datasets", f"{owner_dir.name}/{path.stem}", payload)

    for owner_dir in sorted(path for path in RUN_HISTORY_DIR.iterdir() if path.is_dir()):
        for path in sorted(owner_dir.glob("*.json")):
            payload = _read_json(path)
            if payload:
                yield MigrationRecord("state", "run_history", f"{owner_dir.name}/{path.stem}", payload)

    jobs_root = JOBS_DIR / "state" / "jobs"
    if jobs_root.is_dir():
        for path in sorted(jobs_root.glob("*.json")):
            payload = _read_json(path)
            if payload:
                yield MigrationRecord("session", "jobs", path.stem, payload)


def _backend(kind: str, root: Path, database_url: str, redis_url: str) -> JsonStateBackend:
    return create_state_backend(kind, root_dir=root, database_url=database_url, redis_url=redis_url)


def main() -> None:
    parser = argparse.ArgumentParser(description="Migrate file-backed state without deleting source data")
    parser.add_argument("--state-backend", default=os.getenv("VISION_STATE_BACKEND", "postgres"))
    parser.add_argument("--session-backend", default=os.getenv("VISION_SESSION_BACKEND", "redis"))
    parser.add_argument("--database-url", default=os.getenv("VISION_DATABASE_URL", ""))
    parser.add_argument("--redis-url", default=os.getenv("VISION_REDIS_URL", ""))
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    records = list(collect_records())
    counts: dict[str, int] = {}
    for record in records:
        counts[record.namespace] = counts.get(record.namespace, 0) + 1
    print(json.dumps({"project_root": str(PROJECT_ROOT), "records": len(records), "namespaces": counts}, ensure_ascii=False, indent=2))
    if args.dry_run:
        return

    state = _backend(args.state_backend, STATE_DIR / "migration-domain", args.database_url, args.redis_url)
    session = _backend(args.session_backend, STATE_DIR / "migration-session", args.database_url, args.redis_url)
    try:
        for index, record in enumerate(records, start=1):
            target = state if record.target == "state" else session
            target.put(record.namespace, record.key, record.payload, ttl_seconds=record.ttl_seconds)
            if index % 100 == 0:
                print(f"migrated {index}/{len(records)}")
    finally:
        if session is not state:
            session.close()
        state.close()
    print(f"migration complete: {len(records)} records")


if __name__ == "__main__":
    main()
