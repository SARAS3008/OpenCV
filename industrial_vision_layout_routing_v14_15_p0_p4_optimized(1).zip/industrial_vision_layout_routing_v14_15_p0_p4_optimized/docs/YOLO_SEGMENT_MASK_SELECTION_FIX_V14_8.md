# v14.8 YOLO Segment Mask 筛选修复说明

## 问题现象

使用 YOLO Segment 模型推理后，再通过 `YoloSelectTopDetections` 筛选 Top-K 目标并输出合并 Mask 时，可能出现：

- Mask 出现横向长条、三角形或大面积异常填充；
- 原图抠图结果包含不属于目标的区域；
- 检测框与类别正确，但筛选后的 Mask 形状不正确。

## 根因

YOLO 分割结果中的实例 Mask 通常以闭合多边形点集表示。旧版本为了控制 JSON 结果体积，对 `mask_polygon` 使用了简单的前缀截断：

```python
points[:max_geometry_points]
```

对于闭合多边形，这会破坏轮廓闭合关系。`cv2.fillPoly()` 在生成二值 Mask 时会自动把最后一个点连接回第一个点，于是被截断的轮廓会形成一条伪边，导致 Mask 出现横向条带或异常三角区域。

## 修复内容

v14.8 将 Mask 多边形限制方式改为形状保持型处理：

1. 优先使用 `cv2.approxPolyDP()` 对闭合轮廓进行多边形简化；
2. 如果简化失败，则对闭合轮廓做环形等距采样；
3. 不再对 Mask 多边形做前缀截断；
4. `YoloSelectTopDetections` 继续使用与 detection 绑定的 `mask_polygon` 生成 `mask/mask1/mask2...`。

这样可以在控制点数的同时保持轮廓整体形状，避免筛选 Mask 出现假边。

## 涉及文件

```text
backend/algorithms/ai/yolo/result_parser.py
tests/test_yolo_roi_workflow.py
```

## 建议使用方式

如果需要最准确的下游 Mask：

- `YoloInfer.include_geometry = YES`
- `YoloInfer.max_geometry_points` 保持默认 500 一般足够；
- 对特别复杂的实例轮廓，可以适当增大到 1000 或 2000；
- `YoloSelectTopDetections` 的 `mask/mask1/mask2` 输出可直接连接到 `ApplyMask`、`FilterContours`、`MaskMinAreaRect` 等节点。

## 测试

新增回归测试覆盖了高点数 Mask 轮廓简化场景，确保简化后轮廓仍覆盖原始目标区域，不产生前缀截断导致的伪边。
