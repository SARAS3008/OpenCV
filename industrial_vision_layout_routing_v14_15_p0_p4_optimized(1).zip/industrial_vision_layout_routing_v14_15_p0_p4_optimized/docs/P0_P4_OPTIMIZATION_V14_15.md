# v14.15 P0–P4 稳定性、调试与生产化优化

本版本在 v14.14 三种执行模式基础上，按 P0、P1、P2、P3、P4 五个阶段完成了执行内核、调试资源、前端状态、基础设施适配和工程化改造。默认配置仍使用本地文件，现有单机部署无需 PostgreSQL、Redis 或对象存储即可继续运行。

## P0：统一节点执行内核

### 统一 `NodeExecutor`

新增：

```text
backend/services/node_executor.py
```

整体运行与调试运行现在共用同一套节点执行逻辑，包括：

- 上游结果和输入端口装配；
- `_data`、颜色空间和坐标元数据传递；
- 必需端口和 `fallback_for` 参数兜底验证；
- `If / Else` 已选输入处理；
- 算子调用和异常标准化；
- `data`、`metrics` 合并；
- JSON 安全转换；
- 节点预览生成；
- 输入、输出和图像像素预算；
- 取消检查。

`workflow_engine.py` 只负责完整工作流调度，`workflow_debugger.py` 只负责调试路径和会话状态，不再分别复制节点执行语义。

### 算子契约检查

新增：

```text
backend/algorithms/contract_validation.py
```

应用启动时自动验证：

- 算子元数据和实现是否一一对应；
- 输入、输出端口 handle 是否重复；
- 参数名称是否重复；
- `fallback_for` 是否引用真实输入端口；
- select 默认值是否存在于 options；
- 元数据基本字段是否完整。

契约结果同时进入 `/api/health/ready` 就绪检查。

## P1：调试稳定性、内存和取消

### 调试输出释放

调试会话将“节点是否完成”和“完整中间输出是否仍保留”分开记录。节点输出不再被任何未执行下游依赖时，会释放大尺寸 NumPy/OpenCV 数据，只保留：

- 节点已完成状态；
- 缩略图；
- 指标；
- 调试顺序和跳过状态。

终点节点和仍有消费者的输出继续保留。

环境变量：

```text
VISION_DEBUG_RELEASE_UNUSED_OUTPUTS=true
VISION_DEBUG_SESSION_MAX_MEMORY_BYTES=536870912
VISION_DEBUG_SESSION_TTL_SECONDS=1800
VISION_DEBUG_SESSION_MAX_ITEMS=8
VISION_DEBUG_SESSION_MAX_PER_WORKSPACE=2
```

### 节点资源预算

统一执行内核增加：

```text
VISION_NODE_MAX_INPUT_BYTES
VISION_NODE_MAX_OUTPUT_BYTES
VISION_NODE_MAX_IMAGE_PIXELS
VISION_PREVIEW_MAX_SIDE
VISION_DEBUG_PREVIEW_MAX_SIDE
```

这些限制主要防止大数组被长期保留。算子内部瞬时内存仍可能高于最终输出大小，因此公网或大规模推理仍建议使用带内存限制的独立 Worker。

### 取消和状态接口

新增：

```text
POST /api/debug/status
POST /api/debug/cancel
```

整体运行和调试运行的浏览器请求均使用 `AbortController`。用户取消、切换工作流或连接断开后，后端会停止继续调度后续节点；批量模式会在图片之间响应取消。

OpenCV、YOLO 等底层同步算子一旦开始执行，当前版本不能安全地强制中断其 C/CUDA 调用，因此取消会在当前算子返回后生效。

## P2：前端拆分和统一运行状态

新增模块：

```text
frontend/assets/js/app/edge_router.js
frontend/assets/js/app/run_controller.js
frontend/assets/js/app/execution_state.js
```

职责拆分如下：

- `edge_router.js`：正交路径、避障、反向连线和轻量拖动路径；
- `run_controller.js`：整体运行、单步、运行到节点、取消、NDJSON 流读取；
- `execution_state.js`：运行状态、调试会话、按钮状态和活动请求控制器；
- `canvas.js`：画布和节点交互；
- `actions.js`：项目、导入导出和通用操作。

整体运行、单步和运行到节点不再分别维护冲突的按钮状态。取消按钮仅在活动执行期间启用。

## P3：可渐进迁移的生产基础设施

### 状态后端

新增：

```text
backend/infrastructure/state_backend.py
```

支持：

```text
VISION_STATE_BACKEND=file|postgres
VISION_SESSION_BACKEND=file|redis
```

接入范围：

- 用户；
- 登录会话；
- 工作区；
- Presence；
- 项目与版本；
- 数据集；
- 运行历史；
- 任务状态。

默认 `file` 模式继续使用原有 JSON 文件。PostgreSQL 适配器使用统一 JSONB 状态表；Redis 适配器支持 TTL。

### 对象存储

新增：

```text
backend/infrastructure/artifact_store.py
```

支持：

```text
VISION_ARTIFACT_BACKEND=file|s3|minio
```

图片和模型上传仍会保留本地受管副本，同时可镜像到 S3/MinIO。批量运行只发布本次运行新生成的 CSV 和结果文件，不会重新扫描并上传输出目录中的历史文件；子目录结构会保留在对象键中。

### 文件状态迁移

```bash
python scripts/migrate_file_state.py --dry-run

VISION_DATABASE_URL=postgresql://... \
VISION_REDIS_URL=redis://... \
python scripts/migrate_file_state.py \
  --state-backend postgres \
  --session-backend redis
```

迁移工具：

- 不删除原 JSON 文件；
- 使用确定性 namespace/key；
- 可重复执行；
- 会按原会话剩余有效期设置 Redis TTL。

### 生产编排

```bash
cp .env.example .env
# 修改 PostgreSQL、Redis、MinIO 密码

docker compose -f docker-compose.production.yml up --build -d
```

包含：

- FastAPI 应用；
- PostgreSQL 16；
- Redis 7；
- MinIO；
- MinIO bucket 初始化；
- 健康检查；
- 持久化卷。

### 当前分布式边界

生产适配器解决了业务状态和产物的外部化，但以下组件仍在当前 API 进程：

- 调试会话中的 NumPy 中间输出；
- 后台任务执行器；
- YOLO 模型内存缓存；
- 同步 OpenCV/YOLO 节点执行。

因此 Docker 配置明确使用一个 Uvicorn Worker。真正的多实例横向扩展仍需要：

1. 独立任务/推理 Worker；
2. 调试会话固定路由或专用调试 Worker；
3. 共享图片、模型获取机制；
4. Worker 级 CPU、GPU、内存和超时隔离。

## P4：工程化、可观测性和生命周期

### 可观测性

新增：

```text
backend/infrastructure/observability.py
```

支持：

- JSON 结构化访问日志；
- 请求 ID 生成和响应头回传；
- 请求数量、状态码、耗时指标；
- 任务和调试会话指标；
- Prometheus 文本格式。

接口：

```text
GET /api/health/live
GET /api/health/ready
GET /api/metrics
```

`ready` 会检查状态后端、会话后端、对象存储和算子契约。

### 应用生命周期

FastAPI lifespan 会在关闭时：

- 停止任务线程池；
- 清理调试会话；
- 清理模型缓存；
- 关闭数据库、Redis 和对象存储适配器。

模型管理器改为每个 FastAPI 应用实例独立创建，不再共享模块级默认缓存。

### 跨平台文件锁

文件模式下：

- Linux/macOS 使用 `fcntl.flock`；
- Windows 使用 `msvcrt.locking`；
- 写入继续采用唯一临时文件、`fsync` 和原子替换。

### 工程文件

新增：

```text
pyproject.toml
requirements.lock
requirements-production.txt
requirements-dev.txt
.github/workflows/ci.yml
Dockerfile
docker-compose.production.yml
Makefile
.env.example
.dockerignore
```

CI 执行：

- Ruff 部署级错误检查；
- MyPy 核心模块类型检查；
- Pytest 与分支覆盖率；
- JavaScript 语法检查；
- 示例 JSON 校验；
- coverage.xml 归档。

当前覆盖率门槛为 69%，作为现有代码库的基线，后续新增代码应逐步提高，不建议降低。

## 兼容性说明

不开启任何新环境变量时：

```text
VISION_STATE_BACKEND=file
VISION_SESSION_BACKEND=file
VISION_ARTIFACT_BACKEND=file
```

行为与原单机版本兼容。现有 API、工作流 JSON、项目文件和三种执行模式保持可用。

PostgreSQL、Redis、MinIO 适配器具备自动化单元测试和模拟驱动测试；发布环境未连接真实外部服务进行端到端压测，正式切换前应在团队的预生产环境执行迁移演练、备份恢复和负载测试。
