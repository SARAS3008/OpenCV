# v14.9 Mask 最小外接旋转矩形点位输出修复

## 背景

`MaskMinAreaRect` 节点在诊断图中绘制的 TL/TR/BL/BR 标注位置正确，但下游使用点输出端口或在预览数据中查看点值时，容易出现“图上看起来正确，但端口点值不一致/语义不清”的问题。

## 根因

旧实现存在两个容易引起误解或下游误用的点：

1. 端口输出使用浮点坐标，而诊断图使用 `int(round(x/y))` 后的像素坐标绘制。用户在图像上看到的是像素点，端口返回的是小数点坐标，两者会出现视觉不一致。
2. 四角点排序依赖 sum/diff 规则，在部分旋转角度或接近竖直矩形时，角点语义可能不稳定。普通图像坐标里的“左上/右上/左下/右下”应该由屏幕坐标语义决定，而不是由 OpenCV 原始 box 点顺序或 sum/diff 推断。

## 修复内容

### 1. 端口点值与图上绘制一致

`top_left`、`top_right`、`bottom_left`、`bottom_right`、`points`、`lines` 端口现在输出与诊断图绘制一致的整数像素坐标。

高精度浮点点位仍保留在：

```python
rect["raw_points"]
rect["raw_top_left"]
rect["raw_top_right"]
rect["raw_bottom_left"]
rect["raw_bottom_right"]
rect["raw_lines"]
```

### 2. 四角点排序规则调整

四点排序现在使用图像坐标语义：

1. 先按 y 坐标把四个点分成上边两个点和下边两个点；
2. 上边两个点按 x 排序得到 TL、TR；
3. 下边两个点按 x 排序得到 BL、BR；
4. `points` 统一输出为 `[TL, TR, BR, BL]`。

### 3. 数据区完整同步点位输出

`data` 中现在同步包含所有端口值：

```python
points
top_left
top_right
bottom_left
bottom_right
lines
angle
center
size
rect
```

这样在前端预览、Python 代码片段或调试时，可以直接对照端口输出和 `data` 输出。

### 4. 角度语义增强

- `angle`：按 TL→TR 上边方向计算的视觉角度；
- `opencv_angle`：OpenCV `minAreaRect` 的原始角度，保存在 `rect` 与 metrics 中，便于需要兼容 OpenCV 语义的高级场景。

## 推荐使用方式

如果你要取左上点用于后续测量，直接连接：

```text
Mask最小外接旋转矩形.top_left → 点到直线距离.point
```

如果你要取某条边，推荐：

```text
Mask最小外接旋转矩形.rect → 旋转矩形取点/边.rect
旋转矩形取点/边.line → 点到直线距离.line
```

## 回归测试

新增测试覆盖：

- 端口点值与 `rect` 对象一致；
- 端口点值与 `data` 中点值一致；
- 四条边与四个角点的组合关系一致；
- `RotatedRectFeature` 从 `rect` 输入读取点时保持一致。
