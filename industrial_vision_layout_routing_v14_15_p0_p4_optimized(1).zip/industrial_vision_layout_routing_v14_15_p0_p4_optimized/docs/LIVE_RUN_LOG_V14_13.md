# 实时运行日志 v14.13

## 改造目标

右侧原“运行预览”与每个节点下方的结果区域重复。v14.13 将右侧区域改为实时运行日志：

- 图像、数值和错误结果仍显示在对应节点下方；
- 右侧仅显示工作流执行过程；
- 每条日志包含本地时间、级别、事件说明和必要的节点/图片信息；
- 日志自动滚动并限制为最近 500 条，避免长时间运行持续占用浏览器内存；
- 支持手动清空和折叠。

## 流式接口

新增：

```text
POST /api/run-stream
Content-Type: application/json
Accept: application/x-ndjson
```

响应采用 NDJSON，每行一个 JSON 对象：

```json
{"kind":"log","data":{"event":"node_started","level":"info","timestamp":"2026-07-16T01:14:00+02:00","message":"开始执行节点 n1 · 读取图像"}}
{"kind":"log","data":{"event":"node_completed","level":"success","timestamp":"2026-07-16T01:14:01+02:00","message":"节点 n1 · 读取图像执行完成（12.30 ms，图像）"}}
{"kind":"result","data":{"success":true,"mode":"single","previews":[],"order":["n1"]}}
```

执行期错误仍会先推送实时错误日志，最后发送：

```json
{"kind":"error","status":400,"data":{"success":false,"error":"..."}}
```

原 `POST /api/run` 保留不变，旧客户端和独立脚本不需要迁移。

## 事件类型

单图工作流：

- `workflow_started`
- `node_started`
- `node_completed`
- `node_failed`
- `workflow_completed`
- `workflow_failed`

批量工作流：

- `batch_started`
- `batch_item_started`
- `batch_item_completed`
- `batch_item_failed`
- `batch_completed`

批量运行不逐节点推送日志，而是按图片推送进度，避免图片数量乘以节点数量后产生过多日志。

## 代理部署注意事项

流式响应包含以下响应头：

```text
Cache-Control: no-cache, no-transform
X-Accel-Buffering: no
```

使用 Nginx 时仍建议对 `/api/run-stream` 显式关闭代理缓冲，并适当增加读取超时。不要对该接口进行整段响应缓存。
