# v14.7 几何测量与 Mask 工具算子

本版本新增 5 个公共图像节点，用于 Mask 区域几何测量、旋转矩形取点/边、Mask 抠图、边缘直线拟合以及点到直线距离测量。

## 1. Mask最小外接旋转矩形（MaskMinAreaRect）

位置：`图像节点库 → 几何测量 → Mask最小外接旋转矩形`

输入：

- `in`：Mask / 二值图 / 灰度图 / 彩色图。

主要参数：

- `threshold`：Mask 阈值，默认 1。
- `invert_mask`：是否反转 Mask。
- `select_mode`：
  - `UNION`：所有前景点整体计算最小外接旋转矩形。
  - `LARGEST`：只对最大连通轮廓计算。

输出：

- `out`：带矩形和四角点标注的诊断图。
- `rect`：旋转矩形对象。
- `points`：四个顶点，顺序为左上、右上、右下、左下。
- `top_left` / `top_right` / `bottom_left` / `bottom_right`：四个角点。
- `lines`：四条边线。
- `angle`：角度。
- `center`：中心点。
- `size`：宽高。

## 2. 旋转矩形取点/边（RotatedRectFeature）

位置：`图像节点库 → 几何测量 → 旋转矩形取点/边`

输入：

- `rect`：旋转矩形对象，通常来自 `MaskMinAreaRect.rect`。
- `image`：可选背景图，仅用于诊断标注。

主要参数：

- `feature_type`：`POINT` 或 `LINE`。
- `point`：`TOP_LEFT`、`BOTTOM_LEFT`、`TOP_RIGHT`、`BOTTOM_RIGHT`。
- `line`：`LEFT`、`RIGHT`、`TOP`、`BOTTOM`。
- 如果不连接 `rect`，可用 `center_x / center_y / width / height / angle` 手动定义矩形。

输出：

- `selected`：当前选择的点或线。
- `point`：选中的点。
- `line`：选中的线，包含 `p1`、`p2`、`abc`。
- `points`：全部四点。
- `lines`：全部四边。
- `out`：诊断图。

## 3. Mask抠图（ApplyMask）

位置：`图像节点库 → ROI与Mask → Mask抠图`

输入：

- `in`：原图。
- `mask`：Mask 图。

主要参数：

- `threshold`：Mask 阈值。
- `invert_mask`：是否反转 Mask。
- `resize_mask`：Mask 尺寸与原图不一致时是否自动缩放。
- `bbox_mode`：`UNION` 或 `LARGEST`。
- `background`：非 Mask 区域使用黑色或白色。
- `output_mode`：
  - `MASKED`：`out` 输出全图抠图。
  - `ROI`：`out` 输出裁剪 ROI。
  - `ROI_MASK`：`out` 输出 ROI 局部 Mask。
  - `MASK`：`out` 输出全图二值 Mask。

输出：

- `out`：根据 `output_mode` 决定。
- `masked`：全图抠图。
- `mask`：全图二值 Mask。
- `roi`：裁剪后的抠图 ROI。
- `roi_mask`：ROI 局部 Mask。
- `bbox`：外接框 `[x, y, w, h]`。

## 4. 边缘拟合直线（FitLineFromEdges）

位置：`图像节点库 → 几何测量 → 边缘拟合直线`

输入：

- `in`：Canny 等边缘检测结果。

主要参数：

- `threshold`：边缘点阈值。
- `distance_type`：`L2`、`L1`、`L12`、`FAIR`、`WELSCH`、`HUBER`。
- `min_points`：最少边缘点数。
- `max_points`：最多采样点数，0 为不限。
- `draw_points`：是否绘制边缘点。

输出：

- `line`：拟合直线对象，包含 `p1`、`p2`、`abc`、`vx`、`vy`、`x0`、`y0`、`angle`。
- `p1` / `p2`：画布边界上的两个显示端点。
- `abc`：直线一般式 `ax + by + c = 0`。
- `angle`：直线方向角。
- `out`：诊断图。

## 5. 点到直线距离（PointLineDistance）

位置：`图像节点库 → 几何测量 → 点到直线距离`

输入：

- `point`：点，通常来自 `RotatedRectFeature.point` 或 `MaskMinAreaRect.top_left` 等端口。
- `line`：直线，通常来自 `FitLineFromEdges.line` 或 `RotatedRectFeature.line`。
- `image`：可选背景图，仅用于诊断标注。

输出：

- `distance` / `value`：点到直线的垂直距离。
- `signed_distance`：有符号距离。
- `foot_point`：垂足坐标。
- `out`：诊断标注图。

## 推荐流程

### A. 从 Mask 获取旋转矩形的左边线

```text
ReadImage / Threshold / FilterContours.mask
  → Mask最小外接旋转矩形
  → 旋转矩形取点/边(feature_type=LINE, line=LEFT)
```

### B. 从 Canny 边缘拟合直线，并计算某角点到该直线距离

```text
ReadImage
  → Canny
  → 边缘拟合直线

Mask / ROI
  → Mask最小外接旋转矩形
  → 旋转矩形取点/边(feature_type=POINT, point=TOP_LEFT)

旋转矩形取点/边.point + 边缘拟合直线.line
  → 点到直线距离
```

### C. 用 Mask 从原图抠出目标区域

```text
ReadImage.out + FilterContours.mask / ORBFeatureMatch.mask
  → Mask抠图(output_mode=ROI 或 MASKED)
```
