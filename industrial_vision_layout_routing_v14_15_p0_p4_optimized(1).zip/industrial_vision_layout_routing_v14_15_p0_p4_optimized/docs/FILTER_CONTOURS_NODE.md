# 轮廓筛选节点（FilterContours）

`FilterContours` 是面向二值图测量和缺陷筛选的专用图像算子。它用于从二值图或灰度/彩色图中提取轮廓，再按照指定指标排序，并输出最大、最小、TopK、BottomK 或第 N 个轮廓。

## 节点位置

节点库：`图像 / 测量分析 / 轮廓筛选`

算子类型名：`FilterContours`

实现文件：

```text
backend/algorithms/image/contours.py
```

注册位置：

```text
backend/algorithms/registry.py
backend/algorithms/metadata.py
```

## 典型用途

- 从二值图中获取最大连通区域；
- 从二值图中获取最小杂质/缺陷轮廓；
- 按圆度筛选近似圆形目标；
- 按外接框宽度/高度筛选长条形区域；
- 输出选中轮廓的 mask、ROI、bbox 和轮廓点，供后续测量或逻辑判断节点使用。

## 推荐工作流

```text
ReadImage
  -> ColorConvert / Gray
  -> Threshold / OtsuThreshold / AdaptiveThreshold
  -> MorphOpen / MorphClose，可选
  -> FilterContours
  -> Display / LogicCompare / PythonSnippet
```

如果上游已经是二值图，`binary_mode` 建议使用 `INPUT_BINARY`。

## 输入端口

| 端口 | 类型 | 必填 | 说明 |
|---|---|---:|---|
| `in` | image | 是 | 输入二值图、灰度图或彩色图。 |

## 输出端口

| 端口 | 类型 | 说明 |
|---|---|---|
| `out` | image | 标注图。候选轮廓灰色绘制，选中轮廓绿色绘制。 |
| `mask` | image | 选中轮廓在原图坐标系下的全图二值 mask。 |
| `roi` | image | 选中轮廓整体外接框裁剪出的 ROI。 |
| `roi_mask` | image | `roi` 坐标系下的局部二值 mask。 |
| `bbox` | list | 选中轮廓整体外接框 `[x, y, w, h]`。 |
| `contour` | list | 主轮廓点集，通常是排序后的第一个轮廓。 |
| `contours` | list | 所有选中轮廓点集。 |
| `contour_infos` | list | 所有选中轮廓的统计指标。 |

## 核心参数

| 参数 | 默认值 | 说明 |
|---|---:|---|
| `binary_mode` | `AUTO` | 二值化方式。 |
| `threshold` | `127` | 普通阈值模式下使用。 |
| `retrieval_mode` | `EXTERNAL` | 轮廓检索模式。 |
| `approx_mode` | `SIMPLE` | 轮廓点压缩方式。 |
| `sort_by` | `area` | 排序指标。 |
| `select_mode` | `MAX` | 选择方式。 |
| `top_k` | `1` | TopK 或 BottomK 时选取数量。 |
| `nth_index` | `0` | `NTH` 模式下选取排序后的第几个，从 0 开始。 |
| `min_area` | `0` | 面积下限。 |
| `max_area` | `0` | 面积上限，0 表示不限制。 |
| `min_perimeter` | `0` | 周长下限。 |
| `max_perimeter` | `0` | 周长上限，0 表示不限制。 |
| `min_width` / `max_width` | `0` | 外接框宽度范围。 |
| `min_height` / `max_height` | `0` | 外接框高度范围。 |
| `max_points` | `200` | 返回轮廓点最大数量，0 表示不限制。 |
| `draw_all` | `YES` | 是否在标注图中灰色绘制候选轮廓。 |

## binary_mode 选项

| 值 | 说明 |
|---|---|
| `AUTO` | 自动判断。输入像素基本为 0/255 时直接使用，否则按 `threshold` 阈值化。 |
| `INPUT_BINARY` | 输入已经是二值图，非零像素都视为前景。 |
| `THRESH_BINARY` | 普通阈值。 |
| `THRESH_BINARY_INV` | 反向阈值。 |
| `OTSU` | Otsu 自动阈值。 |
| `OTSU_INV` | Otsu 反向自动阈值。 |

## sort_by 排序指标

| 值 | 说明 |
|---|---|
| `area` | 轮廓面积。 |
| `perimeter` | 轮廓周长。 |
| `bbox_width` | 外接框宽度。 |
| `bbox_height` | 外接框高度。 |
| `bbox_area` | 外接框面积。 |
| `aspect_ratio` | 宽高比。 |
| `circularity` | 圆度，越接近 1 越接近圆。 |
| `solidity` | 实心度，轮廓面积 / 凸包面积。 |
| `extent` | 矩形填充率，轮廓面积 / 外接框面积。 |
| `center_x` | 轮廓中心 X 坐标。 |
| `center_y` | 轮廓中心 Y 坐标。 |

## select_mode 选择方式

| 值 | 说明 |
|---|---|
| `MAX` | 按排序指标取最大/最高的一个。 |
| `MIN` | 按排序指标取最小/最低的一个。 |
| `TOP_K` | 按排序指标取最大的 K 个。 |
| `BOTTOM_K` | 按排序指标取最小的 K 个。 |
| `NTH` | 按 `sort_order` 排序后取第 `nth_index` 个。 |
| `ALL_SORTED` | 全部保留，并按 `sort_order` 排序。 |

## 常用配置示例

### 获取最大轮廓

```text
binary_mode = INPUT_BINARY
sort_by = area
select_mode = MAX
min_area = 0
```

### 获取最小轮廓

```text
binary_mode = INPUT_BINARY
sort_by = area
select_mode = MIN
min_area = 0
```

### 获取面积最大的 3 个轮廓

```text
sort_by = area
select_mode = TOP_K
top_k = 3
```

### 获取最圆的目标

```text
sort_by = circularity
select_mode = MAX
min_area = 100
```

### 获取最靠左的轮廓

```text
sort_by = center_x
select_mode = MIN
```

## 后续节点连接建议

- 接 `mask` 到 Python 代码片段节点，可以做局部统计或抠图；
- 接 `roi` 到后续图像处理节点，可以只处理最大轮廓区域；
- 接 `bbox` / `contour_infos` 到 Python 代码片段节点，可以做自定义判定；
- 通过 `metrics.primary_area`、`metrics.selected_count` 等指标写入批量 CSV，适合回归测试和批量分析。

## 维护注意事项

1. `data` 和 `metrics` 不能返回 NumPy 数组，因此轮廓点会被转换成普通 Python list。
2. `mask`、`roi`、`roi_mask` 是图像输出端口，可以继续传给后续图像节点。
3. `max_points` 用于限制 JSON 返回的轮廓点数量，避免复杂轮廓导致响应过大。
4. 如果需要保留轮廓层级关系，可以把 `retrieval_mode` 设置为 `TREE`，但当前输出主要关注筛选后的轮廓本身，不返回完整 hierarchy。
5. 如果后续要扩展更多筛选指标，优先在 `_contour_info()` 中增加指标，再把字段加入 `_SORT_FIELDS` 和 `metadata.py` 的 `sort_by` 参数选项。
