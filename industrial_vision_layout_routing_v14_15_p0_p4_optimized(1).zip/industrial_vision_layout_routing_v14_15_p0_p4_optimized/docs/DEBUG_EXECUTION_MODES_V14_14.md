# 三种运行与调试模式 v14.14

## 功能目标

顶部运行区域提供三种模式：

1. **整体运行**：保持原行为，从头执行完整工作流；
2. **单步运行**：每次只执行一个新的可执行节点；
3. **运行到节点**：执行目标节点所需的依赖和目标节点，然后暂停；暂停后自动切换为“继续单步”。

节点结果仍显示在节点下方，右侧实时日志会同步显示调试会话、节点开始、完成、失败、暂停和结束事件。

## 调试执行语义

- 调试状态保存在服务端会话中，后续单步不会重复计算已经完成的节点；
- 节点执行顺序遵循工作流依赖关系；
- `If / Else` 只执行实际选中的分支，未选分支会在调试完成时列为跳过节点；
- “运行到节点”包含目标节点本身；
- 目标节点完成后，下一次单步会从整个工作流剩余的实际执行路径继续；
- 修改节点参数、节点类型或连线会使当前调试会话失效；移动、折叠或修改节点颜色不会中断调试；
- 节点失败时会保留调试会话和上游结果，可在外部资源恢复后重试；如果修改参数修复节点，则会重新创建调试会话。

## 画布状态

- 绿色边框：已经执行；
- 黄色高亮：当前暂停或刚执行的节点；
- 蓝色高亮：下一步节点；
- 紫色虚线：运行到节点模式的目标节点。

点击“重置调试”会释放当前会话中的图像和中间数据，但不会删除节点下方已经显示的结果预览。

## API

### 调试执行

```text
POST /api/debug/run-stream
Content-Type: application/json
Accept: application/x-ndjson
```

单步请求：

```json
{
  "workflow": {"nodes": [], "edges": []},
  "session_id": null,
  "action": "step",
  "target_node_id": null
}
```

运行到节点请求：

```json
{
  "workflow": {"nodes": [], "edges": []},
  "session_id": null,
  "action": "run_to_node",
  "target_node_id": "n8"
}
```

后续请求携带响应中的 `debug_session_id`。最终结果包含：

- `executed_order`：累计已执行节点；
- `newly_executed`：本次新执行节点；
- `current_node_id`：当前暂停节点；
- `next_node_id`：下一步节点；
- `pending_nodes`：尚未完成节点；
- `skipped_nodes`：条件分支中未选择的节点；
- `completed`：工作流是否已经完成；
- `previews`：累计节点结果预览。

### 重置调试会话

```text
POST /api/debug/reset
```

```json
{"session_id":"..."}
```

## 批量工作流

批量工作流进入单步调试时只使用目录中的第一张图片，并禁用批量结果写盘。右侧日志会明确提示调试图片名称。整体运行仍按原有方式处理全部图片并保存结果。

## 资源和部署限制

- 会话默认 30 分钟无操作后过期；
- 每个工作区默认最多保留 2 个会话，服务进程默认最多保留 8 个会话；
- 服务重启会清除调试会话；
- 单个会话默认最多占用约 512 MB 中间结果内存，超过限制会停止并提示缩小图片或重置会话；
- 调试输出可能包含较大的 NumPy 图像，因此完成后应点击“重置调试”及时释放内存；
- 当前会话存储在单个服务进程内。使用多个 Uvicorn Worker 或多实例部署时，需要使用粘性会话，或将调试调度迁移到专用 Worker/共享状态服务。

可通过环境变量调整：`VISION_DEBUG_SESSION_TTL_SECONDS`、`VISION_DEBUG_SESSION_MAX_ITEMS`、`VISION_DEBUG_SESSION_MAX_PER_WORKSPACE` 和 `VISION_DEBUG_SESSION_MAX_MEMORY_BYTES`。
