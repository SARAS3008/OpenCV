# v14.11 点到直线距离坐标语义与输入诊断优化

## 背景

用户在使用 `Mask最小外接旋转矩形 -> 点到直线距离` 时，看到上游节点标注的 TL/TR/BL/BR 正确，但下游 `点到直线距离` 节点的预览中红点位置容易被误认为不是对应角点。

排查结果：平台内置几何节点的点坐标标准为 `[x, y]`，没有发生 x/y 自动反转。造成误解的主要原因是：`点到直线距离` 在未连接背景图时，会自动生成一张黑色诊断画布，画布不包含上游 mask/原图上下文，因此红点虽然按实际坐标绘制，但视觉上不容易和上游矩形图对应。

同时，如果 line 来自裁剪 ROI，而 point 来自原图全局坐标，也会导致测量结果不符合预期。这属于坐标系混用问题，不是 x/y 反了。

## 本次优化

### 1. 坐标顺序显式参数

`PointLineDistance` 新增参数：

- `point_order = XY`：默认，表示输入点为 `[x, y]` 图像坐标。
- `point_order = YX`：表示输入点为 `[y, x]` / `[row, col]`，节点内部会自动交换为 `[x, y]`。

平台内置节点，例如 `MaskMinAreaRect`、`RotatedRectFeature`，均输出 `[x, y]`，正常情况下不需要切换。

### 2. 结果中显示实际使用点

`PointLineDistance` 的 `metrics/data` 现在包含：

- `point_x`
- `point_y`
- `raw_point_x`
- `raw_point_y`
- `point_order`
- `canvas_source`
- `canvas_shape`
- `point_source_shape`
- `line_source_shape`
- `warnings`

这样可以直接确认下游节点到底使用了哪个点。

### 3. 诊断图标注点坐标

`PointLineDistance` 的标注图现在会显示：

```text
P=(x,y)
d=...
```

便于与上游节点的 `top_left_x/top_left_y` 等指标核对。

### 4. 传递图像坐标空间元信息

`MaskMinAreaRect` 和 `FitLineFromEdges` 现在会在 `data` 中输出：

```json
{
  "image_shape": [height, width],
  "coordinate_order": "XY"
}
```

`PointLineDistance` 会读取 `point_data` / `line_data` 中的 `image_shape`。当发现 point 和 line 来源图尺寸不一致时，会在 `warnings` 中提示可能存在全图坐标和 ROI 局部坐标混用。

## 使用建议

### 正常全图测量

如果点和线都来自同一张全图：

```text
point_order = XY
```

无需额外设置。

### 如果线来自裁剪 ROI

如果 `FitLineFromEdges` 的输入是裁剪 ROI，而点来自全图坐标，测量结果会不正确。此时需要把 ROI 内拟合线转换回全图坐标，或者在同一个 ROI 坐标系中计算点。

### 如果点来自 numpy 非零点坐标

`np.nonzero()` / `np.where()` 常返回 `[row, col]`，也就是 `[y, x]`。这种自定义代码输出的点，应设置：

```text
point_order = YX
```
