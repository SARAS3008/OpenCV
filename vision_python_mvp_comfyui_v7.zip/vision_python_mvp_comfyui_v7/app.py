import base64
import uuid
from collections import deque
from pathlib import Path
from typing import Any, Callable, Dict, List

import cv2
import numpy as np
from fastapi import FastAPI, File, UploadFile
from fastapi.responses import HTMLResponse, JSONResponse

BASE_DIR = Path(__file__).parent.resolve()
UPLOAD_DIR = BASE_DIR / "uploads"
UPLOAD_DIR.mkdir(exist_ok=True)

app = FastAPI(title="Industrial Vision Python MVP - ComfyUI Style v5")
IMAGE_STORE: Dict[str, str] = {}


def to_int(value: Any, default: int) -> int:
    try:
        return int(float(value))
    except Exception:
        return default


def to_float(value: Any, default: float) -> float:
    try:
        return float(value)
    except Exception:
        return default


def ensure_odd(value: Any, default: int = 3, minimum: int = 1) -> int:
    value = to_int(value, default)
    if value < minimum:
        value = minimum
    if value % 2 == 0:
        value += 1
    return value


def ensure_gray(img: np.ndarray) -> np.ndarray:
    if img is None:
        raise ValueError("输入图像为空")
    if len(img.shape) == 2:
        return img
    return cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)


def ensure_bgr(img: np.ndarray) -> np.ndarray:
    if img is None:
        raise ValueError("输入图像为空")
    if len(img.shape) == 2:
        return cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)
    return img


def kernel_from_params(params: Dict[str, Any], default: int = 3) -> np.ndarray:
    ksize = ensure_odd(params.get("ksize", default), default, 1)
    return np.ones((ksize, ksize), np.uint8)


# =========================
# OpenCV 图像算子
# =========================
def op_read_image(inputs: Dict[str, Any], params: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
    image_id = params.get("image_id") or context.get("image_id")
    if not image_id:
        raise ValueError("请先上传图片，或为 ReadImage 节点设置 image_id")

    path = IMAGE_STORE.get(image_id)
    if not path and (UPLOAD_DIR / image_id).exists():
        path = str(UPLOAD_DIR / image_id)
    if not path:
        raise ValueError(f"找不到图片：{image_id}")

    img = cv2.imread(path, cv2.IMREAD_COLOR)
    if img is None:
        raise ValueError(f"OpenCV 读取图片失败：{image_id}")
    return {"out": img}


def op_display(inputs: Dict[str, Any], params: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
    return {"out": inputs["in"]}


def op_gray(inputs: Dict[str, Any], params: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
    return {"out": ensure_gray(inputs["in"])}


def op_bgr_to_rgb(inputs: Dict[str, Any], params: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
    img = ensure_bgr(inputs["in"])
    return {"out": cv2.cvtColor(img, cv2.COLOR_BGR2RGB)}


def op_invert(inputs: Dict[str, Any], params: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
    return {"out": cv2.bitwise_not(inputs["in"])}


def op_normalize(inputs: Dict[str, Any], params: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
    return {"out": cv2.normalize(inputs["in"], None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)}


def op_equalize_hist(inputs: Dict[str, Any], params: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
    gray = ensure_gray(inputs["in"])
    return {"out": cv2.equalizeHist(gray)}


def op_clahe(inputs: Dict[str, Any], params: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
    gray = ensure_gray(inputs["in"])
    clip = to_float(params.get("clip_limit", 2.0), 2.0)
    tile = ensure_odd(params.get("tile_grid", 8), 8, 2)
    clahe = cv2.createCLAHE(clipLimit=clip, tileGridSize=(tile, tile))
    return {"out": clahe.apply(gray)}


def op_mean_blur(inputs: Dict[str, Any], params: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
    ksize = ensure_odd(params.get("ksize", 5), 5)
    return {"out": cv2.blur(inputs["in"], (ksize, ksize))}


def op_gaussian_blur(inputs: Dict[str, Any], params: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
    ksize = ensure_odd(params.get("ksize", 5), 5)
    sigma = to_float(params.get("sigma", 0), 0.0)
    return {"out": cv2.GaussianBlur(inputs["in"], (ksize, ksize), sigma)}


def op_median_blur(inputs: Dict[str, Any], params: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
    ksize = ensure_odd(params.get("ksize", 5), 5)
    return {"out": cv2.medianBlur(inputs["in"], ksize)}


def op_bilateral_filter(inputs: Dict[str, Any], params: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
    d = to_int(params.get("d", 7), 7)
    sigma_color = to_float(params.get("sigma_color", 75), 75)
    sigma_space = to_float(params.get("sigma_space", 75), 75)
    return {"out": cv2.bilateralFilter(inputs["in"], d, sigma_color, sigma_space)}


def op_sharpen(inputs: Dict[str, Any], params: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
    amount = to_float(params.get("amount", 1.0), 1.0)
    kernel = np.array([[0, -1, 0], [-1, 4 + amount, -1], [0, -1, 0]], dtype=np.float32)
    out = cv2.filter2D(inputs["in"], -1, kernel)
    return {"out": out}


def op_threshold(inputs: Dict[str, Any], params: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
    gray = ensure_gray(inputs["in"])
    threshold = to_int(params.get("threshold", 127), 127)
    max_value = to_int(params.get("max_value", 255), 255)
    _, out = cv2.threshold(gray, threshold, max_value, cv2.THRESH_BINARY)
    return {"out": out}


def op_otsu_threshold(inputs: Dict[str, Any], params: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
    gray = ensure_gray(inputs["in"])
    _, out = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    return {"out": out}


def op_adaptive_threshold(inputs: Dict[str, Any], params: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
    gray = ensure_gray(inputs["in"])
    block_size = ensure_odd(params.get("block_size", 11), 11, 3)
    c = to_int(params.get("c", 2), 2)
    out = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, block_size, c)
    return {"out": out}


def op_canny(inputs: Dict[str, Any], params: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
    gray = ensure_gray(inputs["in"])
    t1 = to_int(params.get("threshold1", 50), 50)
    t2 = to_int(params.get("threshold2", 150), 150)
    return {"out": cv2.Canny(gray, t1, t2)}


def op_sobel(inputs: Dict[str, Any], params: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
    gray = ensure_gray(inputs["in"])
    dx = to_int(params.get("dx", 1), 1)
    dy = to_int(params.get("dy", 0), 0)
    ksize = ensure_odd(params.get("ksize", 3), 3, 1)
    grad = cv2.Sobel(gray, cv2.CV_16S, dx, dy, ksize=ksize)
    return {"out": cv2.convertScaleAbs(grad)}


def op_laplacian(inputs: Dict[str, Any], params: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
    gray = ensure_gray(inputs["in"])
    ksize = ensure_odd(params.get("ksize", 3), 3, 1)
    out = cv2.Laplacian(gray, cv2.CV_16S, ksize=ksize)
    return {"out": cv2.convertScaleAbs(out)}


def op_erode(inputs: Dict[str, Any], params: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
    iterations = to_int(params.get("iterations", 1), 1)
    return {"out": cv2.erode(inputs["in"], kernel_from_params(params, 3), iterations=iterations)}


def op_dilate(inputs: Dict[str, Any], params: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
    iterations = to_int(params.get("iterations", 1), 1)
    return {"out": cv2.dilate(inputs["in"], kernel_from_params(params, 3), iterations=iterations)}


def op_morph_open(inputs: Dict[str, Any], params: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
    return {"out": cv2.morphologyEx(inputs["in"], cv2.MORPH_OPEN, kernel_from_params(params, 3))}


def op_morph_close(inputs: Dict[str, Any], params: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
    return {"out": cv2.morphologyEx(inputs["in"], cv2.MORPH_CLOSE, kernel_from_params(params, 3))}


def op_morph_gradient(inputs: Dict[str, Any], params: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
    return {"out": cv2.morphologyEx(inputs["in"], cv2.MORPH_GRADIENT, kernel_from_params(params, 3))}


def op_resize(inputs: Dict[str, Any], params: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
    img = inputs["in"]
    scale = to_float(params.get("scale_percent", 50), 50.0)
    scale = max(scale, 1.0)
    width = max(1, int(img.shape[1] * scale / 100.0))
    height = max(1, int(img.shape[0] * scale / 100.0))
    return {"out": cv2.resize(img, (width, height), interpolation=cv2.INTER_AREA)}


def op_flip(inputs: Dict[str, Any], params: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
    code = to_int(params.get("flip_code", 1), 1)  # 1水平，0垂直，-1水平+垂直
    if code not in [-1, 0, 1]:
        code = 1
    return {"out": cv2.flip(inputs["in"], code)}


def op_rotate90(inputs: Dict[str, Any], params: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
    direction = to_int(params.get("direction", 0), 0)  # 0顺时针，1逆时针，2旋转180
    if direction == 1:
        code = cv2.ROTATE_90_COUNTERCLOCKWISE
    elif direction == 2:
        code = cv2.ROTATE_180
    else:
        code = cv2.ROTATE_90_CLOCKWISE
    return {"out": cv2.rotate(inputs["in"], code)}


def op_find_contours(inputs: Dict[str, Any], params: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
    img = inputs["in"]
    gray = ensure_gray(img)
    threshold = to_int(params.get("threshold", 127), 127)
    min_area = to_float(params.get("min_area", 20), 20.0)
    _, binary = cv2.threshold(gray, threshold, 255, cv2.THRESH_BINARY)
    contours, _ = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    canvas = ensure_bgr(img).copy()
    count = 0
    for contour in contours:
        if cv2.contourArea(contour) < min_area:
            continue
        cv2.drawContours(canvas, [contour], -1, (0, 255, 0), 2)
        x, y, w, h = cv2.boundingRect(contour)
        cv2.rectangle(canvas, (x, y), (x + w, y + h), (0, 180, 255), 1)
        count += 1
    cv2.putText(canvas, f"contours: {count}", (12, 28), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 220, 255), 2)
    return {"out": canvas}


OPERATORS: Dict[str, Callable[[Dict[str, Any], Dict[str, Any], Dict[str, Any]], Dict[str, Any]]] = {
    "ReadImage": op_read_image,
    "Display": op_display,
    "Gray": op_gray,
    "BGR2RGB": op_bgr_to_rgb,
    "Invert": op_invert,
    "Normalize": op_normalize,
    "EqualizeHist": op_equalize_hist,
    "CLAHE": op_clahe,
    "MeanBlur": op_mean_blur,
    "GaussianBlur": op_gaussian_blur,
    "MedianBlur": op_median_blur,
    "BilateralFilter": op_bilateral_filter,
    "Sharpen": op_sharpen,
    "Threshold": op_threshold,
    "OtsuThreshold": op_otsu_threshold,
    "AdaptiveThreshold": op_adaptive_threshold,
    "Canny": op_canny,
    "Sobel": op_sobel,
    "Laplacian": op_laplacian,
    "Erode": op_erode,
    "Dilate": op_dilate,
    "MorphOpen": op_morph_open,
    "MorphClose": op_morph_close,
    "MorphGradient": op_morph_gradient,
    "Resize": op_resize,
    "Flip": op_flip,
    "Rotate90": op_rotate90,
    "FindContours": op_find_contours,
}

OPERATOR_META: Dict[str, Dict[str, Any]] = {
    "ReadImage": {"label": "读取图像", "category": "图像", "group": "输入输出", "kind": "io", "has_input": False, "has_output": True, "params": {}, "description": "读取当前上传的图片。"},
    "Display": {"label": "结果显示", "category": "图像", "group": "输入输出", "kind": "io", "has_input": True, "has_output": True, "params": {}, "description": "显示并传递上游结果。"},
    "Gray": {"label": "灰度化", "category": "图像", "group": "颜色与增强", "kind": "color", "has_input": True, "has_output": True, "params": {}, "description": "BGR/RGB 图像转灰度。"},
    "BGR2RGB": {"label": "BGR转RGB", "category": "图像", "group": "颜色与增强", "kind": "color", "has_input": True, "has_output": True, "params": {}, "description": "颜色通道转换。"},
    "Invert": {"label": "反相", "category": "图像", "group": "颜色与增强", "kind": "color", "has_input": True, "has_output": True, "params": {}, "description": "像素取反。"},
    "Normalize": {"label": "归一化", "category": "图像", "group": "颜色与增强", "kind": "color", "has_input": True, "has_output": True, "params": {}, "description": "拉伸到 0-255。"},
    "EqualizeHist": {"label": "直方图均衡", "category": "图像", "group": "颜色与增强", "kind": "color", "has_input": True, "has_output": True, "params": {}, "description": "灰度直方图均衡化。"},
    "CLAHE": {"label": "CLAHE增强", "category": "图像", "group": "颜色与增强", "kind": "color", "has_input": True, "has_output": True, "params": {"clip_limit": 2.0, "tile_grid": 8}, "description": "局部对比度增强。"},
    "MeanBlur": {"label": "均值滤波", "category": "图像", "group": "滤波降噪", "kind": "filter", "has_input": True, "has_output": True, "params": {"ksize": 5}, "description": "均值平滑。"},
    "GaussianBlur": {"label": "高斯滤波", "category": "图像", "group": "滤波降噪", "kind": "filter", "has_input": True, "has_output": True, "params": {"ksize": 5, "sigma": 0}, "description": "高斯平滑，常用于边缘检测前降噪。"},
    "MedianBlur": {"label": "中值滤波", "category": "图像", "group": "滤波降噪", "kind": "filter", "has_input": True, "has_output": True, "params": {"ksize": 5}, "description": "适合去椒盐噪声。"},
    "BilateralFilter": {"label": "双边滤波", "category": "图像", "group": "滤波降噪", "kind": "filter", "has_input": True, "has_output": True, "params": {"d": 7, "sigma_color": 75, "sigma_space": 75}, "description": "保边去噪。"},
    "Sharpen": {"label": "锐化", "category": "图像", "group": "滤波降噪", "kind": "filter", "has_input": True, "has_output": True, "params": {"amount": 1.0}, "description": "增强边缘与细节。"},
    "Threshold": {"label": "固定阈值", "category": "图像", "group": "阈值与边缘", "kind": "segment", "has_input": True, "has_output": True, "params": {"threshold": 127, "max_value": 255}, "description": "灰度二值化。"},
    "OtsuThreshold": {"label": "Otsu阈值", "category": "图像", "group": "阈值与边缘", "kind": "segment", "has_input": True, "has_output": True, "params": {}, "description": "自动阈值分割。"},
    "AdaptiveThreshold": {"label": "自适应阈值", "category": "图像", "group": "阈值与边缘", "kind": "segment", "has_input": True, "has_output": True, "params": {"block_size": 11, "c": 2}, "description": "适合光照不均场景。"},
    "Canny": {"label": "Canny边缘", "category": "图像", "group": "阈值与边缘", "kind": "segment", "has_input": True, "has_output": True, "params": {"threshold1": 50, "threshold2": 150}, "description": "经典边缘检测。"},
    "Sobel": {"label": "Sobel梯度", "category": "图像", "group": "阈值与边缘", "kind": "segment", "has_input": True, "has_output": True, "params": {"dx": 1, "dy": 0, "ksize": 3}, "description": "一阶梯度边缘。"},
    "Laplacian": {"label": "Laplacian边缘", "category": "图像", "group": "阈值与边缘", "kind": "segment", "has_input": True, "has_output": True, "params": {"ksize": 3}, "description": "二阶边缘检测。"},
    "Erode": {"label": "腐蚀", "category": "图像", "group": "形态学", "kind": "morph", "has_input": True, "has_output": True, "params": {"ksize": 3, "iterations": 1}, "description": "收缩白色区域。"},
    "Dilate": {"label": "膨胀", "category": "图像", "group": "形态学", "kind": "morph", "has_input": True, "has_output": True, "params": {"ksize": 3, "iterations": 1}, "description": "扩张白色区域。"},
    "MorphOpen": {"label": "开运算", "category": "图像", "group": "形态学", "kind": "morph", "has_input": True, "has_output": True, "params": {"ksize": 3}, "description": "先腐蚀后膨胀，常用于去小噪点。"},
    "MorphClose": {"label": "闭运算", "category": "图像", "group": "形态学", "kind": "morph", "has_input": True, "has_output": True, "params": {"ksize": 3}, "description": "先膨胀后腐蚀，常用于补小孔。"},
    "MorphGradient": {"label": "形态学梯度", "category": "图像", "group": "形态学", "kind": "morph", "has_input": True, "has_output": True, "params": {"ksize": 3}, "description": "提取形态学边缘。"},
    "Resize": {"label": "缩放", "category": "图像", "group": "几何变换", "kind": "geo", "has_input": True, "has_output": True, "params": {"scale_percent": 50}, "description": "按百分比缩放图像。"},
    "Flip": {"label": "翻转", "category": "图像", "group": "几何变换", "kind": "geo", "has_input": True, "has_output": True, "params": {"flip_code": 1}, "description": "1水平，0垂直，-1双向。"},
    "Rotate90": {"label": "旋转90度", "category": "图像", "group": "几何变换", "kind": "geo", "has_input": True, "has_output": True, "params": {"direction": 0}, "description": "0顺时针，1逆时针，2旋转180。"},
    "FindContours": {"label": "轮廓查找", "category": "图像", "group": "测量分析", "kind": "measure", "has_input": True, "has_output": True, "params": {"threshold": 127, "min_area": 20}, "description": "二值化后查找轮廓并绘制包围框。"},
}

OPERATOR_CATALOG = {
    "图像": [
        {"group": "输入输出", "items": ["ReadImage", "Display"]},
        {"group": "颜色与增强", "items": ["Gray", "BGR2RGB", "Invert", "Normalize", "EqualizeHist", "CLAHE"]},
        {"group": "滤波降噪", "items": ["MeanBlur", "GaussianBlur", "MedianBlur", "BilateralFilter", "Sharpen"]},
        {"group": "阈值与边缘", "items": ["Threshold", "OtsuThreshold", "AdaptiveThreshold", "Canny", "Sobel", "Laplacian"]},
        {"group": "形态学", "items": ["Erode", "Dilate", "MorphOpen", "MorphClose", "MorphGradient"]},
        {"group": "几何变换", "items": ["Resize", "Flip", "Rotate90"]},
        {"group": "测量分析", "items": ["FindContours"]},
    ],
    "文本": [],
    "视频": [],
}


def img_to_data_url(img: np.ndarray) -> str:
    if img is None:
        return ""
    if img.dtype != np.uint8:
        img = np.clip(img, 0, 255).astype(np.uint8)
    ok, buffer = cv2.imencode(".png", img)
    if not ok:
        raise ValueError("图像编码失败")
    b64 = base64.b64encode(buffer).decode("utf-8")
    return f"data:image/png;base64,{b64}"


def topo_sort(nodes: List[Dict[str, Any]], edges: List[Dict[str, Any]]) -> List[str]:
    node_ids = [node["id"] for node in nodes]
    node_set = set(node_ids)
    indegree = {node_id: 0 for node_id in node_ids}
    graph = {node_id: [] for node_id in node_ids}

    for edge in edges:
        source = edge.get("source")
        target = edge.get("target")
        if source not in node_set or target not in node_set:
            raise ValueError("存在无效连线：source 或 target 节点不存在")
        graph[source].append(target)
        indegree[target] += 1

    queue = deque([node_id for node_id in node_ids if indegree[node_id] == 0])
    order: List[str] = []
    while queue:
        node_id = queue.popleft()
        order.append(node_id)
        for nxt in graph[node_id]:
            indegree[nxt] -= 1
            if indegree[nxt] == 0:
                queue.append(nxt)

    if len(order) != len(node_ids):
        raise ValueError("流程中存在环，请检查节点连线")
    return order


def run_workflow(workflow: Dict[str, Any]) -> Dict[str, Any]:
    nodes_list = workflow.get("nodes", [])
    edges = workflow.get("edges", [])
    nodes = {node["id"]: node for node in nodes_list}
    context = {"image_id": workflow.get("image_id")}

    if not nodes_list:
        raise ValueError("流程为空，请先添加节点")

    order = topo_sort(nodes_list, edges)
    outputs: Dict[str, Dict[str, Any]] = {}
    previews = []

    for node_id in order:
        node = nodes[node_id]
        op_type = node.get("type")
        params = node.get("params", {}) or {}
        meta = OPERATOR_META.get(op_type, {})

        if op_type not in OPERATORS:
            raise ValueError(f"未知算子或尚未实现：{op_type}")

        inputs: Dict[str, Any] = {}
        incoming_edges = [edge for edge in edges if edge.get("target") == node_id]
        for edge in incoming_edges:
            source_id = edge["source"]
            if source_id not in outputs:
                raise ValueError(f"节点 {node_id} 的上游 {source_id} 尚未执行")
            inputs[edge.get("targetHandle", "in")] = outputs[source_id][edge.get("sourceHandle", "out")]

        if meta.get("has_input", True) and "in" not in inputs:
            raise ValueError(f"节点 {node_id}（{op_type}）缺少输入连线")

        result = OPERATORS[op_type](inputs, params, context)
        outputs[node_id] = result

        out_img = result.get("out")
        previews.append({
            "node_id": node_id,
            "type": op_type,
            "label": meta.get("label", op_type),
            "image": img_to_data_url(out_img),
        })

    return {"success": True, "previews": previews, "order": order}


@app.get("/", response_class=HTMLResponse)
def index() -> str:
    return HTML_PAGE


@app.get("/api/operators")
def operators():
    return {"operators": OPERATOR_META, "catalog": OPERATOR_CATALOG}


@app.post("/api/upload")
async def upload_image(file: UploadFile = File(...)):
    suffix = Path(file.filename or "image.png").suffix.lower()
    if suffix not in [".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff", ".webp"]:
        suffix = ".png"

    image_id = f"{uuid.uuid4().hex}{suffix}"
    path = UPLOAD_DIR / image_id
    content = await file.read()
    path.write_bytes(content)
    IMAGE_STORE[image_id] = str(path)

    img = cv2.imread(str(path), cv2.IMREAD_COLOR)
    if img is None:
        path.unlink(missing_ok=True)
        IMAGE_STORE.pop(image_id, None)
        return JSONResponse(status_code=400, content={"success": False, "error": "上传文件不是有效图片"})

    return {"success": True, "image_id": image_id, "filename": file.filename, "preview": img_to_data_url(img)}


@app.post("/api/run")
async def api_run(workflow: Dict[str, Any]):
    try:
        return run_workflow(workflow)
    except Exception as exc:
        return JSONResponse(status_code=400, content={"success": False, "error": str(exc)})


HTML_PAGE = r'''
<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>工业视觉流程编排 MVP - ComfyUI风格 v6</title>
  <style>
    :root{
      --bg:#080a0d; --top:#111317; --panel:#17191e; --panel2:#1e2229; --panel3:#272c34;
      --line:#2d323b; --text:#e7ebf3; --muted:#8d96a8; --muted2:#bbc3d3;
      --blue:#55a7ff; --green:#22c55e; --orange:#f59e0b; --red:#ef4444; --purple:#8b5cf6;
      --shadow:0 18px 50px rgba(0,0,0,.48); --nodew:260px;
    }
    *{box-sizing:border-box} html,body{height:100%}
    body{margin:0;background:var(--bg);color:var(--text);overflow:hidden;font-family:Inter,Segoe UI,Arial,"Microsoft YaHei",sans-serif;font-size:13px}
    button,input{font-family:inherit} button{cursor:pointer}
    ::-webkit-scrollbar{width:10px;height:10px}::-webkit-scrollbar-track{background:#101318;border-radius:999px}::-webkit-scrollbar-thumb{background:#3b4350;border-radius:999px;border:2px solid #101318}::-webkit-scrollbar-thumb:hover{background:#586272}
    .app{height:100vh;display:grid;grid-template-rows:42px 1fr;background:#0b0d10}
    .topbar{height:42px;background:#111317;border-bottom:1px solid #272c34;display:flex;align-items:center;justify-content:space-between;z-index:20;box-shadow:0 1px 0 rgba(255,255,255,.035) inset}
    .tabs{height:100%;display:flex;align-items:center}.hamb{width:42px;display:grid;place-items:center;color:#98a2b3;font-size:20px}.tab{height:42px;min-width:188px;background:#15181d;border-left:1px solid #0b0c0f;border-right:1px solid #2a2f38;display:flex;align-items:center;padding:0 12px;font-weight:800}.tab .dot{width:7px;height:7px;border-radius:50%;background:#dbeafe;margin-left:9px}.plus{width:42px;height:42px;display:grid;place-items:center;color:#aab2c0;font-size:22px}
    .top-actions{display:flex;align-items:center;gap:8px;padding-right:10px}.pill{height:30px;border:1px solid #373e49;border-radius:8px;background:#20242b;color:#dbe2ee;display:flex;align-items:center;gap:7px;padding:0 11px;font-weight:800}.pill:hover{filter:brightness(1.12)}.pill.run{background:linear-gradient(180deg,#8d5cf8,#6927d7);border-color:#a78bfa;color:#fff}.pill.danger{background:#51242a;border-color:#79313b;color:#fecaca}.pill.green{background:#123d29;border-color:#276749;color:#bbf7d0}.counter{height:30px;border-radius:8px;background:#1d2128;border:1px solid #353b45;color:#d7deea;padding:0 12px;display:flex;align-items:center;font-weight:800}
    .main{height:calc(100vh - 42px);display:grid;grid-template-columns:54px 342px minmax(420px,1fr) 400px;min-width:0}.rail{background:#111317;border-right:1px solid #272c34;display:flex;flex-direction:column;align-items:center;padding-top:8px;gap:6px}.rail-item{width:42px;height:42px;border-radius:10px;display:grid;place-items:center;color:#8993a5;font-size:18px;position:relative}.rail-item:hover,.rail-item.active{background:#272c34;color:#fff}.rail-item span{position:absolute;bottom:3px;font-size:10px}.rail-spacer{flex:1}
    .side{background:#17191e;border-right:1px solid #303640;display:flex;flex-direction:column;min-width:0;overflow:hidden;min-height:0}.side-head{padding:14px 14px 8px;display:flex;align-items:center;justify-content:space-between}.side-title{font-size:16px;font-weight:900}.side-actions{display:flex;gap:6px}.sq{width:30px;height:30px;border:1px solid #3b424e;background:#252a32;color:#c4ccd9;border-radius:8px;display:grid;place-items:center}.category-tabs{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;padding:0 14px 10px}.category-tabs button{height:34px;border:1px solid #303640;background:#20242b;color:#9aa4b5;border-radius:9px;font-weight:900}.category-tabs button.active{color:#fff;background:#303641;border-color:#55606f;box-shadow:0 1px 0 rgba(255,255,255,.05) inset}.search-row{padding:0 14px 10px}.search{width:100%;height:35px;background:#242932;border:1px solid #333a45;color:#d9e0eb;border-radius:9px;padding:0 11px;outline:none}.search:focus{border-color:#5c8fc1}
    .upload-box{margin:0 14px 10px;padding:10px;border:1px dashed #454d59;border-radius:11px;background:#101318}.file-label,.btn{border:1px solid #3c4450;border-radius:9px;padding:8px 10px;background:#242a33;color:#eef2f8;cursor:pointer;display:inline-flex;align-items:center;gap:6px;font-weight:800;font-size:12px}.file-label:hover,.btn:hover{background:#303743}.btn.primary{background:#2563eb;border-color:#3b82f6}.btn.green{background:#166534;border-color:#22c55e}.btn.red{background:#7f1d1d;border-color:#ef4444}.btn.ghost{background:#1b1f26}.hint{color:#909bad;font-size:12px;line-height:1.55}.upload-preview{width:100%;border-radius:8px;margin-top:8px;border:1px solid #353c47;background:#050608;max-height:135px;object-fit:contain}input[type=file]{display:none}
    .op-scroll{overflow:auto;padding:0 10px 14px;flex:1;min-height:0;overscroll-behavior:contain}.op-scroll::before{content:"";display:block;height:1px}.op-group{margin:9px 4px;border:1px solid transparent}.group-title{height:28px;color:#aeb7c6;font-size:12px;font-weight:900;letter-spacing:.02em;display:flex;align-items:center;gap:7px;cursor:pointer;user-select:none}.group-title .chev{width:18px;height:18px;border-radius:6px;background:#242932;border:1px solid #343b46;display:grid;place-items:center;color:#cbd5e1}.op-group.closed .ops{display:none}.op-group.closed .chev{transform:rotate(-90deg)}.op{user-select:none;margin:7px 0;padding:9px 10px;border:1px solid #303743;border-radius:10px;background:#21262e;color:#dfe5ef;cursor:grab;display:grid;grid-template-columns:28px 1fr auto;align-items:center;gap:8px;box-shadow:0 1px 0 rgba(255,255,255,.04) inset}.op:hover{background:#2a303a;border-color:#4e5968}.op:active{cursor:grabbing}.op-icon{width:24px;height:24px;border-radius:7px;display:grid;place-items:center;color:#fff;font-size:13px}.op-name{font-weight:900}.op-desc{font-size:11px;color:#8f99aa;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.op-type{font-size:10px;color:#9aa4b5;background:#161a20;border:1px solid #323946;border-radius:999px;padding:2px 6px}.empty-cat{margin:14px;padding:20px;border:1px dashed #3f4652;border-radius:13px;background:#11141a;color:#9aa4b5;text-align:center}.empty-cat b{display:block;color:#e5e7eb;margin-bottom:6px}
    .canvas-wrap{position:relative;overflow:hidden;background:#0b0d10}.viewport{position:absolute;inset:0;overflow:hidden;background-color:#0d0f12;background-image:linear-gradient(rgba(255,255,255,.025) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.025) 1px,transparent 1px),linear-gradient(rgba(255,255,255,.035) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.035) 1px,transparent 1px);background-size:20px 20px,20px 20px,100px 100px,100px 100px}.viewport.panning{cursor:grabbing}.world{position:absolute;left:0;top:0;width:5200px;height:3300px;transform-origin:0 0}.edge-layer{position:absolute;left:0;top:0;width:5200px;height:3300px;pointer-events:auto;z-index:1}.node-layer{position:absolute;left:0;top:0;width:5200px;height:3300px;z-index:2;pointer-events:none}.canvas-toolbar{position:absolute;left:14px;top:10px;z-index:6;display:flex;gap:8px;align-items:center}.tool-pill{height:36px;border:1px solid #303744;border-radius:10px;background:rgba(31,35,42,.94);box-shadow:0 8px 28px rgba(0,0,0,.35);display:flex;align-items:center;gap:8px;padding:0 11px;color:#dfe6f2;font-weight:900}.tool-icon{width:26px;height:26px;border-radius:8px;background:#111419;border:1px solid #38404d;display:grid;place-items:center}.edge-visible{stroke:#6ab6ff;stroke-width:3;fill:none;opacity:.92;pointer-events:none}.edge-visible.selected{stroke:#fbbf24;stroke-width:5;filter:drop-shadow(0 0 5px rgba(251,191,36,.55))}.edge-hit{stroke:rgba(255,255,255,0);stroke-width:26;fill:none;cursor:pointer;pointer-events:stroke}.edge-hit:hover + .edge-visible{stroke:#93c5fd;stroke-width:4}.edge-temp{stroke:#93c5fd;stroke-width:3;fill:none;stroke-dasharray:8 6;opacity:.95;pointer-events:none}
    .toast{position:absolute;right:14px;top:58px;z-index:9;min-width:300px;max-width:470px;border:1px solid #5c252a;background:rgba(80,20,25,.9);color:#fecaca;border-radius:10px;padding:13px 14px;box-shadow:var(--shadow);display:none}.toast.ok{border-color:#276749;background:rgba(22,61,39,.9);color:#bbf7d0}.toast.show{display:block}.toast b{display:block;color:#fff;margin-bottom:4px}.bottom-controls{position:absolute;right:15px;bottom:14px;z-index:7;display:flex;gap:8px;align-items:flex-end}.zoom-box{height:38px;border:1px solid #363e49;border-radius:10px;background:#1b1f26;box-shadow:var(--shadow);display:flex;align-items:center;overflow:hidden}.zoom-box button{height:38px;width:36px;border:0;background:transparent;color:#d5dbe7;font-size:16px}.zoom-box button:hover{background:#2a303a}.zoom-label{height:38px;min-width:62px;display:grid;place-items:center;color:#d5dbe7;font-weight:900;border-left:1px solid #303743;border-right:1px solid #303743}.minimap{width:230px;height:154px;border:1px solid #4b5563;border-radius:7px;background:rgba(56,58,63,.9);box-shadow:var(--shadow);position:relative;overflow:hidden}.minimap-head{height:22px;border-bottom:1px solid #cbd5e1;background:#4b4d52;color:#dce2ee;font-size:12px;padding:3px 7px}.mini-node{position:absolute;background:#4387b7;border:1px solid rgba(255,255,255,.16);border-radius:2px}.mini-view{position:absolute;border:1px solid #e5e7eb;background:rgba(255,255,255,.05);pointer-events:none}
    .node{position:absolute;width:var(--nodew);min-height:126px;border-radius:11px;background:#2a2f38;border:1px solid #4b5563;box-shadow:0 10px 24px rgba(0,0,0,.38);cursor:move;overflow:visible;pointer-events:auto}.node:hover{filter:brightness(1.04)}.node.selected{outline:2px solid #fbbf24;box-shadow:0 0 0 4px rgba(251,191,36,.15),0 16px 32px rgba(0,0,0,.5)}.node.collapsed{min-height:34px}.node-head{height:34px;border-radius:10px 10px 0 0;border-bottom:1px solid rgba(255,255,255,.08);display:flex;align-items:center;justify-content:space-between;padding:0 8px;color:#f8fafc;font-weight:900;font-size:12px;background:#4b5563}.node.collapsed .node-head{border-radius:10px}.node-title{display:flex;align-items:center;gap:7px;min-width:0}.node-title span{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.fold-btn{width:22px;height:22px;border:0;border-radius:6px;background:rgba(0,0,0,.22);color:#eef2ff;display:grid;place-items:center;font-size:13px;padding:0}.fold-btn:hover{background:rgba(255,255,255,.14)}.node.collapsed .fold-btn{transform:rotate(-90deg)}.node-badge{font-size:10px;color:#fef3c7;background:rgba(0,0,0,.25);border:1px solid rgba(255,255,255,.1);border-radius:999px;padding:2px 6px}.node-body{padding:8px 9px 9px}.node.collapsed .node-body{display:none}.socket-row{height:23px;display:flex;align-items:center;justify-content:space-between;color:#aeb7c6;font-size:11px;position:relative}.node-field{background:#1e232b;border:1px solid #404854;border-radius:7px;color:#aeb7c7;min-height:48px;padding:7px;font-size:11px;margin-top:4px;line-height:1.35}.param-chip{display:inline-block;margin:3px 4px 0 0;padding:2px 6px;border-radius:999px;background:#151a20;border:1px solid #333b46;color:#cbd5e1;font-size:10px}.node-foot{margin-top:7px;padding-top:6px;border-top:1px dashed #4b5563;display:flex;justify-content:center;color:#c8cfda;font-size:10px}.port{position:absolute;width:11px;height:11px;border-radius:50%;border:2px solid #c8d2e0;background:#7dd3fc;top:45px;cursor:crosshair;z-index:5;box-shadow:0 0 0 2px rgba(0,0,0,.45)}.node.collapsed .port{top:12px}.port.in{left:-6px;background:#60a5fa}.port.out{right:-6px;background:#dbeafe}.port:hover{transform:scale(1.35);box-shadow:0 0 0 4px rgba(96,165,250,.22)}.node.io .node-head{background:linear-gradient(180deg,#755a2c,#4f3b1f)}.node.color .node-head{background:linear-gradient(180deg,#4a4c91,#333464)}.node.filter .node-head{background:linear-gradient(180deg,#326087,#25445e)}.node.segment .node-head{background:linear-gradient(180deg,#7d5031,#58371f)}.node.morph .node-head{background:linear-gradient(180deg,#306a55,#20483a)}.node.geo .node-head{background:linear-gradient(180deg,#6d477f,#4a3158)}.node.measure .node-head{background:linear-gradient(180deg,#7f3948,#572733)}
    .right{background:#15181d;border-left:1px solid #303640;display:flex;flex-direction:column;min-width:0;min-height:0;overflow:hidden}.right-section{padding:13px 14px;border-bottom:1px solid #2c323b;flex:0 0 auto;max-height:42%;overflow:auto;overscroll-behavior:contain}.right-title{font-size:15px;font-weight:900;margin-bottom:10px;display:flex;align-items:center;justify-content:space-between;gap:10px}.status{color:#9aa4b5;font-size:12px;line-height:1.45;word-break:break-all}.param-card{border:1px solid #333b46;background:#1d222a;border-radius:12px;padding:10px;margin-top:10px}.param-card h3{margin:0 0 8px;font-size:13px}.param-row{display:grid;grid-template-columns:110px 1fr;gap:8px;align-items:center;margin:7px 0}.param-row label{color:#aab4c5;font-weight:800;font-size:12px}.param-row input{height:30px;border-radius:7px;border:1px solid #3e4754;background:#11151b;color:#e5e7eb;padding:0 8px;outline:none}.param-row input:focus{border-color:#60a5fa}.preview-wrap{flex:1;min-height:0;display:flex;flex-direction:column;overflow:hidden;background:#15181d}.preview-wrap.collapsed{flex:0 0 46px}.preview-wrap.collapsed .preview-scroll{display:none}.preview-wrap.collapsed .preview-toggle .arrow{transform:rotate(-90deg)}.preview-title{height:46px;flex:0 0 46px;padding:0 14px;margin:0;border-bottom:1px solid #2c323b;background:#15181d}.preview-toggle{height:28px;border:1px solid #3b424e;background:#242a33;color:#dbe2ee;border-radius:8px;display:flex;align-items:center;gap:6px;padding:0 9px;font-weight:900;font-size:12px}.preview-toggle:hover{background:#303743}.preview-toggle .arrow{display:inline-block;transition:transform .16s ease}.preview-scroll{flex:1;min-height:0;overflow:auto;padding:14px;overscroll-behavior:contain}.empty-preview{height:160px;border:1px dashed #3f4652;border-radius:12px;display:grid;place-items:center;color:#8f99aa;background:#101318}.preview-card{border:1px solid #343c47;border-radius:12px;background:#1d222a;margin-bottom:12px;overflow:hidden}.preview-meta{min-height:38px;display:flex;align-items:center;justify-content:space-between;gap:8px;padding:8px 10px;border-bottom:1px solid #343c47;color:#dce3ee}.preview-meta b{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.tag{font-size:10px;color:#cbd5e1;background:#11151b;border:1px solid #374151;border-radius:999px;padding:3px 7px;flex:0 0 auto}.preview-card img{display:block;width:100%;max-height:280px;object-fit:contain;background:#060708}.row-actions{display:flex;flex-wrap:wrap;gap:8px;margin-top:10px}.kbd{font-size:11px;color:#cbd5e1;border:1px solid #374151;border-radius:5px;padding:1px 5px;background:#11151b}
  </style>
</head>
<body>
<div class="app">
  <div class="topbar">
    <div class="tabs"><div class="hamb">☰</div><div class="tab">Unsaved Vision Workflow <span class="dot"></span></div><div class="plus">＋</div></div>
    <div class="top-actions">
      <button class="pill green" onclick="saveWorkflowLocal()">💾 保存</button>
      <button class="pill" onclick="loadWorkflowLocal()">📂 加载</button>
      <button class="pill" onclick="downloadWorkflowJson()">⬇ 导出JSON</button>
      <label class="pill" for="workflowInput">⬆ 导入JSON</label><input id="workflowInput" type="file" accept=".json,application/json" />
      <button class="pill" onclick="createDemoWorkflow()">🧪 示例流程</button>
      <button class="pill run" onclick="runWorkflow()">▶ 运行</button>
      <button class="pill danger" onclick="clearWorkflow()">× 清空</button>
      <div class="counter"><span id="taskCount">0</span>&nbsp;个活动任务</div>
    </div>
  </div>

  <div class="main">
    <div class="rail">
      <div class="rail-item active">▣<span>节点</span></div><div class="rail-item">▧<span>资产</span></div><div class="rail-item">◇<span>模型</span></div><div class="rail-item">☷<span>模板</span></div><div class="rail-spacer"></div><div class="rail-item">?</div><div class="rail-item">⚙</div>
    </div>

    <aside class="side">
      <div class="side-head"><div class="side-title">节点库</div><div class="side-actions"><button class="sq" onclick="collapseAllNodes()" title="折叠画布所有节点">▸</button><button class="sq" onclick="expandAllNodes()" title="展开画布所有节点">▾</button></div></div>
      <div class="category-tabs"><button id="cat-图像" class="active" onclick="setCategory('图像')">图像</button><button id="cat-文本" onclick="setCategory('文本')">文本</button><button id="cat-视频" onclick="setCategory('视频')">视频</button></div>
      <div class="search-row"><input id="opSearch" class="search" placeholder="搜索 OpenCV 算子..." oninput="renderOperatorPanel()" /></div>
      <div class="upload-box">
        <label class="file-label" for="imageInput">📷 上传图片</label><input id="imageInput" type="file" accept="image/*" />
        <div id="imageInfo" class="hint" style="margin-top:8px">未上传图片。ReadImage 节点会读取当前上传图片。</div>
        <img id="uploadPreview" class="upload-preview" style="display:none" />
      </div>
      <div id="operatorPanel" class="op-scroll"></div>
    </aside>

    <section class="canvas-wrap">
      <div class="canvas-toolbar"><div class="tool-pill"><span class="tool-icon">⌘</span> 图形 / Workflow</div><div class="tool-pill"><span class="tool-icon">↕</span> 左侧分类：图像 / 文本 / 视频</div></div>
      <div id="viewport" class="viewport">
        <div id="world" class="world"><svg id="edgeLayer" class="edge-layer"></svg><div id="nodeLayer" class="node-layer"></div></div>
      </div>
      <div id="toast" class="toast"><b id="toastTitle">错误</b><div id="toastText"></div></div>
      <div class="bottom-controls"><div class="minimap"><div class="minimap-head">预览</div><div id="miniNodes"></div><div id="miniView" class="mini-view"></div></div><div class="zoom-box"><button onclick="setZoom(zoom/1.1)">−</button><div id="zoomLabel" class="zoom-label">82%</div><button onclick="setZoom(zoom*1.1)">＋</button><button title="重置视图" onclick="resetView()">⟳</button></div></div>
    </section>

    <aside class="right">
      <div class="right-section">
        <div class="right-title"><span>参数 / 状态</span><span class="kbd">点击节点编辑</span></div>
        <div id="status" class="status">就绪。拖拽左侧图像算子到画布，连接端口后运行。</div>
        <div id="paramPanel" class="param-card hint">请选择一个节点</div>
      </div>
      <div id="previewWrap" class="preview-wrap">
        <div class="right-title preview-title">
          <span>运行预览</span>
          <button id="previewToggle" class="preview-toggle" onclick="togglePreviewPanel()"><span class="arrow">▾</span><span id="previewToggleText">折叠</span></button>
        </div>
        <div id="previewScroll" class="preview-scroll"><div id="previewPanel"><div class="empty-preview">运行后显示每步处理结果</div></div></div>
      </div>
    </aside>
  </div>
</div>

<script>
let OPERATOR_META = {};
let OPERATOR_CATALOG = {};
let activeCategory = "图像";
let nodes = [];
let edges = [];
let nodeSeq = 1;
let selectedNodeId = null;
let selectedEdgeId = null;
let connectingSourceId = null;
let connectDrag = null;
let currentImageId = null;
let pan = { x: -260, y: -120 };
let zoom = 0.82;
const viewport = document.getElementById("viewport");
const world = document.getElementById("world");
const nodeLayer = document.getElementById("nodeLayer");
const edgeLayer = document.getElementById("edgeLayer");
const statusEl = document.getElementById("status");
const paramPanel = document.getElementById("paramPanel");
const previewPanel = document.getElementById("previewPanel");
const previewWrap = document.getElementById("previewWrap");
const previewToggleText = document.getElementById("previewToggleText");
let previewCollapsed = false;

const ICONS = { io:"⎋", color:"◐", filter:"≋", segment:"⌁", morph:"⬡", geo:"⟲", measure:"▤" };

async function initOperators(){
  const res = await fetch("/api/operators");
  const data = await res.json();
  OPERATOR_META = data.operators || {};
  OPERATOR_CATALOG = data.catalog || {};
  renderOperatorPanel();
  applyTransform();
  createDemoWorkflow();
}
function setCategory(cat){ activeCategory = cat; document.querySelectorAll('.category-tabs button').forEach(b=>b.classList.remove('active')); document.getElementById('cat-'+cat).classList.add('active'); renderOperatorPanel(); }
function renderOperatorPanel(){
  const panel = document.getElementById("operatorPanel"); panel.innerHTML = "";
  const q = document.getElementById("opSearch").value.trim().toLowerCase();
  const groups = OPERATOR_CATALOG[activeCategory] || [];
  if(activeCategory !== "图像"){
    const div = document.createElement("div"); div.className = "empty-cat";
    div.innerHTML = `<b>${activeCategory}节点暂未开放</b>当前 MVP 只启用可运行的 OpenCV 图像算子，避免出现不能执行的死节点。后续可以在这里接入 OCR、NLP、视频流、帧抽取等节点。`;
    panel.appendChild(div); return;
  }
  groups.forEach(g => {
    const matched = g.items.filter(type => {
      const m = OPERATOR_META[type] || {}; const hay = `${type} ${m.label||''} ${m.description||''} ${g.group}`.toLowerCase();
      return !q || hay.includes(q);
    });
    if(!matched.length) return;
    const group = document.createElement("div"); group.className = "op-group";
    const title = document.createElement("div"); title.className = "group-title"; title.innerHTML = `<span class="chev">▾</span>${g.group}<span style="color:#707b8d;font-weight:700">${matched.length}</span>`;
    title.onclick = () => group.classList.toggle("closed");
    const ops = document.createElement("div"); ops.className = "ops";
    matched.forEach(type => {
      const meta = OPERATOR_META[type];
      const op = document.createElement("div"); op.className = "op"; op.draggable = true; op.dataset.type = type;
      op.innerHTML = `<div class="op-icon" style="background:${kindColor(meta.kind)}">${ICONS[meta.kind]||'□'}</div><div><div class="op-name">${meta.label}</div><div class="op-desc">${meta.description || type}</div></div><div class="op-type">${type}</div>`;
      op.ondragstart = e => e.dataTransfer.setData("operator/type", type);
      op.ondblclick = () => addNode(type, 460 + nodes.length*24, 240 + nodes.length*18);
      ops.appendChild(op);
    });
    group.appendChild(title); group.appendChild(ops); panel.appendChild(group);
  });
}
function kindColor(kind){ return { io:'#7a5728', color:'#514fa0', filter:'#346691', segment:'#8a5631', morph:'#31705a', geo:'#774a8d', measure:'#8b3d4e' }[kind] || '#3f4753'; }
function defaultParams(type){ return JSON.parse(JSON.stringify((OPERATOR_META[type] && OPERATOR_META[type].params) || {})); }
function addNode(type, x, y){
  if(!OPERATOR_META[type]){ toast("不能添加节点", `${type} 尚未实现`, false); return; }
  const id = `n${nodeSeq++}`;
  nodes.push({ id, type, position:{x:Math.round(x), y:Math.round(y)}, params:defaultParams(type), collapsed:false });
  selectedNodeId = id; render(); setStatus(`已添加节点：${id} · ${OPERATOR_META[type].label}`);
}
function clampZoom(value){ return Math.min(2.6, Math.max(0.18, value)); }
function applyTransform(){
  world.style.transform = `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`;
  document.getElementById("zoomLabel").textContent = `${Math.round(zoom*100)}%`;
  const small = 20 * zoom, large = 100 * zoom;
  viewport.style.backgroundSize = `${small}px ${small}px, ${small}px ${small}px, ${large}px ${large}px, ${large}px ${large}px`;
  viewport.style.backgroundPosition = `${pan.x}px ${pan.y}px, ${pan.x}px ${pan.y}px, ${pan.x}px ${pan.y}px, ${pan.x}px ${pan.y}px`;
  updateMinimap();
}
function screenToWorld(clientX, clientY){
  const r = viewport.getBoundingClientRect();
  return { x:(clientX-r.left-pan.x)/zoom, y:(clientY-r.top-pan.y)/zoom, sx:clientX-r.left, sy:clientY-r.top };
}
function setZoom(value, center){
  const next = clampZoom(value);
  if(center){
    pan.x = center.sx - center.x * next;
    pan.y = center.sy - center.y * next;
  }
  zoom = next;
  applyTransform();
}
function zoomBy(delta, clientX, clientY){
  const center = screenToWorld(clientX, clientY);
  const factor = delta > 0 ? 1.1 : 1 / 1.1;
  setZoom(zoom * factor, center);
}
function isCanvasEmptyTarget(target){
  if(!target) return false;
  if(target.closest && target.closest('.node,.port,.canvas-toolbar,.bottom-controls,.toast,button,input,label,textarea,select')) return false;
  return target === viewport || target === world || target === nodeLayer || target === edgeLayer || target.tagName === 'svg' || target.tagName === 'path';
}
viewport.addEventListener("wheel", e => { e.preventDefault(); zoomBy(e.deltaY < 0 ? 1 : -1, e.clientX, e.clientY); }, {passive:false});
viewport.addEventListener("dragover", e => e.preventDefault());
viewport.addEventListener("drop", e => { e.preventDefault(); const type = e.dataTransfer.getData("operator/type"); if(!type) return; const p=screenToWorld(e.clientX,e.clientY); addNode(type,p.x,p.y); });
viewport.addEventListener("mousedown", e => {
  if(e.button !== 0 || !isCanvasEmptyTarget(e.target)) return;
  e.preventDefault();
  selectedNodeId = null; selectedEdgeId = null; renderParams(); renderEdges();
  const sx=e.clientX, sy=e.clientY, start={...pan}; viewport.classList.add("panning");
  function mv(ev){ pan.x=start.x+(ev.clientX-sx); pan.y=start.y+(ev.clientY-sy); applyTransform(); }
  function up(){ viewport.classList.remove("panning"); window.removeEventListener("mousemove",mv); window.removeEventListener("mouseup",up); }
  window.addEventListener("mousemove",mv); window.addEventListener("mouseup",up);
});
function render(){ renderNodes(); renderEdges(); renderParams(); updateMinimap(); }
function nodeHeight(n){ return n.collapsed ? 34 : 128; }
function renderNodes(){
  nodeLayer.innerHTML = "";
  nodes.forEach(n => {
    const meta = OPERATOR_META[n.type] || {label:n.type,kind:'unknown',params:{},has_input:true,has_output:true};
    const el = document.createElement("div"); el.className = `node ${meta.kind||''} ${selectedNodeId===n.id?'selected':''} ${n.collapsed?'collapsed':''}`;
    el.dataset.id = n.id;
    el.style.left = `${n.position.x}px`; el.style.top = `${n.position.y}px`; el.style.minHeight = `${nodeHeight(n)}px`;
    const chips = Object.entries(n.params||{}).map(([k,v]) => `<span class="param-chip">${k}=${v}</span>`).join("") || '<span class="hint">无参数</span>';
    el.innerHTML = `
      <div class="node-head">
        <div class="node-title"><button class="fold-btn" title="折叠/展开">▾</button><span>${meta.label}</span></div><div class="node-badge">${n.id}</div>
      </div>
      ${meta.has_input ? '<div class="port in" title="输入 in"></div>' : ''}
      ${meta.has_output ? '<div class="port out" title="输出 out"></div>' : ''}
      <div class="node-body">
        <div class="socket-row"><span>${meta.has_input?'● image_in':'无输入'}</span><span>${meta.has_output?'image_out ●':'无输出'}</span></div>
        <div class="node-field"><b>${n.type}</b><br>${meta.description || ''}<br><div style="margin-top:5px">${chips}</div></div>
        <div class="node-foot">点击标题左侧箭头可折叠节点</div>
      </div>`;
    el.querySelector('.node-head').addEventListener('mousedown', e => startDragNode(e,n.id));
    el.querySelector('.fold-btn').onclick = e => { e.stopPropagation(); n.collapsed = !n.collapsed; render(); };
    el.ondblclick = e => { e.stopPropagation(); n.collapsed = !n.collapsed; render(); };
    el.addEventListener('mousedown', () => { selectedNodeId=n.id; selectedEdgeId=null; renderParams(); renderEdges(); document.querySelectorAll('.node').forEach(x=>x.classList.remove('selected')); el.classList.add('selected'); });
    const out = el.querySelector('.port.out'); if(out){ out.onclick = e => { e.stopPropagation(); startConnect(n.id); }; out.addEventListener('mousedown', e => startConnectDrag(e,n.id)); }
    const inn = el.querySelector('.port.in'); if(inn){ inn.onclick = e => { e.stopPropagation(); if(connectingSourceId) finishConnect(n.id); else selectIncomingEdge(n.id); }; inn.addEventListener('mousedown', e => { if(connectingSourceId){ e.stopPropagation(); finishConnect(n.id); } }); }
    nodeLayer.appendChild(el);
  });
}
function startConnect(id){
  const sourceMeta = OPERATOR_META[nodes.find(n=>n.id===id)?.type] || {};
  if(!sourceMeta.has_output){ toast("连线失败", "源节点没有输出端口"); return; }
  connectingSourceId = id; selectedEdgeId = null; renderEdges(); setStatus(`请选择目标节点输入端口：${id}.out → ?，也可以拖动到目标输入端口`);
}
function startConnectDrag(e,id){
  if(e.button !== 0) return;
  e.stopPropagation(); e.preventDefault(); startConnect(id);
  connectDrag = { source:id };
  drawTempEdge(e.clientX,e.clientY);
  function mv(ev){ drawTempEdge(ev.clientX,ev.clientY); }
  function up(ev){
    window.removeEventListener('mousemove',mv); window.removeEventListener('mouseup',up);
    clearTempEdge();
    const target = document.elementFromPoint(ev.clientX, ev.clientY);
    const port = target && target.closest ? target.closest('.port.in') : null;
    const nodeEl = port && port.closest ? port.closest('.node') : null;
    const targetId = nodeEl ? nodeEl.dataset.id : null;
    if(targetId) finishConnect(targetId);
    else setStatus(`已选择源端口：${id}.out，请点击目标节点的输入端口完成连线`);
    connectDrag = null;
  }
  window.addEventListener('mousemove',mv);
  window.addEventListener('mouseup',up);
}
function finishConnect(targetId){
  if(!connectingSourceId || connectingSourceId === targetId) return;
  const sourceMeta = OPERATOR_META[nodes.find(n=>n.id===connectingSourceId)?.type] || {};
  const targetMeta = OPERATOR_META[nodes.find(n=>n.id===targetId)?.type] || {};
  if(!sourceMeta.has_output){ toast("连线失败", "源节点没有输出端口"); connectingSourceId=null; return; }
  if(!targetMeta.has_input){ toast("连线失败", "目标节点没有输入端口"); connectingSourceId=null; return; }
  edges = edges.filter(e => !(e.target === targetId && e.targetHandle === 'in'));
  const edgeId = `e${Date.now()}`;
  edges.push({ id:edgeId, source:connectingSourceId, sourceHandle:"out", target:targetId, targetHandle:"in" });
  const msg = `${connectingSourceId} → ${targetId}`; connectingSourceId = null; selectedEdgeId=edgeId; selectedNodeId=null; render(); setStatus(`已创建连线：${msg}`); toast("已创建连线", msg, true);
}
function startDragNode(e,nodeId){
  if(e.target.classList.contains('fold-btn')) return;
  e.stopPropagation(); selectedNodeId=nodeId; selectedEdgeId=null; const n=nodes.find(x=>x.id===nodeId); const sx=e.clientX, sy=e.clientY, start={...n.position};
  function mv(ev){ n.position.x=Math.round(start.x+(ev.clientX-sx)/zoom); n.position.y=Math.round(start.y+(ev.clientY-sy)/zoom); renderNodes(); renderEdges(); updateMinimap(); }
  function up(){ window.removeEventListener('mousemove',mv); window.removeEventListener('mouseup',up); renderParams(); }
  window.addEventListener('mousemove',mv); window.addEventListener('mouseup',up);
}
function getPortPoint(n,kind){ const y = n.position.y + (n.collapsed ? 17 : 50); return { x:n.position.x + (kind==='out'?260:0), y }; }
function makeEdgePath(p1,p2){ const c1=p1.x+95, c2=p2.x-95; return `M ${p1.x} ${p1.y} C ${c1} ${p1.y}, ${c2} ${p2.y}, ${p2.x} ${p2.y}`; }
function drawTempEdge(clientX,clientY){
  clearTempEdge();
  const s=nodes.find(n=>n.id===connectingSourceId); if(!s) return;
  const p1=getPortPoint(s,'out'), p2=screenToWorld(clientX,clientY);
  const path=document.createElementNS('http://www.w3.org/2000/svg','path');
  path.id='tempEdge'; path.setAttribute('class','edge-temp'); path.setAttribute('d', makeEdgePath(p1,p2)); edgeLayer.appendChild(path);
}
function clearTempEdge(){ const t=document.getElementById('tempEdge'); if(t) t.remove(); }
function renderEdges(){
  edgeLayer.innerHTML = "";
  edges.forEach(edge => {
    const s=nodes.find(n=>n.id===edge.source), t=nodes.find(n=>n.id===edge.target); if(!s||!t) return;
    const p1=getPortPoint(s,'out'), p2=getPortPoint(t,'in'); const d=makeEdgePath(p1,p2);
    const hit=document.createElementNS('http://www.w3.org/2000/svg','path'); hit.setAttribute('d',d); hit.setAttribute('class','edge-hit'); hit.dataset.id=edge.id;
    hit.addEventListener('mousedown', ev => { ev.stopPropagation(); });
    hit.addEventListener('click', ev => { ev.stopPropagation(); selectEdge(edge.id); });
    hit.addEventListener('dblclick', ev => { ev.stopPropagation(); deleteEdge(edge.id); });
    hit.addEventListener('contextmenu', ev => { ev.preventDefault(); ev.stopPropagation(); deleteEdge(edge.id); });
    const path=document.createElementNS('http://www.w3.org/2000/svg','path'); path.setAttribute('d',d); path.setAttribute('class',`edge-visible ${selectedEdgeId===edge.id?'selected':''}`);
    edgeLayer.appendChild(hit); edgeLayer.appendChild(path);
  });
}
function selectIncomingEdge(targetId){ const edge=edges.find(e=>e.target===targetId && e.targetHandle==='in'); if(edge) selectEdge(edge.id); }
function selectEdge(edgeId){ selectedEdgeId=edgeId; selectedNodeId=null; connectingSourceId=null; document.querySelectorAll('.node').forEach(x=>x.classList.remove('selected')); renderEdges(); renderParams(); const e=edges.find(x=>x.id===edgeId); if(e) setStatus(`已选择连线：${e.source} → ${e.target}，按 Delete/Backspace 删除，或双击/右键连线删除`); }
function deleteEdge(edgeId){ const e=edges.find(x=>x.id===edgeId); if(!e) return; edges=edges.filter(x=>x.id!==edgeId); if(selectedEdgeId===edgeId) selectedEdgeId=null; render(); toast('已删除连线',`${e.source} → ${e.target}`,true); setStatus(`已删除连线：${e.source} → ${e.target}`); }
function deleteSelectedEdge(){ if(selectedEdgeId) deleteEdge(selectedEdgeId); }
function renderParams(){
  if(selectedEdgeId && !selectedNodeId){
    const edge=edges.find(x=>x.id===selectedEdgeId);
    if(edge){
      paramPanel.className='param-card';
      paramPanel.innerHTML=`<h3>连线 · ${edge.source} → ${edge.target}</h3><div class="hint" style="margin-bottom:8px">sourceHandle：${edge.sourceHandle || 'out'}<br>targetHandle：${edge.targetHandle || 'in'}<br>双击或右键连线也可以删除。</div><div class="row-actions"><button class="btn red" onclick="deleteSelectedEdge()">删除连线</button></div>`;
      return;
    }
  }
  const n=nodes.find(x=>x.id===selectedNodeId); if(!n){ paramPanel.className='param-card hint'; paramPanel.innerHTML='请选择一个节点或连线'; return; }
  const meta=OPERATOR_META[n.type] || {label:n.type,params:{}}; paramPanel.className='param-card'; paramPanel.innerHTML=`<h3>${n.id} · ${meta.label}</h3><div class="hint" style="margin-bottom:8px">类型：${n.type}<br>${meta.description||''}</div>`;
  const keys=Object.keys(meta.params||{});
  if(!keys.length){ const d=document.createElement('div'); d.className='hint'; d.textContent = n.type==='ReadImage' ? '读取当前上传图片，无需手动设置参数。' : '该节点暂无可编辑参数。'; paramPanel.appendChild(d); }
  keys.forEach(key=>{ const row=document.createElement('div'); row.className='param-row'; const label=document.createElement('label'); label.textContent=key; const input=document.createElement('input'); input.value=n.params[key] ?? meta.params[key]; input.onchange=()=>{ const v=input.value; n.params[key] = isNaN(Number(v)) ? v : Number(v); setStatus(`已更新参数：${n.id}.${key} = ${n.params[key]}`); renderNodes(); }; row.appendChild(label); row.appendChild(input); paramPanel.appendChild(row); });
  const actions=document.createElement('div'); actions.className='row-actions';
  actions.innerHTML = `<button class="btn ghost" onclick="toggleSelectedCollapse()">${n.collapsed?'展开节点':'折叠节点'}</button><button class="btn ghost" onclick="duplicateNode('${n.id}')">复制节点</button><button class="btn red" onclick="deleteSelectedNode()">删除节点</button>`;
  paramPanel.appendChild(actions);
}
function toggleSelectedCollapse(){ const n=nodes.find(x=>x.id===selectedNodeId); if(!n) return; n.collapsed=!n.collapsed; render(); }
function collapseAllNodes(){ nodes.forEach(n=>n.collapsed=true); render(); setStatus('已折叠所有画布节点'); }
function expandAllNodes(){ nodes.forEach(n=>n.collapsed=false); render(); setStatus('已展开所有画布节点'); }
function duplicateNode(id){ const n=nodes.find(x=>x.id===id); if(!n) return; const id2=`n${nodeSeq++}`; nodes.push({id:id2,type:n.type,position:{x:n.position.x+36,y:n.position.y+36},params:JSON.parse(JSON.stringify(n.params||{})),collapsed:n.collapsed}); selectedNodeId=id2; render(); }
function deleteSelectedNode(){ if(!selectedNodeId) return; const id=selectedNodeId; nodes=nodes.filter(n=>n.id!==id); edges=edges.filter(e=>e.source!==id&&e.target!==id); selectedNodeId=null; selectedEdgeId=null; render(); toast('已删除节点',id,true); }
async function uploadImage(file){ const fd=new FormData(); fd.append('file',file); const res=await fetch('/api/upload',{method:'POST',body:fd}); const data=await res.json(); if(!data.success) throw new Error(data.error||'上传失败'); currentImageId=data.image_id; document.getElementById('imageInfo').textContent=`已上传：${data.filename}\nimage_id=${data.image_id}`; const img=document.getElementById('uploadPreview'); img.src=data.preview; img.style.display='block'; toast('图片上传成功',data.filename,true); setStatus('图片上传成功'); }
document.getElementById('imageInput').addEventListener('change',async e=>{ const f=e.target.files[0]; if(!f) return; try{await uploadImage(f)}catch(err){toast('上传失败',err.message);setStatus('上传失败：'+err.message)} });
document.getElementById('workflowInput').addEventListener('change',async e=>{ const f=e.target.files[0]; if(!f) return; try{applyWorkflow(JSON.parse(await f.text()));toast('JSON流程已导入',f.name,true)}catch(err){toast('导入失败',err.message)} });
function buildWorkflow(){ return { version:'1.1', image_id:currentImageId, nodes:nodes.map(n=>{ const params={...(n.params||{})}; if(n.type==='ReadImage' && currentImageId) params.image_id=currentImageId; return { id:n.id,type:n.type,position:n.position,params,collapsed:!!n.collapsed }; }), edges }; }
async function runWorkflow(){
  const wf=buildWorkflow();
  setStatus('运行中...');
  document.getElementById('taskCount').textContent='1';
  if(previewCollapsed) togglePreviewPanel(false);
  previewPanel.innerHTML='<div class="empty-preview">正在运行 OpenCV 流程...</div>';
  try{
    const res=await fetch('/api/run',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(wf)});
    const data=await res.json();
    if(!data.success) throw new Error(data.error||'运行失败');
    renderPreviews(data.previews || []);
    setStatus(`运行成功。执行顺序：${(data.order||[]).join(' → ')}`);
    toast('运行成功',`已生成 ${(data.previews||[]).length} 个预览`,true);
  }catch(err){
    const msg = err && err.message ? err.message : String(err);
    setStatus('运行失败：'+msg);
    previewPanel.innerHTML=`<div class="empty-preview">运行失败：${escapeHtml(msg)}</div>`;
    toast('运行失败',msg);
  } finally{
    document.getElementById('taskCount').textContent='0';
  }
}
function togglePreviewPanel(force){ previewCollapsed = (typeof force === 'boolean') ? force : !previewCollapsed; previewWrap.classList.toggle('collapsed', previewCollapsed); previewToggleText.textContent = previewCollapsed ? '展开' : '折叠'; }
function renderPreviews(previews){ previewPanel.innerHTML=''; if(!previews.length){ previewPanel.innerHTML='<div class="empty-preview">没有生成预览结果</div>'; return; } previews.forEach((item,idx)=>{ const div=document.createElement('div'); div.className='preview-card'; const title = `${idx+1}. ${item.node_id} · ${item.label}`; div.innerHTML=`<div class="preview-meta"><b title="${escapeHtml(title)}">${escapeHtml(title)}</b><span class="tag">${escapeHtml(item.type || '')}</span></div><img src="${item.image || ''}" />`; previewPanel.appendChild(div); }); }
function escapeHtml(value){ return String(value).replace(/[&<>"']/g, s => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[s])); }
function saveWorkflowLocal(){ localStorage.setItem('vision_python_mvp_workflow_v2', JSON.stringify(buildWorkflow(),null,2)); toast('流程已保存','保存到浏览器 localStorage',true); setStatus('流程已保存到浏览器 localStorage'); }
function loadWorkflowLocal(){ const raw=localStorage.getItem('vision_python_mvp_workflow_v2'); if(!raw){toast('加载失败','没有找到本地保存的流程');return;} applyWorkflow(JSON.parse(raw)); toast('流程已加载','来自浏览器 localStorage',true); }
function downloadWorkflowJson(){ const blob=new Blob([JSON.stringify(buildWorkflow(),null,2)],{type:'application/json'}); const url=URL.createObjectURL(blob); const a=document.createElement('a'); a.href=url; a.download='vision_workflow.json'; a.click(); URL.revokeObjectURL(url); }
function resetView(){ pan={x:-260,y:-120}; zoom=.82; applyTransform(); setStatus('已重置画布视图'); }
function applyWorkflow(wf){ nodes=(wf.nodes||[]).filter(n=>OPERATOR_META[n.type]).map(n=>({id:n.id,type:n.type,position:n.position||{x:100,y:100},params:n.params||defaultParams(n.type),collapsed:!!n.collapsed})); edges=(wf.edges||[]).filter(e=>nodes.some(n=>n.id===e.source)&&nodes.some(n=>n.id===e.target)); currentImageId=wf.image_id||currentImageId; const maxSeq=nodes.reduce((m,n)=>Math.max(m,Number(String(n.id).replace('n',''))||0),0); nodeSeq=maxSeq+1; selectedNodeId=null; selectedEdgeId=null; render(); }
function createDemoWorkflow(){ nodes=[{id:'n1',type:'ReadImage',position:{x:420,y:230},params:{},collapsed:false},{id:'n2',type:'Gray',position:{x:735,y:230},params:{},collapsed:false},{id:'n3',type:'GaussianBlur',position:{x:1050,y:230},params:{ksize:5,sigma:0},collapsed:false},{id:'n4',type:'Canny',position:{x:1365,y:230},params:{threshold1:50,threshold2:150},collapsed:false},{id:'n5',type:'Display',position:{x:1680,y:230},params:{},collapsed:false}]; edges=[{id:'e1',source:'n1',sourceHandle:'out',target:'n2',targetHandle:'in'},{id:'e2',source:'n2',sourceHandle:'out',target:'n3',targetHandle:'in'},{id:'e3',source:'n3',sourceHandle:'out',target:'n4',targetHandle:'in'},{id:'e4',source:'n4',sourceHandle:'out',target:'n5',targetHandle:'in'}]; nodeSeq=6; selectedNodeId=null; selectedEdgeId=null; pan={x:-260,y:-120}; zoom=.82; applyTransform(); render(); setStatus('已生成示例流程：ReadImage → Gray → GaussianBlur → Canny → Display'); toast('示例流程已生成','上传图片后点击运行',true); }
function clearWorkflow(){ nodes=[]; edges=[]; selectedNodeId=null; selectedEdgeId=null; previewPanel.innerHTML='<div class="empty-preview">运行后显示每步处理结果</div>'; render(); setStatus('流程已清空'); }
function toast(title,text,ok){ const el=document.getElementById('toast'); document.getElementById('toastTitle').textContent=title; document.getElementById('toastText').textContent=text||''; el.className='toast show'+(ok?' ok':''); clearTimeout(window.__toastTimer); window.__toastTimer=setTimeout(()=>el.className='toast',3200); }
function setStatus(t){ statusEl.textContent=t; }
function updateMinimap(){ const mini=document.getElementById('miniNodes'); mini.innerHTML=''; const scale=.045; nodes.forEach(n=>{ const d=document.createElement('div'); d.className='mini-node'; d.style.left=(n.position.x*scale+14)+'px'; d.style.top=(n.position.y*scale+22)+'px'; d.style.width=(260*scale)+'px'; d.style.height=(nodeHeight(n)*scale)+'px'; mini.appendChild(d); }); const rect=viewport.getBoundingClientRect(); const view=document.getElementById('miniView'); view.style.left=((0-pan.x)/zoom*scale+14)+'px'; view.style.top=((0-pan.y)/zoom*scale+22)+'px'; view.style.width=(rect.width/zoom*scale)+'px'; view.style.height=(rect.height/zoom*scale)+'px'; }
document.addEventListener('keydown', e => { if((e.key==='Delete' || e.key==='Backspace') && selectedEdgeId){ e.preventDefault(); deleteSelectedEdge(); } if(e.key==='Escape'){ connectingSourceId=null; clearTempEdge(); setStatus('已取消连线'); } });
window.addEventListener('resize', updateMinimap);
initOperators();
</script>
</body>
</html>
'''

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app:app", host="127.0.0.1", port=8000, reload=True)
