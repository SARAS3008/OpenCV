# YOLO 示例工作流

## 1. 单图示例：yolo_single_image_workflow.json

流程结构：

```text
读取图像(ReadImage) -> YOLO推理(YoloInfer) -> 结果显示(Display)
                         └─ count -> 比较(LogicCompare)：判断检测数量是否 > 0
```

导入后需要修改：

- `ReadImage.image_path`：改成后端服务器可访问的图片路径。
- `YoloInfer.model_path`：在节点参数里点击“选择”上传模型，或填写服务器上的模型路径。
- `YoloInfer.task`：默认 `auto`，也可以改成 `detect`、`segment`、`classify`、`pose`、`obb`。

运行后主要查看：

- `YOLO推理.out`：标注图；
- `YOLO推理.count`：结果数量；
- `YOLO推理.top_class` / `top_confidence`：最高类别和置信度；
- `YOLO推理.detections`：结构化结果列表；
- `比较` 节点：判断是否检出目标。

## 2. 批量示例：yolo_batch_workflow.json

流程结构：

```text
批量读取图片(BatchReadImages) -> YOLO推理(YoloInfer) -> 保存批量结果(SaveBatchResults)
```

导入后需要修改：

- `BatchReadImages.folder_path`：改成待检测图片文件夹。
- `YoloInfer.model_path`：上传或填写 YOLO 模型路径。
- `SaveBatchResults.output_dir`：改成输出目录。

运行后会保存标注图，并生成 `yolo_results.csv`，其中包含 `data.yolo` 展平后的检测摘要。
