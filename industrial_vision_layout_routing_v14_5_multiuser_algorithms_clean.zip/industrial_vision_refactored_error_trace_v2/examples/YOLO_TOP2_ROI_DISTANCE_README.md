# YOLO Top2 ROI 边缘距离示例

示例文件：`examples/yolo_top2_roi_edge_distance_workflow.json`

节点链路：

```text
读取图像 → YOLO推理 → YOLO目标筛选 → ROI边缘距离 → 结果显示
    └───────────────────────────────→ ROI边缘距离.image
```

默认配置：

- 模型：`yolov8n.pt`
- 任务：`detect`
- 置信度阈值：`0.35`
- 筛选数量：`2`
- 筛选排序：`CONFIDENCE_DESC`，即取置信度最高的两个目标
- 若要严格按“目标/类别 ID 最高”筛选，把 `YOLO目标筛选.sort_by` 改成 `CLASS_ID_DESC`
- ROI 边缘检测：Canny，低阈值 `50`，高阈值 `150`
- 输出距离：`ROI边缘距离.distance`，单位为像素

测试图像：`examples/images/bus.jpg`。这张图包含公交车和行人，适合快速验证 COCO 预训练检测模型。

模型获取方式：

1. 保持 `model_path = yolov8n.pt`，首次运行时 Ultralytics 会自动下载预训练模型。
2. 或执行：

```bash
python scripts/download_yolov8n.py
```

然后把 `YOLO推理.model_path` 改成：

```text
models/uploads/yolov8n.pt
```


## 按类别 index 过滤后再测量

新增示例文件：`examples/yolo_class_indices_top2_roi_distance_workflow.json`。

该示例在 `YOLO推理` 节点中设置：

```text
class_indices = 0,1,8
```

运行后，`YoloInfer.detections` 只包含类别 index 为 `0`、`1`、`8` 的检测结果，后续 `YOLO目标筛选`、`ROI边缘距离` 节点会直接基于过滤后的目标继续处理。

如果要改成其他类别，只需要修改 `YOLO推理 → 类别Index过滤` 参数，例如：

```text
2,3,5
```
