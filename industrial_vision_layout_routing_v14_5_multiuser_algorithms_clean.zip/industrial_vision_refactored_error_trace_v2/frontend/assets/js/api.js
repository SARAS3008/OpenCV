/**
 * 前后端通信层。
 * 页面组件只调用 VisionApi，不直接关心 fetch、HTTP 状态码和错误格式。
 */
(() => {
  const API_BASE = "/api";
  const AUTH_TOKEN_KEY = "vision_auth_token_v1";
  const ACTIVE_WORKSPACE_KEY = "vision_active_workspace_v1";

  function getAuthToken(){
    try{ return window.localStorage.getItem(AUTH_TOKEN_KEY) || ""; }catch(_error){ return ""; }
  }
  function setAuthToken(token){
    try{ token ? window.localStorage.setItem(AUTH_TOKEN_KEY, token) : window.localStorage.removeItem(AUTH_TOKEN_KEY); }catch(_error){}
  }
  function getActiveWorkspaceId(){
    try{ return window.localStorage.getItem(ACTIVE_WORKSPACE_KEY) || ""; }catch(_error){ return ""; }
  }
  function setActiveWorkspaceId(workspaceId){
    try{ workspaceId ? window.localStorage.setItem(ACTIVE_WORKSPACE_KEY, workspaceId) : window.localStorage.removeItem(ACTIVE_WORKSPACE_KEY); }catch(_error){}
  }

  function withAuthHeaders(options = {}){
    const merged = { ...options };
    const headers = new Headers(options.headers || {});
    const token = getAuthToken();
    const workspaceId = getActiveWorkspaceId();
    if(token) headers.set("Authorization", `Bearer ${token}`);
    if(workspaceId) headers.set("X-Workspace-Id", workspaceId);
    merged.headers = headers;
    return merged;
  }

  async function request(path, options = {}) {
    const response = await fetch(`${API_BASE}${path}`, withAuthHeaders(options));
    let data;
    try {
      data = await response.json();
    } catch (_error) {
      throw new Error(`服务返回了无法解析的响应（HTTP ${response.status}）`);
    }

    if (!response.ok || data.success === false) {
      const error = new Error(data.error || data.detail || `请求失败（HTTP ${response.status}）`);
      error.payload = data;
      error.httpStatus = response.status;
      throw error;
    }
    return data;
  }


  async function register(payload) {
    const data = await request("/auth/register", { method:"POST", headers:{ "Content-Type":"application/json" }, body:JSON.stringify(payload) });
    if(data.token) setAuthToken(data.token);
    if(data.user?.default_workspace_id) setActiveWorkspaceId(data.user.default_workspace_id);
    return data;
  }

  async function login(payload) {
    const data = await request("/auth/login", { method:"POST", headers:{ "Content-Type":"application/json" }, body:JSON.stringify(payload) });
    if(data.token) setAuthToken(data.token);
    if(data.user?.default_workspace_id) setActiveWorkspaceId(data.user.default_workspace_id);
    return data;
  }

  async function logout() {
    try{ await request("/auth/logout", { method:"POST" }); } finally { setAuthToken(""); }
    return { success:true };
  }

  async function getSession() {
    return request("/auth/session");
  }

  async function getMe() {
    return request("/users/me");
  }

  async function listWorkspaces() {
    return request("/workspaces");
  }

  async function createWorkspace(payload) {
    return request("/workspaces", { method:"POST", headers:{ "Content-Type":"application/json" }, body:JSON.stringify(payload || {}) });
  }

  async function addWorkspaceMember(workspaceId, payload) {
    return request(`/workspaces/${encodeURIComponent(workspaceId)}/members`, { method:"POST", headers:{ "Content-Type":"application/json" }, body:JSON.stringify(payload || {}) });
  }

  async function heartbeat(workspaceId) {
    return request("/presence/heartbeat", { method:"POST", headers:{ "Content-Type":"application/json" }, body:JSON.stringify({ workspace_id: workspaceId || getActiveWorkspaceId() }) });
  }

  async function listPresence(workspaceId) {
    return request(`/workspaces/${encodeURIComponent(workspaceId || getActiveWorkspaceId())}/presence`);
  }

  async function listProjectVersions(projectId) {
    return request(`/projects/${encodeURIComponent(projectId)}/versions`);
  }

  async function diffProject(projectId, fromVersion, toVersion) {
    const params = new URLSearchParams();
    if (fromVersion) params.set("from_version", fromVersion);
    if (toVersion) params.set("to_version", toVersion);
    const query = params.toString();
    return request(`/projects/${encodeURIComponent(projectId)}/diff${query ? `?${query}` : ""}`);
  }

  async function rollbackProject(projectId, versionId) {
    return request(`/projects/${encodeURIComponent(projectId)}/rollback/${encodeURIComponent(versionId)}`, { method:"POST" });
  }

  async function releaseProjectVersion(projectId, versionId) {
    return request(`/projects/${encodeURIComponent(projectId)}/release/${encodeURIComponent(versionId)}`, { method:"POST" });
  }

  async function listDatasets() {
    return request("/datasets");
  }

  async function createDataset(payload) {
    return request("/datasets", { method:"POST", headers:{ "Content-Type":"application/json" }, body:JSON.stringify(payload) });
  }

  async function runRegression(payload) {
    return request("/regression-tests/run", { method:"POST", headers:{ "Content-Type":"application/json" }, body:JSON.stringify(payload) });
  }

  async function submitWorkflowJob(payload) {
    return request("/jobs/run", { method:"POST", headers:{ "Content-Type":"application/json" }, body:JSON.stringify(payload) });
  }

  async function listRuns() {
    return request("/runs");
  }

  async function listJobs() {
    return request("/jobs");
  }

  async function getJob(jobId) {
    return request(`/jobs/${encodeURIComponent(jobId)}`);
  }

  async function listModelAssets() {
    return request("/models/assets");
  }

  async function updateModelMetadata(modelId, metadata) {
    return request(`/models/${encodeURIComponent(modelId)}`, { method:"PATCH", headers:{ "Content-Type":"application/json" }, body:JSON.stringify(metadata) });
  }
  async function validatePythonSnippet(code) {
    return request("/python-snippet/validate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ code: code || "" }),
    });
  }


  async function getOperators() {
    return request("/operators");
  }

  async function executeWorkflow(workflow) {
    return request("/run", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(workflow),
    });
  }


  async function listProjects() {
    return request("/projects");
  }

  async function getProject(projectId) {
    return request(`/projects/${encodeURIComponent(projectId)}`);
  }

  async function saveProject(project) {
    return request("/projects", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(project),
    });
  }

  async function deleteProject(projectId) {
    return request(`/projects/${encodeURIComponent(projectId)}`, { method: "DELETE" });
  }

  async function listModels() {
    return request("/models");
  }

  async function clearModelCache() {
    return request("/models/cache/clear", { method: "POST" });
  }

  async function uploadModel(file) {
    const form = new FormData();
    form.append("file", file);
    return request("/upload-model", {
      method: "POST",
      body: form,
    });
  }

  async function exportScript(workflow) {
    const response = await fetch(`${API_BASE}/export-script`, withAuthHeaders({
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(workflow),
    }));

    if (!response.ok) {
      let message = `导出失败（HTTP ${response.status}）`;
      try {
        const data = await response.json();
        message = data.error || data.detail || message;
      } catch (_error) {
        // 保留默认错误信息。
      }
      throw new Error(message);
    }

    const disposition = response.headers.get("Content-Disposition") || "";
    const match = disposition.match(/filename="?([^";]+)"?/i);
    return {
      blob: await response.blob(),
      filename: match ? match[1] : "vision_algorithm.py",
    };
  }

  window.VisionApi = Object.freeze({
    register,
    login,
    logout,
    getSession,
    getMe,
    listWorkspaces,
    createWorkspace,
    addWorkspaceMember,
    heartbeat,
    listPresence,
    getAuthToken,
    setAuthToken,
    getActiveWorkspaceId,
    setActiveWorkspaceId,
    listProjectVersions,
    diffProject,
    rollbackProject,
    releaseProjectVersion,
    listDatasets,
    createDataset,
    runRegression,
    submitWorkflowJob,
    listRuns,
    listJobs,
    getJob,
    listModelAssets,
    updateModelMetadata,
    validatePythonSnippet,
    getOperators,
    executeWorkflow,
    listProjects,
    getProject,
    saveProject,
    deleteProject,
    listModels,
    clearModelCache,
    uploadModel,
    exportScript,
  });
})();
