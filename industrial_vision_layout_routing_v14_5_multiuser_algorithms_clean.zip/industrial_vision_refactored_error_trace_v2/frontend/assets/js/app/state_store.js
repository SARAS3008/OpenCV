/**
 * 前端状态与持久化模块。
 * 负责把工作区状态从页面全局变量中抽离出来，并统一处理服务端项目与本地兜底缓存。
 */
(() => {
  const WORKSPACE_STORAGE_KEY = "vision_python_mvp_workspace_v2";
  const LEGACY_KEYS = ["vision_python_mvp_workspace_v1", "vision_python_mvp_workflow_v3", "vision_python_mvp_workflow_v2"];
  const fallbackStorage = new Map();

  function storageGet(key){
    try{ return window.localStorage.getItem(key); }
    catch(error){ return fallbackStorage.has(key) ? fallbackStorage.get(key) : null; }
  }
  function storageSet(key, value){
    const serialized = String(value);
    try{ window.localStorage.setItem(key, serialized); }
    catch(error){ fallbackStorage.set(key, serialized); }
  }
  function cloneData(value){ return JSON.parse(JSON.stringify(value)); }
  function signature(workflow){ return JSON.stringify(workflow || { version:"2.1", nodes:[], edges:[] }); }
  function createWorkflowId(){
    if(window.crypto && typeof window.crypto.randomUUID === "function") return `wf_${window.crypto.randomUUID()}`;
    return `wf_${Date.now()}_${Math.random().toString(16).slice(2)}`;
  }

  function makeDocument(workflow, options = {}){
    const normalizedWorkflow = cloneData(workflow || { version:"2.1", nodes:[], edges:[] });
    const name = options.name || "Vision Workflow";
    const saved = Boolean(options.saved);
    return {
      id:options.id || createWorkflowId(),
      projectId:options.projectId || options.project_id || null,
      name,
      workflow:normalizedWorkflow,
      savedSnapshot:saved ? signature(normalizedWorkflow) : (options.savedSnapshot || null),
      savedName:saved ? name : (options.savedName || null),
      dirty:!saved,
      view:options.view || { pan:{ x:-260, y:-120 }, zoom:.82, previewCollapsed:false, nodeLibraryVisible:true, activeSidePanel:"nodes" },
      selectedNodeId:options.selectedNodeId || null,
      runtimePreviews:[],
    };
  }

  async function loadServerProjects(){
    const data = await VisionApi.listProjects();
    return (data.projects || []).map(item => ({ ...item }));
  }

  async function openServerProject(projectId){
    const data = await VisionApi.getProject(projectId);
    const project = data.project;
    return makeDocument(project.workflow, {
      id:`server_${project.project_id}`,
      projectId:project.project_id,
      name:project.name || "Vision Workflow",
      saved:true,
    });
  }

  async function saveServerDocument(documentInfo){
    const data = await VisionApi.saveProject({
      project_id:documentInfo.projectId || undefined,
      name:documentInfo.name,
      workflow:documentInfo.workflow,
    });
    const project = data.project;
    documentInfo.projectId = project.project_id;
    documentInfo.id = documentInfo.id || `server_${project.project_id}`;
    documentInfo.name = project.name || documentInfo.name;
    documentInfo.savedSnapshot = signature(documentInfo.workflow);
    documentInfo.savedName = documentInfo.name;
    documentInfo.dirty = false;
    return project;
  }

  function loadLocalWorkspace(){
    for(const key of [WORKSPACE_STORAGE_KEY, ...LEGACY_KEYS]){
      const raw = storageGet(key);
      if(!raw) continue;
      try{
        const payload = JSON.parse(raw);
        if(Array.isArray(payload.documents)) return payload;
        if(payload.nodes || payload.edges){
          return { version:1, activeWorkflowId:null, documents:[{ name:"Vision Workflow", workflow:payload, savedSnapshot:signature(payload), savedName:"Vision Workflow" }] };
        }
      }catch(error){
        console.warn("本地工作区读取失败", key, error);
      }
    }
    return null;
  }

  function saveLocalWorkspace(payload){
    storageSet(WORKSPACE_STORAGE_KEY, JSON.stringify(payload));
  }

  window.VisionWorkspaceStore = Object.freeze({
    WORKSPACE_STORAGE_KEY,
    cloneData,
    signature,
    createWorkflowId,
    makeDocument,
    storageGet,
    storageSet,
    loadLocalWorkspace,
    saveLocalWorkspace,
    loadServerProjects,
    openServerProject,
    saveServerDocument,
  });
})();
