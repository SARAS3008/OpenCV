/**
 * PythonSnippet 专用编辑体验。
 * 目标：让代码片段节点像一个小型本地 IDE：清楚看到输入、输出、变量、模板和校验结果。
 */
(() => {
  const OUTPUT_KEYS = ["out", "image", "value", "metrics", "data", "result"];
  const RUNTIME_VARIABLES = [
    ["inputs", "dict", "所有输入端口值，例如 inputs['in']、inputs['aux']、inputs['value']"],
    ["image", "ndarray | None", "inputs['in'] 的快捷别名，通常是主图像"],
    ["aux", "any", "inputs['aux'] 的快捷别名，可接第二张图、mask 或对象"],
    ["value", "any", "inputs['value'] 的快捷别名，适合数值、布尔、JSON 对象"],
    ["params", "dict", "节点参数，已自动排除 code 本身"],
    ["context", "dict", "运行上下文：image_id、current_image_path、batch_index、user_id 等"],
    ["np", "module", "numpy"],
    ["cv2", "module", "OpenCV"],
    ["math/statistics/json", "module", "常用 Python 标准库模块"],
  ];
  const OUTPUT_CONTRACT = [
    ["out", "主输出", "连接到后续节点默认使用的结果；图像或数值均可"],
    ["image", "图像输出", "当 out 是图像时会自动同步，也可显式指定"],
    ["value", "值输出", "数值、布尔、字符串或 JSON 对象"],
    ["metrics", "预览指标", "显示在节点和右侧运行预览中，不直接作为图像传递"],
    ["data", "结构化数据", "会并入流程 data，适合传递检测结果、坐标、统计信息"],
    ["process(inputs, params, context)", "函数写法", "定义该函数时，函数返回值优先作为节点输出"],
  ];
  const TEMPLATES = {
    identity: {
      label: "透传/查看输入",
      description: "不改变主图，只统计尺寸和数据类型。",
      code: `# 透传输入，并把输入信息显示在 metrics 中\nif image is None:\n    out = value\n    metrics = {"input_type": type(value).__name__}\nelse:\n    out = image.copy()\n    metrics = {\n        "shape": list(image.shape),\n        "dtype": str(image.dtype),\n        "min": int(np.min(image)),\n        "max": int(np.max(image)),\n    }\n`,
    },
    edges: {
      label: "Canny 边缘",
      description: "灰度化后提取边缘，并输出边缘像素数量。",
      code: `# Canny 边缘检测\nif image is None:\n    raise ValueError("请把图像连接到 in 输入端口")\n\ngray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY) if image.ndim == 3 else image\nout = cv2.Canny(gray, 50, 150)\nmetrics = {\n    "edge_pixels": int(np.count_nonzero(out)),\n    "edge_ratio": float(np.count_nonzero(out) / out.size),\n}\ndata = {"edge_pixels": metrics["edge_pixels"]}\n`,
    },
    mask_apply: {
      label: "应用 aux Mask",
      description: "aux 接二值 mask，对主图做抠图。",
      code: `# 使用 aux 作为 mask，对 image 做抠图\nif image is None:\n    raise ValueError("请把待处理图像连接到 in 输入端口")\nif aux is None:\n    raise ValueError("请把 mask 图连接到 aux 输入端口")\n\nmask = aux\nif mask.ndim == 3:\n    mask = cv2.cvtColor(mask, cv2.COLOR_BGR2GRAY)\nmask = (mask > 0).astype(np.uint8) * 255\nout = cv2.bitwise_and(image, image, mask=mask)\nmetrics = {\n    "mask_pixels": int(np.count_nonzero(mask)),\n    "mask_ratio": float(np.count_nonzero(mask) / mask.size),\n}\ndata = {"mask_pixels": metrics["mask_pixels"]}\n`,
    },
    threshold: {
      label: "阈值分割",
      description: "把图像转灰度并根据阈值得到二值图。",
      code: `# 简单阈值分割\nif image is None:\n    raise ValueError("请把图像连接到 in 输入端口")\n\nthreshold = int(params.get("threshold", 128))\ngray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY) if image.ndim == 3 else image\n_, out = cv2.threshold(gray, threshold, 255, cv2.THRESH_BINARY)\nmetrics = {\n    "threshold": threshold,\n    "foreground_pixels": int(np.count_nonzero(out)),\n}\n`,
    },
    process_fn: {
      label: "process 函数模板",
      description: "适合较复杂逻辑，把输入、参数、上下文集中处理。",
      code: `def process(inputs, params, context):\n    img = inputs.get("in")\n    aux_img = inputs.get("aux")\n    val = inputs.get("value")\n\n    if img is None:\n        return {\n            "out": val,\n            "value": val,\n            "metrics": {"input_type": type(val).__name__},\n        }\n\n    result = cv2.bitwise_not(img)\n    return {\n        "out": result,\n        "image": result,\n        "metrics": {\n            "shape": list(result.shape),\n            "batch_index": context.get("batch_index"),\n        },\n        "data": {"ok": True},\n    }\n`,
    },
    scalar_logic: {
      label: "数值/逻辑输出",
      description: "接收 value，输出布尔判断和指标。",
      code: `# value 可来自逻辑节点或上游 metrics/data 节点\nscore = float(value if value is not None else 0)\npassed = score >= float(params.get("min_score", 0.8))\nout = passed\nvalue = passed\nmetrics = {"score": score, "passed": passed}\ndata = {"decision": "OK" if passed else "NG", "score": score}\n`,
    },
  };

  function esc(value){
    return String(value ?? "").replace(/[&<>'"]/g, ch => ({"&":"&amp;","<":"&lt;",">":"&gt;","'":"&#39;",'"':"&quot;"}[ch]));
  }

  function getNode(nodeId){ return (window.nodes || nodes || []).find(item => item.id === nodeId) || null; }
  function getMeta(type){ return (window.OPERATOR_META || OPERATOR_META || {})[type] || {}; }
  function portLabel(port){ return `${port.handle || "out"}${port.type ? ` · ${port.type}` : ""}${port.label ? ` · ${port.label}` : ""}`; }

  function getIncomingConnections(node){
    if(!node) return [];
    return (edges || []).filter(edge => edge.target === node.id).map(edge => {
      const source = getNode(edge.source);
      const sourceMeta = getMeta(source?.type);
      const outputs = Array.isArray(sourceMeta.outputs) ? sourceMeta.outputs : [{ handle:"out", label:"输出", type:sourceMeta.result_type || "any" }];
      const sourceHandle = edge.sourceHandle || "out";
      const targetHandle = edge.targetHandle || "in";
      const port = outputs.find(item => (item.handle || "out") === sourceHandle) || { handle:sourceHandle, type:"any" };
      return { edge, source, sourceMeta, sourceHandle, targetHandle, port };
    });
  }

  function getInputRows(node){
    const meta = getMeta(node?.type);
    const declared = Array.isArray(meta.inputs) ? meta.inputs : [];
    const connections = getIncomingConnections(node);
    const byTarget = new Map(connections.map(item => [item.targetHandle, item]));
    return declared.map(port => {
      const handle = port.handle || "in";
      const connection = byTarget.get(handle);
      return {
        handle,
        label: port.label || handle,
        type: port.type || "any",
        required: port.required !== false,
        connection,
      };
    });
  }

  function previewFor(nodeId){
    try{ return nodePreviews.get(nodeId) || null; }
    catch(_error){ return null; }
  }

  function objectTable(rows){
    return `<div class="snippet-table">${rows.map(row => `<div class="snippet-table-row"><b>${esc(row[0])}</b><span>${esc(row[1])}</span><em>${esc(row[2])}</em></div>`).join("")}</div>`;
  }

  function renderInputContract(node){
    const rows = getInputRows(node);
    if(!rows.length) return '<div class="snippet-empty">没有声明输入端口。</div>';
    return `<div class="snippet-port-list">${rows.map(row => {
      const c = row.connection;
      const status = c ? "connected" : row.required ? "missing" : "optional";
      const statusText = c ? `${c.source?.id || c.edge.source}.${c.sourceHandle}` : row.required ? "未连接" : "可选";
      const desc = c ? `${c.sourceMeta?.label || c.source?.type || "上游节点"} → ${portLabel(c.port)}` : "未连接时变量值为 None";
      return `<div class="snippet-port ${status}"><div><strong>inputs['${esc(row.handle)}']</strong><span>${esc(row.label)} · ${esc(row.type)}</span></div><small>${esc(statusText)}</small><p>${esc(desc)}</p></div>`;
    }).join("")}</div>`;
  }

  function renderLastRun(node){
    const preview = previewFor(node?.id);
    if(!preview) return '<div class="snippet-empty">还没有运行结果。运行工作流后，这里会显示该节点最近一次输出的 metrics/data。</div>';
    const metrics = preview.metrics || {};
    const data = preview.data || {};
    const metricRows = Object.entries(metrics).map(([k, v]) => [k, typeof v, JSON.stringify(v)]);
    const dataRows = Object.entries(data).slice(0, 20).map(([k, v]) => [k, Array.isArray(v) ? "array" : typeof v, typeof v === "object" ? JSON.stringify(v).slice(0, 160) : String(v)]);
    return `<div class="snippet-last-run"><div class="snippet-run-head"><b>${esc(preview.status || "success")}</b><span>${esc(preview.result_type || "")}</span></div>
      <h5>metrics</h5>${metricRows.length ? objectTable(metricRows) : '<div class="snippet-empty compact">无 metrics</div>'}
      <h5>data</h5>${dataRows.length ? objectTable(dataRows) : '<div class="snippet-empty compact">无 data</div>'}</div>`;
  }

  function makeTextarea(value, onChange){
    const wrap = document.createElement("div");
    wrap.className = "snippet-code-shell";
    const gutter = document.createElement("div");
    gutter.className = "snippet-line-gutter";
    const textarea = document.createElement("textarea");
    textarea.className = "snippet-code-textarea";
    textarea.value = value || "";
    textarea.spellcheck = false;
    textarea.wrap = "off";
    function updateLines(){
      const count = Math.max(1, textarea.value.split("\n").length);
      gutter.innerHTML = Array.from({ length: count }, (_, index) => `<span>${index + 1}</span>`).join("");
      if(typeof onChange === "function") onChange(textarea.value);
    }
    textarea.addEventListener("input", updateLines);
    textarea.addEventListener("scroll", () => { gutter.scrollTop = textarea.scrollTop; });
    textarea.addEventListener("keydown", event => {
      if(event.key === "Tab"){
        event.preventDefault();
        const start = textarea.selectionStart;
        const end = textarea.selectionEnd;
        textarea.value = `${textarea.value.slice(0, start)}    ${textarea.value.slice(end)}`;
        textarea.selectionStart = textarea.selectionEnd = start + 4;
        updateLines();
      }
    });
    wrap.append(gutter, textarea);
    updateLines();
    return { wrap, textarea, updateLines };
  }

  function insertAtCursor(textarea, text){
    const start = textarea.selectionStart ?? textarea.value.length;
    const end = textarea.selectionEnd ?? textarea.value.length;
    textarea.value = `${textarea.value.slice(0, start)}${text}${textarea.value.slice(end)}`;
    textarea.selectionStart = textarea.selectionEnd = start + text.length;
    textarea.dispatchEvent(new Event("input", { bubbles:true }));
    textarea.focus();
  }

  async function validateCode(code, targetEl){
    targetEl.className = "snippet-validation pending";
    targetEl.textContent = "正在校验代码...";
    try{
      const result = await VisionApi.validatePythonSnippet(code);
      const analysis = result.analysis || {};
      const outputs = (analysis.assigned_outputs || []).join("、") || "未显式赋值";
      const warnings = (analysis.warnings || []).map(item => `<li>${esc(item)}</li>`).join("");
      targetEl.className = `snippet-validation ${warnings ? "warning" : "ok"}`;
      targetEl.innerHTML = `<b>语法和安全校验通过</b><br>行数：${Number(analysis.line_count || 0)}；process：${analysis.has_process ? "已定义" : "未定义"}；输出赋值：${esc(outputs)}${warnings ? `<ul>${warnings}</ul>` : ""}`;
      return true;
    }catch(error){
      targetEl.className = "snippet-validation error";
      targetEl.textContent = error?.message || String(error);
      return false;
    }
  }

  function commitCode(nodeId, key, code){
    const node = getNode(nodeId);
    if(!node) return;
    updateNodeParam(nodeId, key || "code", code);
  }

  function setParamSilently(nodeId, key, value){
    const node = getNode(nodeId);
    if(!node) return;
    node.params[key] = value;
    invalidateNodeAndDownstreamPreviews(nodeId);
    commitActiveWorkflowChange();
  }

  function renderPythonSnippetInlineEditor(container, node, key, value, schema){
    const wrapper = document.createElement("div");
    wrapper.className = "python-snippet-inline";
    const header = document.createElement("div");
    header.className = "python-snippet-inline-head";
    header.innerHTML = `<b>Python 小型编辑器</b><span>Tab 缩进 · Ctrl/⌘+S 保存 · Ctrl/⌘+Enter 保存并运行</span>`;
    const actions = document.createElement("div");
    actions.className = "python-snippet-inline-actions";
    const open = document.createElement("button");
    open.type = "button";
    open.textContent = "打开开发界面";
    open.onclick = event => { event.stopPropagation(); openPythonSnippetIde(node.id); };
    const validate = document.createElement("button");
    validate.type = "button";
    validate.textContent = "校验";
    const template = document.createElement("button");
    template.type = "button";
    template.textContent = "插入透传模板";
    const validation = document.createElement("div");
    validation.className = "snippet-validation compact";
    validation.textContent = "可先校验，再运行工作流。";
    const editor = makeTextarea(value ?? "", null);
    editor.textarea.classList.add("node-param-textarea");
    editor.textarea.rows = Math.max(8, Number(schema.rows || 12));
    editor.textarea.addEventListener("mousedown", event => selectNodeWithoutRerender(node.id, event));
    editor.textarea.addEventListener("keydown", event => {
      if((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "s"){
        event.preventDefault();
        commitCode(node.id, key, editor.textarea.value);
      }else if((event.ctrlKey || event.metaKey) && event.key === "Enter"){
        event.preventDefault();
        commitCode(node.id, key, editor.textarea.value);
        runWorkflow();
      }
    });
    editor.textarea.onchange = () => commitCode(node.id, key, editor.textarea.value);
    validate.onclick = event => { event.stopPropagation(); validateCode(editor.textarea.value, validation); };
    template.onclick = event => { event.stopPropagation(); insertAtCursor(editor.textarea, TEMPLATES.identity.code); };
    actions.append(open, validate, template);
    wrapper.append(header, actions, editor.wrap, validation);
    container.appendChild(wrapper);
  }

  function renderPythonSnippetParamPanel(node, meta){
    const previewState = previewFor(node.id) ? "已生成节点输出" : "尚未运行";
    return `<h3>${esc(node.id)} · ${esc(meta.label || node.type)}</h3>
      <div class="snippet-param-summary">
        <div><b>当前节点是代码片段节点</b><span>${esc(meta.description || "")}</span></div>
        <button class="btn" onclick="openPythonSnippetIde('${esc(node.id)}')">打开 Python 开发界面</button>
      </div>
      <div class="snippet-side-section"><h4>输入端口映射</h4>${renderInputContract(node)}</div>
      <div class="snippet-side-section"><h4>输出约定</h4>${objectTable(OUTPUT_CONTRACT)}</div>
      <div class="snippet-side-section"><h4>最近运行</h4><div class="hint">${esc(previewState)}</div>${renderLastRun(node)}</div>
      <div class="row-actions"><button class="btn ghost" onclick="duplicateNode('${esc(node.id)}')">复制节点</button><button class="btn red" onclick="deleteNode('${esc(node.id)}')">删除节点</button></div>`;
  }

  function createModal(){
    let modal = document.getElementById("pythonSnippetIde");
    if(modal) return modal;
    modal = document.createElement("div");
    modal.id = "pythonSnippetIde";
    modal.className = "snippet-ide";
    modal.innerHTML = `<div class="snippet-ide-backdrop" data-close="1"></div>
      <div class="snippet-ide-dialog" role="dialog" aria-modal="true" aria-labelledby="snippetIdeTitle">
        <div class="snippet-ide-topbar">
          <div><strong id="snippetIdeTitle">Python 代码片段开发界面</strong><span id="snippetIdeSubtitle"></span></div>
          <div class="snippet-ide-top-actions">
            <button type="button" data-action="run">保存并运行</button>
            <button type="button" data-action="save" class="primary">保存代码</button>
            <button type="button" data-action="close" class="icon">×</button>
          </div>
        </div>
        <div class="snippet-ide-body">
          <aside class="snippet-ide-left">
            <section><h4>输入端口</h4><div id="snippetIdeInputs"></div></section>
            <section><h4>可用变量</h4><div id="snippetIdeVariables"></div></section>
            <section><h4>输出约定</h4><div id="snippetIdeOutputs"></div></section>
          </aside>
          <main class="snippet-ide-center">
            <div class="snippet-template-bar" id="snippetTemplateBar"></div>
            <div id="snippetIdeEditorMount"></div>
            <div id="snippetIdeValidation" class="snippet-validation compact">保存前可点击“校验代码”检查语法和安全限制。</div>
          </main>
          <aside class="snippet-ide-right">
            <section><h4>运行设置</h4><div id="snippetIdeParams"></div></section>
            <section><h4>最近运行输出</h4><div id="snippetIdeLastRun"></div></section>
            <section><h4>快捷键</h4><div class="snippet-shortcuts"><kbd>Tab</kbd><span>插入四个空格</span><kbd>Ctrl/⌘ + S</kbd><span>保存代码</span><kbd>Ctrl/⌘ + Enter</kbd><span>保存并运行</span></div></section>
          </aside>
        </div>
      </div>`;
    document.body.appendChild(modal);
    modal.addEventListener("mousedown", event => {
      if(event.target?.dataset?.close) closePythonSnippetIde();
    });
    modal.querySelector('[data-action="close"]').onclick = closePythonSnippetIde;
    return modal;
  }

  function renderParamsControls(node){
    const controls = [
      ["timeout_ms", "超时ms", "number"],
      ["isolated", "隔离执行", "select", [["YES", "是，子进程"], ["NO", "否，当前进程"]]],
      ["output_kind", "导出类型", "select", [["AUTO", "自动"], ["IMAGE", "图像"], ["VALUE", "值"], ["BOOLEAN", "布尔"]]],
      ["output_color_space", "输出颜色", "select", [["AUTO", "自动"], ["BGR", "BGR"], ["RGB", "RGB"], ["GRAY", "GRAY"]]],
    ];
    return controls.map(([key, label, type, options]) => {
      const value = node.params?.[key] ?? getMeta(node.type).params?.[key] ?? "";
      if(type === "select"){
        return `<label class="snippet-setting"><span>${esc(label)}</span><select data-snippet-param="${esc(key)}">${options.map(([v, text]) => `<option value="${esc(v)}" ${String(v) === String(value) ? "selected" : ""}>${esc(text)}</option>`).join("")}</select></label>`;
      }
      return `<label class="snippet-setting"><span>${esc(label)}</span><input data-snippet-param="${esc(key)}" type="number" value="${esc(value)}"></label>`;
    }).join("");
  }

  function openPythonSnippetIde(nodeId){
    const node = getNode(nodeId);
    if(!node || node.type !== "PythonSnippet"){
      toast("无法打开", "请选择一个 Python代码片段 节点");
      return;
    }
    selectedNodeId = node.id;
    selectedEdgeId = null;
    const meta = getMeta(node.type);
    const modal = createModal();
    modal.dataset.nodeId = node.id;
    modal.classList.add("open");
    document.body.classList.add("snippet-ide-open");
    document.getElementById("snippetIdeTitle").textContent = `${node.id} · ${meta.label || node.type}`;
    document.getElementById("snippetIdeSubtitle").textContent = "像本地开发一样查看输入、输出和运行结果";
    document.getElementById("snippetIdeInputs").innerHTML = renderInputContract(node);
    document.getElementById("snippetIdeVariables").innerHTML = objectTable(RUNTIME_VARIABLES);
    document.getElementById("snippetIdeOutputs").innerHTML = objectTable(OUTPUT_CONTRACT);
    document.getElementById("snippetIdeLastRun").innerHTML = renderLastRun(node);
    document.getElementById("snippetIdeParams").innerHTML = renderParamsControls(node);

    const templateBar = document.getElementById("snippetTemplateBar");
    templateBar.innerHTML = Object.entries(TEMPLATES).map(([key, item]) => `<button type="button" data-template="${esc(key)}" title="${esc(item.description)}">${esc(item.label)}</button>`).join("") + `<button type="button" data-action="validate">校验代码</button>`;

    const mount = document.getElementById("snippetIdeEditorMount");
    mount.innerHTML = "";
    const currentCode = node.params?.code ?? meta.params?.code ?? "";
    const editor = makeTextarea(currentCode, null);
    mount.appendChild(editor.wrap);
    editor.textarea.focus();

    function save(){
      const latest = getNode(nodeId);
      if(!latest) return;
      latest.params.code = editor.textarea.value;
      invalidateNodeAndDownstreamPreviews(nodeId);
      commitActiveWorkflowChange();
      render();
      setStatus(`已保存 ${nodeId} 的 Python 代码`);
      toast("代码已保存", nodeId, true);
    }
    modal.querySelector('[data-action="save"]').onclick = event => { event.stopPropagation(); save(); };
    modal.querySelector('[data-action="run"]').onclick = event => { event.stopPropagation(); save(); runWorkflow(); };
    templateBar.querySelectorAll("[data-template]").forEach(button => {
      button.onclick = event => {
        event.stopPropagation();
        const tpl = TEMPLATES[button.dataset.template];
        if(!tpl) return;
        if(editor.textarea.value.trim() && !confirm(`用“${tpl.label}”替换当前代码？选择取消则插入到光标位置。`)){
          insertAtCursor(editor.textarea, `\n\n${tpl.code}`);
        }else{
          editor.textarea.value = tpl.code;
          editor.textarea.dispatchEvent(new Event("input", { bubbles:true }));
        }
      };
    });
    templateBar.querySelector('[data-action="validate"]').onclick = event => {
      event.stopPropagation();
      validateCode(editor.textarea.value, document.getElementById("snippetIdeValidation"));
    };
    modal.querySelectorAll("[data-snippet-param]").forEach(control => {
      control.onchange = () => {
        const key = control.dataset.snippetParam;
        const value = control.type === "number" ? Number(control.value) : control.value;
        setParamSilently(nodeId, key, value);
        setStatus(`已更新 ${nodeId}.${key}`);
      };
    });
    editor.textarea.addEventListener("keydown", event => {
      if((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "s"){
        event.preventDefault();
        save();
      }else if((event.ctrlKey || event.metaKey) && event.key === "Enter"){
        event.preventDefault();
        save();
        runWorkflow();
      }
    });
    window.__activePythonSnippetEditor = editor;
  }

  function closePythonSnippetIde(){
    const modal = document.getElementById("pythonSnippetIde");
    if(modal) modal.classList.remove("open");
    document.body.classList.remove("snippet-ide-open");
  }

  window.renderPythonSnippetInlineEditor = renderPythonSnippetInlineEditor;
  window.renderPythonSnippetParamPanel = renderPythonSnippetParamPanel;
  window.openPythonSnippetIde = openPythonSnippetIde;
  window.closePythonSnippetIde = closePythonSnippetIde;
})();
