(() => {
  const state = {
    user:null,
    workspaces:[],
    heartbeatTimer:null,
    onlineUsers:[],
    onlinePanelOpen:false,
  };

  function el(id){ return document.getElementById(id); }
  function displayName(user){ return user?.display_name || user?.email || user?.user_id || "未登录"; }
  function activeWorkspaceId(){ return VisionApi.getActiveWorkspaceId(); }
  function isLoggedIn(){ return Boolean(VisionApi.getAuthToken() && state.user); }

  function setAuthMessage(message, ok = false){
    const node = el("authMessage");
    if(!node) return;
    node.textContent = message || "";
    node.classList.toggle("ok", Boolean(ok));
  }

  function setLoginGate(loggedIn){
    document.body.classList.toggle("auth-required", !loggedIn);
    const gate = el("loginGate");
    if(gate){
      gate.classList.toggle("open", !loggedIn);
      gate.setAttribute("aria-hidden", String(loggedIn));
    }
  }

  function openAuthDialog(){
    const dialog = el("authDialog");
    if(!dialog) return;
    dialog.classList.add("open");
    dialog.setAttribute("aria-hidden", "false");
    setAuthMessage("");
    setTimeout(() => el("authEmail")?.focus(), 30);
  }

  function closeAuthDialog(){
    const dialog = el("authDialog");
    if(!dialog) return;
    dialog.classList.remove("open");
    dialog.setAttribute("aria-hidden", "true");
  }

  async function ensurePlatformInitialized(){
    try{
      if(typeof initOperators === "function"){
        const loaded = typeof OPERATOR_META !== "undefined" && OPERATOR_META && Object.keys(OPERATOR_META).length > 0;
        if(!loaded) await initOperators();
        else if(typeof initializeWorkspace === "function" && (!workflowDocuments || !workflowDocuments.length)) await initializeWorkspace();
      }
    }catch(error){
      console.warn("登录后平台初始化失败", error);
      if(typeof toast === "function") toast("初始化失败", error.message || String(error));
    }
  }

  async function submitAuthLogin(){
    try{
      setAuthMessage("登录中...");
      await VisionApi.login({ email:el("authEmail")?.value || "", password:el("authPassword")?.value || "" });
      closeAuthDialog();
      await refreshIdentity(true);
      await ensurePlatformInitialized();
      if(typeof toast === "function") toast("登录成功", displayName(state.user), true);
    }catch(error){
      setAuthMessage(error.message || String(error));
    }
  }

  async function submitAuthRegister(){
    try{
      setAuthMessage("注册中...");
      await VisionApi.register({
        email:el("authEmail")?.value || "",
        password:el("authPassword")?.value || "",
        display_name:el("authDisplayName")?.value || "",
      });
      closeAuthDialog();
      await refreshIdentity(true);
      await ensurePlatformInitialized();
      if(typeof toast === "function") toast("注册并登录成功", displayName(state.user), true);
    }catch(error){
      setAuthMessage(error.message || String(error));
    }
  }

  async function logoutCurrentUser(){
    await VisionApi.logout();
    state.user = null;
    state.workspaces = [];
    state.onlineUsers = [];
    state.onlinePanelOpen = false;
    VisionApi.setActiveWorkspaceId("");
    stopHeartbeat();
    renderAccountBar();
    setLoginGate(false);
    renderOnlinePanel();
    if(typeof setStatus === "function") setStatus("请先登录后再操作平台。");
    if(typeof toast === "function") toast("已退出登录", "请重新登录后继续使用", true);
  }

  async function refreshIdentity(forceWorkspace = false){
    if(!VisionApi.getAuthToken()){
      state.user = null;
      state.workspaces = [];
      state.onlineUsers = [];
      state.onlinePanelOpen = false;
      stopHeartbeat();
      renderAccountBar();
      setLoginGate(false);
      renderOnlinePanel();
      if(typeof setStatus === "function") setStatus("请先登录后再操作平台。");
      return false;
    }
    try{
      const me = await VisionApi.getMe();
      state.user = me.user;
      const workspacePayload = await VisionApi.listWorkspaces();
      state.workspaces = workspacePayload.workspaces || [];
      let ws = activeWorkspaceId();
      if(forceWorkspace || !ws || !state.workspaces.some(item => item.workspace_id === ws)){
        ws = state.user?.default_workspace_id || state.workspaces[0]?.workspace_id || "";
        if(ws) VisionApi.setActiveWorkspaceId(ws);
      }
      renderAccountBar();
      setLoginGate(true);
      startHeartbeat();
      return true;
    }catch(error){
      console.warn("用户/工作区状态初始化失败", error);
      VisionApi.setAuthToken("");
      VisionApi.setActiveWorkspaceId("");
      state.user = null;
      state.workspaces = [];
      state.onlineUsers = [];
      state.onlinePanelOpen = false;
      stopHeartbeat();
      renderAccountBar();
      setLoginGate(false);
      renderOnlinePanel();
      if(typeof setStatus === "function") setStatus(error.message || "登录状态已失效，请重新登录。");
      return false;
    }
  }

  function renderAccountBar(){
    const loginButton = el("loginButton");
    const logoutButton = el("logoutButton");
    const workspaceSelect = el("workspaceSelect");
    const online = el("onlineUsers");
    const workspaceButton = document.querySelector('[onclick="createWorkspaceFromUi()"]');
    const inviteButton = document.querySelector('[onclick="showInviteMemberDialog()"]');
    const loggedIn = isLoggedIn();
    if(loginButton){
      loginButton.textContent = loggedIn && state.user ? displayName(state.user) : "登录";
      loginButton.title = loggedIn && state.user ? `${displayName(state.user)} · ${state.user.email || state.user.user_id}` : "登录 / 注册";
    }
    if(logoutButton) logoutButton.style.display = loggedIn ? "inline-flex" : "none";
    [workspaceButton, inviteButton].forEach(button => { if(button) button.disabled = !loggedIn; });
    if(workspaceSelect){
      workspaceSelect.disabled = !loggedIn;
      workspaceSelect.innerHTML = "";
      const workspaces = loggedIn ? state.workspaces : [];
      if(!workspaces.length){
        const option = document.createElement("option");
        option.value = "";
        option.textContent = loggedIn ? "暂无工作区" : "请先登录";
        workspaceSelect.appendChild(option);
      }else{
        for(const workspace of workspaces){
          const option = document.createElement("option");
          option.value = workspace.workspace_id;
          option.textContent = `${workspace.name || workspace.workspace_id}${workspace.role ? ` · ${workspace.role}` : ""}`;
          workspaceSelect.appendChild(option);
        }
      }
      workspaceSelect.value = loggedIn ? (VisionApi.getActiveWorkspaceId() || workspaces[0]?.workspace_id || "") : "";
      workspaceSelect.onchange = async () => {
        VisionApi.setActiveWorkspaceId(workspaceSelect.value);
        state.onlineUsers = [];
        renderAccountBar();
        await refreshOnlineUsers();
        if(typeof toast === "function") toast("已切换工作区", workspaceSelect.options[workspaceSelect.selectedIndex]?.textContent || workspaceSelect.value, true);
      };
    }
    if(online){
      online.disabled = !loggedIn;
      if(!loggedIn) online.textContent = "在线：-";
    }
  }

  async function createWorkspaceFromUi(){
    if(!isLoggedIn()){ openAuthDialog(); return; }
    const name = window.prompt("请输入新工作区名称", "视觉开发工作区");
    if(!name) return;
    try{
      const data = await VisionApi.createWorkspace({ name });
      VisionApi.setActiveWorkspaceId(data.workspace.workspace_id);
      await refreshIdentity(false);
      if(typeof toast === "function") toast("工作区已创建", data.workspace.name, true);
    }catch(error){
      if(typeof toast === "function") toast("创建工作区失败", error.message || String(error));
      else alert(error.message || String(error));
    }
  }

  async function showInviteMemberDialog(){
    if(!isLoggedIn()){ openAuthDialog(); return; }
    const workspaceId = activeWorkspaceId();
    if(!workspaceId){ alert("请先选择工作区"); return; }
    const userId = window.prompt("输入成员邮箱或用户ID", "");
    if(!userId) return;
    const role = window.prompt("输入角色：Maintainer / Developer / Reviewer / Viewer / Operator", "Developer") || "Developer";
    try{
      await VisionApi.addWorkspaceMember(workspaceId, { user_id:userId, role });
      await refreshIdentity(false);
      if(typeof toast === "function") toast("成员已加入工作区", `${userId} · ${role}`, true);
    }catch(error){
      if(typeof toast === "function") toast("邀请成员失败", error.message || String(error));
      else alert(error.message || String(error));
    }
  }

  function startHeartbeat(){
    stopHeartbeat();
    refreshOnlineUsers();
    state.heartbeatTimer = window.setInterval(refreshOnlineUsers, 10000);
  }
  function stopHeartbeat(){
    if(state.heartbeatTimer){
      window.clearInterval(state.heartbeatTimer);
      state.heartbeatTimer = null;
    }
  }

  function renderOnlinePanel(){
    const panel = el("onlineUsersPanel");
    const trigger = el("onlineUsers");
    if(!panel) return;
    panel.classList.toggle("open", Boolean(state.onlinePanelOpen));
    panel.setAttribute("aria-hidden", String(!state.onlinePanelOpen));
    if(trigger) trigger.classList.toggle("active", Boolean(state.onlinePanelOpen));
    if(!state.onlinePanelOpen) return;
    if(!isLoggedIn()){
      panel.innerHTML = '<div class="online-empty">请先登录。</div>';
      return;
    }
    const users = state.onlineUsers || [];
    if(!users.length){
      panel.innerHTML = '<div class="online-empty">当前工作区暂无在线用户。</div>';
      return;
    }
    panel.innerHTML = users.map(user => {
      const name = user.display_name || user.email || user.user_id;
      const email = user.email ? `<small>${escapeHtml(user.email)}</small>` : `<small>${escapeHtml(user.user_id || "")}</small>`;
      return `<div class="online-user-row"><span class="online-dot"></span><b>${escapeHtml(name)}</b>${email}</div>`;
    }).join("");
  }

  async function toggleOnlineUsersPanel(){
    if(!isLoggedIn()){ openAuthDialog(); return; }
    state.onlinePanelOpen = !state.onlinePanelOpen;
    if(state.onlinePanelOpen) await refreshOnlineUsers();
    renderOnlinePanel();
  }

  async function refreshOnlineUsers(){
    const workspaceId = activeWorkspaceId();
    const online = el("onlineUsers");
    if(!workspaceId || !online || !isLoggedIn()) return;
    try{
      const data = await VisionApi.heartbeat(workspaceId);
      const users = data.online_users || [];
      state.onlineUsers = users;
      online.dataset.loaded = "1";
      online.textContent = `在线：${users.length}`;
      online.title = "点击查看在线用户列表";
      renderOnlinePanel();
    }catch(error){
      online.textContent = "在线：?";
      online.title = error.message || String(error);
      state.onlineUsers = [];
      renderOnlinePanel();
    }
  }

  window.openAuthDialog = openAuthDialog;
  window.closeAuthDialog = closeAuthDialog;
  window.submitAuthLogin = submitAuthLogin;
  window.submitAuthRegister = submitAuthRegister;
  window.logoutCurrentUser = logoutCurrentUser;
  window.createWorkspaceFromUi = createWorkspaceFromUi;
  window.showInviteMemberDialog = showInviteMemberDialog;
  window.refreshWorkspaceIdentity = refreshIdentity;
  window.refreshOnlineUsers = refreshOnlineUsers;
  window.toggleOnlineUsersPanel = toggleOnlineUsersPanel;

  document.addEventListener("click", event => {
    if(!state.onlinePanelOpen) return;
    if(event.target.closest?.(".online-box")) return;
    state.onlinePanelOpen = false;
    renderOnlinePanel();
  });
  document.addEventListener("DOMContentLoaded", () => refreshIdentity(false));
})();
