from pathlib import Path
import subprocess
import sys

import cv2
import numpy as np

from backend.algorithms.registry import OPERATORS, OPERATOR_CATALOG, OPERATOR_META
from backend.models.workflow import WorkflowRequest
from backend.services.image_store import ImageStore
from backend.services.script_exporter import generate_algorithm_script
from backend.services.workflow_engine import run_workflow


def make_store(tmp_path: Path) -> ImageStore:
    return ImageStore(tmp_path, {".png", ".jpg", ".jpeg"})


def encode_png(image: np.ndarray) -> bytes:
    ok, encoded = cv2.imencode(".png", image)
    assert ok
    return encoded.tobytes()


def make_orb_fixture() -> tuple[np.ndarray, np.ndarray]:
    template = np.zeros((120, 120, 3), dtype=np.uint8)
    cv2.rectangle(template, (10, 10), (110, 110), (255, 255, 255), 2)
    cv2.circle(template, (35, 35), 12, (255, 255, 255), -1)
    cv2.circle(template, (85, 80), 16, (255, 255, 255), 2)
    cv2.line(template, (20, 100), (105, 25), (255, 255, 255), 3)
    cv2.putText(template, "A7", (30, 70), cv2.FONT_HERSHEY_SIMPLEX, 1.1, (255, 255, 255), 3)

    scene = np.zeros((260, 320, 3), dtype=np.uint8)
    scene[70:190, 110:230] = template
    cv2.circle(scene, (260, 60), 20, (120, 120, 120), -1)
    cv2.line(scene, (15, 240), (300, 230), (80, 80, 80), 2)
    return scene, template


def test_orb_feature_match_is_registered_in_image_library() -> None:
    assert "ORBFeatureMatch" in OPERATORS
    meta = OPERATOR_META["ORBFeatureMatch"]
    assert meta["label"] == "ORB角点ROI/Mask匹配"
    assert [port["handle"] for port in meta["inputs"]] == ["in", "template", "mask"]
    assert [port["handle"] for port in meta["outputs"][:5]] == ["out", "mask", "roi", "roi_mask", "masked"]
    assert any(group["group"] == "模板匹配" and "ORBFeatureMatch" in group["items"] for group in OPERATOR_CATALOG["图像"])


def test_orb_feature_match_executes_with_template_input(tmp_path: Path) -> None:
    store = make_store(tmp_path)
    scene, template = make_orb_fixture()
    scene_record = store.save("scene.png", encode_png(scene))
    template_record = store.save("template.png", encode_png(template))

    workflow = WorkflowRequest.model_validate(
        {
            "nodes": [
                {"id": "scene", "type": "ReadImage", "params": {"image_id": scene_record.image_id}},
                {"id": "template", "type": "ReadImage", "params": {"image_id": template_record.image_id}},
                {"id": "orb", "type": "ORBFeatureMatch", "params": {"min_matches": 6, "n_features": 1500}},
            ],
            "edges": [
                {"source": "scene", "target": "orb", "targetHandle": "in"},
                {"source": "template", "target": "orb", "targetHandle": "template"},
            ],
        }
    )

    result = run_workflow(workflow, store)
    preview = next(item for item in result["previews"] if item["node_id"] == "orb")

    assert result["success"] is True
    assert preview["result_type"] == "image"
    assert preview["image"].startswith("data:image/png;base64,")
    assert preview["metrics"]["homography_found"] is True
    assert preview["metrics"]["good_match_count"] >= 6
    assert len(preview["data"]["orb_feature_match"]["corners"]) == 4


def test_orb_feature_match_executes_with_template_path(tmp_path: Path) -> None:
    store = make_store(tmp_path)
    scene, template = make_orb_fixture()
    scene_record = store.save("scene.png", encode_png(scene))
    template_record = store.save("template.png", encode_png(template))

    workflow = WorkflowRequest.model_validate(
        {
            "image_id": scene_record.image_id,
            "nodes": [
                {"id": "scene", "type": "ReadImage"},
                {
                    "id": "orb",
                    "type": "ORBFeatureMatch",
                    "params": {"template_path": str(template_record.path), "min_matches": 6, "n_features": 1500},
                },
            ],
            "edges": [{"source": "scene", "target": "orb", "targetHandle": "in"}],
        }
    )

    result = run_workflow(workflow, store)
    preview = next(item for item in result["previews"] if item["node_id"] == "orb")
    assert preview["metrics"]["homography_found"] is True
    assert preview["metrics"]["confidence"] > 0.5


def test_exported_script_supports_orb_feature_match_with_template_path(tmp_path: Path) -> None:
    scene, template = make_orb_fixture()
    scene_path = tmp_path / "scene.png"
    template_path = tmp_path / "template.png"
    script_path = tmp_path / "vision_algorithm.py"
    output_path = tmp_path / "orb_result.png"
    assert cv2.imwrite(str(scene_path), scene)
    assert cv2.imwrite(str(template_path), template)

    workflow = WorkflowRequest.model_validate(
        {
            "nodes": [
                {"id": "scene", "type": "ReadImage"},
                {
                    "id": "orb",
                    "type": "ORBFeatureMatch",
                    "params": {"template_path": str(template_path), "min_matches": 6, "n_features": 1500},
                },
            ],
            "edges": [{"source": "scene", "target": "orb"}],
        }
    )
    source = generate_algorithm_script(workflow)
    assert "ORB_create" in source
    script_path.write_text(source, encoding="utf-8")

    subprocess.run(
        [sys.executable, str(script_path), "--input", str(scene_path), "--output", str(output_path)],
        check=True,
        cwd=tmp_path,
    )
    result = cv2.imread(str(output_path), cv2.IMREAD_COLOR)
    assert result is not None
    assert result.shape[:2] == scene.shape[:2]


def test_orb_feature_match_maps_rect_roi_to_target_mask(tmp_path: Path) -> None:
    store = make_store(tmp_path)
    scene, template = make_orb_fixture()
    scene_record = store.save("scene.png", encode_png(scene))
    template_record = store.save("template.png", encode_png(template))

    workflow = WorkflowRequest.model_validate(
        {
            "nodes": [
                {"id": "scene", "type": "ReadImage", "params": {"image_id": scene_record.image_id}},
                {"id": "template", "type": "ReadImage", "params": {"image_id": template_record.image_id}},
                {
                    "id": "orb",
                    "type": "ORBFeatureMatch",
                    "params": {
                        "roi_mode": "RECT",
                        "roi_x": 20,
                        "roi_y": 25,
                        "roi_w": 50,
                        "roi_h": 45,
                        "output_mode": "MASK",
                        "min_matches": 6,
                        "n_features": 1500,
                    },
                },
            ],
            "edges": [
                {"source": "scene", "target": "orb", "targetHandle": "in"},
                {"source": "template", "target": "orb", "targetHandle": "template"},
            ],
        }
    )

    result = run_workflow(workflow, store)
    preview = next(item for item in result["previews"] if item["node_id"] == "orb")
    data = result["data"]["orb"]["orb_feature_match"]

    assert result["success"] is True
    assert preview["result_type"] == "image"
    assert preview["metrics"]["transform_found"] is True
    assert data["roi_area"] > 1000
    assert data["roi_bbox"][2] > 20
    assert data["roi_bbox"][3] > 20
    assert data["output_mode"] == "MASK"


def test_orb_feature_match_maps_irregular_mask_input_to_roi(tmp_path: Path) -> None:
    store = make_store(tmp_path)
    scene, template = make_orb_fixture()
    mask = np.zeros(template.shape[:2], dtype=np.uint8)
    cv2.circle(mask, (55, 55), 28, 255, -1)
    cv2.rectangle(mask, (70, 70), (105, 98), 255, -1)
    scene_record = store.save("scene.png", encode_png(scene))
    template_record = store.save("template.png", encode_png(template))
    mask_record = store.save("mask.png", encode_png(mask))

    workflow = WorkflowRequest.model_validate(
        {
            "nodes": [
                {"id": "scene", "type": "ReadImage", "params": {"image_id": scene_record.image_id}},
                {"id": "template", "type": "ReadImage", "params": {"image_id": template_record.image_id}},
                {"id": "mask", "type": "ReadImage", "params": {"image_id": mask_record.image_id}},
                {
                    "id": "orb",
                    "type": "ORBFeatureMatch",
                    "params": {
                        "roi_mode": "MASK",
                        "output_mode": "ROI",
                        "min_matches": 6,
                        "n_features": 1500,
                    },
                },
            ],
            "edges": [
                {"source": "scene", "target": "orb", "targetHandle": "in"},
                {"source": "template", "target": "orb", "targetHandle": "template"},
                {"source": "mask", "target": "orb", "targetHandle": "mask"},
            ],
        }
    )

    result = run_workflow(workflow, store)
    data = result["data"]["orb"]["orb_feature_match"]

    assert result["success"] is True
    assert data["transform_found"] is True
    assert data["roi_mode"] == "MASK"
    assert data["output_mode"] == "ROI"
    assert data["roi_area"] > 2000
    assert len(data["roi_polygon"]) >= 4
