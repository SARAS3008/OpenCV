from pathlib import Path

import cv2
import numpy as np

from backend.models.workflow import WorkflowRequest
from backend.services.image_store import ImageStore
from backend.services.workflow_engine import run_workflow, topological_sort


def make_store(tmp_path: Path) -> ImageStore:
    return ImageStore(tmp_path, {".png", ".jpg", ".jpeg"})


def test_demo_workflow_executes(tmp_path: Path) -> None:
    store = make_store(tmp_path)
    ok, encoded = cv2.imencode(".png", np.full((40, 60, 3), 128, dtype=np.uint8))
    assert ok
    stored = store.save("sample.png", encoded.tobytes())

    workflow = WorkflowRequest.model_validate(
        {
            "image_id": stored.image_id,
            "nodes": [
                {"id": "n1", "type": "ReadImage"},
                {"id": "n2", "type": "Gray"},
                {"id": "n3", "type": "Canny", "params": {"threshold1": 50, "threshold2": 150}},
            ],
            "edges": [
                {"source": "n1", "target": "n2"},
                {"source": "n2", "target": "n3"},
            ],
        }
    )

    result = run_workflow(workflow, store)
    assert result["success"] is True
    assert result["order"] == ["n1", "n2", "n3"]
    assert len(result["previews"]) == 3


def test_cycle_is_rejected() -> None:
    workflow = WorkflowRequest.model_validate(
        {
            "nodes": [
                {"id": "n1", "type": "Gray"},
                {"id": "n2", "type": "Canny"},
            ],
            "edges": [
                {"source": "n1", "target": "n2"},
                {"source": "n2", "target": "n1"},
            ],
        }
    )
    try:
        topological_sort(workflow.nodes, workflow.edges)
    except ValueError as exc:
        assert "存在环" in str(exc)
    else:
        raise AssertionError("应当拒绝环形流程")


def test_metric_operator_returns_numeric_preview_instead_of_image(tmp_path: Path) -> None:
    store = make_store(tmp_path)
    image = np.full((20, 30, 3), 100, dtype=np.uint8)
    ok, encoded = cv2.imencode(".png", image)
    assert ok
    stored = store.save("brightness.png", encoded.tobytes())

    workflow = WorkflowRequest.model_validate(
        {
            "image_id": stored.image_id,
            "nodes": [
                {"id": "n1", "type": "ReadImage"},
                {"id": "n2", "type": "MeanBrightness"},
            ],
            "edges": [{"source": "n1", "target": "n2"}],
        }
    )

    result = run_workflow(workflow, store)
    metric_preview = next(item for item in result["previews"] if item["node_id"] == "n2")

    assert metric_preview["result_type"] == "metrics"
    assert metric_preview["metrics"]["mean_brightness"] == 100.0
    assert metric_preview["metrics"]["brightness_std"] == 0.0
    assert "image" not in metric_preview


def test_image_operator_can_keep_image_preview_while_also_emitting_metrics(tmp_path: Path) -> None:
    store = make_store(tmp_path)
    image = np.zeros((40, 60, 3), dtype=np.uint8)
    cv2.rectangle(image, (10, 10), (35, 30), (255, 255, 255), -1)
    ok, encoded = cv2.imencode(".png", image)
    assert ok
    stored = store.save("contours.png", encoded.tobytes())

    workflow = WorkflowRequest.model_validate(
        {
            "image_id": stored.image_id,
            "nodes": [
                {"id": "n1", "type": "ReadImage"},
                {"id": "n2", "type": "FindContours", "params": {"threshold": 127, "min_area": 5}},
            ],
            "edges": [{"source": "n1", "target": "n2"}],
        }
    )

    result = run_workflow(workflow, store)
    preview = next(item for item in result["previews"] if item["node_id"] == "n2")

    assert preview["result_type"] == "image"
    assert preview["image"].startswith("data:image/png;base64,")
    assert preview["metrics"]["contour_count"] == 1


def test_node_failure_keeps_completed_previews_and_identifies_failed_node(tmp_path: Path) -> None:
    from backend.services.workflow_engine import WorkflowExecutionError

    workflow = WorkflowRequest.model_validate(
        {
            "nodes": [
                {
                    "id": "start",
                    "type": "LogicConstant",
                    "params": {"value_type": "NUMBER", "value": "8"},
                },
                {
                    "id": "broken",
                    "type": "LogicForLoop",
                    "params": {
                        "iterations": 2,
                        "update_operation": "DIVIDE",
                        "step": 0,
                    },
                },
                {
                    "id": "after",
                    "type": "LogicNot",
                },
            ],
            "edges": [
                {"source": "start", "target": "broken", "targetHandle": "in"},
                {"source": "broken", "target": "after", "targetHandle": "in"},
            ],
        }
    )

    try:
        run_workflow(workflow, make_store(tmp_path))
    except WorkflowExecutionError as exc:
        payload = exc.to_response()
    else:
        raise AssertionError("预期节点执行失败")

    assert payload["success"] is False
    assert payload["failed_node"]["node_id"] == "broken"
    assert payload["executed_order"] == ["start"]
    assert payload["pending_nodes"] == ["after"]
    assert payload["previews"][0]["node_id"] == "start"
    assert payload["previews"][-1]["node_id"] == "broken"
    assert payload["previews"][-1]["status"] == "error"
    assert "除数不能为 0" in payload["error"]
