from __future__ import annotations

from pathlib import Path

import cv2
import numpy as np
from fastapi.testclient import TestClient

from backend.main import app
from backend.models.workflow import WorkflowRequest
from backend.services.project_store import ProjectStore
from tests.auth_utils import auth_headers

client = TestClient(app)


def test_workflow_modules_are_preserved_by_schema() -> None:
    workflow = WorkflowRequest.model_validate({
        "version": "2.2",
        "nodes": [{"id": "n1", "type": "ReadImage", "params": {"image_path": ""}}],
        "edges": [],
        "modules": [{"id": "m1", "name": "定位模块", "node_ids": ["n1"], "color": "#526b75"}],
    })
    assert workflow.modules[0].name == "定位模块"
    assert workflow.model_dump()["modules"][0]["node_ids"] == ["n1"]


def test_project_versions_diff_release_and_rollback(tmp_path: Path) -> None:
    store = ProjectStore(tmp_path / "projects")
    wf1 = {"nodes": [{"id": "n1", "type": "ReadImage", "params": {"image_path": "a.png"}}], "edges": [], "modules": []}
    project = store.save_project(workflow=wf1, owner_id="alice", name="版本项目", change_note="初版")
    wf2 = {"nodes": [*wf1["nodes"], {"id": "n2", "type": "Display", "params": {}}], "edges": [{"source": "n1", "target": "n2"}], "modules": [{"id": "m1", "name": "显示模块", "node_ids": ["n1", "n2"]}]}
    store.save_project(workflow=wf2, owner_id="alice", project_id=project["project_id"], name="版本项目", change_note="加入显示")

    versions = store.list_versions(project["project_id"], "alice")
    assert [item["version_id"] for item in versions] == ["v000002", "v000001"]

    diff = store.diff_versions(project["project_id"], "alice", from_version="v000001", to_version="v000002")["diff"]
    assert diff["added_nodes"][0]["id"] == "n2"
    assert diff["added_modules"][0]["name"] == "显示模块"

    released = store.release_version(project["project_id"], "v000002", "alice")
    assert released["released_version_id"] == "v000002"

    rolled = store.rollback_project(project["project_id"], "v000001", "alice")
    assert len(rolled["workflow"]["nodes"]) == 1
    assert rolled["latest_version_id"] == "v000003"


def test_team_dataset_run_history_and_jobs_apis(tmp_path: Path) -> None:
    _user, headers = auth_headers(client, "team-platform-user")
    me = client.get("/api/users/me", headers=headers)
    assert me.status_code == 200
    assert me.json()["user"]["default_workspace_id"]

    dataset = client.post(
        "/api/datasets",
        json={"name": "回归集", "samples": [{"image_path": "", "label": "OK", "expected": {"success": True}}]},
        headers=headers,
    )
    assert dataset.status_code == 200
    dataset_id = dataset.json()["dataset"]["dataset_id"]
    assert client.get("/api/datasets", headers=headers).json()["datasets"][0]["sample_count"] >= 1

    # 异步任务接口至少应能创建和查询任务。使用空流程避免依赖外部图片。
    job = client.post("/api/jobs/run", json={"workflow": {"nodes": [], "edges": [], "modules": []}}, headers=headers)
    assert job.status_code == 200
    job_id = job.json()["job"]["job_id"]
    fetched = client.get(f"/api/jobs/{job_id}", headers=headers)
    assert fetched.status_code == 200
    assert fetched.json()["job"]["status"] in {"queued", "running", "success", "failed"}

    runs = client.get("/api/runs", headers=headers)
    assert runs.status_code == 200
    assert "runs" in runs.json()


def test_model_asset_metadata_endpoint(tmp_path: Path) -> None:
    user, headers = auth_headers(client, "asset-user")
    path = tmp_path / "fake.pt"
    path.write_bytes(b"fake")
    model = app.state.model_manager.register_upload(path=path, original_filename="detector.pt", owner_id=user["user_id"], workspace_id=user["default_workspace_id"], size=4)
    updated = client.patch(
        f"/api/models/{model['model_id']}",
        json={"asset_name": "surface-detector", "model_version": "v2.1", "status": "released", "class_names": ["scratch"]},
        headers=headers,
    )
    assert updated.status_code == 200
    assert updated.json()["model"]["asset_name"] == "surface-detector"
    assets = client.get("/api/models/assets", headers=headers)
    assert any(item["asset_name"] == "surface-detector" for item in assets.json()["assets"])
