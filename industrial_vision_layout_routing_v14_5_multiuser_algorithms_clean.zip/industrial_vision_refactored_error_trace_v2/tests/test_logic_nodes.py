from pathlib import Path
import subprocess
import sys

import cv2
import numpy as np
from fastapi.testclient import TestClient

from backend.main import app
from backend.models.workflow import WorkflowRequest
from backend.services.image_store import ImageStore
from backend.services.script_exporter import generate_algorithm_script
from backend.services.workflow_engine import run_workflow
from tests.auth_utils import auth_headers


client = TestClient(app)
_, AUTH_HEADERS = auth_headers(client, "logic")


def make_store(tmp_path: Path) -> ImageStore:
    return ImageStore(tmp_path, {".png", ".jpg", ".jpeg"})


def test_logic_catalog_is_exposed() -> None:
    response = client.get("/api/operators", headers=AUTH_HEADERS)
    assert response.status_code == 200
    payload = response.json()
    assert "逻辑" in payload["catalog"]
    types = {
        type_name
        for group in payload["catalog"]["逻辑"]
        for type_name in group["items"]
    }
    assert {
        "LogicConstant",
        "LogicCompare",
        "LogicBoolean",
        "LogicNot",
        "LogicIfElse",
        "LogicForLoop",
        "LogicWhileLoop",
    }.issubset(types)


def test_if_else_selects_scalar_value() -> None:
    workflow = WorkflowRequest.model_validate(
        {
            "nodes": [
                {"id": "a", "type": "LogicConstant", "params": {"value_type": "NUMBER", "value": "2"}},
                {"id": "b", "type": "LogicConstant", "params": {"value_type": "NUMBER", "value": "3"}},
                {"id": "compare", "type": "LogicCompare", "params": {"operator": "GT"}},
                {"id": "yes", "type": "LogicConstant", "params": {"value_type": "TEXT", "value": "IF"}},
                {"id": "no", "type": "LogicConstant", "params": {"value_type": "TEXT", "value": "ELSE"}},
                {"id": "select", "type": "LogicIfElse"},
            ],
            "edges": [
                {"source": "a", "target": "compare", "targetHandle": "a"},
                {"source": "b", "target": "compare", "targetHandle": "b"},
                {"source": "compare", "target": "select", "targetHandle": "condition"},
                {"source": "yes", "target": "select", "targetHandle": "true_value"},
                {"source": "no", "target": "select", "targetHandle": "false_value"},
            ],
        }
    )
    result = run_workflow(workflow, make_store(Path("/tmp")))
    preview = next(item for item in result["previews"] if item["node_id"] == "select")
    assert preview["result_type"] == "metrics"
    assert preview["metrics"]["condition"] is False
    assert preview["metrics"]["branch"] == "else"
    assert preview["metrics"]["result"] == "ELSE"


def test_for_and_while_loops_execute_with_safety_limits(tmp_path: Path) -> None:
    workflow = WorkflowRequest.model_validate(
        {
            "nodes": [
                {"id": "start", "type": "LogicConstant", "params": {"value_type": "NUMBER", "value": "1"}},
                {
                    "id": "for",
                    "type": "LogicForLoop",
                    "params": {"iterations": 4, "update_operation": "ADD", "step": 2},
                },
                {
                    "id": "while",
                    "type": "LogicWhileLoop",
                    "params": {
                        "compare_operator": "LT",
                        "compare_value": 15,
                        "update_operation": "ADD",
                        "step": 1,
                        "max_iterations": 20,
                    },
                },
            ],
            "edges": [
                {"source": "start", "target": "for", "targetHandle": "in"},
                {"source": "for", "target": "while", "targetHandle": "in"},
            ],
        }
    )
    result = run_workflow(workflow, make_store(tmp_path))
    for_preview = next(item for item in result["previews"] if item["node_id"] == "for")
    while_preview = next(item for item in result["previews"] if item["node_id"] == "while")
    assert for_preview["metrics"]["final"] == 9
    assert while_preview["metrics"]["final"] == 15
    assert while_preview["metrics"]["iterations"] == 6
    assert while_preview["metrics"]["hit_max_iterations"] is False


def test_if_else_can_select_between_image_results(tmp_path: Path) -> None:
    store = make_store(tmp_path)
    image = np.zeros((24, 32, 3), dtype=np.uint8)
    image[:, :16] = (20, 40, 80)
    ok, encoded = cv2.imencode(".png", image)
    assert ok
    stored = store.save("source.png", encoded.tobytes())

    workflow = WorkflowRequest.model_validate(
        {
            "image_id": stored.image_id,
            "nodes": [
                {"id": "read", "type": "ReadImage"},
                {"id": "invert", "type": "Invert"},
                {"id": "condition", "type": "LogicConstant", "params": {"value_type": "BOOLEAN", "value": "true"}},
                {"id": "select", "type": "LogicIfElse"},
            ],
            "edges": [
                {"source": "read", "target": "invert"},
                {"source": "condition", "target": "select", "targetHandle": "condition"},
                {"source": "invert", "target": "select", "targetHandle": "true_value"},
                {"source": "read", "target": "select", "targetHandle": "false_value"},
            ],
        }
    )
    result = run_workflow(workflow, store)
    preview = next(item for item in result["previews"] if item["node_id"] == "select")
    assert preview["result_type"] == "image"
    assert preview["image"].startswith("data:image/png;base64,")
    assert preview["metrics"]["branch"] == "if"


def test_logic_nodes_export_as_plain_python_control_flow(tmp_path: Path) -> None:
    workflow = WorkflowRequest.model_validate(
        {
            "nodes": [
                {"id": "read", "type": "ReadImage"},
                {"id": "invert", "type": "Invert"},
                {"id": "condition", "type": "LogicConstant", "params": {"value_type": "BOOLEAN", "value": "true"}},
                {"id": "select", "type": "LogicIfElse"},
            ],
            "edges": [
                {"source": "read", "target": "invert"},
                {"source": "condition", "target": "select", "targetHandle": "condition"},
                {"source": "invert", "target": "select", "targetHandle": "true_value"},
                {"source": "read", "target": "select", "targetHandle": "false_value"},
            ],
        }
    )
    source = generate_algorithm_script(workflow)
    assert " if bool(" in source
    assert "WORKFLOW" not in source
    script = tmp_path / "logic_algorithm.py"
    script.write_text(source, encoding="utf-8")
    input_path = tmp_path / "input.png"
    output_path = tmp_path / "result.png"
    image = np.full((20, 30, 3), 25, dtype=np.uint8)
    assert cv2.imwrite(str(input_path), image)
    subprocess.run(
        [sys.executable, str(script), "--input", str(input_path), "--output", str(output_path)],
        cwd=tmp_path,
        check=True,
    )
    result = cv2.imread(str(output_path), cv2.IMREAD_COLOR)
    assert result is not None
    assert int(result[0, 0, 0]) == 230


def test_for_and_while_export_to_real_python_loops() -> None:
    workflow = WorkflowRequest.model_validate(
        {
            "nodes": [
                {"id": "read", "type": "ReadImage"},
                {"id": "start", "type": "LogicConstant", "params": {"value_type": "NUMBER", "value": "1"}},
                {"id": "for", "type": "LogicForLoop", "params": {"iterations": 3, "update_operation": "ADD", "step": 2}},
                {"id": "while", "type": "LogicWhileLoop", "params": {"compare_operator": "LT", "compare_value": 10, "update_operation": "ADD", "step": 1, "max_iterations": 20}},
            ],
            "edges": [
                {"source": "start", "target": "for", "targetHandle": "in"},
                {"source": "for", "target": "while", "targetHandle": "in"},
            ],
        }
    )
    source = generate_algorithm_script(workflow)
    assert "for _ in range(3)" in source
    assert "while " in source
    namespace: dict[str, object] = {}
    exec(compile(source, "vision_algorithm.py", "exec"), namespace)
    result = namespace["run_algorithm"](np.zeros((2, 2, 3), dtype=np.uint8))
    assert isinstance(result, dict)
    assert result["while"] == 10


def test_run_api_returns_partial_results_on_node_failure() -> None:
    response = client.post(
        "/api/run",
        headers=AUTH_HEADERS,
        json={
            "nodes": [
                {
                    "id": "start",
                    "type": "LogicConstant",
                    "params": {"value_type": "NUMBER", "value": "8"},
                },
                {
                    "id": "broken",
                    "type": "LogicForLoop",
                    "params": {
                        "iterations": 2,
                        "update_operation": "DIVIDE",
                        "step": 0,
                    },
                },
            ],
            "edges": [
                {"source": "start", "target": "broken", "targetHandle": "in"},
            ],
        },
    )
    assert response.status_code == 400
    payload = response.json()
    assert payload["success"] is False
    assert payload["failed_node"]["node_id"] == "broken"
    assert payload["executed_order"] == ["start"]
    assert payload["previews"][0]["node_id"] == "start"
    assert payload["previews"][-1]["result_type"] == "error"


def test_image_connected_to_numeric_compare_returns_partial_json_error(tmp_path: Path) -> None:
    store = make_store(tmp_path)
    image = np.full((24, 32, 3), 100, dtype=np.uint8)
    ok, encoded = cv2.imencode('.png', image)
    assert ok
    stored = store.save('invalid_compare.png', encoded.tobytes())

    workflow = WorkflowRequest.model_validate(
        {
            'image_id': stored.image_id,
            'nodes': [
                {'id': 'read', 'type': 'ReadImage'},
                {'id': 'brightness', 'type': 'MeanBrightness'},
                {'id': 'limit', 'type': 'LogicConstant', 'params': {'value_type': 'NUMBER', 'value': '4'}},
                {'id': 'compare', 'type': 'LogicCompare', 'params': {'operator': 'GT'}},
            ],
            'edges': [
                {'source': 'read', 'target': 'brightness'},
                {'source': 'brightness', 'sourceHandle': 'out', 'target': 'compare', 'targetHandle': 'a'},
                {'source': 'limit', 'target': 'compare', 'targetHandle': 'b'},
            ],
        }
    )

    from backend.services.workflow_engine import WorkflowExecutionError

    try:
        run_workflow(workflow, store)
    except WorkflowExecutionError as exc:
        payload = exc.to_response()
    else:
        raise AssertionError('图像连接到数值比较时应当在比较节点报错')

    assert payload['failed_node']['node_id'] == 'compare'
    assert payload['executed_order'] == ['read', 'limit', 'brightness']
    assert [item['node_id'] for item in payload['previews'][:-1]] == ['read', 'limit', 'brightness']
    assert payload['previews'][0]['image'].startswith('data:image/png;base64,')
    assert payload['previews'][-1]['status'] == 'error'
    assert '图像/数组数据' in payload['error']


def test_mean_brightness_numeric_output_can_feed_compare(tmp_path: Path) -> None:
    store = make_store(tmp_path)
    image = np.full((24, 32, 3), 100, dtype=np.uint8)
    ok, encoded = cv2.imencode('.png', image)
    assert ok
    stored = store.save('valid_compare.png', encoded.tobytes())

    workflow = WorkflowRequest.model_validate(
        {
            'image_id': stored.image_id,
            'nodes': [
                {'id': 'read', 'type': 'ReadImage'},
                {'id': 'brightness', 'type': 'MeanBrightness'},
                {'id': 'limit', 'type': 'LogicConstant', 'params': {'value_type': 'NUMBER', 'value': '4'}},
                {'id': 'compare', 'type': 'LogicCompare', 'params': {'operator': 'GT'}},
            ],
            'edges': [
                {'source': 'read', 'target': 'brightness'},
                {'source': 'brightness', 'sourceHandle': 'mean_brightness', 'target': 'compare', 'targetHandle': 'a'},
                {'source': 'limit', 'target': 'compare', 'targetHandle': 'b'},
            ],
        }
    )

    result = run_workflow(workflow, store)
    preview = next(item for item in result['previews'] if item['node_id'] == 'compare')
    assert preview['metrics']['left'] == 100.0
    assert preview['metrics']['right'] == 4
    assert preview['metrics']['result'] is True


def test_run_api_returns_json_for_image_to_numeric_type_error(tmp_path: Path) -> None:
    image_path = tmp_path / 'api_invalid_compare.png'
    assert cv2.imwrite(str(image_path), np.full((20, 20, 3), 80, dtype=np.uint8))
    response = client.post(
        '/api/run',
        headers=AUTH_HEADERS,
        json={
            'nodes': [
                {'id': 'read', 'type': 'ReadImage', 'params': {'image_path': str(image_path)}},
                {'id': 'brightness', 'type': 'MeanBrightness'},
                {'id': 'limit', 'type': 'LogicConstant', 'params': {'value_type': 'NUMBER', 'value': '4'}},
                {'id': 'compare', 'type': 'LogicCompare', 'params': {'operator': 'GT'}},
            ],
            'edges': [
                {'source': 'read', 'target': 'brightness'},
                {'source': 'brightness', 'sourceHandle': 'out', 'target': 'compare', 'targetHandle': 'a'},
                {'source': 'limit', 'target': 'compare', 'targetHandle': 'b'},
            ],
        },
    )
    assert response.status_code == 400
    assert response.headers['content-type'].startswith('application/json')
    payload = response.json()
    assert payload['failed_node']['node_id'] == 'compare'
    assert payload['previews'][0]['node_id'] == 'read'
    assert payload['previews'][-1]['status'] == 'error'


def test_if_else_skips_unselected_branch(tmp_path: Path) -> None:
    workflow = WorkflowRequest.model_validate(
        {
            "nodes": [
                {"id": "condition", "type": "LogicConstant", "params": {"value_type": "BOOLEAN", "value": "false"}},
                {"id": "broken", "type": "LogicForLoop", "params": {"iterations": 1, "update_operation": "DIVIDE", "step": 0}},
                {"id": "safe", "type": "LogicConstant", "params": {"value_type": "TEXT", "value": "ELSE"}},
                {"id": "select", "type": "LogicIfElse"},
            ],
            "edges": [
                {"source": "condition", "target": "select", "targetHandle": "condition"},
                {"source": "broken", "target": "select", "targetHandle": "true_value"},
                {"source": "safe", "target": "select", "targetHandle": "false_value"},
            ],
        }
    )
    result = run_workflow(workflow, make_store(tmp_path))
    preview_ids = [item["node_id"] for item in result["previews"]]
    assert "broken" not in preview_ids
    select_preview = next(item for item in result["previews"] if item["node_id"] == "select")
    assert select_preview["metrics"]["branch"] == "else"
    assert select_preview["metrics"]["result"] == "ELSE"


def test_operator_api_exposes_plugin_error_list() -> None:
    payload = client.get("/api/operators", headers=AUTH_HEADERS).json()
    assert "plugin_errors" in payload
    assert isinstance(payload["plugin_errors"], list)
