from __future__ import annotations

import numpy as np

from backend.algorithms.image import op_threshold as exported_threshold
from backend.algorithms.image.thresholding import op_threshold as module_threshold
from backend.algorithms.registry import OPERATORS


def test_image_operator_package_exports_match_module_implementation():
    assert module_threshold is exported_threshold
    assert OPERATORS["Threshold"] is exported_threshold


def test_split_threshold_operator_still_runs():
    image = np.array([[0, 100, 200]], dtype=np.uint8)
    result = module_threshold({"in": image}, {"threshold": 127, "max_value": 255}, None)
    assert result["out"].tolist() == [[0, 0, 255]]
