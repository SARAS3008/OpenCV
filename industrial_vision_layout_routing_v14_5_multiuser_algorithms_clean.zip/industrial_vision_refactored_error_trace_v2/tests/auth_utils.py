from __future__ import annotations

import uuid


def auth_headers(client, prefix: str = "pytest"):
    safe_prefix = "".join(ch if ch.isalnum() or ch in "-_" else "-" for ch in prefix.lower())[:32] or "pytest"
    email = f"{safe_prefix}-{uuid.uuid4().hex[:12]}@example.com"
    response = client.post(
        "/api/auth/register",
        json={"email": email, "password": "secret123", "display_name": prefix},
    )
    assert response.status_code == 200, response.text
    data = response.json()
    user = data["user"]
    headers = {"Authorization": f"Bearer {data['token']}", "X-Workspace-Id": user["default_workspace_id"]}
    return user, headers
