"""下载 Ultralytics YOLOv8n COCO 预训练检测模型到 models/uploads/yolov8n.pt。"""
from __future__ import annotations

import urllib.request
from pathlib import Path

MODEL_URL = "https://github.com/ultralytics/assets/releases/download/v8.3.0/yolov8n.pt"
PROJECT_ROOT = Path(__file__).resolve().parents[1]
TARGET = PROJECT_ROOT / "models" / "uploads" / "yolov8n.pt"


def main() -> None:
    TARGET.parent.mkdir(parents=True, exist_ok=True)
    if TARGET.exists() and TARGET.stat().st_size > 0:
        print(f"模型已存在：{TARGET}")
        return
    print(f"正在下载：{MODEL_URL}")
    urllib.request.urlretrieve(MODEL_URL, TARGET)
    print(f"完成：{TARGET}")


if __name__ == "__main__":
    main()
