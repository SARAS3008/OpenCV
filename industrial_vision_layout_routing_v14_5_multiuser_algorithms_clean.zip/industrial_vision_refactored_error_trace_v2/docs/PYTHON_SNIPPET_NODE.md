# Python代码片段节点

`PythonSnippet` 用于在工作流中插入自定义 Python 代码。它适合做快速验证、特殊后处理、临时指标计算、图像数组变换、结构化数据清洗等不值得单独开发成正式算子的逻辑。

## 节点位置

- 逻辑节点库
- 脚本扩展
- Python代码片段

## 输入端口

| 端口 | 类型 | 必填 | 说明 |
|---|---|---:|---|
| `in` | any | 否 | 主输入，通常是图像；代码里可通过 `inputs['in']` 或 `image` 访问。 |
| `aux` | any | 否 | 辅助输入，可接第二张图、mask、数值或对象。 |
| `value` | any | 否 | 数值/对象输入，适合接逻辑常量、检测数量、ROI 信息等。 |

## 输出端口

| 端口 | 类型 | 说明 |
|---|---|---|
| `out` | any | 主输出；后续节点默认接这个端口。 |
| `image` | image | 图像输出；当脚本返回图像时会自动补齐。 |
| `value` | any | 数值/对象输出；当脚本返回标量时会自动补齐。 |
| `data` | object | 结构化数据输出。 |

## 代码写法一：直接赋值

```python
# image 等价于 inputs.get('in')
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
out = cv2.Canny(gray, 50, 150)
metrics = {
    'edge_pixels': int(np.count_nonzero(out)),
}
data = {
    'shape': list(out.shape),
}
```

节点会自动收集 `out`、`image`、`value`、`metrics`、`data` 这些变量。

## 代码写法二：定义 process 函数

```python
def process(inputs, params, context):
    img = inputs.get('in')
    mask = inputs.get('aux')
    if mask is None:
        return {'out': img, 'metrics': {'used_mask': False}}
    masked = cv2.bitwise_and(img, img, mask=mask)
    return {
        'out': masked,
        'image': masked,
        'metrics': {'used_mask': True},
    }
```

如果定义了 `process(inputs, params, context)`，它的返回值优先作为节点输出。

## 可用对象

代码片段内置以下对象：

- `inputs`：输入端口字典。
- `params`：节点参数字典，不包含代码本身。
- `context`：运行上下文摘要，包括 `image_id`、`batch_index`、`batch_total`、`current_image_path`、`user_id` 等。
- `image`：`inputs.get('in')` 的快捷变量。
- `aux`：`inputs.get('aux')` 的快捷变量。
- `value`：`inputs.get('value')` 的快捷变量。
- `np`：NumPy。
- `cv2`：OpenCV。
- `math`、`statistics`、`json`。

## 安全限制

节点默认在子进程中隔离执行，并带超时保护。代码片段会拒绝以下高风险语法或调用：

- `import` / `from import`
- `open`
- `eval`
- `exec`
- `compile`
- `__import__`
- 访问双下划线名称或属性
- `class`、`with`、`try`、`global`、`nonlocal` 等复杂语法

这些限制不是完整安全沙箱，但能避免多数误操作和高风险片段。多人部署时仍建议只开放给可信用户。

## 参数

| 参数 | 默认值 | 说明 |
|---|---:|---|
| `code` | 示例代码 | 自定义 Python 片段。 |
| `timeout_ms` | `1000` | 执行超时，范围 50 到 30000 毫秒。 |
| `isolated` | `YES` | 是否在子进程中隔离执行。建议保持开启。 |
| `output_kind` | `AUTO` | 独立脚本导出时用于判断 `out` 端口类型。 |
| `output_color_space` | `AUTO` | 当 `out` / `image` 是图像时，指定颜色空间。 |

## 独立脚本导出

`PythonSnippet` 已支持独立算法脚本导出。导出脚本中会嵌入用户代码，并在运行时执行。若后续节点需要把 `out` 当图像处理，建议把 `output_kind` 设为 `IMAGE`；若后续节点需要把 `out` 当逻辑值或数值使用，建议显式连接 `value` 端口。
