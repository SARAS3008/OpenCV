# 团队级图像开发平台能力说明

本版本在原有节点式工业视觉流程编排器基础上，补齐了团队主流程开发需要的核心能力，并新增“功能模块”用于管理复杂工作流。

## 1. 用户与工作区

当前采用轻量 header 识别用户：

- `X-User-Id`
- `X-User-Email`

新增接口：

- `GET /api/users/me`
- `GET /api/workspaces`
- `POST /api/workspaces`

说明：目前没有引入真实登录系统，数据模型已按团队/工作区设计，后续可替换为 OAuth、LDAP 或企业 SSO。

## 2. 项目版本历史、差异对比、发布与回滚

项目保存现在会自动生成版本快照。

新增接口：

- `GET /api/projects/{project_id}/versions`
- `GET /api/projects/{project_id}/versions/{version_id}`
- `GET /api/projects/{project_id}/diff?from_version=v000001&to_version=v000002`
- `POST /api/projects/{project_id}/rollback/{version_id}`
- `POST /api/projects/{project_id}/release/{version_id}`

版本差异会统计：

- 新增/删除节点
- 节点类型、参数、位置、颜色变化
- 新增/删除连线
- 新增/删除/修改功能模块

## 3. 数据集管理

新增文件系统数据集管理，用于保存回归样本、标签、期望结果和样本元数据。

新增接口：

- `GET /api/datasets`
- `POST /api/datasets`
- `GET /api/datasets/{dataset_id}`
- `PUT /api/datasets/{dataset_id}`
- `POST /api/datasets/{dataset_id}/samples`
- `DELETE /api/datasets/{dataset_id}`

样本结构示例：

```json
{
  "image_path": "samples/ok/001.png",
  "label": "OK",
  "tags": ["low-light", "line-a"],
  "expected": {
    "success": true,
    "metrics": {
      "defect_count": 0
    }
  }
}
```

## 4. 图像算法回归测试报告

新增接口：

- `POST /api/regression-tests/run`
- `POST /api/regression-tests/jobs`

回归测试会将数据集中的每张图依次写入第一个 `ReadImage` 节点，运行指定项目/版本的工作流，并与样本 `expected` 做比较。

报告包含：

- 总样本数
- 通过数
- 失败数
- 错误数
- 通过率
- 单样本耗时
- 失败/错误样本列表

## 5. 运行历史与结果归档

每次 `/api/run` 或异步任务运行后会保存运行记录。

新增接口：

- `GET /api/runs`
- `GET /api/runs/{run_id}`

为了避免历史记录过大，运行记录会压缩预览图，只保存节点结果摘要、metrics、批处理摘要、错误信息和工作流快照。

## 6. 模型资产版本管理

已有模型上传/缓存功能继续保留，本版本新增逻辑模型资产字段：

- `asset_name`
- `model_version`
- `status`
- `task`
- `class_names`
- `metrics`
- `notes`
- `project_ids`
- `dataset_id`

新增接口：

- `GET /api/models/assets`
- `PATCH /api/models/{model_id}`

一个模型资产可以包含多个上传版本，可用于后续发布、锁定、回滚和兼容性检查。

## 7. 异步任务队列

新增进程内任务队列，避免长耗时工作流阻塞前端请求。

新增接口：

- `POST /api/jobs/run`
- `GET /api/jobs`
- `GET /api/jobs/{job_id}`

当前为 `ThreadPoolExecutor` 实现，生产部署可替换为 Celery/RQ/Dramatiq + Redis。

## 8. 工作流功能模块

前端新增“创建模块”功能。它可以把多个节点聚合为一个命名模块，用于降低复杂工作流的视觉和逻辑混乱。

使用方式：

1. 选中某个节点。
2. 点击画布顶部 `▦ 创建模块`，或节点工具条中的 `▦`。
3. 在弹窗中输入节点 ID 列表；留空时默认使用“当前节点及其所有上游节点”。
4. 输入模块名称。
5. 画布上会出现模块框，包住这些节点。

模块数据会保存到工作流 JSON：

```json
{
  "modules": [
    {
      "id": "m1",
      "name": "定位与ROI提取",
      "node_ids": ["n1", "n2", "n3"],
      "description": "模板匹配后映射ROI",
      "color": "#526b75",
      "collapsed": false
    }
  ]
}
```

注意：模块目前不改变工作流执行语义，只是大型流程的结构化分组。后续可继续升级为“可复用子流程/宏节点”。

## 推荐后续升级

这个版本完成的是团队平台的 MVP 骨架。若要生产化部署，建议继续推进：

- 接入真实身份认证和权限系统。
- 将文件系统存储替换为数据库和对象存储。
- 将进程内任务队列替换为 Redis/Celery/RQ。
- 增加工作流评审和审批流程。
- 将功能模块升级为可复用子流程节点。
- 增加模型与工作流的兼容性检查。
