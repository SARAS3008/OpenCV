# 多用户登录、工作区权限与资源隔离

本版本把原来的轻量 `X-User-Id` 隔离升级为可长期多人使用的基础平台能力。

## 核心概念

```text
User
  └── Workspace
        ├── Projects
        ├── Models
        ├── Datasets
        ├── Runs
        └── Jobs
```

工作区是项目、模型、数据集、运行历史和异步任务的隔离边界。同一工作区内的成员可以按角色共享资源；不同工作区之间默认互不可见。

## 登录与会话

新增接口：

```text
POST /api/auth/register
POST /api/auth/login
POST /api/auth/logout
GET  /api/auth/session
```

登录成功后返回 Bearer Token。前端会自动保存 token，并在后续请求中加入：

```text
Authorization: Bearer <token>
X-Workspace-Id: <current_workspace_id>
```

为了兼容旧版本地工具，后端仍支持未登录状态下使用 `X-User-Id` / `X-User-Email`，但正式多人使用建议登录。

## 工作区与角色

新增/增强接口：

```text
GET    /api/users/me
GET    /api/workspaces
POST   /api/workspaces
GET    /api/workspaces/{workspace_id}
POST   /api/workspaces/{workspace_id}/members
DELETE /api/workspaces/{workspace_id}/members/{member_user_id}
```

角色权限：

| 角色 | 查看 | 编辑 | 运行 | 模型 | 发布/管理 | 成员管理 | 删除 |
|---|---:|---:|---:|---:|---:|---:|---:|
| Owner | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| Maintainer | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |  |
| Developer | ✓ | ✓ | ✓ | ✓ |  |  |  |
| Reviewer | ✓ |  | ✓ |  |  |  |  |
| Viewer | ✓ |  |  |  |  |  |  |
| Operator | ✓ |  | ✓ |  |  |  |  |

## 项目隔离

以下接口现在按当前工作区隔离：

```text
GET    /api/projects
POST   /api/projects
GET    /api/projects/{project_id}
DELETE /api/projects/{project_id}
GET    /api/projects/{project_id}/versions
GET    /api/projects/{project_id}/diff
POST   /api/projects/{project_id}/rollback/{version_id}
POST   /api/projects/{project_id}/release/{version_id}
```

用户只能看到当前工作区内的项目。工作区外用户即使知道 `project_id`，也无法读取、修改或删除。

## 模型隔离

以下接口现在按当前工作区隔离：

```text
GET    /api/models
GET    /api/models/assets
PATCH  /api/models/{model_id}
DELETE /api/models/{model_id}
POST   /api/upload-model
POST   /api/models/cache/clear
```

上传模型时会记录：

```json
{
  "owner_id": "上传者用户ID",
  "workspace_id": "所属工作区ID"
}
```

YOLO 节点运行时会按当前执行上下文的 `workspace_id` 校验模型权限。已注册模型如果属于其他工作区，会被拒绝使用。

## 在线用户

新增接口：

```text
POST /api/presence/heartbeat
GET  /api/workspaces/{workspace_id}/presence
```

前端每 10 秒发送一次心跳，顶部会显示当前工作区在线人数。鼠标悬停可看到在线成员名称。

## 前端新增交互

顶部栏新增：

- 登录/注册入口
- 当前工作区下拉选择
- 创建工作区
- 邀请成员
- 当前工作区在线用户数量
- 退出登录

切换工作区后，项目列表、模型列表、数据集、运行历史和任务列表都会切换到对应工作区作用域。

## 当前实现说明

当前版本使用文件系统保存用户、会话、工作区、项目和模型元数据，适合内网、小团队和原型部署。正式生产部署时建议进一步升级：

```text
1. 用户与会话迁移到数据库
2. 接入企业 SSO / LDAP / OAuth
3. 项目、模型、运行历史迁移到 PostgreSQL
4. 在线状态迁移到 Redis
5. 异步任务队列迁移到 Redis + Celery/RQ
6. 上传文件迁移到对象存储或受控文件服务
```
