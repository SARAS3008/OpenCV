# v14.3 工作流结构树层级规则优化

本版本修复了工作流结构树中“普通执行依赖被误显示成父子层级”的问题。

## 主要变化

### 1. 普通节点不再因为连线缩进

普通图像处理链路：

```text
ReadImage → ColorConvert → GaussianBlur → Canny
```

现在在结构树中会保持同级对齐，只通过 `#1 / #2 / #3` 表示执行顺序，不再显示成一层套一层。

### 2. 模块才形成包含层级

模块是工作流的组织单元，因此模块下面的节点会显示为模块子节点：

```text
工作流名称
  模块 A
    #1 节点
    #2 节点
  模块 B
    #3 节点
    #4 节点
```

同一个模块内的同级节点会保持对齐。

### 3. If / Else 分支形成逻辑层级

`LogicIfElse` 的 `true_value` 和 `false_value` 输入代表逻辑分支，因此会在结构树中显示为：

```text
#5 If / Else 选择
  If 分支
    #3 true_value 来源节点
  Else 分支
    #4 false_value 来源节点
```

只有这类明确的逻辑关系才会产生上下级缩进。

### 4. 结构树说明文字更新

根节点统计信息现在提示：

```text
普通连线仅排序，模块/If 才形成层级
```

避免误解结构树中的层级含义。

## 修改文件

```text
frontend/assets/js/app/actions.js
frontend/assets/css/styles.css
```
