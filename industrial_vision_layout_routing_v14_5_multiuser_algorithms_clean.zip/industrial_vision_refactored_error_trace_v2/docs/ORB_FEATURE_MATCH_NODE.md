# ORB角点ROI/Mask匹配算子

节点类型：`ORBFeatureMatch`，位于图像节点库的“模板匹配”分组。

## 典型用途

用于模板定位后提取目标区域：给定一张待检测图、一张模板图，以及模板图上的矩形 ROI 或不规则 mask，节点会先用 ORB 角点、Hamming BFMatcher、Lowe ratio test 与 RANSAC 估计模板到待检测图的变换矩阵，然后把模板侧 ROI/mask 映射到待检测图，直接输出目标图上的 ROI、mask 或抠图结果。

这适合以下场景：

- 在模板图上圈定一个检测区域，运行时自动找到待检测图中的对应区域；
- 模板目标有旋转、平移、缩放或轻微透视变化；
- 需要把不规则 mask 映射到待检测图，用于后续测量、缺陷检测、裁剪或分割。

## 输入端口

- `in`：待检测图，必填。
- `template`：模板图，可选。若不连接该端口，则需要填写参数 `template_path`。
- `mask`：模板侧不规则 mask，可选。仅当 `roi_mode=MASK` 时使用；若不连接该端口，则需要填写参数 `mask_path`。

## 输出端口

- `out`：直接输出端口，由 `output_mode` 决定，可输出全图 mask、裁剪 ROI、裁剪 mask、全图抠图或诊断标注图。
- `mask`：映射到待检测图坐标系的全图二值 mask，尺寸与待检测图一致。
- `roi`：根据映射后 mask 外接框裁剪出的 ROI 图像；默认会应用不规则 mask。
- `roi_mask`：裁剪 ROI 对应的局部二值 mask。
- `masked`：待检测图中仅保留映射 mask 区域的全图抠图结果。
- `annotated`：诊断标注图，包含模板四角、ROI/mask 轮廓、外接框和匹配点。
- `matches`：模板图与待检测图的匹配连线图。
- `match_count`：原始 KNN 匹配数量。
- `good_match_count`：通过 Lowe ratio test 的优质匹配数量。
- `inlier_count`：RANSAC 内点数量。
- `confidence`：综合匹配质量评分，范围约为 0 到 1。
- `homography_found` / `transform_found`：是否成功定位并估计变换。
- `corners`：模板四角映射到待检测图中的坐标。
- `roi_bbox`：映射后 ROI/mask 的外接框 `[x, y, w, h]`。
- `roi_polygon`：映射后 ROI/mask 的近似轮廓点。
- `homography`：3x3 单应矩阵；仿射模式下也会返回由 2x3 仿射矩阵补齐得到的 3x3 矩阵。
- `affine`：仿射模式下的 2x3 仿射矩阵。

## 关键参数

### 模板与 ROI/mask

- `template_path`：模板图片路径；未连接 `template` 端口时使用。
- `roi_mode`：模板侧 ROI 来源：
  - `FULL`：整个模板区域；
  - `RECT`：通过 `roi_x`、`roi_y`、`roi_w`、`roi_h` 指定矩形 ROI；
  - `MASK`：通过 `mask` 输入端口或 `mask_path` 指定不规则二值 mask。
- `roi_x` / `roi_y` / `roi_w` / `roi_h`：矩形 ROI 参数，坐标基于模板图。
- `mask_path`：模板侧 mask 图片路径；`roi_mode=MASK` 且未连接 `mask` 端口时使用。
- `mask_threshold`：mask 二值化阈值，大于该值的像素视为有效区域。
- `output_mode`：决定 `out` 端口直接输出什么：
  - `MASK`：全图二值 mask；
  - `MASKED`：全图抠图；
  - `ROI`：裁剪 ROI；
  - `ROI_MASK`：裁剪 mask；
  - `ANNOTATED`：诊断标注图。
- `crop_apply_mask`：输出 `roi` 时是否应用不规则 mask。选择 `NO` 时只裁剪外接框。

### ORB 与变换估计

- `transform_model`：变换模型：
  - `HOMOGRAPHY`：透视单应性，适合平面目标或有透视变化的场景；
  - `AFFINE`：完整仿射矩阵；
  - `AFFINE_PARTIAL`：相似/部分仿射，适合旋转、平移、尺度变化较稳定的场景。
- `n_features`：ORB 提取的最大特征数。
- `scale_factor`：ORB 图像金字塔缩放系数。
- `n_levels`：ORB 金字塔层数。
- `fast_threshold`：FAST 角点阈值。
- `ratio_test`：Lowe ratio 阈值，常用 0.7 到 0.8。
- `min_matches`：估计变换矩阵所需的最少优质匹配数量。
- `ransac_reproj_threshold`：RANSAC 重投影误差阈值，单位像素。
- `max_draw_matches`：匹配连线图最多绘制的优质匹配数量。

## 推荐工作流

### 矩形 ROI

1. `ReadImage` 读取待检测图，连接到 `ORBFeatureMatch.in`。
2. `ReadImage` 读取模板图，连接到 `ORBFeatureMatch.template`。
3. 设置 `roi_mode=RECT`，填写 `roi_x`、`roi_y`、`roi_w`、`roi_h`。
4. 设置 `output_mode=MASK`、`MASKED` 或 `ROI`。
5. 将 `mask`、`masked` 或 `roi` 输出端口连接到后续检测/测量节点。

### 不规则 mask

1. 在模板图坐标系中制作一张同尺寸二值 mask，白色为有效区域，黑色为忽略区域。
2. 将 mask 作为第三个 `ReadImage` 节点连接到 `ORBFeatureMatch.mask`，或填写 `mask_path`。
3. 设置 `roi_mode=MASK`。
4. 设置 `output_mode=ROI` 或 `MASKED`，即可直接得到映射后的目标区域。

## 脚本导出说明

独立脚本导出只有一个命令行输入图，因此 `ORBFeatureMatch` 导出脚本时需要使用：

- `template_path` 指定模板图；
- `mask_path` 指定模板 mask，仅 `roi_mode=MASK` 时需要。

节点式运行仍支持连接 `template` 和 `mask` 输入端口；导出脚本暂不支持通过输入端口传入模板图或模板 mask。
