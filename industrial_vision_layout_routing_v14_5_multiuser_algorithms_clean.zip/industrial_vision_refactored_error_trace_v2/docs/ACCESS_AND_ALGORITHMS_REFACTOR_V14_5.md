# v14.5 登录门禁、在线列表与算法目录整理

## 1. 严格登录门禁

v14.5 起，平台进入严格多人协作模式：除 `/api/auth/register`、`/api/auth/login`、`/api/auth/logout` 外，平台操作 API 都要求携带：

```http
Authorization: Bearer <token>
X-Workspace-Id: <workspace_id>
```

旧版开发用的 `X-User-Id` / `X-User-Email` 不再创建临时身份，也不能绕过登录。

受保护范围包括：

- 算子元数据 `/api/operators`
- 工作流运行 `/api/run`
- 项目、版本、回滚、发布
- 模型上传、模型列表、模型元数据、缓存清理
- 数据集、回归测试、任务队列、运行历史
- Python 代码片段校验
- 脚本导出

前端未登录时会显示登录门禁层，不能拖拽节点、运行、保存、导入导出或操作模型。

## 2. 在线用户列表

顶部 `在线：N` 从纯文本改为按钮：

- 点击展开当前工作区在线用户列表；
- 再次点击收起；
- 点击页面其他区域自动收起；
- 心跳接口仍为 `/api/presence/heartbeat`；
- 查询接口仍为 `/api/workspaces/{workspace_id}/presence`。

在线状态只在同一工作区内可见，非成员无法查看。

## 3. 浏览器保存密码误弹修复

模块编辑器的输入项增加：

```html
autocomplete="off"
data-lpignore="true"
```

登录弹窗明确标记：

```html
autocomplete="username"
autocomplete="current-password"
data-form-type="other"
```

这样浏览器和常见密码管理器不会再把“模块标题/说明/折叠按钮操作”误判为登录表单提交。

## 4. backend/algorithms 目录整理

移除了历史兼容入口：

```text
backend/algorithms/image_ops.py
backend/algorithms/ai/yolo/
backend/algorithms/logic_ops.py
backend/algorithms/python_snippet_ops.py
```

新的算法目录结构：

```text
backend/algorithms/
  image/                  OpenCV 和传统图像处理算子
    io.py
    color.py
    filters.py
    thresholding.py
    edges.py
    morphology.py
    geometry.py
    contours.py
    template_matching.py

  ai/                     AI 模型类算子扩展入口
    yolo/                 YOLO 检测/分割/分类/姿态/OBB 统一实现
      model_manager.py
      ops.py
      result_parser.py
      selection.py
      roi_distance.py
      common.py

  logic/                  逻辑控制类算子
    ops.py

  script/                 脚本扩展类算子
    python_snippet.py

  registry.py             内置算子统一注册入口
  operator_registry.py    算子定义、元数据、目录与导出编译器统一注册表
  metadata.py             节点元数据、端口、参数 schema
  plugin_loader.py        自定义算子插件加载
  types.py                ExecutionContext / Operator 类型
  helpers.py              通用图像辅助函数
  utils.py                ID 安全化等通用工具
```

## 5. 后续扩展分割模型建议

如果后续要扩展非 YOLO 的分割模型，建议新增：

```text
backend/algorithms/ai/segmentation/
  __init__.py
  model_manager.py
  ops.py
  result_parser.py
  mask_utils.py
```

然后在 `backend/algorithms/registry.py` 中注册新算子，并在 `backend/algorithms/metadata.py` 中添加元数据。

如果仍使用 Ultralytics YOLO 分割，优先扩展现有：

```text
backend/algorithms/ai/yolo/ops.py
backend/algorithms/ai/yolo/result_parser.py
backend/algorithms/ai/yolo/selection.py
```

不要再把新模型算子放回 `backend/algorithms` 根目录。
