# Python代码片段开发界面

本版本把 `PythonSnippet` 节点从普通多行文本框升级为专用开发界面，目标是让用户在工作流中写自定义 Python 时，能像本地开发一样清楚地看到输入、输出、变量和运行结果。

## 入口

在 Python代码片段节点中可以通过两种方式打开：

1. 节点卡片里的 `打开开发界面` 按钮。
2. 选中节点后，右侧参数面板里的 `打开 Python 开发界面` 按钮。

## 开发界面包含什么

### 输入端口映射

左侧会列出当前节点声明的输入端口：

- `inputs['in']`：主输入，快捷别名是 `image`。
- `inputs['aux']`：辅助输入，快捷别名是 `aux`。
- `inputs['value']`：数值/对象输入，快捷别名是 `value`。

如果端口已经连线，会显示来自哪个上游节点、哪个输出端口以及上游端口类型。

### 可用变量

代码中可直接使用：

```python
inputs
params
context
image
aux
value
np
cv2
math
statistics
json
```

### 输出约定

代码可以直接给以下变量赋值：

```python
out      # 主输出
image    # 图像输出
value    # 数值/对象输出
metrics  # 节点预览指标
data     # 结构化数据，会继续传给后续节点
```

也可以定义：

```python
def process(inputs, params, context):
    return {
        "out": ...,
        "metrics": {...},
        "data": {...},
    }
```

定义 `process()` 时，函数返回值优先作为节点输出。

### 模板代码

界面提供常用模板：

- 透传/查看输入
- Canny 边缘
- 应用 aux Mask
- 阈值分割
- process 函数模板
- 数值/逻辑输出

### 代码校验

新增后端接口：

```text
POST /api/python-snippet/validate
```

用于在不执行代码的情况下检查：

- Python 语法是否正确；
- 是否使用了禁止语法，例如 import；
- 是否给 `out/image/value/metrics/data/result` 赋值；
- 是否定义了 `process()`。

### 最近运行输出

运行工作流后，开发界面右侧会显示该节点最近一次的：

- `result_type`
- `metrics`
- `data`

方便用户确认代码实际输出了什么。

## 快捷键

| 快捷键 | 作用 |
|---|---|
| `Tab` | 插入四个空格 |
| `Ctrl/⌘ + S` | 保存代码 |
| `Ctrl/⌘ + Enter` | 保存并运行当前工作流 |

## 注意事项

当前仍沿用原来的安全策略：

- 禁止 `import`、`open`、`eval`、`exec`、`compile`、`__import__` 等高风险能力；
- 默认子进程隔离执行；
- 支持超时保护；
- 支持节点级错误定位。

如果未来要给多人生产环境使用，建议继续把代码执行隔离升级为容器或独立 Worker 沙箱。
