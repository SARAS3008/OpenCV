from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


class NodePosition(BaseModel):
    x: float = 0
    y: float = 0


class WorkflowNode(BaseModel):
    id: str = Field(min_length=1, max_length=100)
    type: str = Field(min_length=1, max_length=100)
    position: NodePosition = Field(default_factory=NodePosition)
    params: dict[str, Any] = Field(default_factory=dict)
    collapsed: bool = False


class WorkflowEdge(BaseModel):
    id: str | None = None
    source: str = Field(min_length=1, max_length=100)
    target: str = Field(min_length=1, max_length=100)
    sourceHandle: str = "out"
    targetHandle: str = "in"


class WorkflowModule(BaseModel):
    """画布上的功能模块/节点分组。

    模块本身不改变工作流执行语义；执行器仍按节点和边运行。
    它用于大型流程的逻辑分区、评审、版本对比和文档化。
    """

    id: str = Field(min_length=1, max_length=100)
    name: str = Field(default="功能模块", min_length=1, max_length=120)
    node_ids: list[str] = Field(default_factory=list, max_length=500)
    description: str = Field(default="", max_length=1000)
    color: str | None = None
    collapsed: bool = False


class WorkflowRequest(BaseModel):
    version: str | None = None
    image_id: str | None = None
    nodes: list[WorkflowNode] = Field(default_factory=list, max_length=500)
    edges: list[WorkflowEdge] = Field(default_factory=list, max_length=2000)
    modules: list[WorkflowModule] = Field(default_factory=list, max_length=200)
