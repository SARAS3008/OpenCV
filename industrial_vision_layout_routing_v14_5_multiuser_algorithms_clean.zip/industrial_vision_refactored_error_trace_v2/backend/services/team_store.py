from __future__ import annotations

import json
import threading
import time
import uuid
from pathlib import Path
from typing import Any

from backend.algorithms.utils import safe_user_id
from backend.config import WORKSPACES_DIR

ROLE_ORDER = ["Owner", "Maintainer", "Developer", "Reviewer", "Viewer", "Operator"]
ROLE_PERMISSIONS: dict[str, set[str]] = {
    "Owner": {"view", "edit", "run", "manage", "delete", "release", "model", "member"},
    "Maintainer": {"view", "edit", "run", "manage", "release", "model", "member"},
    "Developer": {"view", "edit", "run", "model"},
    "Reviewer": {"view", "run"},
    "Viewer": {"view"},
    "Operator": {"view", "run"},
}


def _now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


class WorkspaceStore:
    """团队/工作区、角色权限与在线用户服务。

    工作区是项目、模型、数据集的隔离边界；同一工作区内的成员按角色共享资源。
    """

    def __init__(self, root_dir: Path = WORKSPACES_DIR, *, presence_ttl_seconds: int = 90) -> None:
        self.root_dir = root_dir.resolve()
        self.root_dir.mkdir(parents=True, exist_ok=True)
        self.presence_ttl_seconds = max(20, int(presence_ttl_seconds))
        self._lock = threading.RLock()
        self._presence: dict[str, dict[str, dict[str, Any]]] = {}

    def _path(self, workspace_id: str) -> Path:
        safe_id = safe_user_id(workspace_id)
        return self.root_dir / f"{safe_id}.json"

    def _read(self, workspace_id: str) -> dict[str, Any] | None:
        path = self._path(workspace_id)
        if not path.is_file():
            return None
        try:
            item = json.loads(path.read_text(encoding="utf-8"))
            return item if isinstance(item, dict) else None
        except (OSError, json.JSONDecodeError):
            return None

    def _default_workspace(self, owner_id: str) -> dict[str, Any]:
        active_user = safe_user_id(owner_id)
        workspace_id = f"ws_{active_user}"
        now = _now_iso()
        return {
            "version": 2,
            "workspace_id": workspace_id,
            "name": "个人工作区",
            "owner_id": active_user,
            "created_at": now,
            "updated_at": now,
            "members": [{"user_id": active_user, "role": "Owner", "joined_at": now, "display_name": active_user}],
        }

    def ensure_personal_workspace(self, owner_id: str) -> dict[str, Any]:
        active_user = safe_user_id(owner_id)
        workspace_id = f"ws_{active_user}"
        with self._lock:
            payload = self._read(workspace_id)
            if payload:
                return payload
            payload = self._default_workspace(active_user)
            self._write(self._path(workspace_id), payload)
            return payload

    def me(self, user: str | dict[str, Any]) -> dict[str, Any]:
        active_user = safe_user_id(user.get("user_id") if isinstance(user, dict) else user)
        public_user = dict(user) if isinstance(user, dict) else {"user_id": active_user, "display_name": active_user, "email": ""}
        workspace = self.ensure_personal_workspace(active_user)
        roles = {item["workspace_id"]: item.get("role") for item in self.list_workspaces(active_user)}
        return {
            **public_user,
            "user_id": active_user,
            "display_name": public_user.get("display_name") or active_user,
            "roles": roles or {workspace["workspace_id"]: "Owner"},
            "default_workspace_id": public_user.get("default_workspace_id") or workspace["workspace_id"],
        }

    def list_workspaces(self, user_id: str) -> list[dict[str, Any]]:
        active_user = safe_user_id(user_id)
        self.ensure_personal_workspace(active_user)
        result: list[dict[str, Any]] = []
        with self._lock:
            paths = sorted(self.root_dir.glob("*.json"))
            for path in paths:
                try:
                    item = json.loads(path.read_text(encoding="utf-8"))
                except (OSError, json.JSONDecodeError):
                    continue
                if not isinstance(item, dict) or not item.get("workspace_id"):
                    continue
                members = item.get("members") or []
                member = next((m for m in members if safe_user_id(m.get("user_id")) == active_user), None)
                if item.get("owner_id") == active_user or member:
                    result.append({
                        "workspace_id": item.get("workspace_id") or path.stem,
                        "name": item.get("name") or path.stem,
                        "owner_id": item.get("owner_id") or "default",
                        "created_at": item.get("created_at") or "",
                        "updated_at": item.get("updated_at") or "",
                        "member_count": len(members),
                        "role": (member or {}).get("role") or ("Owner" if item.get("owner_id") == active_user else "Viewer"),
                    })
        return result

    def get_workspace(self, workspace_id: str, user_id: str | None = None) -> dict[str, Any]:
        item = self._read(workspace_id)
        if not item:
            raise ValueError("工作区不存在")
        if user_id and not self.has_permission(workspace_id, user_id, "view"):
            raise PermissionError("无权访问该工作区")
        return item

    def create_workspace(self, *, owner_id: str, name: str, members: list[dict[str, Any]] | None = None) -> dict[str, Any]:
        active_user = safe_user_id(owner_id)
        now = _now_iso()
        workspace_id = f"ws_{uuid.uuid4().hex}"
        normalized_members = [{"user_id": active_user, "role": "Owner", "joined_at": now, "display_name": active_user}]
        seen = {active_user}
        for member in members or []:
            member_user = safe_user_id(member.get("user_id") or member.get("email"))
            if not member_user or member_user in seen:
                continue
            role = self.normalize_role(member.get("role") or "Developer")
            normalized_members.append({"user_id": member_user, "role": role, "joined_at": now, "display_name": member.get("display_name") or member_user})
            seen.add(member_user)
        payload = {
            "version": 2,
            "workspace_id": workspace_id,
            "name": str(name or "新工作区")[:120],
            "owner_id": active_user,
            "created_at": now,
            "updated_at": now,
            "members": normalized_members,
        }
        with self._lock:
            self._write(self._path(workspace_id), payload)
        return payload

    def normalize_role(self, role: Any) -> str:
        value = str(role or "Viewer").strip()
        aliases = {"admin": "Owner", "owner": "Owner", "maintainer": "Maintainer", "dev": "Developer", "developer": "Developer", "reviewer": "Reviewer", "viewer": "Viewer", "operator": "Operator"}
        return aliases.get(value.lower(), value if value in ROLE_PERMISSIONS else "Viewer")

    def member_role(self, workspace_id: str, user_id: str) -> str | None:
        active_user = safe_user_id(user_id)
        item = self._read(workspace_id)
        if not item:
            return None
        if item.get("owner_id") == active_user:
            return "Owner"
        for member in item.get("members") or []:
            if safe_user_id(member.get("user_id")) == active_user:
                return self.normalize_role(member.get("role"))
        return None

    def has_permission(self, workspace_id: str, user_id: str, permission: str) -> bool:
        role = self.member_role(workspace_id, user_id)
        return bool(role and permission in ROLE_PERMISSIONS.get(role, set()))

    def require_permission(self, workspace_id: str, user_id: str, permission: str) -> str:
        role = self.member_role(workspace_id, user_id)
        if not role:
            raise PermissionError("无权访问该工作区")
        if permission not in ROLE_PERMISSIONS.get(role, set()):
            raise PermissionError("当前角色没有执行该操作的权限")
        return role

    def upsert_member(self, *, workspace_id: str, acting_user_id: str, member_user_id: str, role: str = "Developer", display_name: str | None = None) -> dict[str, Any]:
        self.require_permission(workspace_id, acting_user_id, "member")
        active_member = safe_user_id(member_user_id)
        now = _now_iso()
        with self._lock:
            payload = self._read(workspace_id)
            if not payload:
                raise ValueError("工作区不存在")
            members = payload.setdefault("members", [])
            existing = next((m for m in members if safe_user_id(m.get("user_id")) == active_member), None)
            if existing:
                existing["role"] = self.normalize_role(role)
                existing["display_name"] = display_name or existing.get("display_name") or active_member
            else:
                members.append({"user_id": active_member, "role": self.normalize_role(role), "joined_at": now, "display_name": display_name or active_member})
            payload["updated_at"] = now
            self._write(self._path(workspace_id), payload)
            return payload

    def remove_member(self, *, workspace_id: str, acting_user_id: str, member_user_id: str) -> dict[str, Any]:
        self.require_permission(workspace_id, acting_user_id, "member")
        active_member = safe_user_id(member_user_id)
        with self._lock:
            payload = self._read(workspace_id)
            if not payload:
                raise ValueError("工作区不存在")
            if payload.get("owner_id") == active_member:
                raise ValueError("不能移除工作区 Owner")
            payload["members"] = [m for m in payload.get("members") or [] if safe_user_id(m.get("user_id")) != active_member]
            payload["updated_at"] = _now_iso()
            self._write(self._path(workspace_id), payload)
            return payload

    def touch_presence(self, *, workspace_id: str, user: dict[str, Any]) -> dict[str, Any]:
        user_id = safe_user_id(user.get("user_id"))
        self.require_permission(workspace_id, user_id, "view")
        now = time.time()
        item = {
            "user_id": user_id,
            "display_name": user.get("display_name") or user_id,
            "email": user.get("email") or "",
            "workspace_id": safe_user_id(workspace_id),
            "last_seen_at": _now_iso(),
            "last_seen_ts": now,
        }
        with self._lock:
            ws = self._presence.setdefault(safe_user_id(workspace_id), {})
            ws[user_id] = item
            self._purge_presence_locked()
        return dict(item)

    def list_presence(self, workspace_id: str, user_id: str) -> list[dict[str, Any]]:
        self.require_permission(workspace_id, user_id, "view")
        with self._lock:
            self._purge_presence_locked()
            users = list(self._presence.get(safe_user_id(workspace_id), {}).values())
        return sorted(({k: v for k, v in item.items() if k != "last_seen_ts"} for item in users), key=lambda item: str(item.get("display_name") or item.get("user_id")))

    def _purge_presence_locked(self) -> None:
        cutoff = time.time() - self.presence_ttl_seconds
        for workspace_id, users in list(self._presence.items()):
            for user_id, item in list(users.items()):
                if float(item.get("last_seen_ts") or 0) < cutoff:
                    users.pop(user_id, None)
            if not users:
                self._presence.pop(workspace_id, None)

    def _write(self, path: Path, payload: dict[str, Any]) -> None:
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(path)
