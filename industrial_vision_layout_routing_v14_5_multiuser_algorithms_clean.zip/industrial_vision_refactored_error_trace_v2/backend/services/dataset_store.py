from __future__ import annotations

import json
import time
import uuid
from pathlib import Path
from typing import Any

from backend.algorithms.utils import safe_user_id
from backend.config import DATASETS_DIR


def _now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


class DatasetStore:
    """文件系统数据集管理：样本、标签、期望结果和回归测试定义。"""

    def __init__(self, root_dir: Path = DATASETS_DIR) -> None:
        self.root_dir = root_dir.resolve()
        self.root_dir.mkdir(parents=True, exist_ok=True)

    def _user_dir(self, owner_id: str) -> Path:
        path = self.root_dir / safe_user_id(owner_id)
        path.mkdir(parents=True, exist_ok=True)
        return path

    def _path(self, owner_id: str, dataset_id: str) -> Path:
        return self._user_dir(owner_id) / f"{safe_user_id(dataset_id)}.json"

    def create_dataset(
        self,
        *,
        owner_id: str,
        name: str,
        description: str = "",
        samples: list[dict[str, Any]] | None = None,
        tags: list[str] | None = None,
    ) -> dict[str, Any]:
        now = _now_iso()
        dataset_id = uuid.uuid4().hex
        payload = {
            "version": 1,
            "dataset_id": dataset_id,
            "name": str(name or "图像数据集")[:120],
            "description": str(description or "")[:1000],
            "owner_id": safe_user_id(owner_id),
            "tags": [str(tag) for tag in (tags or [])][:50],
            "created_at": now,
            "updated_at": now,
            "samples": [self._normalize_sample(sample) for sample in (samples or [])],
        }
        self._write(self._path(owner_id, dataset_id), payload)
        return payload

    def list_datasets(self, *, owner_id: str) -> list[dict[str, Any]]:
        rows = []
        for path in sorted(self._user_dir(owner_id).glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True):
            try:
                payload = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                continue
            samples = payload.get("samples") or []
            rows.append({
                "dataset_id": payload.get("dataset_id") or path.stem,
                "name": payload.get("name") or path.stem,
                "description": payload.get("description") or "",
                "owner_id": payload.get("owner_id") or safe_user_id(owner_id),
                "created_at": payload.get("created_at") or "",
                "updated_at": payload.get("updated_at") or "",
                "tags": payload.get("tags") or [],
                "sample_count": len(samples),
            })
        return rows

    def get_dataset(self, *, owner_id: str, dataset_id: str) -> dict[str, Any]:
        path = self._path(owner_id, dataset_id)
        if not path.is_file():
            raise ValueError("数据集不存在")
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise ValueError(f"数据集读取失败：{exc}") from exc

    def update_dataset(self, *, owner_id: str, dataset_id: str, payload: dict[str, Any]) -> dict[str, Any]:
        current = self.get_dataset(owner_id=owner_id, dataset_id=dataset_id)
        for key in ("name", "description", "tags"):
            if key in payload:
                current[key] = payload[key]
        if "samples" in payload:
            current["samples"] = [self._normalize_sample(sample) for sample in (payload.get("samples") or [])]
        current["updated_at"] = _now_iso()
        self._write(self._path(owner_id, dataset_id), current)
        return current

    def add_samples(self, *, owner_id: str, dataset_id: str, samples: list[dict[str, Any]]) -> dict[str, Any]:
        current = self.get_dataset(owner_id=owner_id, dataset_id=dataset_id)
        existing = current.get("samples") or []
        existing.extend(self._normalize_sample(sample) for sample in samples)
        current["samples"] = existing
        current["updated_at"] = _now_iso()
        self._write(self._path(owner_id, dataset_id), current)
        return current

    def delete_dataset(self, *, owner_id: str, dataset_id: str) -> dict[str, Any]:
        current = self.get_dataset(owner_id=owner_id, dataset_id=dataset_id)
        self._path(owner_id, dataset_id).unlink(missing_ok=True)
        return current

    def _normalize_sample(self, sample: dict[str, Any]) -> dict[str, Any]:
        return {
            "sample_id": str(sample.get("sample_id") or uuid.uuid4().hex),
            "image_path": str(sample.get("image_path") or sample.get("path") or ""),
            "label": str(sample.get("label") or sample.get("expected_label") or ""),
            "tags": [str(tag) for tag in (sample.get("tags") or [])],
            "expected": sample.get("expected") or {},
            "metadata": sample.get("metadata") or {},
        }

    def _write(self, path: Path, payload: dict[str, Any]) -> None:
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(path)
