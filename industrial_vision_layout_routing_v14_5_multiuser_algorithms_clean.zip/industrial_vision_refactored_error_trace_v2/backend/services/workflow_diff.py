from __future__ import annotations

import json
from typing import Any


def _by_id(items: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    return {str(item.get("id")): item for item in items if isinstance(item, dict) and item.get("id")}


def _json_equal(a: Any, b: Any) -> bool:
    return json.dumps(a, sort_keys=True, ensure_ascii=False, default=str) == json.dumps(b, sort_keys=True, ensure_ascii=False, default=str)


def diff_workflows(before: dict[str, Any] | None, after: dict[str, Any] | None) -> dict[str, Any]:
    """返回面向评审的工作流差异摘要。"""

    before = before or {"nodes": [], "edges": [], "modules": []}
    after = after or {"nodes": [], "edges": [], "modules": []}
    before_nodes = _by_id(before.get("nodes") or [])
    after_nodes = _by_id(after.get("nodes") or [])
    added_nodes = [after_nodes[node_id] for node_id in sorted(set(after_nodes) - set(before_nodes))]
    removed_nodes = [before_nodes[node_id] for node_id in sorted(set(before_nodes) - set(after_nodes))]
    changed_nodes = []
    for node_id in sorted(set(before_nodes) & set(after_nodes)):
        left = before_nodes[node_id]
        right = after_nodes[node_id]
        changes = {}
        for key in ("type", "params", "position", "collapsed", "color"):
            if not _json_equal(left.get(key), right.get(key)):
                changes[key] = {"before": left.get(key), "after": right.get(key)}
        if changes:
            changed_nodes.append({"id": node_id, "changes": changes})

    def edge_key(edge: dict[str, Any]) -> str:
        return "|".join(str(edge.get(k, "")) for k in ("source", "sourceHandle", "target", "targetHandle"))

    before_edges = {edge_key(edge): edge for edge in before.get("edges") or [] if isinstance(edge, dict)}
    after_edges = {edge_key(edge): edge for edge in after.get("edges") or [] if isinstance(edge, dict)}

    before_modules = _by_id(before.get("modules") or [])
    after_modules = _by_id(after.get("modules") or [])
    changed_modules = []
    for module_id in sorted(set(before_modules) & set(after_modules)):
        if not _json_equal(before_modules[module_id], after_modules[module_id]):
            changed_modules.append({"id": module_id, "before": before_modules[module_id], "after": after_modules[module_id]})

    return {
        "node_count_before": len(before_nodes),
        "node_count_after": len(after_nodes),
        "added_nodes": added_nodes,
        "removed_nodes": removed_nodes,
        "changed_nodes": changed_nodes,
        "added_edges": [after_edges[key] for key in sorted(set(after_edges) - set(before_edges))],
        "removed_edges": [before_edges[key] for key in sorted(set(before_edges) - set(after_edges))],
        "added_modules": [after_modules[key] for key in sorted(set(after_modules) - set(before_modules))],
        "removed_modules": [before_modules[key] for key in sorted(set(before_modules) - set(after_modules))],
        "changed_modules": changed_modules,
    }
