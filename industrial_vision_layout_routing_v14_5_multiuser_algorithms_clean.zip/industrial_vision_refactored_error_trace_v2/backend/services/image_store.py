from __future__ import annotations

import uuid
from dataclasses import dataclass
from pathlib import Path

import cv2
import numpy as np


@dataclass(frozen=True)
class StoredImage:
    image_id: str
    original_filename: str
    path: Path
    image: np.ndarray


class ImageStore:
    """负责上传图片兼容存储，以及服务器本地图片路径解析。"""

    def __init__(
        self,
        upload_dir: Path,
        allowed_extensions: set[str],
        path_base: Path | None = None,
    ) -> None:
        self.upload_dir = upload_dir.resolve()
        self.allowed_extensions = {suffix.lower() for suffix in allowed_extensions}
        self.path_base = (path_base or self.upload_dir.parent).resolve()
        self.upload_dir.mkdir(parents=True, exist_ok=True)

    def save(self, filename: str | None, content: bytes) -> StoredImage:
        """保留旧上传 API 的兼容能力；新前端不再使用该入口。"""
        original_filename = filename or "image.png"
        suffix = Path(original_filename).suffix.lower()
        if suffix not in self.allowed_extensions:
            suffix = ".png"

        image_id = f"{uuid.uuid4().hex}{suffix}"
        path = self.upload_dir / image_id
        path.write_bytes(content)

        image = self.read(path)
        if image is None:
            path.unlink(missing_ok=True)
            raise ValueError("上传文件不是有效图片")

        return StoredImage(
            image_id=image_id,
            original_filename=original_filename,
            path=path,
            image=image,
        )

    def resolve(self, image_id: str) -> Path | None:
        """解析旧版工作流使用的 uploads/image_id。"""
        if not image_id or Path(image_id).name != image_id:
            return None
        path = (self.upload_dir / image_id).resolve()
        if path.parent != self.upload_dir or not path.is_file():
            return None
        return path

    def resolve_path(self, image_path: str) -> Path | None:
        """解析 ReadImage 节点中的服务器图片路径。

        相对路径以项目根目录为基准；绝对路径按原样解析。这里只允许已配置的
        图片扩展名，避免误把其他类型文件交给 OpenCV。
        """
        raw_path = str(image_path or "").strip()
        if not raw_path:
            return None

        candidate = Path(raw_path).expanduser()
        if not candidate.is_absolute():
            candidate = self.path_base / candidate

        try:
            resolved = candidate.resolve(strict=True)
        except (OSError, RuntimeError):
            return None

        if not resolved.is_file() or resolved.suffix.lower() not in self.allowed_extensions:
            return None
        return resolved

    def resolve_directory(self, directory_path: str) -> Path | None:
        """解析服务器目录路径；相对路径以项目根目录为基准。"""
        raw_path = str(directory_path or "").strip()
        if not raw_path:
            return None
        candidate = Path(raw_path).expanduser()
        if not candidate.is_absolute():
            candidate = self.path_base / candidate
        try:
            resolved = candidate.resolve(strict=True)
        except (OSError, RuntimeError):
            return None
        return resolved if resolved.is_dir() else None

    def prepare_output_directory(self, directory_path: str) -> Path:
        """解析并创建结果目录；相对路径以项目根目录为基准。"""
        raw_path = str(directory_path or "").strip()
        if not raw_path:
            raise ValueError("结果保存目录不能为空")
        candidate = Path(raw_path).expanduser()
        if not candidate.is_absolute():
            candidate = self.path_base / candidate
        try:
            resolved = candidate.resolve(strict=False)
            resolved.mkdir(parents=True, exist_ok=True)
        except (OSError, RuntimeError) as exc:
            raise ValueError(f"无法创建结果目录：{directory_path}") from exc
        if not resolved.is_dir():
            raise ValueError(f"结果路径不是目录：{resolved}")
        return resolved

    def list_images(
        self,
        directory: Path,
        extensions: set[str] | None = None,
        recursive: bool = True,
        limit: int = 0,
    ) -> list[Path]:
        allowed = {suffix.lower() for suffix in (extensions or self.allowed_extensions)}
        iterator = directory.rglob("*") if recursive else directory.glob("*")
        paths = sorted(
            (path.resolve() for path in iterator if path.is_file() and path.suffix.lower() in allowed),
            key=lambda item: str(item).lower(),
        )
        if limit > 0:
            paths = paths[:limit]
        return paths

    @staticmethod
    def read(path: Path) -> np.ndarray | None:
        """使用 imdecode 读取，兼容 Windows 上包含中文的路径。"""
        try:
            encoded = np.fromfile(str(path), dtype=np.uint8)
        except OSError:
            return None
        if encoded.size == 0:
            return None
        return cv2.imdecode(encoded, cv2.IMREAD_COLOR)
