from __future__ import annotations

import importlib
import pkgutil
from dataclasses import dataclass
from typing import Any, Callable

from backend.algorithms.types import Operator


ScriptCompiler = Callable[..., Any]


@dataclass(frozen=True)
class CustomOperatorDefinition:
    type_name: str
    operator: Operator
    metadata: dict[str, Any]
    category: str = "图像"
    group: str = "自定义算子"
    script_compiler: ScriptCompiler | None = None


@dataclass(frozen=True)
class PluginLoadError:
    module: str
    error: str
    cause_type: str

    def as_dict(self) -> dict[str, str]:
        return {
            "module": self.module,
            "error": self.error,
            "cause_type": self.cause_type,
        }


def _definition_from_module(module: Any) -> CustomOperatorDefinition:
    raw = getattr(module, "OPERATOR_DEFINITION", None)
    if not isinstance(raw, dict):
        raise ValueError(f"{module.__name__} 必须导出 OPERATOR_DEFINITION 字典")

    type_name = str(raw.get("type_name") or "").strip()
    operator = raw.get("operator")
    metadata = raw.get("metadata")
    if not type_name:
        raise ValueError(f"{module.__name__} 缺少 type_name")
    if not callable(operator):
        raise ValueError(f"{module.__name__} 的 operator 必须可调用")
    if not isinstance(metadata, dict):
        raise ValueError(f"{module.__name__} 的 metadata 必须是字典")

    normalized_metadata = dict(metadata)
    normalized_metadata.setdefault("label", type_name)
    normalized_metadata.setdefault("category", raw.get("category", "图像"))
    normalized_metadata.setdefault("group", raw.get("group", "自定义算子"))
    normalized_metadata.setdefault("kind", "custom")
    normalized_metadata.setdefault("has_input", True)
    normalized_metadata.setdefault("has_output", True)
    normalized_metadata.setdefault("params", {})
    normalized_metadata.setdefault("description", "自定义算子")

    compiler = raw.get("script_compiler")
    if compiler is not None and not callable(compiler):
        raise ValueError(f"{module.__name__} 的 script_compiler 必须可调用")

    return CustomOperatorDefinition(
        type_name=type_name,
        operator=operator,
        metadata=normalized_metadata,
        category=str(raw.get("category") or normalized_metadata["category"]),
        group=str(raw.get("group") or normalized_metadata["group"]),
        script_compiler=compiler,
    )


def load_custom_operators(
    package_name: str = "backend.custom_operators",
) -> tuple[list[CustomOperatorDefinition], list[PluginLoadError]]:
    """自动加载自定义算子插件，并隔离单个插件的失败。

    文件名以下划线开头时会被忽略，方便保留模板或草稿。某个插件导入或
    校验失败时不会再阻止整个 FastAPI 应用启动；失败信息会被记录并通过
    /api/operators 返回，便于页面和运维人员定位问题。
    """

    definitions: list[CustomOperatorDefinition] = []
    errors: list[PluginLoadError] = []
    try:
        package = importlib.import_module(package_name)
    except Exception as exc:  # pragma: no cover - 正常项目中包应始终存在。
        return definitions, [
            PluginLoadError(
                module=package_name,
                error=f"无法导入插件包：{exc}",
                cause_type=type(exc).__name__,
            )
        ]

    for module_info in pkgutil.iter_modules(package.__path__):
        if module_info.name.startswith("_"):
            continue
        module_name = f"{package.__name__}.{module_info.name}"
        try:
            module = importlib.import_module(module_name)
            definitions.append(_definition_from_module(module))
        except Exception as exc:
            errors.append(
                PluginLoadError(
                    module=module_name,
                    error=str(exc),
                    cause_type=type(exc).__name__,
                )
            )
    return definitions, errors
