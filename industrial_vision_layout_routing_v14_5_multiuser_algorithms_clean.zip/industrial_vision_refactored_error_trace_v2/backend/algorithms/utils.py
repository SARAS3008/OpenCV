from __future__ import annotations

import re

_SAFE_ID_RE = re.compile(r"[^0-9A-Za-z_.-]+")


def safe_user_id(value: object, fallback: str = "default") -> str:
    """把用户、工作区等外部标识规范化为可安全作为文件名片段的字符串。"""
    text = str(value or fallback).strip().lower()
    text = _SAFE_ID_RE.sub("_", text).strip("._-")
    return text[:96] or fallback
