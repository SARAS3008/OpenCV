from __future__ import annotations

import cv2

from backend.algorithms.helpers import ensure_bgr, to_float, to_int
from backend.algorithms.image.common import gray_input
from backend.algorithms.types import ExecutionContext, OperatorInputs, OperatorParams, OperatorResult

def op_find_contours(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    img = inputs["in"]
    gray = gray_input({"in": img, "in_color_space": inputs.get("in_color_space", "BGR")})
    threshold = to_int(params.get("threshold", 127), 127)
    min_area = to_float(params.get("min_area", 20), 20.0)
    _, binary = cv2.threshold(gray, threshold, 255, cv2.THRESH_BINARY)
    contours, _ = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    canvas = ensure_bgr(img).copy()
    count = 0
    for contour in contours:
        if cv2.contourArea(contour) < min_area:
            continue
        cv2.drawContours(canvas, [contour], -1, (0, 255, 0), 2)
        x, y, w, h = cv2.boundingRect(contour)
        cv2.rectangle(canvas, (x, y), (x + w, y + h), (0, 180, 255), 1)
        count += 1
    areas = [float(cv2.contourArea(contour)) for contour in contours if cv2.contourArea(contour) >= min_area]
    cv2.putText(canvas, f"contours: {count}", (12, 28), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 220, 255), 2)
    return {
        "out": canvas,
        "out_color_space": "BGR",
        "metrics": {
            "contour_count": count,
            "contour_area_total": round(sum(areas), 4),
            "contour_area_max": round(max(areas, default=0.0), 4),
        },
    }
