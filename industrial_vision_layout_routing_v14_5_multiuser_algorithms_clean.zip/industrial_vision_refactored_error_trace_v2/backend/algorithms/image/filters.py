from __future__ import annotations

import cv2
import numpy as np

from backend.algorithms.helpers import ensure_odd, to_float, to_int
from backend.algorithms.types import ExecutionContext, OperatorInputs, OperatorParams, OperatorResult

def op_mean_blur(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    ksize = ensure_odd(params.get("ksize", 5), 5)
    return {"out": cv2.blur(inputs["in"], (ksize, ksize))}

def op_gaussian_blur(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    ksize = ensure_odd(params.get("ksize", 5), 5)
    sigma = to_float(params.get("sigma", 0), 0.0)
    return {"out": cv2.GaussianBlur(inputs["in"], (ksize, ksize), sigma)}

def op_median_blur(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    ksize = ensure_odd(params.get("ksize", 5), 5)
    return {"out": cv2.medianBlur(inputs["in"], ksize)}

def op_bilateral_filter(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    d = to_int(params.get("d", 7), 7)
    sigma_color = to_float(params.get("sigma_color", 75), 75)
    sigma_space = to_float(params.get("sigma_space", 75), 75)
    return {"out": cv2.bilateralFilter(inputs["in"], d, sigma_color, sigma_space)}

def op_sharpen(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    amount = to_float(params.get("amount", 1.0), 1.0)
    kernel = np.array([[0, -1, 0], [-1, 4 + amount, -1], [0, -1, 0]], dtype=np.float32)
    out = cv2.filter2D(inputs["in"], -1, kernel)
    return {"out": out}
