from __future__ import annotations

import cv2

from backend.algorithms.helpers import ensure_odd, to_int
from backend.algorithms.image.common import gray_input
from backend.algorithms.types import ExecutionContext, OperatorInputs, OperatorParams, OperatorResult

def op_canny(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    gray = gray_input(inputs)
    t1 = to_int(params.get("threshold1", 50), 50)
    t2 = to_int(params.get("threshold2", 150), 150)
    return {"out": cv2.Canny(gray, t1, t2)}

def op_sobel(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    gray = gray_input(inputs)
    dx = to_int(params.get("dx", 1), 1)
    dy = to_int(params.get("dy", 0), 0)
    ksize = ensure_odd(params.get("ksize", 3), 3, 1)
    grad = cv2.Sobel(gray, cv2.CV_16S, dx, dy, ksize=ksize)
    return {"out": cv2.convertScaleAbs(grad)}

def op_laplacian(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    gray = gray_input(inputs)
    ksize = ensure_odd(params.get("ksize", 3), 3, 1)
    out = cv2.Laplacian(gray, cv2.CV_16S, ksize=ksize)
    return {"out": cv2.convertScaleAbs(out)}
