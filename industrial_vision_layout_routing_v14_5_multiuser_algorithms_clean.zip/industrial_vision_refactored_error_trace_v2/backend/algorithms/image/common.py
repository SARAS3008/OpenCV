from __future__ import annotations

import cv2
import numpy as np

from backend.algorithms.helpers import ensure_bgr, ensure_gray
from backend.algorithms.types import OperatorInputs

def gray_input(inputs: OperatorInputs) -> np.ndarray:
    image = inputs["in"]
    if image.ndim == 2:
        return image
    if str(inputs.get("in_color_space", "BGR")).upper() == "RGB":
        return cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
    return ensure_gray(image)

def bgr_input(inputs: OperatorInputs, handle: str = "in") -> np.ndarray:
    """按端口颜色空间把图像转换为 BGR，主要用于可视化输出。"""
    image = inputs[handle]
    if image.ndim == 2:
        return cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
    if str(inputs.get(f"{handle}_color_space", "BGR")).upper() == "RGB":
        return cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
    return ensure_bgr(image)
