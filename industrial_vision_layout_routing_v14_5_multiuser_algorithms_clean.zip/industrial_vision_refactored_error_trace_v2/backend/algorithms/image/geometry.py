from __future__ import annotations

import cv2

from backend.algorithms.helpers import to_float, to_int
from backend.algorithms.types import ExecutionContext, OperatorInputs, OperatorParams, OperatorResult

def op_resize(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    img = inputs["in"]
    scale = to_float(params.get("scale_percent", 50), 50.0)
    scale = max(scale, 1.0)
    width = max(1, int(img.shape[1] * scale / 100.0))
    height = max(1, int(img.shape[0] * scale / 100.0))
    return {"out": cv2.resize(img, (width, height), interpolation=cv2.INTER_AREA)}

def op_flip(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    code = to_int(params.get("flip_code", 1), 1)  # 1水平，0垂直，-1水平+垂直
    if code not in [-1, 0, 1]:
        code = 1
    return {"out": cv2.flip(inputs["in"], code)}

def op_rotate90(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    direction = to_int(params.get("direction", 0), 0)  # 0顺时针，1逆时针，2旋转180
    if direction == 1:
        code = cv2.ROTATE_90_COUNTERCLOCKWISE
    elif direction == 2:
        code = cv2.ROTATE_180
    else:
        code = cv2.ROTATE_90_CLOCKWISE
    return {"out": cv2.rotate(inputs["in"], code)}
