from __future__ import annotations

import cv2

from backend.algorithms.helpers import kernel_from_params, to_int
from backend.algorithms.types import ExecutionContext, OperatorInputs, OperatorParams, OperatorResult

def op_erode(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    iterations = to_int(params.get("iterations", 1), 1)
    return {"out": cv2.erode(inputs["in"], kernel_from_params(params, 3), iterations=iterations)}

def op_dilate(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    iterations = to_int(params.get("iterations", 1), 1)
    return {"out": cv2.dilate(inputs["in"], kernel_from_params(params, 3), iterations=iterations)}

def op_morph_open(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    return {"out": cv2.morphologyEx(inputs["in"], cv2.MORPH_OPEN, kernel_from_params(params, 3))}

def op_morph_close(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    return {"out": cv2.morphologyEx(inputs["in"], cv2.MORPH_CLOSE, kernel_from_params(params, 3))}

def op_morph_gradient(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    return {"out": cv2.morphologyEx(inputs["in"], cv2.MORPH_GRADIENT, kernel_from_params(params, 3))}
