from __future__ import annotations

import cv2
import numpy as np

from backend.algorithms.helpers import ensure_bgr, to_float, to_int
from backend.algorithms.image.common import gray_input
from backend.algorithms.types import ExecutionContext, OperatorInputs, OperatorParams, OperatorResult

def op_color_convert(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    image = inputs["in"]
    input_color_space = str(inputs.get("in_color_space") or ("GRAY" if image.ndim == 2 else "BGR")).upper()
    mode = str(params.get("mode", "GRAY")).strip().upper()

    if mode == "GRAY":
        if image.ndim == 2:
            output = image
        elif input_color_space == "RGB":
            output = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
        else:
            output = cv2.cvtColor(ensure_bgr(image), cv2.COLOR_BGR2GRAY)
        return {"out": output, "out_color_space": "GRAY"}

    if mode == "RGB":
        if image.ndim == 2:
            output = cv2.cvtColor(image, cv2.COLOR_GRAY2RGB)
        elif input_color_space == "RGB":
            output = image.copy()
        else:
            output = cv2.cvtColor(ensure_bgr(image), cv2.COLOR_BGR2RGB)
        return {"out": output, "out_color_space": "RGB"}

    raise ValueError(f"不支持的颜色转换模式：{mode}，可选值为 GRAY 或 RGB")

def op_gray(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    """旧版 Gray 节点兼容入口。"""
    return op_color_convert(inputs, {**params, "mode": "GRAY"}, context)

def op_bgr_to_rgb(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    """旧版 BGR2RGB 节点兼容入口。"""
    return op_color_convert(inputs, {**params, "mode": "RGB"}, context)

def op_invert(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    return {"out": cv2.bitwise_not(inputs["in"])}

def op_normalize(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    return {"out": cv2.normalize(inputs["in"], None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)}

def op_equalize_hist(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    gray = gray_input(inputs)
    return {"out": cv2.equalizeHist(gray)}

def op_clahe(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    gray = gray_input(inputs)
    clip = to_float(params.get("clip_limit", 2.0), 2.0)
    tile = max(1, to_int(params.get("tile_grid", 8), 8))
    clahe = cv2.createCLAHE(clipLimit=clip, tileGridSize=(tile, tile))
    return {"out": clahe.apply(gray)}
