from __future__ import annotations

import cv2

from backend.algorithms.helpers import ensure_odd, to_int
from backend.algorithms.image.common import gray_input
from backend.algorithms.types import ExecutionContext, OperatorInputs, OperatorParams, OperatorResult

def op_threshold(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    gray = gray_input(inputs)
    threshold = to_int(params.get("threshold", 127), 127)
    max_value = to_int(params.get("max_value", 255), 255)
    _, out = cv2.threshold(gray, threshold, max_value, cv2.THRESH_BINARY)
    return {"out": out}

def op_otsu_threshold(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    gray = gray_input(inputs)
    _, out = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    return {"out": out}

def op_adaptive_threshold(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    gray = gray_input(inputs)
    block_size = ensure_odd(params.get("block_size", 11), 11, 3)
    c = to_int(params.get("c", 2), 2)
    out = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, block_size, c)
    return {"out": out}
