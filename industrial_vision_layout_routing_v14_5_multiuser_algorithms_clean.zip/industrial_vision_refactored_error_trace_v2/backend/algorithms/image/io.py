from __future__ import annotations

from backend.algorithms.types import ExecutionContext, OperatorInputs, OperatorParams, OperatorResult

def op_read_image(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    image_path = str(params.get("image_path") or "").strip()
    if image_path:
        path = context.image_store.resolve_path(image_path)
        if path is None:
            raise ValueError(f"图片路径不存在、不可访问或不是受支持的图片：{image_path}")
    else:
        # 兼容旧版工作流中的 image_id；新前端只使用 image_path。
        image_id = params.get("image_id") or context.image_id
        if not image_id:
            raise ValueError("请在 ReadImage 节点右侧参数面板中填写图片路径")
        path = context.image_store.resolve(str(image_id))
        if path is None:
            raise ValueError(f"找不到旧版上传图片：{image_id}")

    img = context.image_store.read(path)
    if img is None:
        raise ValueError(f"OpenCV 读取图片失败：{path}")
    return {"out": img, "out_color_space": "BGR"}

def op_batch_read_images(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    """批量运行时读取当前图片。目录枚举由工作流引擎负责。"""
    if context.current_image_path is None:
        raise ValueError("BatchReadImages 只能通过批量工作流运行")
    image = context.image_store.read(context.current_image_path)
    if image is None:
        raise ValueError(f"OpenCV 读取图片失败：{context.current_image_path}")
    return {"out": image, "out_color_space": "BGR"}

def op_save_batch_results(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    """批量结果终点。实际写盘和 CSV 汇总由工作流引擎统一完成。"""
    return {
        "out": inputs["in"],
        "out_color_space": inputs.get("in_color_space", "BGR"),
    }

def op_display(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    return {
        "out": inputs["in"],
        "out_color_space": inputs.get("in_color_space", "BGR"),
    }
