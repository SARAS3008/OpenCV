from __future__ import annotations

import cv2
import numpy as np

from backend.algorithms.helpers import ensure_gray, to_float, to_int
from backend.algorithms.image.common import bgr_input, gray_input
from backend.algorithms.types import ExecutionContext, OperatorInputs, OperatorParams, OperatorResult

def _resolve_template_image(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> tuple[np.ndarray, str]:
    if isinstance(inputs.get("template"), np.ndarray):
        return inputs["template"], str(inputs.get("template_color_space", "BGR"))

    template_path = str(params.get("template_path") or "").strip()
    if not template_path:
        raise ValueError("ORB模板匹配需要连接 template 输入端口，或在参数中填写 template_path 模板图片路径")
    path = context.image_store.resolve_path(template_path)
    if path is None:
        raise ValueError(f"模板图片路径不存在、不可访问或不是受支持的图片：{template_path}")
    image = context.image_store.read(path)
    if image is None:
        raise ValueError(f"OpenCV 读取模板图片失败：{path}")
    return image, "BGR"

def _parse_yes_no(value: object, default: bool = True) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    text = str(value).strip().upper()
    if text in {"YES", "TRUE", "1", "ON", "是", "保留", "启用"}:
        return True
    if text in {"NO", "FALSE", "0", "OFF", "否", "不保留", "禁用"}:
        return False
    return default

def _threshold_mask(mask: np.ndarray, threshold: int = 1) -> np.ndarray:
    if mask.ndim == 3:
        mask = ensure_gray(mask)
    if mask.dtype != np.uint8:
        mask = np.clip(mask, 0, 255).astype(np.uint8)
    _, binary = cv2.threshold(mask, max(0, min(255, int(threshold))), 255, cv2.THRESH_BINARY)
    return binary

def _resolve_orb_template_mask(
    inputs: OperatorInputs,
    params: OperatorParams,
    context: ExecutionContext,
    template_shape: tuple[int, int],
) -> tuple[np.ndarray, str, list[int] | None]:
    """解析模板侧 ROI/mask。

    支持三种模式：
    - FULL：整个模板区域；
    - RECT：通过 roi_x/roi_y/roi_w/roi_h 定义矩形 ROI；
    - MASK：通过 mask 输入端口或 mask_path 定义不规则区域。
    """

    height, width = template_shape[:2]
    roi_mode = str(params.get("roi_mode", "FULL") or "FULL").strip().upper()
    mask_threshold = to_int(params.get("mask_threshold", 1), 1)

    if roi_mode == "MASK":
        if isinstance(inputs.get("mask"), np.ndarray):
            mask = _threshold_mask(inputs["mask"], mask_threshold)
        else:
            mask_path = str(params.get("mask_path") or "").strip()
            if not mask_path:
                raise ValueError("ORB模板匹配的 ROI模式为 MASK 时，需要连接 mask 输入端口，或填写 mask_path")
            path = context.image_store.resolve_path(mask_path)
            if path is None:
                raise ValueError(f"模板 mask 路径不存在、不可访问或不是受支持的图片：{mask_path}")
            raw_mask = context.image_store.read(path)
            if raw_mask is None:
                raise ValueError(f"OpenCV 读取模板 mask 失败：{path}")
            mask = _threshold_mask(raw_mask, mask_threshold)
        if mask.shape[:2] != (height, width):
            raise ValueError(
                f"模板 mask 尺寸必须与模板图一致：mask={mask.shape[:2]} template={(height, width)}"
            )
        return mask, "MASK", None

    if roi_mode == "RECT":
        x = max(0, min(width - 1, to_int(params.get("roi_x", 0), 0)))
        y = max(0, min(height - 1, to_int(params.get("roi_y", 0), 0)))
        default_w = width - x
        default_h = height - y
        w = max(1, to_int(params.get("roi_w", default_w), default_w))
        h = max(1, to_int(params.get("roi_h", default_h), default_h))
        w = min(w, width - x)
        h = min(h, height - y)
        mask = np.zeros((height, width), dtype=np.uint8)
        mask[y : y + h, x : x + w] = 255
        return mask, "RECT", [int(x), int(y), int(w), int(h)]

    mask = np.full((height, width), 255, dtype=np.uint8)
    return mask, "FULL", [0, 0, int(width), int(height)]

def _transform_points(points: np.ndarray, matrix: np.ndarray, transform_model: str) -> np.ndarray:
    pts = np.float32(points).reshape(-1, 1, 2)
    if transform_model == "HOMOGRAPHY":
        return cv2.perspectiveTransform(pts, matrix).reshape(-1, 2)
    return cv2.transform(pts, matrix).reshape(-1, 2)

def _warp_mask_to_image(mask: np.ndarray, matrix: np.ndarray | None, transform_model: str, output_size: tuple[int, int]) -> np.ndarray:
    width, height = output_size
    if matrix is None:
        return np.zeros((height, width), dtype=np.uint8)
    if transform_model == "HOMOGRAPHY":
        warped = cv2.warpPerspective(
            mask,
            matrix,
            (width, height),
            flags=cv2.INTER_NEAREST,
            borderMode=cv2.BORDER_CONSTANT,
            borderValue=0,
        )
    else:
        warped = cv2.warpAffine(
            mask,
            matrix,
            (width, height),
            flags=cv2.INTER_NEAREST,
            borderMode=cv2.BORDER_CONSTANT,
            borderValue=0,
        )
    return _threshold_mask(warped, 1)

def _mask_geometry(mask: np.ndarray) -> tuple[list[int], list[list[float]]]:
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return [0, 0, 0, 0], []
    contour = max(contours, key=cv2.contourArea)
    x, y, w, h = cv2.boundingRect(contour)
    epsilon = max(1.0, 0.01 * cv2.arcLength(contour, True))
    polygon = cv2.approxPolyDP(contour, epsilon, True).reshape(-1, 2)
    polygon_list = [[round(float(px), 3), round(float(py), 3)] for px, py in polygon[:200]]
    return [int(x), int(y), int(w), int(h)], polygon_list

def _apply_mask_to_bgr(image_bgr: np.ndarray, mask: np.ndarray) -> np.ndarray:
    return cv2.bitwise_and(image_bgr, image_bgr, mask=mask)

def _crop_masked_roi(image_bgr: np.ndarray, mask: np.ndarray, bbox: list[int], apply_mask: bool = True) -> tuple[np.ndarray, np.ndarray]:
    x, y, w, h = bbox
    if w <= 0 or h <= 0:
        return np.zeros((1, 1, 3), dtype=np.uint8), np.zeros((1, 1), dtype=np.uint8)
    crop = image_bgr[y : y + h, x : x + w].copy()
    crop_mask = mask[y : y + h, x : x + w].copy()
    if apply_mask:
        crop = cv2.bitwise_and(crop, crop, mask=crop_mask)
    return crop, crop_mask

def op_orb_feature_match(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    """ORB 角点模板匹配，并把模板侧 ROI/mask 映射到待检测图。

    输入：
    - in: 待匹配图像
    - template: 模板图像（可选；未连接时读取 params.template_path）
    - mask: 模板侧不规则 mask（可选；roi_mode=MASK 时可连接，未连接时读取 params.mask_path）

    核心输出：
    - out: 根据 output_mode 直接输出 mask / masked / roi / annotated
    - mask: 待检测图同尺寸二值 ROI/mask
    - roi: 待检测图中的 ROI 裁剪图
    - roi_mask: ROI 裁剪区域对应的二值 mask
    - masked: 待检测图中只保留 ROI/mask 区域的抠图结果
    """
    if "in" not in inputs or not isinstance(inputs.get("in"), np.ndarray):
        raise ValueError("ORB模板匹配缺少待匹配图像输入 in")

    image = inputs["in"]
    template, template_color_space = _resolve_template_image(inputs, params, context)
    if not isinstance(template, np.ndarray):
        raise ValueError("ORB模板匹配的 template 输入必须是图像")

    image_gray = gray_input({"in": image, "in_color_space": inputs.get("in_color_space", "BGR")})
    template_gray = gray_input({"in": template, "in_color_space": template_color_space})
    image_bgr = bgr_input(inputs, "in")
    template_bgr = bgr_input({"template": template, "template_color_space": template_color_space}, "template")
    template_roi_mask, roi_mode_used, template_roi_rect = _resolve_orb_template_mask(inputs, params, context, template_gray.shape[:2])

    n_features = max(50, to_int(params.get("n_features", 1000), 1000))
    scale_factor = max(1.01, to_float(params.get("scale_factor", 1.2), 1.2))
    n_levels = max(1, to_int(params.get("n_levels", 8), 8))
    fast_threshold = max(0, to_int(params.get("fast_threshold", 20), 20))
    ratio_test = min(0.99, max(0.05, to_float(params.get("ratio_test", 0.75), 0.75)))
    min_matches = max(4, to_int(params.get("min_matches", 8), 8))
    max_draw_matches = max(0, to_int(params.get("max_draw_matches", 40), 40))
    ransac_threshold = max(0.1, to_float(params.get("ransac_reproj_threshold", 5.0), 5.0))
    transform_model = str(params.get("transform_model", "HOMOGRAPHY") or "HOMOGRAPHY").strip().upper()
    if transform_model not in {"HOMOGRAPHY", "AFFINE", "AFFINE_PARTIAL"}:
        transform_model = "HOMOGRAPHY"
    output_mode = str(params.get("output_mode", "MASK") or "MASK").strip().upper()
    if output_mode not in {"MASK", "MASKED", "ROI", "ROI_MASK", "ANNOTATED"}:
        output_mode = "MASK"
    crop_apply_mask = _parse_yes_no(params.get("crop_apply_mask", "YES"), True)

    orb = cv2.ORB_create(
        nfeatures=n_features,
        scaleFactor=scale_factor,
        nlevels=n_levels,
        fastThreshold=fast_threshold,
    )
    template_keypoints, template_descriptors = orb.detectAndCompute(template_gray, None)
    image_keypoints, image_descriptors = orb.detectAndCompute(image_gray, None)

    raw_match_count = 0
    good_matches: list[cv2.DMatch] = []
    if template_descriptors is not None and image_descriptors is not None and len(template_keypoints) and len(image_keypoints):
        matcher = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=False)
        knn_matches = matcher.knnMatch(template_descriptors, image_descriptors, k=2)
        raw_match_count = len(knn_matches)
        for pair in knn_matches:
            if len(pair) < 2:
                continue
            first, second = pair
            if first.distance < ratio_test * second.distance:
                good_matches.append(first)
    good_matches.sort(key=lambda match: match.distance)

    transform_matrix: np.ndarray | None = None
    homography: np.ndarray | None = None
    affine_matrix: np.ndarray | None = None
    homography_mask: list[int] = []
    corners: list[list[float]] = []
    inlier_count = 0
    transform_found = False
    canvas = image_bgr.copy()

    if len(good_matches) >= min_matches:
        src_points = np.float32([template_keypoints[m.queryIdx].pt for m in good_matches]).reshape(-1, 1, 2)
        dst_points = np.float32([image_keypoints[m.trainIdx].pt for m in good_matches]).reshape(-1, 1, 2)
        if transform_model == "HOMOGRAPHY":
            homography, mask = cv2.findHomography(src_points, dst_points, cv2.RANSAC, ransac_threshold)
            if homography is not None and mask is not None:
                transform_matrix = homography
                homography_mask = mask.ravel().astype(int).tolist()
                inlier_count = int(sum(homography_mask))
                transform_found = inlier_count >= max(4, min_matches // 2)
        else:
            estimator = cv2.estimateAffinePartial2D if transform_model == "AFFINE_PARTIAL" else cv2.estimateAffine2D
            affine_matrix, mask = estimator(src_points, dst_points, method=cv2.RANSAC, ransacReprojThreshold=ransac_threshold)
            if affine_matrix is not None and mask is not None:
                transform_matrix = affine_matrix
                homography = np.vstack([affine_matrix, np.array([0.0, 0.0, 1.0], dtype=np.float64)])
                homography_mask = mask.ravel().astype(int).tolist()
                inlier_count = int(sum(homography_mask))
                transform_found = inlier_count >= max(3, min_matches // 2)

    h, w = template_gray.shape[:2]
    template_corners = np.float32([[0, 0], [w - 1, 0], [w - 1, h - 1], [0, h - 1]])
    if transform_matrix is not None:
        projected = _transform_points(template_corners, transform_matrix, "HOMOGRAPHY" if transform_model == "HOMOGRAPHY" else "AFFINE")
        corners = [[round(float(x), 3), round(float(y), 3)] for x, y in projected]
        if transform_found:
            polygon = np.int32(projected).reshape(-1, 1, 2)
            cv2.polylines(canvas, [polygon], True, (0, 255, 0), 3, cv2.LINE_AA)

    target_h, target_w = image_gray.shape[:2]
    target_mask = _warp_mask_to_image(
        template_roi_mask,
        transform_matrix if transform_found else None,
        "HOMOGRAPHY" if transform_model == "HOMOGRAPHY" else "AFFINE",
        (target_w, target_h),
    )
    bbox, roi_polygon = _mask_geometry(target_mask)
    masked = _apply_mask_to_bgr(image_bgr, target_mask)
    roi, roi_mask = _crop_masked_roi(image_bgr, target_mask, bbox, crop_apply_mask)

    contours, _ = cv2.findContours(target_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if contours:
        cv2.drawContours(canvas, contours, -1, (255, 180, 0), 2, cv2.LINE_AA)
        x, y, bw, bh = bbox
        cv2.rectangle(canvas, (x, y), (x + bw, y + bh), (0, 180, 255), 2, cv2.LINE_AA)

    draw_matches = good_matches[:max_draw_matches] if max_draw_matches else []
    for match in draw_matches:
        x, y = image_keypoints[match.trainIdx].pt
        cv2.circle(canvas, (int(round(x)), int(round(y))), 3, (0, 180, 255), -1, cv2.LINE_AA)

    if draw_matches:
        matches_canvas = cv2.drawMatches(
            template_bgr,
            template_keypoints,
            image_bgr,
            image_keypoints,
            draw_matches,
            None,
            flags=cv2.DrawMatchesFlags_NOT_DRAW_SINGLE_POINTS,
        )
    else:
        left = template_bgr
        right = image_bgr
        height = max(left.shape[0], right.shape[0])
        width = left.shape[1] + right.shape[1]
        matches_canvas = np.zeros((height, width, 3), dtype=np.uint8)
        matches_canvas[: left.shape[0], : left.shape[1]] = left
        matches_canvas[: right.shape[0], left.shape[1] : left.shape[1] + right.shape[1]] = right

    if good_matches:
        avg_distance = float(np.mean([match.distance for match in good_matches[: max(1, min(len(good_matches), min_matches * 2))]]))
        distance_score = max(0.0, min(1.0, 1.0 - avg_distance / 256.0))
    else:
        distance_score = 0.0
    count_score = max(0.0, min(1.0, len(good_matches) / float(max(1, min_matches))))
    inlier_score = max(0.0, min(1.0, inlier_count / float(max(1, len(good_matches))))) if good_matches else 0.0
    confidence = round(float(distance_score * (0.45 + 0.35 * count_score + 0.20 * inlier_score)), 4)
    if not transform_found:
        confidence = round(confidence * 0.65, 4)

    status_text = (
        f"ORB {transform_model} good:{len(good_matches)} inliers:{inlier_count} conf:{confidence:.2f}"
        if transform_found
        else f"ORB not found good:{len(good_matches)} need:{min_matches}"
    )
    cv2.putText(canvas, status_text, (12, 28), cv2.FONT_HERSHEY_SIMPLEX, 0.72, (0, 220, 255), 2, cv2.LINE_AA)
    cv2.putText(matches_canvas, status_text, (12, 28), cv2.FONT_HERSHEY_SIMPLEX, 0.72, (0, 220, 255), 2, cv2.LINE_AA)

    if output_mode == "ROI":
        out_image = roi
        out_color_space = "BGR"
    elif output_mode == "ROI_MASK":
        out_image = roi_mask
        out_color_space = "GRAY"
    elif output_mode == "MASKED":
        out_image = masked
        out_color_space = "BGR"
    elif output_mode == "ANNOTATED":
        out_image = canvas
        out_color_space = "BGR"
    else:
        out_image = target_mask
        out_color_space = "GRAY"

    homography_list = homography.round(6).tolist() if homography is not None else None
    affine_list = affine_matrix.round(6).tolist() if affine_matrix is not None else None
    metrics = {
        "template_keypoints": len(template_keypoints),
        "image_keypoints": len(image_keypoints),
        "match_count": raw_match_count,
        "good_match_count": len(good_matches),
        "inlier_count": inlier_count,
        "confidence": confidence,
        "homography_found": transform_found,
        "transform_found": transform_found,
        "roi_area": int(cv2.countNonZero(target_mask)),
        "roi_bbox_x": bbox[0],
        "roi_bbox_y": bbox[1],
        "roi_bbox_w": bbox[2],
        "roi_bbox_h": bbox[3],
    }
    match_data = {
        **metrics,
        "corners": corners,
        "roi_bbox": bbox,
        "roi_polygon": roi_polygon,
        "homography": homography_list,
        "affine": affine_list,
        "transform_matrix": homography_list if transform_model == "HOMOGRAPHY" else affine_list,
        "transform_model": transform_model,
        "roi_mode": roi_mode_used,
        "template_roi_rect": template_roi_rect,
        "output_mode": output_mode,
        "ratio_test": ratio_test,
        "min_matches": min_matches,
    }
    return {
        "out": out_image,
        "out_color_space": out_color_space,
        "mask": target_mask,
        "mask_color_space": "GRAY",
        "roi": roi,
        "roi_color_space": "BGR",
        "roi_mask": roi_mask,
        "roi_mask_color_space": "GRAY",
        "masked": masked,
        "masked_color_space": "BGR",
        "annotated": canvas,
        "annotated_color_space": "BGR",
        "matches": matches_canvas,
        "matches_color_space": "BGR",
        "match_count": raw_match_count,
        "good_match_count": len(good_matches),
        "inlier_count": inlier_count,
        "confidence": confidence,
        "homography_found": transform_found,
        "transform_found": transform_found,
        "corners": corners,
        "roi_bbox": bbox,
        "roi_polygon": roi_polygon,
        "homography": homography_list,
        "affine": affine_list,
        "metrics": metrics,
        "data": {"orb_feature_match": match_data},
    }
