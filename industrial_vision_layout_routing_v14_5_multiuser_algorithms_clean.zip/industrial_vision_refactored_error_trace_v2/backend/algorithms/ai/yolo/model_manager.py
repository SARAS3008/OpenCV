from __future__ import annotations

import json
import threading
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from backend.algorithms.types import ExecutionContext
from backend.algorithms.utils import safe_user_id
from backend.config import (
    ALLOWED_MODEL_EXTENSIONS,
    MODEL_CACHE_MAX_ITEMS,
    MODEL_CACHE_TTL_SECONDS,
    MODEL_DIR,
    MODEL_METADATA_PATH,
    PROJECT_ROOT,
)

_VALID_TASKS = {"auto", "detect", "segment", "classify", "pose", "obb"}


def normalize_task(value: Any) -> str:
    task = str(value or "auto").strip().lower()
    aliases = {
        "": "auto",
        "detection": "detect",
        "det": "detect",
        "seg": "segment",
        "classification": "classify",
        "cls": "classify",
        "keypoint": "pose",
        "keypoints": "pose",
    }
    task = aliases.get(task, task)
    if task not in _VALID_TASKS:
        allowed = "、".join(sorted(_VALID_TASKS))
        raise ValueError(f"不支持的 YOLO 推理任务：{value}，可选值：{allowed}")
    return task


def is_ultralytics_model_alias(raw_path: str) -> bool:
    """允许 yolov8n.pt / yolo11n.pt 等 Ultralytics 预训练模型短名称。"""

    if not raw_path:
        return False
    if "/" in raw_path or "\\" in raw_path:
        return False
    path = Path(raw_path)
    return path.name == raw_path and path.stem.lower().startswith("yolo") and path.suffix.lower() in ALLOWED_MODEL_EXTENSIONS


def relative_to_project(path: Path) -> str:
    try:
        return path.resolve().relative_to(PROJECT_ROOT.resolve()).as_posix()
    except ValueError:
        return str(path.resolve())


@dataclass
class CachedYoloModel:
    key: tuple[str, str, int, int, str]
    model: Any
    user_id: str
    display_name: str
    location: str
    loaded_at: float = field(default_factory=time.time)
    last_used_at: float = field(default_factory=time.time)
    hits: int = 0

    def touch(self) -> None:
        self.last_used_at = time.time()
        self.hits += 1


class ModelCacheView:
    """兼容旧测试中 yolo_ops._MODEL_CACHE.clear() 的轻量代理。"""

    def __init__(self, manager: "YoloModelManager") -> None:
        self._manager = manager

    def clear(self) -> None:
        self._manager.clear_cache()

    def __len__(self) -> int:
        return len(self._manager.cache_snapshot())

    def __bool__(self) -> bool:
        return bool(len(self))

    def get(self, key: Any, default: Any = None) -> Any:
        return self._manager.cache_snapshot().get(key, default)


class YoloModelManager:
    """统一管理模型上传记录、路径解析、YOLO 实例 LRU/TTL 缓存。"""

    def __init__(
        self,
        model_dir: Path = MODEL_DIR,
        metadata_path: Path = MODEL_METADATA_PATH,
        *,
        max_items: int = MODEL_CACHE_MAX_ITEMS,
        ttl_seconds: int = MODEL_CACHE_TTL_SECONDS,
        path_base: Path = PROJECT_ROOT,
    ) -> None:
        self.model_dir = model_dir.resolve()
        self.metadata_path = metadata_path.resolve()
        self.max_items = max(1, int(max_items))
        self.ttl_seconds = max(0, int(ttl_seconds))
        self.path_base = path_base.resolve()
        self.model_dir.mkdir(parents=True, exist_ok=True)
        self.metadata_path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._cache: dict[tuple[str, str, int, int, str], CachedYoloModel] = {}
        self._records: dict[str, dict[str, Any]] = self._load_records()

    def _load_records(self) -> dict[str, dict[str, Any]]:
        if not self.metadata_path.is_file():
            return {}
        try:
            payload = json.loads(self.metadata_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return {}
        records = payload.get("models") if isinstance(payload, dict) else None
        if not isinstance(records, list):
            return {}
        return {str(item.get("model_id")): dict(item) for item in records if isinstance(item, dict) and item.get("model_id")}

    def _save_records(self) -> None:
        payload = {"version": 1, "models": sorted(self._records.values(), key=lambda item: str(item.get("created_at", "")), reverse=True)}
        tmp = self.metadata_path.with_suffix(".tmp")
        tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(self.metadata_path)

    def resolve_model_ref(
        self,
        model_path: Any,
        context: ExecutionContext | None = None,
        *,
        user_id: str | None = None,
    ) -> tuple[Path | str, str, str]:
        raw_path = str(model_path or "").strip()
        if not raw_path:
            raise ValueError("请先在 YOLO 推理节点选择或填写模型文件路径，或填写 yolov8n.pt 使用 Ultralytics 预训练模型")

        active_user = safe_user_id(user_id or getattr(context, "user_id", None))
        raw_workspace = getattr(context, "workspace_id", None)
        active_workspace = safe_user_id(raw_workspace if raw_workspace and str(raw_workspace) != "default" else active_user)
        with self._lock:
            record = self._records.get(raw_path)
            if record:
                record_owner = record.get("owner_id")
                record_workspace = record.get("workspace_id") or record_owner
                if record_owner in {active_user, active_workspace, "shared"} or record_workspace in {active_workspace, "shared"} or active_user == "admin":
                    raw_path = str(record.get("path") or raw_path)

        base = getattr(getattr(context, "image_store", None), "path_base", self.path_base) if context else self.path_base
        candidate = Path(raw_path).expanduser()
        if not candidate.is_absolute():
            candidate = Path(base) / candidate

        try:
            resolved = candidate.resolve(strict=True)
        except (OSError, RuntimeError):
            if is_ultralytics_model_alias(raw_path):
                return raw_path, raw_path, raw_path
            raise ValueError(f"模型文件不存在或不可访问：{raw_path}")

        if not resolved.is_file():
            raise ValueError(f"模型路径不是文件：{resolved}")
        # 工作区模型隔离：如果路径对应已注册模型，必须属于当前工作区/用户。
        with self._lock:
            matching_record = next((item for item in self._records.values() if str(item.get("location") or "") == str(resolved)), None)
            if matching_record:
                record_owner = matching_record.get("owner_id")
                record_workspace = matching_record.get("workspace_id") or record_owner
                if record_owner not in {active_user, active_workspace, "shared"} and record_workspace not in {active_workspace, "shared"} and active_user != "admin":
                    raise ValueError("无权使用该工作区之外的模型")
        suffix = resolved.suffix.lower()
        if suffix not in ALLOWED_MODEL_EXTENSIONS:
            allowed = ", ".join(sorted(ALLOWED_MODEL_EXTENSIONS))
            raise ValueError(f"不支持的模型文件类型：{suffix or '无扩展名'}；允许：{allowed}")
        return resolved, resolved.name, str(resolved)

    def _cache_key(self, model_ref: Path | str, task: str, user_id: str) -> tuple[str, str, int, int, str]:
        if isinstance(model_ref, Path):
            stat = model_ref.stat()
            return (str(model_ref), task, stat.st_mtime_ns, stat.st_size, safe_user_id(user_id))
        return (str(model_ref), task, -1, -1, safe_user_id(user_id))

    def _evict_expired_locked(self) -> None:
        if self.ttl_seconds <= 0:
            return
        now = time.time()
        expired = [key for key, item in self._cache.items() if now - item.last_used_at > self.ttl_seconds]
        for key in expired:
            self._cache.pop(key, None)

    def _evict_lru_locked(self) -> None:
        while len(self._cache) > self.max_items:
            oldest_key = min(self._cache, key=lambda key: self._cache[key].last_used_at)
            self._cache.pop(oldest_key, None)

    def load_model(self, model_ref: Path | str, task: str, *, user_id: str = "default") -> Any:
        try:
            from ultralytics import YOLO  # type: ignore
        except ImportError as exc:
            raise ValueError(
                "当前环境未安装 Ultralytics YOLO。请执行：pip install ultralytics，"
                "或重新安装项目 requirements.txt 中的依赖。"
            ) from exc

        active_user = safe_user_id(user_id)
        key = self._cache_key(model_ref, task, active_user)
        with self._lock:
            self._evict_expired_locked()
            cached = self._cache.get(key)
            if cached is not None:
                cached.touch()
                return cached.model

        model = YOLO(str(model_ref)) if task == "auto" else YOLO(str(model_ref), task=task)
        with self._lock:
            self._cache[key] = CachedYoloModel(
                key=key,
                model=model,
                user_id=active_user,
                display_name=Path(str(model_ref)).name,
                location=str(model_ref),
            )
            self._evict_lru_locked()
        return model

    def register_upload(
        self,
        *,
        path: Path,
        original_filename: str,
        owner_id: str = "default",
        size: int,
        workspace_id: str | None = None,
    ) -> dict[str, Any]:
        now = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        model_id = uuid.uuid4().hex
        record = {
            "model_id": model_id,
            "filename": original_filename,
            "stored_name": path.name,
            "path": relative_to_project(path),
            "location": str(path.resolve()),
            "owner_id": safe_user_id(owner_id),
            "workspace_id": safe_user_id(workspace_id or owner_id),
            "size": int(size),
            "suffix": path.suffix.lower(),
            "created_at": now,
            "updated_at": now,
            "asset_name": Path(original_filename).stem,
            "model_version": "v1",
            "status": "draft",
            "task": "auto",
            "class_names": [],
            "metrics": {},
            "notes": "",
        }
        with self._lock:
            self._records[model_id] = record
            self._save_records()
        return dict(record)

    def list_models(self, *, owner_id: str = "default", include_shared: bool = True, workspace_id: str | None = None) -> list[dict[str, Any]]:
        active_user = safe_user_id(owner_id)
        active_workspace = safe_user_id(workspace_id or owner_id)
        with self._lock:
            records = []
            for record in self._records.values():
                owner = record.get("owner_id", "default")
                workspace = record.get("workspace_id") or owner
                if workspace == active_workspace or owner == active_user or (include_shared and (owner == "shared" or workspace == "shared")) or active_user == "admin":
                    item = dict(record)
                    item["exists"] = Path(str(record.get("location", ""))).is_file()
                    item["cache_loaded"] = any(cache.location == item.get("location") for cache in self._cache.values())
                    records.append(item)
            return sorted(records, key=lambda item: str(item.get("created_at", "")), reverse=True)

    def update_model_metadata(self, model_id: str, *, owner_id: str = "default", metadata: dict[str, Any], workspace_id: str | None = None) -> dict[str, Any]:
        active_user = safe_user_id(owner_id)
        active_workspace = safe_user_id(workspace_id or owner_id)
        allowed_keys = {"asset_name", "model_version", "status", "task", "class_names", "metrics", "notes", "project_ids", "dataset_id"}
        with self._lock:
            record = self._records.get(model_id)
            if not record:
                raise ValueError("模型不存在")
            if record.get("workspace_id", record.get("owner_id")) != active_workspace and record.get("owner_id") != active_user and active_user != "admin":
                raise ValueError("无权修改该模型")
            for key in allowed_keys:
                if key in metadata:
                    record[key] = metadata[key]
            record["updated_at"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
            self._save_records()
            return dict(record)

    def list_model_assets(self, *, owner_id: str = "default", include_shared: bool = True, workspace_id: str | None = None) -> list[dict[str, Any]]:
        grouped: dict[str, dict[str, Any]] = {}
        for record in self.list_models(owner_id=owner_id, include_shared=include_shared, workspace_id=workspace_id):
            asset_name = str(record.get("asset_name") or Path(str(record.get("filename") or record.get("stored_name") or "model")).stem)
            group = grouped.setdefault(asset_name, {"asset_name": asset_name, "versions": [], "latest_updated_at": "", "released_version": None})
            group["versions"].append(record)
            if str(record.get("updated_at") or "") > str(group.get("latest_updated_at") or ""):
                group["latest_updated_at"] = record.get("updated_at") or ""
            if record.get("status") == "released":
                group["released_version"] = record
        return sorted(grouped.values(), key=lambda item: item.get("latest_updated_at") or "", reverse=True)

    def delete_model(self, model_id: str, *, owner_id: str = "default", remove_file: bool = True, workspace_id: str | None = None) -> dict[str, Any]:
        active_user = safe_user_id(owner_id)
        active_workspace = safe_user_id(workspace_id or owner_id)
        with self._lock:
            record = self._records.get(model_id)
            if not record:
                raise ValueError("模型不存在")
            if record.get("workspace_id", record.get("owner_id")) != active_workspace and record.get("owner_id") != active_user and active_user != "admin":
                raise ValueError("无权删除该模型")
            self._records.pop(model_id, None)
            self._save_records()
            location = str(record.get("location") or "")
            for key, item in list(self._cache.items()):
                if item.location == location:
                    self._cache.pop(key, None)
        if remove_file and location:
            try:
                path = Path(location).resolve()
                if path.is_file() and path.parent == self.model_dir:
                    path.unlink(missing_ok=True)
            except OSError:
                pass
        return dict(record)

    def clear_cache(self, *, owner_id: str | None = None) -> None:
        with self._lock:
            if owner_id is None:
                self._cache.clear()
                return
            active_user = safe_user_id(owner_id)
            for key, item in list(self._cache.items()):
                if item.user_id == active_user:
                    self._cache.pop(key, None)

    def cache_snapshot(self) -> dict[tuple[str, str, int, int, str], Any]:
        with self._lock:
            return {key: item.model for key, item in self._cache.items()}

    def stats(self) -> dict[str, Any]:
        with self._lock:
            self._evict_expired_locked()
            return {
                "max_items": self.max_items,
                "ttl_seconds": self.ttl_seconds,
                "cached_count": len(self._cache),
                "registered_count": len(self._records),
                "cached_models": [
                    {
                        "user_id": item.user_id,
                        "display_name": item.display_name,
                        "location": item.location,
                        "task": item.key[1],
                        "hits": item.hits,
                        "loaded_at": item.loaded_at,
                        "last_used_at": item.last_used_at,
                    }
                    for item in self._cache.values()
                ],
            }


DEFAULT_MODEL_MANAGER = YoloModelManager()
MODEL_CACHE_VIEW = ModelCacheView(DEFAULT_MODEL_MANAGER)


def resolve_model_ref(model_path: Any, context: ExecutionContext) -> tuple[Path | str, str, str]:
    manager = getattr(context, "model_manager", None) or DEFAULT_MODEL_MANAGER
    return manager.resolve_model_ref(model_path, context, user_id=getattr(context, "user_id", None))


def load_yolo_model(model_ref: Path | str, task: str, context: ExecutionContext | None = None) -> Any:
    manager = getattr(context, "model_manager", None) or DEFAULT_MODEL_MANAGER
    workspace = getattr(context, "workspace_id", None)
    user = getattr(context, "user_id", "default")
    return manager.load_model(model_ref, task, user_id=workspace if workspace and str(workspace) != "default" else user)
