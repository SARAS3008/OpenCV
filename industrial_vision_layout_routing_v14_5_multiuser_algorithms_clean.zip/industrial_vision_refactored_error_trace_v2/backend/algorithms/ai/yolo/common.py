from __future__ import annotations

from typing import Any

import cv2
import numpy as np

from backend.algorithms.helpers import ensure_bgr

_VALID_TASKS = {"auto", "detect", "segment", "classify", "pose", "obb"}

def _yes(value: Any, default: bool = False) -> bool:
    if value is None:
        return default
    return str(value).strip().upper() in {"1", "TRUE", "YES", "Y", "是", "ON"}


def _normalize_task(value: Any) -> str:
    task = str(value or "auto").strip().lower()
    aliases = {
        "": "auto",
        "detection": "detect",
        "det": "detect",
        "seg": "segment",
        "classification": "classify",
        "cls": "classify",
        "keypoint": "pose",
        "keypoints": "pose",
    }
    task = aliases.get(task, task)
    if task not in _VALID_TASKS:
        allowed = "、".join(sorted(_VALID_TASKS))
        raise ValueError(f"不支持的 YOLO 推理任务：{value}，可选值：{allowed}")
    return task


def _image_for_yolo(image: np.ndarray, color_space: Any) -> np.ndarray:
    if not isinstance(image, np.ndarray):
        raise ValueError("YOLO 推理节点的输入必须是图像")
    if image.ndim == 2:
        return cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
    if str(color_space or "BGR").upper() == "RGB":
        return cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
    return ensure_bgr(image)


def _to_numpy(value: Any) -> np.ndarray | None:
    if value is None:
        return None
    try:
        if hasattr(value, "detach"):
            value = value.detach()
        if hasattr(value, "cpu"):
            value = value.cpu()
        if hasattr(value, "numpy"):
            value = value.numpy()
        if isinstance(value, np.ndarray):
            return value
        if hasattr(value, "tolist"):
            return np.asarray(value.tolist())
    except Exception:
        return None
    try:
        return np.asarray(value)
    except Exception:
        return None


def _to_list(value: Any, *, digits: int = 6) -> Any:
    array = _to_numpy(value)
    if array is None:
        return None
    if np.issubdtype(array.dtype, np.floating):
        array = np.round(array.astype(float), digits)
    if array.ndim == 0:
        scalar = array.item()
        if isinstance(scalar, np.generic):
            return scalar.item()
        return scalar
    return array.tolist()


def _int_or_none(value: Any) -> int | None:
    if value is None:
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        scalar = _to_list(value)
        try:
            return int(scalar)
        except (TypeError, ValueError):
            return None


def _float_or_none(value: Any) -> float | None:
    if value is None:
        return None
    try:
        return round(float(value), 6)
    except (TypeError, ValueError):
        scalar = _to_list(value)
        try:
            return round(float(scalar), 6)
        except (TypeError, ValueError):
            return None


def _name_for(names: Any, class_id: int | None) -> str:
    if class_id is None:
        return ""
    if isinstance(names, dict):
        return str(names.get(class_id, names.get(str(class_id), class_id)))
    if isinstance(names, (list, tuple)) and 0 <= class_id < len(names):
        return str(names[class_id])
    return str(class_id)


def _parse_class_filter(value: Any) -> set[str]:
    text = str(value or "").strip()
    if not text:
        return set()
    return {part.strip().lower() for part in text.replace("；", ",").replace(";", ",").split(",") if part.strip()}


def _parse_class_indices(value: Any) -> list[int]:
    """解析 YOLO 类别 index 白名单，例如："0,1,8"。

    该参数只表示模型类别 ID，不匹配类别名；类别名仍由 class_filter 支持。
    返回有序去重后的非负整数列表，便于直接传给 Ultralytics 的 classes 参数。
    """

    if value is None:
        return []
    if isinstance(value, (list, tuple, set)):
        raw_parts = list(value)
    else:
        text = str(value or "").strip()
        if not text:
            return []
        for left, right in [("[", ""), ("]", ""), ("（", ""), ("）", ""), ("(", ""), (")", "")]:
            text = text.replace(left, right)
        text = text.replace("，", ",").replace("；", ",").replace(";", ",").replace(" ", ",")
        raw_parts = [part for part in text.split(",") if str(part).strip()]

    indices: list[int] = []
    seen: set[int] = set()
    for part in raw_parts:
        raw = str(part).strip()
        if not raw:
            continue
        try:
            class_id = int(raw)
        except (TypeError, ValueError) as exc:
            raise ValueError(f"类别 index 过滤只能填写非负整数，例如 0,1,8；无法解析：{raw}") from exc
        if class_id < 0:
            raise ValueError(f"类别 index 不能为负数：{class_id}")
        if class_id not in seen:
            indices.append(class_id)
            seen.add(class_id)
    return indices


def _passes_class_indices(item: dict[str, Any], class_indices: set[int]) -> bool:
    if not class_indices:
        return True
    class_id = _int_or_none(item.get("class_id"))
    return class_id in class_indices


def _passes_class_filter(item: dict[str, Any], class_filter: set[str]) -> bool:
    if not class_filter:
        return True
    class_id = item.get("class_id")
    class_name = str(item.get("class_name") or "").lower()
    return str(class_id).lower() in class_filter or class_name in class_filter


