"""AI 模型类算子包。

用于放置检测、分割、分类、姿态、OBB 等深度学习模型算子。
当前实现：ai.yolo；后续新增分割模型时建议增加 ai/segmentation/ 或 ai/<vendor>/。
"""
