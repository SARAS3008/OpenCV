"""通用逻辑与数值控制算子。

这些算子遵循现有数据流工作流模型：节点按 DAG 顺序执行，If/Else 在已经
计算出的两个候选值之间进行选择；For/While 用于安全的数值迭代，不允许
执行任意 Python 代码。
"""

from __future__ import annotations

from typing import Any

import numpy as np

from backend.algorithms.types import ExecutionContext, OperatorInputs, OperatorParams, OperatorResult


def _to_number(value: Any, default: float = 0.0) -> float | int:
    if isinstance(value, bool):
        return int(value)
    try:
        number = float(value)
    except (TypeError, ValueError):
        return default
    return int(number) if number.is_integer() else number


def _to_bool(value: Any) -> bool:
    if isinstance(value, str):
        normalized = value.strip().lower()
        if normalized in {"", "0", "false", "no", "off", "否", "假"}:
            return False
        if normalized in {"1", "true", "yes", "on", "是", "真"}:
            return True
    return bool(value)


def _parse_constant(value: Any, value_type: str) -> Any:
    normalized = str(value_type or "NUMBER").upper()
    if normalized == "BOOLEAN":
        return _to_bool(value)
    if normalized == "TEXT":
        return str(value)
    return _to_number(value)


def _scalar_value(value: Any, label: str) -> Any:
    """确保逻辑比较接收到的是单个值，而不是图像或数组。"""

    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, np.ndarray):
        raise ValueError(
            f"{label} 收到的是图像/数组数据，不能直接进行数值比较；"
            "请连接算子的数值输出端口，例如 mean_brightness"
        )
    if isinstance(value, (list, tuple, set, dict)):
        raise ValueError(f"{label} 必须是单个数值、文本或布尔值，不能是集合数据")
    return value


def _comparison_number(value: Any, label: str) -> float | int:
    value = _scalar_value(value, label)
    if isinstance(value, bool):
        return int(value)
    try:
        number = float(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{label} 不是有效数值：{value!r}") from exc
    return int(number) if number.is_integer() else number


def _compare(left: Any, right: Any, operator: str) -> bool:
    operation = str(operator or "EQ").upper()
    if operation in {"GT", "GE", "LT", "LE"}:
        left = _comparison_number(left, "左值 A")
        right = _comparison_number(right, "右值 B")
    else:
        left = _scalar_value(left, "左值 A")
        right = _scalar_value(right, "右值 B")
    if operation == "GT":
        return left > right
    if operation == "GE":
        return left >= right
    if operation == "LT":
        return left < right
    if operation == "LE":
        return left <= right
    if operation == "NE":
        return left != right
    return left == right


def _update(value: Any, operation: str, step: Any) -> float | int:
    current = _to_number(value)
    amount = _to_number(step, 1.0)
    normalized = str(operation or "ADD").upper()
    if normalized == "SUBTRACT":
        return current - amount
    if normalized == "MULTIPLY":
        return current * amount
    if normalized == "DIVIDE":
        if amount == 0:
            raise ValueError("循环更新的除数不能为 0")
        return current / amount
    return current + amount


def op_logic_constant(
    inputs: OperatorInputs,
    params: OperatorParams,
    context: ExecutionContext,
) -> OperatorResult:
    value = _parse_constant(params.get("value", 0), str(params.get("value_type", "NUMBER")))
    return {"out": value, "metrics": {"value": value}}


def op_logic_compare(
    inputs: OperatorInputs,
    params: OperatorParams,
    context: ExecutionContext,
) -> OperatorResult:
    left = inputs["a"]
    right = inputs["b"]
    operation = str(params.get("operator", "GT")).upper()
    result = _compare(left, right, operation)
    return {
        "out": result,
        "metrics": {"left": left, "operator": operation, "right": right, "result": result},
    }


def op_logic_boolean(
    inputs: OperatorInputs,
    params: OperatorParams,
    context: ExecutionContext,
) -> OperatorResult:
    left = _to_bool(inputs["a"])
    right = _to_bool(inputs["b"])
    operation = str(params.get("operation", "AND")).upper()
    if operation == "OR":
        result = left or right
    elif operation == "XOR":
        result = left != right
    elif operation == "NAND":
        result = not (left and right)
    elif operation == "NOR":
        result = not (left or right)
    else:
        result = left and right
    return {
        "out": result,
        "metrics": {"left": left, "operation": operation, "right": right, "result": result},
    }


def op_logic_not(
    inputs: OperatorInputs,
    params: OperatorParams,
    context: ExecutionContext,
) -> OperatorResult:
    source = _to_bool(inputs["in"])
    result = not source
    return {"out": result, "metrics": {"input": source, "result": result}}


def op_logic_if_else(
    inputs: OperatorInputs,
    params: OperatorParams,
    context: ExecutionContext,
) -> OperatorResult:
    condition = _to_bool(inputs["condition"])
    selected = inputs["true_value"] if condition else inputs["false_value"]
    metrics: dict[str, Any] = {
        "condition": condition,
        "branch": "if" if condition else "else",
    }
    if selected is None or isinstance(selected, (str, int, float, bool, list, tuple, dict)):
        metrics["result"] = selected
    result: OperatorResult = {"out": selected, "metrics": metrics}
    selected_color_key = "true_value_color_space" if condition else "false_value_color_space"
    if selected_color_key in inputs:
        result["out_color_space"] = inputs[selected_color_key]
    return result


def op_logic_for_loop(
    inputs: OperatorInputs,
    params: OperatorParams,
    context: ExecutionContext,
) -> OperatorResult:
    initial = inputs.get("in", params.get("initial_value", 0))
    iterations = max(0, min(10000, int(_to_number(params.get("iterations", 1), 1))))
    operation = str(params.get("update_operation", "ADD")).upper()
    step = params.get("step", 1)
    current = _to_number(initial)
    history: list[Any] = []
    for _ in range(iterations):
        current = _update(current, operation, step)
        if len(history) < 100:
            history.append(current)
    return {
        "out": current,
        "metrics": {
            "iterations": iterations,
            "initial": _to_number(initial),
            "final": current,
            "history": history,
            "history_truncated": iterations > len(history),
        },
    }


def op_logic_while_loop(
    inputs: OperatorInputs,
    params: OperatorParams,
    context: ExecutionContext,
) -> OperatorResult:
    initial = inputs.get("in", params.get("initial_value", 0))
    current = _to_number(initial)
    compare_value = _to_number(params.get("compare_value", 10), 10)
    compare_operator = str(params.get("compare_operator", "LT")).upper()
    update_operation = str(params.get("update_operation", "ADD")).upper()
    step = params.get("step", 1)
    max_iterations = max(1, min(10000, int(_to_number(params.get("max_iterations", 100), 100))))
    iterations = 0
    history: list[Any] = []
    while _compare(current, compare_value, compare_operator) and iterations < max_iterations:
        current = _update(current, update_operation, step)
        iterations += 1
        if len(history) < 100:
            history.append(current)
    hit_limit = iterations >= max_iterations and _compare(current, compare_value, compare_operator)
    return {
        "out": current,
        "metrics": {
            "iterations": iterations,
            "initial": _to_number(initial),
            "final": current,
            "hit_max_iterations": hit_limit,
            "history": history,
            "history_truncated": iterations > len(history),
        },
    }
