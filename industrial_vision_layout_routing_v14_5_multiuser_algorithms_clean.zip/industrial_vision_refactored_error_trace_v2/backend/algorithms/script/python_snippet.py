from __future__ import annotations

import ast
import json
import math
import multiprocessing as mp
import os
import statistics
import time
import traceback
from queue import Empty
from dataclasses import asdict, is_dataclass
from pathlib import Path
from typing import Any

import cv2
import numpy as np

from backend.algorithms.types import ExecutionContext, OperatorInputs, OperatorParams, OperatorResult


_DEFAULT_CODE = """# 输入可通过 inputs['in'] / image / aux / value 访问。\n# 方式一：直接给 out / image / value / metrics / data 赋值。\nout = image.copy() if image is not None else value\nmetrics = {\n    'shape': list(image.shape) if image is not None else None,\n}\n\n# 方式二：也可以定义函数，函数返回值会优先作为节点输出：\n# def process(inputs, params, context):\n#     img = inputs.get('in')\n#     return {'out': cv2.bitwise_not(img), 'metrics': {'ok': True}}\n"""

_FORBIDDEN_CALLS = {
    "__import__",
    "breakpoint",
    "compile",
    "delattr",
    "dir",
    "eval",
    "exec",
    "getattr",
    "globals",
    "help",
    "input",
    "locals",
    "memoryview",
    "open",
    "setattr",
    "super",
    "vars",
}
_FORBIDDEN_NODES = (
    ast.AsyncFunctionDef,
    ast.Await,
    ast.ClassDef,
    ast.Delete,
    ast.Global,
    ast.Import,
    ast.ImportFrom,
    ast.Lambda,
    ast.Nonlocal,
    ast.Try,
    ast.With,
    ast.AsyncWith,
)

_ALLOWED_BUILTINS: dict[str, Any] = {
    "abs": abs,
    "all": all,
    "any": any,
    "bool": bool,
    "dict": dict,
    "enumerate": enumerate,
    "filter": filter,
    "float": float,
    "int": int,
    "isinstance": isinstance,
    "len": len,
    "list": list,
    "map": map,
    "max": max,
    "min": min,
    "pow": pow,
    "print": print,
    "range": range,
    "reversed": reversed,
    "round": round,
    "set": set,
    "slice": slice,
    "sorted": sorted,
    "str": str,
    "sum": sum,
    "tuple": tuple,
    "zip": zip,
    "Exception": Exception,
    "ValueError": ValueError,
    "TypeError": TypeError,
    "RuntimeError": RuntimeError,
}


def _to_int(value: Any, default: int, *, minimum: int | None = None, maximum: int | None = None) -> int:
    try:
        result = int(float(value))
    except (TypeError, ValueError):
        result = default
    if minimum is not None:
        result = max(minimum, result)
    if maximum is not None:
        result = min(maximum, result)
    return result


def _yes(value: Any, default: bool = False) -> bool:
    if isinstance(value, bool):
        return value
    if value is None:
        return default
    text = str(value).strip().upper()
    if text in {"YES", "TRUE", "1", "ON", "Y", "是", "启用"}:
        return True
    if text in {"NO", "FALSE", "0", "OFF", "N", "否", "禁用"}:
        return False
    return default


def _context_info(context: ExecutionContext) -> dict[str, Any]:
    return {
        "image_id": context.image_id,
        "current_image_path": str(context.current_image_path) if context.current_image_path else None,
        "source_root": str(context.source_root) if context.source_root else None,
        "batch_index": context.batch_index,
        "batch_total": context.batch_total,
        "user_id": context.user_id,
    }


class _SnippetSafetyVisitor(ast.NodeVisitor):
    def visit(self, node: ast.AST) -> Any:  # noqa: ANN401
        if isinstance(node, _FORBIDDEN_NODES):
            raise ValueError(f"代码片段不允许使用语法：{type(node).__name__}")
        return super().visit(node)

    def visit_Attribute(self, node: ast.Attribute) -> Any:  # noqa: ANN401
        if node.attr.startswith("__"):
            raise ValueError("代码片段不允许访问双下划线属性")
        self.generic_visit(node)

    def visit_Name(self, node: ast.Name) -> Any:  # noqa: ANN401
        if node.id.startswith("__"):
            raise ValueError("代码片段不允许访问双下划线名称")
        self.generic_visit(node)

    def visit_Call(self, node: ast.Call) -> Any:  # noqa: ANN401
        func = node.func
        if isinstance(func, ast.Name) and func.id in _FORBIDDEN_CALLS:
            raise ValueError(f"代码片段不允许调用：{func.id}")
        if isinstance(func, ast.Attribute) and func.attr in _FORBIDDEN_CALLS:
            raise ValueError(f"代码片段不允许调用：{func.attr}")
        self.generic_visit(node)


def _validate_code(code: str) -> None:
    try:
        tree = ast.parse(code, mode="exec")
    except SyntaxError as exc:
        raise ValueError(f"Python 语法错误：第 {exc.lineno} 行，{exc.msg}") from exc
    _SnippetSafetyVisitor().visit(tree)


def _json_safe(value: Any) -> Any:
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, np.ndarray):
        return {
            "array": True,
            "shape": list(value.shape),
            "dtype": str(value.dtype),
        }
    if isinstance(value, Path):
        return str(value)
    if is_dataclass(value):
        return _json_safe(asdict(value))
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, dict):
        return {str(key): _json_safe(child) for key, child in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [_json_safe(child) for child in value]
    try:
        json.dumps(value)
        return value
    except TypeError:
        return str(value)


def _normalize_result(raw_result: Any, namespace: dict[str, Any], params: dict[str, Any]) -> dict[str, Any]:
    if raw_result is None:
        if "result" in namespace:
            raw_result = namespace["result"]
        else:
            raw_result = {
                key: namespace[key]
                for key in ("out", "image", "value", "metrics", "data")
                if key in namespace
            }

    if isinstance(raw_result, dict):
        result = dict(raw_result)
    elif isinstance(raw_result, np.ndarray):
        result = {"out": raw_result, "image": raw_result}
    else:
        result = {"out": raw_result, "value": raw_result, "metrics": {"value": _json_safe(raw_result)}}

    if "out" not in result:
        if isinstance(result.get("image"), np.ndarray):
            result["out"] = result["image"]
        elif "value" in result:
            result["out"] = result["value"]

    if "image" not in result and isinstance(result.get("out"), np.ndarray):
        result["image"] = result["out"]
    if "value" not in result and not isinstance(result.get("out"), np.ndarray):
        result["value"] = result.get("out")

    metrics = result.get("metrics")
    if metrics is None:
        metrics = {}
    elif not isinstance(metrics, dict):
        metrics = {"result": metrics}
    metrics = _json_safe(metrics)
    if not isinstance(metrics, dict):
        metrics = {"result": metrics}
    result["metrics"] = metrics

    data = result.get("data")
    if data is None:
        data = {}
    elif not isinstance(data, dict):
        data = {"result": data}
    data = _json_safe(data)
    if not isinstance(data, dict):
        data = {"result": data}
    result["data"] = data

    color = str(result.get("out_color_space") or params.get("output_color_space") or "AUTO").upper()
    if color in {"BGR", "RGB", "GRAY"} and isinstance(result.get("out"), np.ndarray):
        result["out_color_space"] = color
    if isinstance(result.get("image"), np.ndarray):
        image_color = str(result.get("image_color_space") or result.get("out_color_space") or color).upper()
        if image_color in {"BGR", "RGB", "GRAY"}:
            result["image_color_space"] = image_color

    return result


def _execute_snippet_worker(
    queue: mp.Queue,
    code: str,
    inputs: dict[str, Any],
    params: dict[str, Any],
    context_info: dict[str, Any],
) -> None:
    try:
        namespace: dict[str, Any] = {
            "inputs": inputs,
            "params": params,
            "context": context_info,
            "np": np,
            "cv2": cv2,
            "math": math,
            "statistics": statistics,
            "json": json,
            "image": inputs.get("in"),
            "aux": inputs.get("aux"),
            "value": inputs.get("value"),
            "out": None,
            "metrics": {},
            "data": {},
        }
        globals_dict = {"__builtins__": _ALLOWED_BUILTINS, **namespace}
        exec(compile(code, "<PythonSnippet>", "exec"), globals_dict, namespace)
        process = namespace.get("process") or globals_dict.get("process")
        if callable(process):
            raw_result = process(inputs, params, context_info)
        else:
            raw_result = namespace.get("result") if "result" in namespace else None
        normalized = _normalize_result(raw_result, namespace, params)
        queue.put({"ok": True, "result": normalized})
    except Exception as exc:  # pragma: no cover - exercised through parent process
        queue.put(
            {
                "ok": False,
                "error": str(exc),
                "cause_type": type(exc).__name__,
                "traceback": traceback.format_exc(limit=8),
            }
        )


def _run_in_subprocess(code: str, inputs: dict[str, Any], params: dict[str, Any], context_info: dict[str, Any], timeout_ms: int) -> dict[str, Any]:
    mp_context = mp.get_context("fork" if hasattr(os, "fork") else "spawn")
    queue: mp.Queue = mp_context.Queue(maxsize=1)
    process = mp_context.Process(target=_execute_snippet_worker, args=(queue, code, inputs, params, context_info), daemon=True)
    process.start()
    try:
        payload = queue.get(timeout=timeout_ms / 1000.0)
    except Empty:
        if process.is_alive():
            process.terminate()
            process.join(1.0)
            raise TimeoutError(f"Python代码片段执行超时：{timeout_ms} ms")
        process.join(1.0)
        if process.exitcode not in (0, None):
            raise RuntimeError(f"Python代码片段子进程异常退出，exitcode={process.exitcode}")
        raise RuntimeError("Python代码片段没有返回结果")
    finally:
        if process.is_alive():
            process.join(1.0)
    if not payload.get("ok"):
        detail = payload.get("error") or "未知错误"
        raise ValueError(f"Python代码片段执行失败：{detail}")
    result = payload.get("result")
    if not isinstance(result, dict):
        raise ValueError("Python代码片段返回结果必须是字典")
    return result


def _run_inline(code: str, inputs: dict[str, Any], params: dict[str, Any], context_info: dict[str, Any]) -> dict[str, Any]:
    queue: Any = type("InlineQueue", (), {})()
    payloads: list[dict[str, Any]] = []
    queue.put = payloads.append
    _execute_snippet_worker(queue, code, inputs, params, context_info)
    payload = payloads[0]
    if not payload.get("ok"):
        raise ValueError(f"Python代码片段执行失败：{payload.get('error') or '未知错误'}")
    result = payload.get("result")
    if not isinstance(result, dict):
        raise ValueError("Python代码片段返回结果必须是字典")
    return result


def op_python_snippet(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    """执行受限 Python 代码片段。"""

    code = str(params.get("code") or "").strip("\ufeff")
    if not code.strip():
        code = _DEFAULT_CODE
    _validate_code(code)

    timeout_ms = _to_int(params.get("timeout_ms", 1000), 1000, minimum=50, maximum=30000)
    isolated = _yes(params.get("isolated", "YES"), True)
    context_info = _context_info(context)

    # 传入用户代码的 params 不包含 code 本身，避免结果 data 中意外回显大量代码。
    runtime_params = {key: value for key, value in params.items() if key != "code"}
    started = time.perf_counter()
    result = _run_in_subprocess(code, dict(inputs), runtime_params, context_info, timeout_ms) if isolated else _run_inline(code, dict(inputs), runtime_params, context_info)
    elapsed_ms = round((time.perf_counter() - started) * 1000.0, 3)

    metrics = result.get("metrics") if isinstance(result.get("metrics"), dict) else {}
    metrics.setdefault("elapsed_ms", elapsed_ms)
    metrics.setdefault("isolated", isolated)
    result["metrics"] = metrics
    data = result.get("data") if isinstance(result.get("data"), dict) else {}
    data.setdefault("python_snippet", {"elapsed_ms": elapsed_ms, "isolated": isolated})
    result["data"] = data
    return result


