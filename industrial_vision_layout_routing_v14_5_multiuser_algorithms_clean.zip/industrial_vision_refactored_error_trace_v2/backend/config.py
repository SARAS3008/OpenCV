from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
FRONTEND_DIR = PROJECT_ROOT / "frontend"
UPLOAD_DIR = PROJECT_ROOT / "uploads"
MODEL_DIR = PROJECT_ROOT / "models" / "uploads"
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
MODEL_DIR.mkdir(parents=True, exist_ok=True)

ALLOWED_IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff", ".webp"}
ALLOWED_MODEL_EXTENSIONS = {".pt", ".onnx", ".engine", ".torchscript", ".mlmodel", ".tflite", ".pb", ".xml", ".bin", ".yaml", ".yml"}
MAX_UPLOAD_BYTES = 20 * 1024 * 1024
MAX_MODEL_UPLOAD_BYTES = 512 * 1024 * 1024

PROJECTS_DIR = PROJECT_ROOT / "projects"
MODEL_METADATA_PATH = MODEL_DIR / "models.json"
MODEL_CACHE_MAX_ITEMS = 4
MODEL_CACHE_TTL_SECONDS = 30 * 60
PROJECTS_DIR.mkdir(parents=True, exist_ok=True)


# 团队级功能：这些仍是文件系统实现，后续可替换为数据库/对象存储。
WORKSPACES_DIR = PROJECT_ROOT / "workspaces"
DATASETS_DIR = PROJECT_ROOT / "datasets"
RUN_HISTORY_DIR = PROJECT_ROOT / "run_history"
JOBS_DIR = PROJECT_ROOT / "jobs"
AUTH_DIR = PROJECT_ROOT / "auth"
for _directory in (WORKSPACES_DIR, DATASETS_DIR, RUN_HISTORY_DIR, JOBS_DIR, AUTH_DIR):
    _directory.mkdir(parents=True, exist_ok=True)
