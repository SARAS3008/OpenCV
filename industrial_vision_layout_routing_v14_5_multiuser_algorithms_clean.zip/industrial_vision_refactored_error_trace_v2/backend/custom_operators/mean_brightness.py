"""自定义算子示例：计算平均亮度并把数据写入批量 CSV。"""

from __future__ import annotations

import cv2
import numpy as np

from backend.algorithms.types import ExecutionContext, OperatorInputs, OperatorParams, OperatorResult


def op_mean_brightness(
    inputs: OperatorInputs,
    params: OperatorParams,
    context: ExecutionContext,
) -> OperatorResult:
    image = inputs["in"]
    color_space = str(inputs.get("in_color_space", "BGR")).upper()
    if image.ndim == 2:
        gray = image
    elif color_space == "RGB":
        gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
    else:
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    mean_value = float(np.mean(gray))
    std_value = float(np.std(gray))
    mean_result = round(mean_value, 4)
    std_result = round(std_value, 4)
    return {
        # out 保留图像通路，方便继续串联图像算子。
        "out": image.copy(),
        "out_color_space": color_space,
        # 独立数值端口供比较、If/Else 等逻辑节点使用。
        "mean_brightness": mean_result,
        "brightness_std": std_result,
        "metrics": {
            "mean_brightness": mean_result,
            "brightness_std": std_result,
        },
    }


def compile_script(input_var: str, input_color: str, params: dict):
    """纯算法脚本导出扩展点。

    使用多输出协议返回每个输出端口的表达式。这样 mean_brightness
    或 brightness_std 连接到逻辑节点时，导出的脚本会传递数值而不是图像。
    """

    if input_color.upper() == "GRAY":
        gray_expr = input_var
    elif input_color.upper() == "RGB":
        gray_expr = f"cv2.cvtColor({input_var}, cv2.COLOR_RGB2GRAY)"
    else:
        gray_expr = f"cv2.cvtColor({input_var}, cv2.COLOR_BGR2GRAY)"
    return [], {
        "out": {
            "expression": f"{input_var}.copy()",
            "kind": "image",
            "color_space": input_color,
        },
        "mean_brightness": {
            "expression": f"round(float(np.mean({gray_expr})), 4)",
            "kind": "value",
        },
        "brightness_std": {
            "expression": f"round(float(np.std({gray_expr})), 4)",
            "kind": "value",
        },
    }


OPERATOR_DEFINITION = {
    "type_name": "MeanBrightness",
    "operator": op_mean_brightness,
    "metadata": {
        "label": "平均亮度统计",
        "kind": "measure",
        "has_input": True,
        "has_output": True,
        "inputs": [
            {"handle": "in", "label": "图像", "type": "image", "required": True},
        ],
        "outputs": [
            {"handle": "out", "label": "图像", "type": "image"},
            {"handle": "mean_brightness", "label": "平均亮度", "type": "number"},
            {"handle": "brightness_std", "label": "亮度标准差", "type": "number"},
        ],
        "result_type": "metrics",
        "params": {},
        "description": "计算图像平均亮度和标准差；批量运行时自动写入 CSV。",
    },
    "category": "图像",
    "group": "自定义算子",
    "script_compiler": compile_script,
}
