from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Request

from backend.api.dependencies import get_model_manager, get_user_id, require_workspace_model, require_workspace_view
from backend.algorithms.ai.yolo.model_manager import YoloModelManager

router = APIRouter(prefix="/models")


@router.get("")
def list_models(
    manager: YoloModelManager = Depends(get_model_manager),
    user_id: str = Depends(get_user_id),
    workspace_id: str = Depends(require_workspace_view),
) -> dict[str, Any]:
    return {"success": True, "models": manager.list_models(owner_id=user_id, workspace_id=workspace_id), "cache": manager.stats(), "workspace_id": workspace_id}


@router.get("/assets")
def list_model_assets(
    manager: YoloModelManager = Depends(get_model_manager),
    user_id: str = Depends(get_user_id),
    workspace_id: str = Depends(require_workspace_view),
) -> dict[str, Any]:
    return {"success": True, "assets": manager.list_model_assets(owner_id=user_id, workspace_id=workspace_id), "cache": manager.stats(), "workspace_id": workspace_id}


@router.patch("/{model_id}")
async def update_model_metadata(
    model_id: str,
    request: Request,
    manager: YoloModelManager = Depends(get_model_manager),
    user_id: str = Depends(get_user_id),
    workspace_id: str = Depends(require_workspace_model),
) -> dict[str, Any]:
    payload = await request.json()
    try:
        return {"success": True, "model": manager.update_model_metadata(model_id, owner_id=user_id, workspace_id=workspace_id, metadata=payload)}
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.delete("/{model_id}")
def delete_model(
    model_id: str,
    manager: YoloModelManager = Depends(get_model_manager),
    user_id: str = Depends(get_user_id),
    workspace_id: str = Depends(require_workspace_model),
) -> dict[str, Any]:
    try:
        return {"success": True, "model": manager.delete_model(model_id, owner_id=user_id, workspace_id=workspace_id)}
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.post("/cache/clear")
def clear_model_cache(
    manager: YoloModelManager = Depends(get_model_manager),
    workspace_id: str = Depends(require_workspace_model),
) -> dict[str, Any]:
    manager.clear_cache(owner_id=workspace_id)
    return {"success": True, "cache": manager.stats()}
