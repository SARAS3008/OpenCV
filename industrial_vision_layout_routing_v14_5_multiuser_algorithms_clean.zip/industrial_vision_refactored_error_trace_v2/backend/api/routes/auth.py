from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Request

from backend.api.dependencies import get_auth_store, get_current_user
from backend.services.auth_store import AuthStore

router = APIRouter(prefix="/auth")


def _token_from_request(request: Request) -> str | None:
    auth = request.headers.get("Authorization") or ""
    if auth.lower().startswith("bearer "):
        return auth.split(" ", 1)[1].strip() or None
    return None


@router.post("/register")
async def register(request: Request, auth: AuthStore = Depends(get_auth_store)) -> dict[str, Any]:
    payload = await request.json()
    try:
        user = auth.register(
            email=payload.get("email") or "",
            password=payload.get("password") or "",
            display_name=payload.get("display_name") or payload.get("name"),
        )
        workspace = request.app.state.workspace_store.ensure_personal_workspace(user["user_id"])
        login = auth.authenticate(email=payload.get("email") or "", password=payload.get("password") or "")
        return {"success": True, "user": {**user, "default_workspace_id": workspace["workspace_id"]}, "token": login["token"], "expires_at": login["expires_at"]}
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.post("/login")
async def login(request: Request, auth: AuthStore = Depends(get_auth_store)) -> dict[str, Any]:
    payload = await request.json()
    try:
        result = auth.authenticate(email=payload.get("email") or "", password=payload.get("password") or "")
        workspace = request.app.state.workspace_store.ensure_personal_workspace(result["user"]["user_id"])
        result["user"]["default_workspace_id"] = workspace["workspace_id"]
        return {"success": True, **result}
    except ValueError as exc:
        raise HTTPException(status_code=401, detail=str(exc)) from exc


@router.post("/logout")
def logout(request: Request, auth: AuthStore = Depends(get_auth_store)) -> dict[str, Any]:
    auth.logout(_token_from_request(request))
    return {"success": True}


@router.get("/session")
def session(user: dict[str, Any] = Depends(get_current_user)) -> dict[str, Any]:
    return {"success": True, "user": user}
