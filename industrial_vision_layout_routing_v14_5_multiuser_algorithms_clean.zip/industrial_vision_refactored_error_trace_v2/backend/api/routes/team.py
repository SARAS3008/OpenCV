from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Request

from backend.api.dependencies import get_current_user, get_user_id, get_workspace_store
from backend.services.team_store import WorkspaceStore

router = APIRouter()


@router.get("/users/me")
def get_me(
    store: WorkspaceStore = Depends(get_workspace_store),
    user: dict[str, Any] = Depends(get_current_user),
) -> dict[str, Any]:
    return {"success": True, "user": store.me(user)}


@router.get("/workspaces")
def list_workspaces(
    store: WorkspaceStore = Depends(get_workspace_store),
    user_id: str = Depends(get_user_id),
) -> dict[str, Any]:
    return {"success": True, "workspaces": store.list_workspaces(user_id)}


@router.post("/workspaces")
async def create_workspace(
    request: Request,
    store: WorkspaceStore = Depends(get_workspace_store),
    user_id: str = Depends(get_user_id),
) -> dict[str, Any]:
    payload = await request.json()
    workspace = store.create_workspace(
        owner_id=user_id,
        name=payload.get("name") or "新工作区",
        members=payload.get("members") or [],
    )
    return {"success": True, "workspace": workspace}


@router.get("/workspaces/{workspace_id}")
def get_workspace(
    workspace_id: str,
    store: WorkspaceStore = Depends(get_workspace_store),
    user_id: str = Depends(get_user_id),
) -> dict[str, Any]:
    try:
        return {"success": True, "workspace": store.get_workspace(workspace_id, user_id)}
    except PermissionError as exc:
        raise HTTPException(status_code=403, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.post("/workspaces/{workspace_id}/members")
async def upsert_member(
    workspace_id: str,
    request: Request,
    store: WorkspaceStore = Depends(get_workspace_store),
    user_id: str = Depends(get_user_id),
) -> dict[str, Any]:
    payload = await request.json()
    try:
        workspace = store.upsert_member(
            workspace_id=workspace_id,
            acting_user_id=user_id,
            member_user_id=payload.get("user_id") or payload.get("email"),
            role=payload.get("role") or "Developer",
            display_name=payload.get("display_name") or payload.get("name"),
        )
        return {"success": True, "workspace": workspace}
    except PermissionError as exc:
        raise HTTPException(status_code=403, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.delete("/workspaces/{workspace_id}/members/{member_user_id}")
def remove_member(
    workspace_id: str,
    member_user_id: str,
    store: WorkspaceStore = Depends(get_workspace_store),
    user_id: str = Depends(get_user_id),
) -> dict[str, Any]:
    try:
        workspace = store.remove_member(workspace_id=workspace_id, acting_user_id=user_id, member_user_id=member_user_id)
        return {"success": True, "workspace": workspace}
    except PermissionError as exc:
        raise HTTPException(status_code=403, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.post("/presence/heartbeat")
async def heartbeat(
    request: Request,
    store: WorkspaceStore = Depends(get_workspace_store),
    user: dict[str, Any] = Depends(get_current_user),
) -> dict[str, Any]:
    payload = await request.json() if request.headers.get("content-type", "").startswith("application/json") else {}
    workspace_id = payload.get("workspace_id") or request.headers.get("X-Workspace-Id") or user.get("default_workspace_id")
    try:
        presence = store.touch_presence(workspace_id=workspace_id, user=user)
        online = store.list_presence(workspace_id, user["user_id"])
        return {"success": True, "presence": presence, "online_users": online}
    except PermissionError as exc:
        raise HTTPException(status_code=403, detail=str(exc)) from exc


@router.get("/workspaces/{workspace_id}/presence")
def list_presence(
    workspace_id: str,
    store: WorkspaceStore = Depends(get_workspace_store),
    user_id: str = Depends(get_user_id),
) -> dict[str, Any]:
    try:
        return {"success": True, "online_users": store.list_presence(workspace_id, user_id)}
    except PermissionError as exc:
        raise HTTPException(status_code=403, detail=str(exc)) from exc
