from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, HTTPException

from backend.api.dependencies import get_run_history_store, require_workspace_view
from backend.services.run_history_store import RunHistoryStore

router = APIRouter(prefix="/runs")


@router.get("")
def list_runs(
    project_id: str | None = None,
    limit: int = 50,
    store: RunHistoryStore = Depends(get_run_history_store),
    workspace_id: str = Depends(require_workspace_view),
) -> dict[str, Any]:
    return {"success": True, "runs": store.list_runs(owner_id=workspace_id, project_id=project_id, limit=limit)}


@router.get("/{run_id}")
def get_run(
    run_id: str,
    store: RunHistoryStore = Depends(get_run_history_store),
    workspace_id: str = Depends(require_workspace_view),
) -> dict[str, Any]:
    try:
        return {"success": True, "run": store.get_run(owner_id=workspace_id, run_id=run_id)}
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
