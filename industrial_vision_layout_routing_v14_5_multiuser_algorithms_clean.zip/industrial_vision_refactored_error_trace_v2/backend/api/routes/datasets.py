from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Request

from backend.api.dependencies import get_dataset_store, require_workspace_edit, require_workspace_manage, require_workspace_view
from backend.services.dataset_store import DatasetStore

router = APIRouter(prefix="/datasets")


@router.get("")
def list_datasets(
    store: DatasetStore = Depends(get_dataset_store),
    workspace_id: str = Depends(require_workspace_view),
) -> dict[str, Any]:
    return {"success": True, "datasets": store.list_datasets(owner_id=workspace_id)}


@router.post("")
async def create_dataset(
    request: Request,
    store: DatasetStore = Depends(get_dataset_store),
    workspace_id: str = Depends(require_workspace_edit),
) -> dict[str, Any]:
    payload = await request.json()
    dataset = store.create_dataset(
        owner_id=workspace_id,
        name=payload.get("name") or "图像数据集",
        description=payload.get("description") or "",
        samples=payload.get("samples") or [],
        tags=payload.get("tags") or [],
    )
    return {"success": True, "dataset": dataset}


@router.get("/{dataset_id}")
def get_dataset(
    dataset_id: str,
    store: DatasetStore = Depends(get_dataset_store),
    workspace_id: str = Depends(require_workspace_view),
) -> dict[str, Any]:
    try:
        return {"success": True, "dataset": store.get_dataset(owner_id=workspace_id, dataset_id=dataset_id)}
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.put("/{dataset_id}")
async def update_dataset(
    dataset_id: str,
    request: Request,
    store: DatasetStore = Depends(get_dataset_store),
    workspace_id: str = Depends(require_workspace_edit),
) -> dict[str, Any]:
    payload = await request.json()
    try:
        return {"success": True, "dataset": store.update_dataset(owner_id=workspace_id, dataset_id=dataset_id, payload=payload)}
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.post("/{dataset_id}/samples")
async def add_samples(
    dataset_id: str,
    request: Request,
    store: DatasetStore = Depends(get_dataset_store),
    workspace_id: str = Depends(require_workspace_edit),
) -> dict[str, Any]:
    payload = await request.json()
    samples = payload.get("samples") or []
    try:
        return {"success": True, "dataset": store.add_samples(owner_id=workspace_id, dataset_id=dataset_id, samples=samples)}
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.delete("/{dataset_id}")
def delete_dataset(
    dataset_id: str,
    store: DatasetStore = Depends(get_dataset_store),
    workspace_id: str = Depends(require_workspace_manage),
) -> dict[str, Any]:
    try:
        return {"success": True, "dataset": store.delete_dataset(owner_id=workspace_id, dataset_id=dataset_id)}
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
