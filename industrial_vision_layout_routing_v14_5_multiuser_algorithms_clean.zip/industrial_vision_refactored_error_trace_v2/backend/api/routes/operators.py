from fastapi import APIRouter, Depends

from backend.algorithms.registry import FAILED_CUSTOM_PLUGINS, OPERATOR_CATALOG, OPERATOR_META
from backend.api.dependencies import require_workspace_view

router = APIRouter()


@router.get("/operators")
def list_operators(_workspace_id: str = Depends(require_workspace_view)) -> dict:
    return {"operators": OPERATOR_META, "catalog": OPERATOR_CATALOG, "plugin_errors": FAILED_CUSTOM_PLUGINS}
