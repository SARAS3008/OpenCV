# 图像处理算子模块拆分说明

`backend/algorithms/image_ops.py` 原来集中承载了所有图像处理算子。为了便于团队维护和后续扩展，当前版本已把运行实现拆分到 `backend/algorithms/image/` 包下，并保留 `image_ops.py` 作为兼容导出入口。

## 新目录结构

```text
backend/algorithms/image/
  __init__.py             统一导出图像处理算子
  common.py               图像输入辅助函数，例如 gray_input、bgr_input
  io.py                   ReadImage、BatchReadImages、SaveBatchResults、Display
  color.py                色彩/灰度/增强类算子
  filters.py              均值、高斯、中值、双边、锐化等滤波算子
  thresholding.py         固定阈值、Otsu、自适应阈值
  edges.py                Canny、Sobel、Laplacian 边缘算子
  morphology.py           腐蚀、膨胀、开闭运算、形态学梯度
  geometry.py             Resize、Flip、Rotate90 几何变换
  contours.py             FindContours 轮廓检测
  template_matching.py    ORB 模板匹配、ROI/Mask 映射
```

## 兼容性

旧代码仍然可以继续使用：

```python
from backend.algorithms.image_ops import op_threshold
```

新代码建议直接使用更清晰的模块路径：

```python
from backend.algorithms.image.thresholding import op_threshold
from backend.algorithms.image.template_matching import op_orb_feature_match
```

注册表 `backend/algorithms/registry.py` 已改为从 `backend.algorithms.image` 统一导入，外部 API、工作流 JSON、节点类型名称均不变。

## 后续新增算子建议

新增图像处理算子时，请优先放入对应领域文件：

- 新增滤波算法：放入 `filters.py`
- 新增阈值算法：放入 `thresholding.py`
- 新增形态学算法：放入 `morphology.py`
- 新增模板匹配/定位算法：放入 `template_matching.py`
- 新增几何变换：放入 `geometry.py`

如果某类算法持续变大，可以继续拆成子包，例如：

```text
backend/algorithms/image/template_matching/
  orb.py
  ncc.py
  shape_match.py
```

当前版本选择一层文件拆分，是为了在清晰度和迁移风险之间保持平衡。
