from __future__ import annotations

import time
from pathlib import Path

from fastapi.testclient import TestClient

from backend.main import app

client = TestClient(app)


def _register(prefix: str) -> tuple[dict, dict[str, str]]:
    stamp = f"{int(time.time() * 1000)}"
    email = f"{prefix}.{stamp}@example.com"
    response = client.post("/api/auth/register", json={"email": email, "password": "secret123", "display_name": prefix})
    assert response.status_code == 200, response.text
    payload = response.json()
    return payload["user"], {"Authorization": f"Bearer {payload['token']}"}


def test_workspace_project_permissions_and_presence() -> None:
    alice, alice_headers = _register("alice")
    bob, bob_headers = _register("bob")
    carol, carol_headers = _register("carol")

    workspace = client.post(
        "/api/workspaces",
        json={"name": "产线视觉团队", "members": [{"user_id": bob["user_id"], "role": "Developer"}]},
        headers=alice_headers,
    )
    assert workspace.status_code == 200, workspace.text
    workspace_id = workspace.json()["workspace"]["workspace_id"]
    alice_ws = {**alice_headers, "X-Workspace-Id": workspace_id}
    bob_ws = {**bob_headers, "X-Workspace-Id": workspace_id}
    carol_ws = {**carol_headers, "X-Workspace-Id": workspace_id}

    workflow = {"nodes": [], "edges": [], "modules": []}
    saved = client.post("/api/projects", json={"name": "团队共享流程", "workflow": workflow}, headers=alice_ws)
    assert saved.status_code == 200, saved.text
    project_id = saved.json()["project"]["project_id"]

    listed_for_bob = client.get("/api/projects", headers=bob_ws)
    assert listed_for_bob.status_code == 200, listed_for_bob.text
    assert any(item["project_id"] == project_id for item in listed_for_bob.json()["projects"])

    # Bob 是 Developer，可以查看/编辑，但不能管理删除。
    forbidden_delete = client.delete(f"/api/projects/{project_id}", headers=bob_ws)
    assert forbidden_delete.status_code == 403

    # Carol 不在工作区，不能通过伪造工作区头访问项目。
    forbidden_list = client.get("/api/projects", headers=carol_ws)
    assert forbidden_list.status_code == 403

    assert client.post("/api/presence/heartbeat", json={"workspace_id": workspace_id}, headers=alice_ws).status_code == 200
    assert client.post("/api/presence/heartbeat", json={"workspace_id": workspace_id}, headers=bob_ws).status_code == 200
    presence = client.get(f"/api/workspaces/{workspace_id}/presence", headers=alice_ws)
    assert presence.status_code == 200
    online_ids = {item["user_id"] for item in presence.json()["online_users"]}
    assert {alice["user_id"], bob["user_id"]}.issubset(online_ids)


def test_model_assets_are_scoped_to_workspace(tmp_path: Path) -> None:
    alice, alice_headers = _register("modelalice")
    bob, bob_headers = _register("modelbob")
    carol, carol_headers = _register("modelcarol")
    workspace = client.post(
        "/api/workspaces",
        json={"name": "模型资产工作区", "members": [{"user_id": bob["user_id"], "role": "Developer"}]},
        headers=alice_headers,
    ).json()["workspace"]
    workspace_id = workspace["workspace_id"]
    alice_ws = {**alice_headers, "X-Workspace-Id": workspace_id}
    bob_ws = {**bob_headers, "X-Workspace-Id": workspace_id}
    carol_ws = {**carol_headers, "X-Workspace-Id": workspace_id}

    path = tmp_path / "shared-detector.pt"
    path.write_bytes(b"fake")
    model = app.state.model_manager.register_upload(
        path=path,
        original_filename="shared-detector.pt",
        owner_id=alice["user_id"],
        workspace_id=workspace_id,
        size=4,
    )

    models_for_bob = client.get("/api/models", headers=bob_ws)
    assert models_for_bob.status_code == 200, models_for_bob.text
    assert any(item["model_id"] == model["model_id"] for item in models_for_bob.json()["models"])

    forbidden = client.get("/api/models", headers=carol_ws)
    assert forbidden.status_code == 403
