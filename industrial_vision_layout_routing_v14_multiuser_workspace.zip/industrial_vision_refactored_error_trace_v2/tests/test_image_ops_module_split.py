from __future__ import annotations

import numpy as np

from backend.algorithms.image import op_threshold as exported_threshold
from backend.algorithms.image.thresholding import op_threshold as module_threshold
from backend.algorithms.image_ops import op_threshold as legacy_threshold
from backend.algorithms.registry import OPERATORS


def test_image_operator_module_split_keeps_legacy_import_compatible():
    assert legacy_threshold is exported_threshold
    assert module_threshold is exported_threshold
    assert OPERATORS["Threshold"] is exported_threshold


def test_split_threshold_operator_still_runs():
    image = np.array([[0, 100, 200]], dtype=np.uint8)
    result = module_threshold({"in": image}, {"threshold": 127, "max_value": 255}, None)
    assert result["out"].tolist() == [[0, 0, 255]]
