from fastapi import FastAPI
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from backend.api.router import api_router
from backend.config import ALLOWED_IMAGE_EXTENSIONS, AUTH_DIR, DATASETS_DIR, FRONTEND_DIR, JOBS_DIR, PROJECTS_DIR, RUN_HISTORY_DIR, UPLOAD_DIR, WORKSPACES_DIR
from backend.algorithms.yolo.model_manager import DEFAULT_MODEL_MANAGER
from backend.services.image_store import ImageStore
from backend.services.project_store import ProjectStore
from backend.services.team_store import WorkspaceStore
from backend.services.dataset_store import DatasetStore
from backend.services.run_history_store import RunHistoryStore
from backend.services.job_queue import JobQueue
from backend.services.auth_store import AuthStore


def create_app() -> FastAPI:
    application = FastAPI(
        title="Industrial Vision Workflow",
        version="2.2.0",
    )
    application.state.auth_store = AuthStore(AUTH_DIR)
    application.state.image_store = ImageStore(
        upload_dir=UPLOAD_DIR,
        allowed_extensions=ALLOWED_IMAGE_EXTENSIONS,
    )
    application.state.model_manager = DEFAULT_MODEL_MANAGER
    application.state.project_store = ProjectStore(PROJECTS_DIR)
    application.state.workspace_store = WorkspaceStore(WORKSPACES_DIR)
    application.state.dataset_store = DatasetStore(DATASETS_DIR)
    application.state.run_history_store = RunHistoryStore(RUN_HISTORY_DIR)
    application.state.job_queue = JobQueue(max_workers=2)
    application.include_router(api_router, prefix="/api")
    application.mount(
        "/assets",
        StaticFiles(directory=FRONTEND_DIR / "assets"),
        name="assets",
    )

    @application.get("/", include_in_schema=False)
    def index() -> FileResponse:
        return FileResponse(FRONTEND_DIR / "index.html")

    return application


app = create_app()
