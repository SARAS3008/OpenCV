from __future__ import annotations

from fastapi import HTTPException, Request

from backend.algorithms.yolo.model_manager import YoloModelManager, safe_user_id
from backend.services.auth_store import AuthStore
from backend.services.dataset_store import DatasetStore
from backend.services.image_store import ImageStore
from backend.services.job_queue import JobQueue
from backend.services.project_store import ProjectStore
from backend.services.run_history_store import RunHistoryStore
from backend.services.team_store import WorkspaceStore


def _bearer_token(request: Request) -> str | None:
    auth = request.headers.get("Authorization") or ""
    if auth.lower().startswith("bearer "):
        return auth.split(" ", 1)[1].strip() or None
    return None


def get_auth_store(request: Request) -> AuthStore:
    return request.app.state.auth_store


def get_current_user(request: Request) -> dict:
    """返回当前用户。

    优先使用 Bearer token；为了兼容旧版本地工具，未登录时仍允许 X-User-Id / X-User-Email。
    """

    token = _bearer_token(request)
    if token:
        user = request.app.state.auth_store.get_user_by_token(token)
        if not user:
            raise HTTPException(status_code=401, detail="登录状态已失效，请重新登录")
        return user
    raw = request.headers.get("X-User-Id") or request.headers.get("X-User-Email") or "default"
    user_id = safe_user_id(raw)
    return {"user_id": user_id, "email": request.headers.get("X-User-Email") or "", "display_name": user_id, "default_workspace_id": f"ws_{user_id}"}


def get_user_id(request: Request) -> str:
    return safe_user_id(get_current_user(request).get("user_id"))


def get_active_workspace_id(request: Request) -> str:
    user = get_current_user(request)
    requested = request.headers.get("X-Workspace-Id") or request.query_params.get("workspace_id")
    return safe_user_id(requested or user.get("default_workspace_id") or f"ws_{user.get('user_id')}")


def require_workspace_view(request: Request) -> str:
    user_id = get_user_id(request)
    workspace_id = get_active_workspace_id(request)
    try:
        request.app.state.workspace_store.ensure_personal_workspace(user_id)
        request.app.state.workspace_store.require_permission(workspace_id, user_id, "view")
    except PermissionError as exc:
        raise HTTPException(status_code=403, detail=str(exc)) from exc
    return workspace_id


def require_workspace_edit(request: Request) -> str:
    return _require_workspace_permission(request, "edit")


def require_workspace_run(request: Request) -> str:
    return _require_workspace_permission(request, "run")


def require_workspace_model(request: Request) -> str:
    return _require_workspace_permission(request, "model")


def require_workspace_manage(request: Request) -> str:
    return _require_workspace_permission(request, "manage")


def _require_workspace_permission(request: Request, permission: str) -> str:
    user_id = get_user_id(request)
    workspace_id = get_active_workspace_id(request)
    try:
        request.app.state.workspace_store.ensure_personal_workspace(user_id)
        request.app.state.workspace_store.require_permission(workspace_id, user_id, permission)
    except PermissionError as exc:
        raise HTTPException(status_code=403, detail=str(exc)) from exc
    return workspace_id


def get_image_store(request: Request) -> ImageStore:
    return request.app.state.image_store


def get_model_manager(request: Request) -> YoloModelManager:
    return request.app.state.model_manager


def get_project_store(request: Request) -> ProjectStore:
    return request.app.state.project_store


def get_workspace_store(request: Request) -> WorkspaceStore:
    return request.app.state.workspace_store


def get_dataset_store(request: Request) -> DatasetStore:
    return request.app.state.dataset_store


def get_run_history_store(request: Request) -> RunHistoryStore:
    return request.app.state.run_history_store


def get_job_queue(request: Request) -> JobQueue:
    return request.app.state.job_queue
