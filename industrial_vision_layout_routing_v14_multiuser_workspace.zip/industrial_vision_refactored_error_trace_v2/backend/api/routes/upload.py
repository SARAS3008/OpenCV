from __future__ import annotations

import re
import uuid
from pathlib import Path

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile, status

from backend.api.dependencies import get_image_store, get_model_manager, get_user_id, require_workspace_model
from backend.config import (
    ALLOWED_MODEL_EXTENSIONS,
    MAX_MODEL_UPLOAD_BYTES,
    MAX_UPLOAD_BYTES,
    MODEL_DIR,
    PROJECT_ROOT,
)
from backend.algorithms.yolo.model_manager import YoloModelManager
from backend.services.image_store import ImageStore
from backend.services.workflow_engine import image_to_data_url

router = APIRouter()

_SAFE_NAME_RE = re.compile(r"[^0-9A-Za-z._\-\u4e00-\u9fff]+")


def _safe_filename(filename: str | None, fallback: str) -> str:
    name = Path(filename or fallback).name.strip() or fallback
    name = _SAFE_NAME_RE.sub("_", name)
    return name[:160] or fallback


def _relative_to_project(path: Path) -> str:
    try:
        return path.resolve().relative_to(PROJECT_ROOT.resolve()).as_posix()
    except ValueError:
        return str(path.resolve())


@router.post("/upload")
async def upload_image(
    file: UploadFile = File(...),
    image_store: ImageStore = Depends(get_image_store),
) -> dict:
    content = await file.read(MAX_UPLOAD_BYTES + 1)
    if len(content) > MAX_UPLOAD_BYTES:
        raise HTTPException(
            status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
            detail=f"图片不能超过 {MAX_UPLOAD_BYTES // (1024 * 1024)} MB",
        )
    if not content:
        raise HTTPException(status_code=400, detail="上传文件为空")

    try:
        stored = image_store.save(file.filename, content)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    return {
        "success": True,
        "image_id": stored.image_id,
        "filename": stored.original_filename,
        "preview": image_to_data_url(stored.image),
    }


@router.post("/upload-model")
async def upload_model(
    file: UploadFile = File(...),
    model_manager: YoloModelManager = Depends(get_model_manager),
    user_id: str = Depends(get_user_id),
    workspace_id: str = Depends(require_workspace_model),
) -> dict:
    """上传 YOLO/Ultralytics 可加载的模型文件，返回可写入节点参数的相对路径。"""

    original_filename = _safe_filename(file.filename, "model.pt")
    suffix = Path(original_filename).suffix.lower()
    if suffix not in ALLOWED_MODEL_EXTENSIONS:
        allowed = ", ".join(sorted(ALLOWED_MODEL_EXTENSIONS))
        raise HTTPException(status_code=400, detail=f"不支持的模型文件类型：{suffix or '无扩展名'}；允许：{allowed}")

    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    stored_name = f"{uuid.uuid4().hex}_{original_filename}"
    stored_path = (MODEL_DIR / stored_name).resolve()
    if stored_path.parent != MODEL_DIR.resolve():
        raise HTTPException(status_code=400, detail="模型文件名无效")

    total = 0
    try:
        with stored_path.open("wb") as output:
            while True:
                chunk = await file.read(1024 * 1024)
                if not chunk:
                    break
                total += len(chunk)
                if total > MAX_MODEL_UPLOAD_BYTES:
                    output.close()
                    stored_path.unlink(missing_ok=True)
                    raise HTTPException(
                        status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
                        detail=f"模型文件不能超过 {MAX_MODEL_UPLOAD_BYTES // (1024 * 1024)} MB",
                    )
                output.write(chunk)
    except HTTPException:
        raise
    except OSError as exc:
        stored_path.unlink(missing_ok=True)
        raise HTTPException(status_code=500, detail=f"模型文件保存失败：{exc}") from exc

    if total <= 0:
        stored_path.unlink(missing_ok=True)
        raise HTTPException(status_code=400, detail="上传文件为空")

    record = model_manager.register_upload(
        path=stored_path,
        original_filename=original_filename,
        owner_id=user_id,
        workspace_id=workspace_id,
        size=total,
    )
    return {
        "success": True,
        "model_id": record["model_id"],
        "model_path": record["path"],
        "filename": original_filename,
        "size": total,
        "owner_id": record["owner_id"],
        "workspace_id": record.get("workspace_id"),
    }
