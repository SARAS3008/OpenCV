from __future__ import annotations

import ast
from typing import Any

from fastapi import APIRouter
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field

from backend.algorithms.python_snippet_ops import _validate_code

router = APIRouter()


class PythonSnippetValidationRequest(BaseModel):
    code: str = Field(default="", max_length=200_000)


def _target_names(target: ast.expr) -> list[str]:
    if isinstance(target, ast.Name):
        return [target.id]
    if isinstance(target, (ast.Tuple, ast.List)):
        names: list[str] = []
        for item in target.elts:
            names.extend(_target_names(item))
        return names
    return []


def _analyze_code(code: str) -> dict[str, Any]:
    tree = ast.parse(code or "", mode="exec")
    assigned: set[str] = set()
    has_process = False
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef) and node.name == "process":
            has_process = True
        elif isinstance(node, ast.Assign):
            for target in node.targets:
                assigned.update(_target_names(target))
        elif isinstance(node, ast.AnnAssign):
            assigned.update(_target_names(node.target))
        elif isinstance(node, ast.AugAssign):
            assigned.update(_target_names(node.target))

    output_names = [name for name in ["out", "image", "value", "metrics", "data", "result"] if name in assigned]
    warnings: list[str] = []
    if not has_process and not output_names:
        warnings.append("代码没有定义 process()，也没有给 out/image/value/metrics/data/result 赋值，运行后可能没有有效输出。")
    if "metrics" in assigned and "data" not in assigned:
        warnings.append("metrics 会显示在节点预览里；如需把结构化结果传给后续节点，建议同时写入 data。")

    return {
        "line_count": len((code or "").splitlines()),
        "has_process": has_process,
        "assigned_outputs": output_names,
        "warnings": warnings,
    }


@router.post("/python-snippet/validate")
def validate_python_snippet(payload: PythonSnippetValidationRequest):
    code = payload.code or ""
    try:
        _validate_code(code)
        analysis = _analyze_code(code)
        return {"success": True, "valid": True, "analysis": analysis}
    except Exception as exc:
        return JSONResponse(
            status_code=400,
            content={
                "success": False,
                "valid": False,
                "error": str(exc),
                "cause_type": type(exc).__name__,
            },
        )
