from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import JSONResponse

from backend.api.dependencies import get_image_store, get_job_queue, get_model_manager, get_run_history_store, get_user_id, require_workspace_run, require_workspace_view
from backend.models.workflow import WorkflowRequest
from backend.services.image_store import ImageStore
from backend.algorithms.yolo.model_manager import YoloModelManager
from backend.services.job_queue import JobQueue
from backend.services.run_history_store import RunHistoryStore
from backend.services.workflow_engine import WorkflowExecutionError, run_workflow

router = APIRouter(prefix="/jobs")


@router.get("")
def list_jobs(
    queue: JobQueue = Depends(get_job_queue),
    workspace_id: str = Depends(require_workspace_view),
) -> dict[str, Any]:
    return {"success": True, "jobs": queue.list_jobs(owner_id=workspace_id)}


@router.get("/{job_id}")
def get_job(
    job_id: str,
    queue: JobQueue = Depends(get_job_queue),
    workspace_id: str = Depends(require_workspace_view),
) -> dict[str, Any]:
    try:
        return {"success": True, "job": queue.get(job_id, owner_id=workspace_id)}
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.post("/run")
async def submit_workflow_job(
    request: Request,
    queue: JobQueue = Depends(get_job_queue),
    history: RunHistoryStore = Depends(get_run_history_store),
    image_store: ImageStore = Depends(get_image_store),
    model_manager: YoloModelManager = Depends(get_model_manager),
    user_id: str = Depends(get_user_id),
    workspace_id: str = Depends(require_workspace_run),
) -> dict[str, Any]:
    payload = await request.json()
    workflow = WorkflowRequest.model_validate(payload.get("workflow") or payload)
    project_id = payload.get("project_id")
    version_id = payload.get("version_id")

    def run_task(progress):
        progress(0, 1, "工作流运行中")
        result = run_workflow(workflow, image_store, user_id=user_id, workspace_id=workspace_id, model_manager=model_manager)
        history.record_run(owner_id=workspace_id, workflow=workflow.model_dump(), result=result, project_id=project_id, version_id=version_id, kind="workflow-job")
        progress(1, 1, "工作流运行完成")
        return result

    try:
        return {"success": True, "job": queue.submit(owner_id=workspace_id, kind="workflow", fn=run_task)}
    except WorkflowExecutionError as exc:
        return JSONResponse(status_code=400, content=exc.to_response())
