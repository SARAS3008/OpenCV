from fastapi import APIRouter, Depends
from fastapi.responses import JSONResponse

from backend.api.dependencies import get_image_store, get_model_manager, get_run_history_store, get_user_id, require_workspace_run
from backend.algorithms.yolo.model_manager import YoloModelManager
from backend.models.workflow import WorkflowRequest
from backend.services.image_store import ImageStore
from backend.services.run_history_store import RunHistoryStore
from backend.services.workflow_engine import WorkflowExecutionError, run_workflow

router = APIRouter()


@router.post("/run")
def execute_workflow(
    workflow: WorkflowRequest,
    image_store: ImageStore = Depends(get_image_store),
    model_manager: YoloModelManager = Depends(get_model_manager),
    run_history: RunHistoryStore = Depends(get_run_history_store),
    user_id: str = Depends(get_user_id),
    workspace_id: str = Depends(require_workspace_run),
):
    try:
        result = run_workflow(workflow, image_store, user_id=user_id, workspace_id=workspace_id, model_manager=model_manager)
        run_history.record_run(owner_id=workspace_id, workflow=workflow.model_dump(), result=result, kind="workflow")
        return result
    except WorkflowExecutionError as exc:
        payload = exc.to_response()
        run_history.record_run(owner_id=workspace_id, workflow=workflow.model_dump(), result=payload, kind="workflow", status="failed", error=payload.get("error"))
        return JSONResponse(
            status_code=400,
            content=payload,
        )
    except (ValueError, KeyError, TypeError, OSError) as exc:
        payload = {"success": False, "error": str(exc)}
        run_history.record_run(owner_id=workspace_id, workflow=workflow.model_dump(), result=payload, kind="workflow", status="failed", error=str(exc))
        return JSONResponse(
            status_code=400,
            content=payload,
        )
    except Exception as exc:  # 最后的 JSON 兜底，避免浏览器只收到不可解析的 500 页面。
        payload = {
            "success": False,
            "error": f"服务端未处理异常：{type(exc).__name__}: {exc}",
        }
        run_history.record_run(owner_id=workspace_id, workflow=workflow.model_dump(), result=payload, kind="workflow", status="failed", error=payload["error"])
        return JSONResponse(
            status_code=500,
            content=payload,
        )
