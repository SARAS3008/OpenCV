from __future__ import annotations

import base64
import csv
import json
from collections import defaultdict, deque
from pathlib import Path
from typing import Any

import cv2
import numpy as np

from backend.algorithms.registry import OPERATORS, OPERATOR_META
from backend.algorithms.types import ExecutionContext
from backend.models.workflow import WorkflowEdge, WorkflowNode, WorkflowRequest
from backend.services.image_store import ImageStore
from backend.algorithms.yolo.model_manager import YoloModelManager


class WorkflowExecutionError(ValueError):
    """工作流节点执行失败，并携带已经完成的执行现场。"""

    def __init__(
        self,
        message: str,
        *,
        node_id: str,
        node_type: str,
        node_label: str,
        order: list[str],
        executed_order: list[str],
        previews: list[dict[str, Any]],
        cause_type: str = "",
    ) -> None:
        super().__init__(message)
        self.node_id = node_id
        self.node_type = node_type
        self.node_label = node_label
        self.order = list(order)
        self.executed_order = list(executed_order)
        self.previews = list(previews)
        self.cause_type = cause_type

    @property
    def pending_nodes(self) -> list[str]:
        completed = set(self.executed_order)
        completed.add(self.node_id)
        return [node_id for node_id in self.order if node_id not in completed]

    def to_response(self) -> dict[str, Any]:
        failed_preview = {
            "node_id": self.node_id,
            "type": self.node_type,
            "label": self.node_label,
            "result_type": "error",
            "status": "error",
            "error": str(self),
            "metrics": {},
            "data": {},
        }
        return {
            "success": False,
            "error": str(self),
            "mode": "single",
            "stage": "node_execution",
            "order": self.order,
            "executed_order": self.executed_order,
            "pending_nodes": self.pending_nodes,
            "previews": [*self.previews, failed_preview],
            "failed_node": {
                "node_id": self.node_id,
                "type": self.node_type,
                "label": self.node_label,
                "error": str(self),
                "cause_type": self.cause_type,
            },
        }


def image_to_data_url(image: np.ndarray, color_space: str = "BGR") -> str:
    if image is None:
        return ""
    if image.dtype != np.uint8:
        image = np.clip(image, 0, 255).astype(np.uint8)
    encode_image = image
    if image.ndim == 3 and str(color_space).upper() == "RGB":
        encode_image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
    ok, buffer = cv2.imencode(".png", encode_image)
    if not ok:
        raise ValueError("图像编码失败")
    encoded = base64.b64encode(buffer).decode("utf-8")
    return f"data:image/png;base64,{encoded}"




def _json_safe_value(value: Any, path: str = "result") -> Any:
    """把节点结果限制为可安全返回给浏览器的 JSON 数据。

    图像数组只能通过算子的图像输出端口传递，不能混入 metrics/data。
    这样可在具体节点执行阶段抛出错误，并保留此前节点的预览，而不是
    等 FastAPI 序列化整个响应时才产生无法定位的 HTTP 500。
    """

    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, np.ndarray):
        raise ValueError(
            f"{path} 包含图像/数组数据，不能作为数值结果返回；"
            "请把图像放在 out 输出端口，把统计值放在 metrics 或独立数值输出端口"
        )
    if isinstance(value, Path):
        return str(value)
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, dict):
        return {
            str(key): _json_safe_value(child, f"{path}.{key}")
            for key, child in value.items()
        }
    if isinstance(value, (list, tuple, set)):
        return [
            _json_safe_value(child, f"{path}[{index}]")
            for index, child in enumerate(value)
        ]
    raise ValueError(f"{path} 包含无法序列化的结果类型：{type(value).__name__}")


def topological_sort(nodes: list[WorkflowNode], edges: list[WorkflowEdge]) -> list[str]:
    node_ids = [node.id for node in nodes]
    if len(node_ids) != len(set(node_ids)):
        raise ValueError("节点 ID 不能重复")

    node_set = set(node_ids)
    indegree = {node_id: 0 for node_id in node_ids}
    graph: dict[str, list[str]] = {node_id: [] for node_id in node_ids}

    for edge in edges:
        if edge.source not in node_set or edge.target not in node_set:
            raise ValueError("存在无效连线：source 或 target 节点不存在")
        graph[edge.source].append(edge.target)
        indegree[edge.target] += 1

    queue = deque(node_id for node_id in node_ids if indegree[node_id] == 0)
    order: list[str] = []
    while queue:
        node_id = queue.popleft()
        order.append(node_id)
        for target_id in graph[node_id]:
            indegree[target_id] -= 1
            if indegree[target_id] == 0:
                queue.append(target_id)

    if len(order) != len(node_ids):
        raise ValueError("流程中存在环，请检查节点连线")
    return order


def _merge_data(target: dict[str, Any], source: Any) -> None:
    if not isinstance(source, dict):
        return
    for key, value in source.items():
        target[key] = value


def _prepare_graph(workflow: WorkflowRequest):
    order = topological_sort(workflow.nodes, workflow.edges)
    nodes = {node.id: node for node in workflow.nodes}
    incoming: dict[str, list[WorkflowEdge]] = defaultdict(list)
    outgoing: dict[str, list[WorkflowEdge]] = defaultdict(list)
    for edge in workflow.edges:
        incoming[edge.target].append(edge)
        outgoing[edge.source].append(edge)
    return order, nodes, incoming, outgoing


def _truthy(value: Any) -> bool:
    if isinstance(value, str):
        normalized = value.strip().lower()
        if normalized in {"", "0", "false", "no", "off", "否", "假"}:
            return False
        if normalized in {"1", "true", "yes", "on", "是", "真"}:
            return True
    return bool(value)


def _execute_once(
    workflow: WorkflowRequest,
    image_store: ImageStore,
    context: ExecutionContext,
    *,
    collect_previews: bool,
) -> tuple[list[str], dict[str, dict[str, Any]], list[dict[str, Any]]]:
    order, nodes, incoming, outgoing = _prepare_graph(workflow)
    outputs: dict[str, dict[str, Any]] = {}
    previews: list[dict[str, Any]] = []
    executed_order: list[str] = []
    executing: set[str] = set()
    order_index = {node_id: index for index, node_id in enumerate(order)}

    def edge_handle(edge: WorkflowEdge) -> str:
        return edge.targetHandle or "in"

    def sorted_edges(edge_list: list[WorkflowEdge]) -> list[WorkflowEdge]:
        return sorted(edge_list, key=lambda item: order_index.get(item.source, 10**9))

    def collect_static_ancestors(node_id: str, target: set[str]) -> None:
        if node_id in target:
            return
        target.add(node_id)
        # LogicIfElse 的 true/false 分支是运行期根据 condition 决定的，不能静态展开两个分支。
        if nodes[node_id].type == "LogicIfElse":
            return
        for edge in sorted_edges(incoming[node_id]):
            collect_static_ancestors(edge.source, target)

    def execute_static_prerequisites(input_edges: list[WorkflowEdge]) -> None:
        required: set[str] = set()
        for edge in input_edges:
            collect_static_ancestors(edge.source, required)
        for candidate_id in order:
            if candidate_id in required:
                execute_node(candidate_id)

    def output_value(edge: WorkflowEdge) -> Any:
        source_output = outputs[edge.source]
        source_handle = edge.sourceHandle or "out"
        if source_handle not in source_output:
            raise ValueError(f"上游节点 {edge.source} 不存在输出端口：{source_handle}")
        return source_output[source_handle]

    def run_current_node(node_id: str, input_edges: list[WorkflowEdge], selected_if_handle: str | None = None) -> None:
        node = nodes[node_id]
        metadata = OPERATOR_META.get(node.type, {})
        node_label = str(metadata.get("label", node.type))
        operator = OPERATORS.get(node.type)
        if operator is None:
            raise ValueError(f"未知算子或尚未实现：{node.type}")

        inputs: dict[str, Any] = {}
        inherited_data: dict[str, Any] = {}
        for edge in input_edges:
            if edge.source not in outputs:
                raise ValueError(f"上游节点 {edge.source} 尚未执行")
            source_output = outputs[edge.source]
            source_handle = edge.sourceHandle or "out"
            if source_handle not in source_output:
                raise ValueError(f"上游节点 {edge.source} 不存在输出端口：{source_handle}")
            target_handle = edge.targetHandle or "in"
            inputs[target_handle] = source_output[source_handle]
            source_color_key = f"{source_handle}_color_space"
            if source_color_key in source_output:
                inputs[f"{target_handle}_color_space"] = source_output[source_color_key]
            source_data = source_output.get("data")
            if isinstance(source_data, dict):
                inputs[f"{target_handle}_data"] = source_data
            _merge_data(inherited_data, source_data)

        configured_inputs = metadata.get("inputs")
        if node.type == "LogicIfElse" and selected_if_handle:
            required_handles = ["condition", selected_if_handle]
            missing_handles = [handle for handle in required_handles if handle not in inputs]
            if missing_handles:
                missing_text = "、".join(missing_handles)
                raise ValueError(f"缺少输入端口：{missing_text}")
        elif isinstance(configured_inputs, list):
            required_handles = [
                str(port.get("handle", "in"))
                for port in configured_inputs
                if port.get("required", True)
            ]
            missing_handles = [handle for handle in required_handles if handle not in inputs]
            if missing_handles:
                missing_text = "、".join(missing_handles)
                raise ValueError(f"缺少输入端口：{missing_text}")
            if not configured_inputs and input_edges:
                raise ValueError("输入节点不应存在输入连线")
        else:
            if metadata.get("has_input", True) and "in" not in inputs:
                raise ValueError("缺少输入连线")
            if not metadata.get("has_input", True) and input_edges:
                raise ValueError("输入节点不应存在输入连线")

        result = operator(inputs, node.params, context)
        if not isinstance(result, dict):
            raise ValueError("算子返回值必须是字典")

        out_image = result.get("out")
        if isinstance(out_image, np.ndarray) and "out_color_space" not in result:
            result["out_color_space"] = "GRAY" if out_image.ndim == 2 else inputs.get("in_color_space", "BGR")

        explicit_data = result.get("data")
        if explicit_data is not None:
            if not isinstance(explicit_data, dict):
                raise ValueError("data 必须是字典")
            explicit_data = _json_safe_value(explicit_data, f"节点 {node_id}.data")
        _merge_data(inherited_data, explicit_data)
        metrics = result.pop("metrics", None)
        own_metrics: dict[str, Any] = {}
        if metrics is not None:
            if not isinstance(metrics, dict):
                raise ValueError("metrics 必须是字典")
            own_metrics = _json_safe_value(metrics, f"节点 {node_id}.metrics")
            data_key = f"{node_id}_{node_label}"
            inherited_data[data_key] = own_metrics
        if inherited_data:
            result["data"] = _json_safe_value(
                inherited_data, f"节点 {node_id}.data"
            )

        outputs[node_id] = result
        if collect_previews and (isinstance(out_image, np.ndarray) or own_metrics):
            configured_result_type = str(metadata.get("result_type", "")).strip().lower()
            if configured_result_type == "metrics" and own_metrics:
                result_type = "metrics"
            elif isinstance(out_image, np.ndarray):
                result_type = "image"
            else:
                result_type = "metrics"

            preview: dict[str, Any] = {
                "node_id": node_id,
                "type": node.type,
                "label": node_label,
                "result_type": result_type,
                "status": "success",
                "metrics": own_metrics,
                "data": result.get("data", {}),
            }
            if result_type == "image" and isinstance(out_image, np.ndarray):
                preview["image"] = image_to_data_url(
                    out_image, result.get("out_color_space", "BGR")
                )
            previews.append(preview)

        executed_order.append(node_id)

    def execute_node(node_id: str) -> None:
        if node_id in outputs:
            return
        if node_id in executing:
            raise ValueError("流程中存在递归执行，请检查节点连线")
        if node_id not in nodes:
            raise ValueError(f"节点不存在：{node_id}")

        node = nodes[node_id]
        metadata = OPERATOR_META.get(node.type, {})
        node_label = str(metadata.get("label", node.type))
        executing.add(node_id)
        try:
            if node.type == "LogicIfElse":
                by_handle: dict[str, list[WorkflowEdge]] = defaultdict(list)
                for edge in incoming[node_id]:
                    by_handle[edge_handle(edge)].append(edge)
                condition_edges = by_handle.get("condition", [])
                if len(condition_edges) != 1:
                    raise ValueError("If/Else 节点必须连接且只能连接一个 condition 输入")
                condition_edge = condition_edges[0]
                execute_node(condition_edge.source)
                condition = _truthy(output_value(condition_edge))
                selected_handle = "true_value" if condition else "false_value"
                selected_edges = by_handle.get(selected_handle, [])
                if len(selected_edges) != 1:
                    raise ValueError(f"If/Else 条件为 {condition}，但缺少 {selected_handle} 输入")
                selected_edge = selected_edges[0]
                execute_node(selected_edge.source)
                run_current_node(node_id, [condition_edge, selected_edge], selected_handle)
            else:
                input_edges = sorted_edges(incoming[node_id])
                execute_static_prerequisites(input_edges)
                run_current_node(node_id, input_edges)
        except WorkflowExecutionError:
            raise
        except Exception as exc:
            raise WorkflowExecutionError(
                f"节点 {node_id}（{node_label} / {node.type}）执行失败：{exc}",
                node_id=node_id,
                node_type=node.type,
                node_label=node_label,
                order=order,
                executed_order=executed_order,
                previews=previews,
                cause_type=type(exc).__name__,
            ) from exc
        finally:
            executing.discard(node_id)

    sink_ids = [node_id for node_id in order if not outgoing[node_id]] or order
    for node_id in sink_ids:
        execute_node(node_id)

    return order, outputs, previews


def _yes(value: Any, default: bool = False) -> bool:
    if value is None:
        return default
    return str(value).strip().upper() in {"1", "TRUE", "YES", "Y", "是", "ON"}


def _integer(value: Any, default: int = 0) -> int:
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return default


def _parse_extensions(value: Any, defaults: set[str]) -> set[str]:
    text = str(value or "").strip()
    if not text:
        return set(defaults)
    extensions: set[str] = set()
    for item in text.replace(";", ",").split(","):
        suffix = item.strip().lower()
        if not suffix:
            continue
        extensions.add(suffix if suffix.startswith(".") else f".{suffix}")
    return extensions or set(defaults)


def _flatten_metrics(data: dict[str, Any]) -> dict[str, Any]:
    flat: dict[str, Any] = {}

    def visit(prefix: str, value: Any) -> None:
        if isinstance(value, dict):
            for key, child in value.items():
                visit(f"{prefix}.{key}" if prefix else str(key), child)
        elif isinstance(value, (list, tuple, set)):
            flat[prefix] = json.dumps(list(value), ensure_ascii=False)
        elif value is None or isinstance(value, (str, int, float, bool)):
            flat[prefix] = value
        else:
            flat[prefix] = json.dumps(value, ensure_ascii=False, default=str)

    visit("", data)
    return {key: value for key, value in flat.items() if key}


def _safe_csv_name(value: Any) -> str:
    name = Path(str(value or "results.csv").strip()).name
    if not name.lower().endswith(".csv"):
        name += ".csv"
    return name


def _output_suffix(source_path: Path, format_name: str) -> str:
    normalized = str(format_name or "SOURCE").upper()
    if normalized == "PNG":
        return ".png"
    if normalized == "JPG":
        return ".jpg"
    if normalized == "WEBP":
        return ".webp"
    return source_path.suffix.lower() or ".png"


def _save_result_image(path: Path, image: np.ndarray, color_space: str) -> None:
    encode_image = image
    if image.ndim == 3 and str(color_space).upper() == "RGB":
        encode_image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
    path.parent.mkdir(parents=True, exist_ok=True)
    ok, buffer = cv2.imencode(path.suffix or ".png", encode_image)
    if not ok:
        raise ValueError(f"无法编码结果图：{path}")
    try:
        buffer.tofile(str(path))
    except OSError as exc:
        raise ValueError(f"无法保存结果图：{path}") from exc


def _write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    base_fields = [
        "source_path",
        "source_name",
        "relative_path",
        "output_path",
        "status",
        "error",
    ]
    metric_fields = sorted({key for row in rows for key in row if key not in base_fields})
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8-sig") as stream:
        writer = csv.DictWriter(stream, fieldnames=base_fields + metric_fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def _validate_batch_workflow(workflow: WorkflowRequest):
    batch_inputs = [node for node in workflow.nodes if node.type == "BatchReadImages"]
    savers = [node for node in workflow.nodes if node.type == "SaveBatchResults"]
    single_inputs = [node for node in workflow.nodes if node.type == "ReadImage"]
    if len(batch_inputs) != 1:
        raise ValueError("批量流程必须且只能包含一个“批量读取图片”节点")
    if single_inputs:
        raise ValueError("批量流程不能同时包含“读取图像”节点")
    if len(savers) != 1:
        raise ValueError("批量流程必须且只能包含一个“保存批量结果”节点")

    order, nodes, incoming, outgoing = _prepare_graph(workflow)
    batch_node = batch_inputs[0]
    saver = savers[0]
    if incoming[batch_node.id]:
        raise ValueError("批量读取图片节点不能有上游连线")
    if len(incoming[saver.id]) != 1:
        raise ValueError("保存批量结果节点必须连接且只能连接一个上游图像节点")
    if outgoing[saver.id]:
        raise ValueError("保存批量结果节点必须是工作流末端节点")
    return order, nodes, batch_node, saver


def run_batch_workflow(workflow: WorkflowRequest, image_store: ImageStore, *, user_id: str = "default", workspace_id: str | None = None, model_manager: YoloModelManager | None = None) -> dict[str, Any]:
    order, nodes, batch_node, saver = _validate_batch_workflow(workflow)
    input_params = batch_node.params
    save_params = saver.params

    source_root = image_store.resolve_directory(str(input_params.get("folder_path") or ""))
    if source_root is None:
        raise ValueError(f"批量图片文件夹不存在或不可访问：{input_params.get('folder_path', '')}")

    extensions = _parse_extensions(input_params.get("extensions"), image_store.allowed_extensions)
    images = image_store.list_images(
        source_root,
        extensions=extensions,
        recursive=_yes(input_params.get("recursive"), True),
        limit=max(0, _integer(input_params.get("max_images"), 0)),
    )
    if not images:
        raise ValueError(f"文件夹中没有找到符合扩展名的图片：{source_root}")

    output_dir = image_store.prepare_output_directory(str(save_params.get("output_dir") or "batch_outputs"))
    save_images = _yes(save_params.get("save_images"), True)
    preserve_structure = _yes(save_params.get("preserve_structure"), True)
    continue_on_error = _yes(input_params.get("continue_on_error"), True)
    write_csv = _yes(save_params.get("write_csv"), True)
    filename_suffix = str(save_params.get("filename_suffix") or "")
    image_format = str(save_params.get("image_format") or "SOURCE")

    rows: list[dict[str, Any]] = []
    succeeded = 0
    failed = 0
    last_success_path: Path | None = None

    for index, source_path in enumerate(images, start=1):
        relative = source_path.relative_to(source_root)
        row: dict[str, Any] = {
            "source_path": str(source_path),
            "source_name": source_path.name,
            "relative_path": str(relative),
            "output_path": "",
            "status": "success",
            "error": "",
        }
        try:
            context = ExecutionContext(
                image_id=None,
                image_store=image_store,
                current_image_path=source_path,
                source_root=source_root,
                batch_index=index,
                batch_total=len(images),
                user_id=user_id,
                workspace_id=workspace_id or user_id,
                model_manager=model_manager,
            )
            _, outputs, _ = _execute_once(workflow, image_store, context, collect_previews=False)
            result = outputs[saver.id]
            result_image = result.get("out")
            if not isinstance(result_image, np.ndarray):
                raise ValueError("保存批量结果节点没有收到有效图像")

            if save_images:
                result_suffix = _output_suffix(source_path, image_format)
                relative_parent = relative.parent if preserve_structure else Path()
                destination = output_dir / relative_parent / f"{source_path.stem}{filename_suffix}{result_suffix}"
                if not preserve_structure and destination.exists():
                    destination = output_dir / f"{source_path.stem}{filename_suffix}_{index:05d}{result_suffix}"
                _save_result_image(destination, result_image, str(result.get("out_color_space", "BGR")))
                row["output_path"] = str(destination)

            row.update(_flatten_metrics(result.get("data", {})))
            succeeded += 1
            last_success_path = source_path
        except Exception as exc:  # 每张图片独立记录错误，便于批量排查。
            failed += 1
            row["status"] = "error"
            row["error"] = str(exc)
            if not continue_on_error:
                rows.append(row)
                if write_csv:
                    _write_csv(output_dir / _safe_csv_name(save_params.get("csv_filename")), rows)
                raise ValueError(f"处理图片失败：{source_path}：{exc}") from exc
        rows.append(row)

    csv_path: Path | None = None
    if write_csv:
        csv_path = output_dir / _safe_csv_name(save_params.get("csv_filename"))
        _write_csv(csv_path, rows)

    previews: list[dict[str, Any]] = []
    if last_success_path is not None:
        preview_context = ExecutionContext(
            image_id=None,
            image_store=image_store,
            current_image_path=last_success_path,
            source_root=source_root,
            batch_index=succeeded + failed,
            batch_total=len(images),
            user_id=user_id,
            workspace_id=workspace_id or user_id,
            model_manager=model_manager,
        )
        _, _, previews = _execute_once(workflow, image_store, preview_context, collect_previews=True)

    return {
        "success": True,
        "mode": "batch",
        "order": order,
        "previews": previews,
        "batch": {
            "source_dir": str(source_root),
            "output_dir": str(output_dir),
            "csv_path": str(csv_path) if csv_path else "",
            "total": len(images),
            "succeeded": succeeded,
            "failed": failed,
            "rows": rows[:100],
            "rows_truncated": len(rows) > 100,
        },
    }


def run_workflow(workflow: WorkflowRequest, image_store: ImageStore, *, user_id: str = "default", workspace_id: str | None = None, model_manager: YoloModelManager | None = None) -> dict[str, Any]:
    if not workflow.nodes:
        raise ValueError("流程为空，请先添加节点")

    has_batch_input = any(node.type == "BatchReadImages" for node in workflow.nodes)
    has_batch_saver = any(node.type == "SaveBatchResults" for node in workflow.nodes)
    if has_batch_input or has_batch_saver:
        return run_batch_workflow(workflow, image_store, user_id=user_id, workspace_id=workspace_id, model_manager=model_manager)

    context = ExecutionContext(image_id=workflow.image_id, image_store=image_store, user_id=user_id, workspace_id=workspace_id or user_id, model_manager=model_manager)
    order, outputs, previews = _execute_once(workflow, image_store, context, collect_previews=True)
    sink_data: dict[str, Any] = {}
    outgoing_ids = {edge.source for edge in workflow.edges}
    for node_id, result in outputs.items():
        if node_id not in outgoing_ids and result.get("data"):
            sink_data[node_id] = result["data"]
    return {
        "success": True,
        "mode": "single",
        "previews": previews,
        "order": order,
        "data": sink_data,
    }
