(() => {
  const state = {
    user:null,
    workspaces:[],
    heartbeatTimer:null,
  };

  function el(id){ return document.getElementById(id); }
  function displayName(user){ return user?.display_name || user?.email || user?.user_id || "未登录"; }

  function activeWorkspaceId(){ return VisionApi.getActiveWorkspaceId(); }

  function setAuthMessage(message, ok = false){
    const node = el("authMessage");
    if(!node) return;
    node.textContent = message || "";
    node.classList.toggle("ok", Boolean(ok));
  }

  function openAuthDialog(){
    const dialog = el("authDialog");
    if(!dialog) return;
    dialog.classList.add("open");
    dialog.setAttribute("aria-hidden", "false");
    setAuthMessage("");
    setTimeout(() => el("authEmail")?.focus(), 30);
  }

  function closeAuthDialog(){
    const dialog = el("authDialog");
    if(!dialog) return;
    dialog.classList.remove("open");
    dialog.setAttribute("aria-hidden", "true");
  }

  async function submitAuthLogin(){
    try{
      setAuthMessage("登录中...");
      await VisionApi.login({ email:el("authEmail")?.value || "", password:el("authPassword")?.value || "" });
      closeAuthDialog();
      await refreshIdentity(true);
      if(typeof toast === "function") toast("登录成功", displayName(state.user), true);
    }catch(error){
      setAuthMessage(error.message || String(error));
    }
  }

  async function submitAuthRegister(){
    try{
      setAuthMessage("注册中...");
      await VisionApi.register({
        email:el("authEmail")?.value || "",
        password:el("authPassword")?.value || "",
        display_name:el("authDisplayName")?.value || "",
      });
      closeAuthDialog();
      await refreshIdentity(true);
      if(typeof toast === "function") toast("注册并登录成功", displayName(state.user), true);
    }catch(error){
      setAuthMessage(error.message || String(error));
    }
  }

  async function logoutCurrentUser(){
    await VisionApi.logout();
    state.user = null;
    state.workspaces = [];
    VisionApi.setActiveWorkspaceId("");
    stopHeartbeat();
    await refreshIdentity(true);
    if(typeof toast === "function") toast("已退出登录", "当前使用本地默认身份", true);
  }

  async function refreshIdentity(forceWorkspace = false){
    try{
      const me = await VisionApi.getMe();
      state.user = me.user;
      const workspacePayload = await VisionApi.listWorkspaces();
      state.workspaces = workspacePayload.workspaces || [];
      let ws = activeWorkspaceId();
      if(forceWorkspace || !ws || !state.workspaces.some(item => item.workspace_id === ws)){
        ws = state.user?.default_workspace_id || state.workspaces[0]?.workspace_id || "";
        if(ws) VisionApi.setActiveWorkspaceId(ws);
      }
      renderAccountBar();
      startHeartbeat();
    }catch(error){
      console.warn("用户/工作区状态初始化失败", error);
      renderAccountBar();
    }
  }

  function renderAccountBar(){
    const loginButton = el("loginButton");
    const logoutButton = el("logoutButton");
    const workspaceSelect = el("workspaceSelect");
    const online = el("onlineUsers");
    const loggedIn = Boolean(VisionApi.getAuthToken());
    if(loginButton){
      loginButton.textContent = loggedIn && state.user ? displayName(state.user) : "登录";
      loginButton.title = loggedIn && state.user ? `${displayName(state.user)} · ${state.user.email || state.user.user_id}` : "登录 / 注册";
    }
    if(logoutButton) logoutButton.style.display = loggedIn ? "inline-flex" : "none";
    if(workspaceSelect){
      workspaceSelect.innerHTML = "";
      const workspaces = state.workspaces.length ? state.workspaces : [{ workspace_id:VisionApi.getActiveWorkspaceId() || "ws_default", name:"默认工作区", role:"Owner" }];
      for(const workspace of workspaces){
        const option = document.createElement("option");
        option.value = workspace.workspace_id;
        option.textContent = `${workspace.name || workspace.workspace_id}${workspace.role ? ` · ${workspace.role}` : ""}`;
        workspaceSelect.appendChild(option);
      }
      workspaceSelect.value = VisionApi.getActiveWorkspaceId() || workspaces[0]?.workspace_id || "";
      workspaceSelect.onchange = () => {
        VisionApi.setActiveWorkspaceId(workspaceSelect.value);
        renderAccountBar();
        refreshOnlineUsers();
        if(typeof toast === "function") toast("已切换工作区", workspaceSelect.options[workspaceSelect.selectedIndex]?.textContent || workspaceSelect.value, true);
      };
    }
    if(online && !online.dataset.loaded) online.textContent = "在线：-";
  }

  async function createWorkspaceFromUi(){
    const name = window.prompt("请输入新工作区名称", "视觉开发工作区");
    if(!name) return;
    try{
      const data = await VisionApi.createWorkspace({ name });
      VisionApi.setActiveWorkspaceId(data.workspace.workspace_id);
      await refreshIdentity(false);
      if(typeof toast === "function") toast("工作区已创建", data.workspace.name, true);
    }catch(error){
      if(typeof toast === "function") toast("创建工作区失败", error.message || String(error));
      else alert(error.message || String(error));
    }
  }

  async function showInviteMemberDialog(){
    const workspaceId = activeWorkspaceId();
    if(!workspaceId){ alert("请先选择工作区"); return; }
    const userId = window.prompt("输入成员邮箱或用户ID", "");
    if(!userId) return;
    const role = window.prompt("输入角色：Maintainer / Developer / Reviewer / Viewer / Operator", "Developer") || "Developer";
    try{
      await VisionApi.addWorkspaceMember(workspaceId, { user_id:userId, role });
      await refreshIdentity(false);
      if(typeof toast === "function") toast("成员已加入工作区", `${userId} · ${role}`, true);
    }catch(error){
      if(typeof toast === "function") toast("邀请成员失败", error.message || String(error));
      else alert(error.message || String(error));
    }
  }

  function startHeartbeat(){
    stopHeartbeat();
    refreshOnlineUsers();
    state.heartbeatTimer = window.setInterval(refreshOnlineUsers, 10000);
  }
  function stopHeartbeat(){
    if(state.heartbeatTimer){
      window.clearInterval(state.heartbeatTimer);
      state.heartbeatTimer = null;
    }
  }

  async function refreshOnlineUsers(){
    const workspaceId = activeWorkspaceId();
    const online = el("onlineUsers");
    if(!workspaceId || !online) return;
    try{
      const data = await VisionApi.heartbeat(workspaceId);
      const users = data.online_users || [];
      online.dataset.loaded = "1";
      online.textContent = `在线：${users.length}`;
      online.title = users.length ? users.map(item => item.display_name || item.user_id).join("、") : "当前工作区暂无在线用户";
    }catch(error){
      online.textContent = "在线：?";
      online.title = error.message || String(error);
    }
  }

  window.openAuthDialog = openAuthDialog;
  window.closeAuthDialog = closeAuthDialog;
  window.submitAuthLogin = submitAuthLogin;
  window.submitAuthRegister = submitAuthRegister;
  window.logoutCurrentUser = logoutCurrentUser;
  window.createWorkspaceFromUi = createWorkspaceFromUi;
  window.showInviteMemberDialog = showInviteMemberDialog;
  window.refreshWorkspaceIdentity = refreshIdentity;
  window.refreshOnlineUsers = refreshOnlineUsers;

  document.addEventListener("DOMContentLoaded", () => refreshIdentity(false));
})();
